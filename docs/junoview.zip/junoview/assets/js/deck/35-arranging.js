/* 35-arranging.js — stacking, arranging, aligning and distributing.
   ONE FRAGMENT of deck.js's single IIFE, concatenated with its
   siblings in filename order by assets.deck_js(). It does not
   parse alone and is not meant to: see 00-page.js. */
  /* ---- STACKING ORDER -------------------------------------------------
     There is no z property: order in s.annots IS the order on the page,
     so every one of these is an array move. It used to act on selAnnot
     alone, so bringing a GROUP to the front brought one member of it and
     left the rest behind (2026-08-20).
     `step` moves one place instead of all the way, which is what you
     actually want when three things overlap - the user asked for "the
     bring to forewards send to back" and Word/PowerPoint give you both
     pairs. */
  function zReorder(front,step){
    var s=pres.slides[cur];
    if(!s||!s.annots) return;
    var idxs=selIdxs();
    if(!idxs.length) return;
    idxs=idxs.slice().sort(function(a,b){return a-b;});
    var n=s.annots.length;
    /* already as far as it goes: say so rather than silently doing
       nothing, which reads as a broken button */
    var atEnd=front
      ?idxs[0]===n-idxs.length
      :idxs[idxs.length-1]===idxs.length-1;
    /* T487: the comment above promised the words and the code returned
       bare (2026-09-15 review) */
    if(atEnd){
      toast(front?'Already in front of everything on this page'
        :'Already behind everything on this page');
      return;
    }
    var moving=idxs.map(function(i){return s.annots[i];});
    var rest=s.annots.filter(function(a,i){return idxs.indexOf(i)<0;});
    /* idxs[0] is the LOWEST selected index, so every item below it is in
       `rest` — which makes idxs[0] exactly the insertion point that would
       leave the block where it is. One step is one either side of that. */
    var at0=idxs[0];
    var at=step
      ?(front?Math.min(rest.length,at0+1):Math.max(0,at0-1))
      :(front?rest.length:0);
    s.annots=rest.slice(0,at).concat(moving,rest.slice(at));
    /* the selection is a set of INDICES, so it has to be rebuilt */
    var moved=[];
    for(var k=0;k<moving.length;k++) moved.push(at+k);
    selSet=moved;selAnnot=moved[moved.length-1];
    markDirty();
    var l=stage.querySelector('.annot-layer');
    if(l){renderAnnots(l,s);paintSel(l);showFmt();renderSelPane();}
  }
  function zMove(front){zReorder(front,false);}
  var fwdBtn=$('#fmt-forward');
  if(fwdBtn) fwdBtn.addEventListener('click',function(){
    zReorder(true,true);});
  var bwdBtn=$('#fmt-backward');
  if(bwdBtn) bwdBtn.addEventListener('click',function(){
    zReorder(false,true);});
  var frontBtn=$('#fmt-front');
  if(frontBtn) frontBtn.addEventListener('click',function(){
    zMove(true);});
  var backBtn=$('#fmt-back');
  if(backBtn) backBtn.addEventListener('click',function(){
    zMove(false);});
  /* ---- Row / Grid arrange + "Make same size" (multi-selection) ---- */
  /* the selected, laid-out items with their VISUAL rects (an aspect-
     fitted figure answers with the plot it shows, not its stored box).

     `sizeOnly` names which lock excuses an item. A POSITION LOCK IS
     ABOUT POSITION: this filtered on pinned() for every caller, so
     "Match widths to the widest" silently skipped a position-locked box
     and said nothing about it — a size verb refusing on the strength of
     a promise about where things are (2026-08-26 audit, T57). Only a
     FULL lock takes an item out of a resize. */
  function selRects(sizeOnly){
    var s=pres.slides[cur]; if(!s) return [];
    var l=stage.querySelector('.annot-layer'); if(!l) return [];
    return selSet.filter(function(i){return typeof i==='number';})
      .map(function(i){
        var a=(s.annots||[])[i];
        if(!a||a.k==='arrow'||a.hide) return null;
        if(sizeOnly?lockedAll(a):pinned(a)) return null;
        var r=annotRectPct(l,s,i);
        return r?{i:i,a:a,r:r,w:r.r-r.l,h:r.b-r.t}:null;
      }).filter(Boolean);
  }
  function selBBox(items){
    var bb={l:1e9,r:-1e9,t:1e9,b:-1e9};
    items.forEach(function(x){
      bb.l=Math.min(bb.l,x.r.l);bb.r=Math.max(bb.r,x.r.r);
      bb.t=Math.min(bb.t,x.r.t);bb.b=Math.max(bb.b,x.r.b);});
    return bb;
  }
  function placeAt(x,l2,t2){
    anchorSet(x.a,l2,t2,x.w,x.h);
    /* figure frames: pin the model to the visual box so the aspect fit
       re-renders the plot exactly in the slot we computed */
    if(x.a.k==='cell'){x.a.w=x.w;x.a.h=x.h;}
  }
  function rerenderSel(){
    markDirty();
    var s=pres.slides[cur];
    var l=stage.querySelector('.annot-layer');
    if(l&&s){renderAnnots(l,s);paintSel(l);}
  }
  function arrangeRow(){
    var items=selRects(); if(items.length<2) return;
    var bb=selBBox(items);
    items.sort(function(p,q){return p.r.l-q.r.l;});
    var sum=0;items.forEach(function(x){sum+=x.w;});
    /* keep the selection's horizontal span; if the items cannot fit in
       it side by side, fall back to the DECK'S OWN gap — the spacing
       token, so one deck's rhythm is one number rather than a constant
       repeated in three arrange verbs (T12) */
    var gap=(bb.r-bb.l>=sum)
      ?((bb.r-bb.l-sum)/(items.length-1)):tokens().gap;
    var cy=(bb.t+bb.b)/2,x0=bb.l;
    items.forEach(function(x){
      placeAt(x,x0,cy-x.h/2);x0+=x.w+gap;});
    rerenderSel();
  }
  function arrangeGrid(){
    var items=selRects(); if(items.length<2) return;
    var bb=selBBox(items);
    /* reading order: rows top-to-bottom, then left-to-right */
    items.sort(function(p,q){return (p.r.t-q.r.t)||(p.r.l-q.r.l);});
    var n=items.length;
    var cols=Math.ceil(Math.sqrt(n)),rows=Math.ceil(n/cols);
    var mw=0,mh=0;
    items.forEach(function(x){mw=Math.max(mw,x.w);mh=Math.max(mh,x.h);});
    /* grid cells at least as big as the largest item, growing past the
       current bounding box when the items started stacked */
    var tg=tokens().gap;
    var cw=Math.max((bb.r-bb.l)/cols,mw+tg);
    var ch=Math.max((bb.b-bb.t)/rows,mh+tg);
    var ox=Math.max(0,Math.min(bb.l,100-cw*cols));
    var oy=Math.max(0,Math.min(bb.t,100-ch*rows));
    items.forEach(function(x,k){
      placeAt(x,
        ox+(k%cols)*cw+(cw-x.w)/2,
        oy+Math.floor(k/cols)*ch+(ch-x.h)/2);
    });
    rerenderSel();
  }
  function sameSize(mode){
    var items=selRects(true); if(items.length<2) return;
    var nums=selSet.filter(function(i){return typeof i==='number';});
    var ref=null;
    if(mode==='first'||mode==='last'){
      var want=(mode==='first')?nums[0]:nums[nums.length-1];
      ref=items.filter(function(x){return x.i===want;})[0];
    } else {
      items.forEach(function(x){
        if(!ref||(mode==='smallest'
          ?x.w*x.h<ref.w*ref.h:x.w*x.h>ref.w*ref.h)) ref=x;});
    }
    /* w / h / both take the BIGGEST as the model: matching down to the
       smallest usually crops something, matching up never does
       (2026-08-20) */
    if(mode==='w'||mode==='h'||mode==='both'){
      ref=null;
      items.forEach(function(x){
        var v=(mode==='h')?x.h:(mode==='w'?x.w:x.w*x.h);
        var rv=ref?((mode==='h')?ref.h:(mode==='w'?ref.w:ref.w*ref.h)):-1;
        if(v>rv) ref=x;});
    }
    if(!ref) ref=items[items.length-1];  /* the reference was an arrow */
    items.forEach(function(x){
      if(x===ref) return;
      if(x.a.k==='cell'){x.a.x=x.r.l;x.a.y=x.r.t;}
      if(mode!=='h') x.a.w=ref.w;
      if(x.a.k!=='text'&&mode!=='w') x.a.h=ref.h;
    });
    toast(mode==='w'?'Matched widths to the widest'
      :mode==='h'?'Matched heights to the tallest'
      :mode==='both'?'Matched sizes to the biggest'
      :('Same size: matched the '+
        (mode==='first'?'first selected':mode==='last'?'last selected'
         :mode)+' item'));
    rerenderSel();
  }
  /* ---- centre on the PAGE ---------------------------------------------
     Aligning puts items in line with EACH OTHER; this puts them in line
     with the page. With one item selected the two look the same, which is
     why nobody notices the difference until they want a block of three
     centred and discover that aligning centres them on their own average
     (2026-08-20). The selection moves as one, so the arrangement inside
     it is preserved. */
  function centreOnPage(how){
    var items=selRects();
    if(!items.length){toast('Select something first');return;}
    var bb=selBBox(items);
    var dx=(how==='vmiddle')?0:(50-(bb.l+bb.r)/2);
    var dy=(how==='hcenter')?0:(50-(bb.t+bb.b)/2);
    items.forEach(function(x){placeAt(x,x.r.l+dx,x.r.t+dy);});
    rerenderSel();
    toast('Centred on the page');
  }
  /* ---- close the gaps -------------------------------------------------
     The opposite of "space them evenly": push everything up against its
     neighbour, in order, keeping the first one where it is. This is the
     one you want after deleting something out of a row. */
  function closeGaps(axis){
    var items=selRects();
    if(needTwo(items,'close the gaps between')) return;
    var horiz=(axis==='h');
    items.sort(function(a,b){
      return horiz?(a.r.l-b.r.l):(a.r.t-b.r.t);});
    /* a hair of air, not a hard butt joint — and it is the deck's own
       spacing token halved, so "close the gaps" is tighter than "space
       them out" by construction rather than by coincidence (T12) */
    var GAP=tokens().gap/2;
    var at=horiz?items[0].r.l:items[0].r.t;
    items.forEach(function(x){
      if(horiz){placeAt(x,at,x.r.t);at+=x.w+GAP;}
      else {placeAt(x,x.r.l,at);at+=x.h+GAP;}
    });
    rerenderSel();
    toast('Closed the gaps');
  }
  /* ---- flip ------------------------------------------------------------
     Mirror the selection within its own bounding box. With one item that
     is a no-op on its position and only matters to arrows and freehand,
     which carry real geometry to mirror; with several it reverses their
     order, which is the useful case. */
  function flipSel(axis){
    var items=selRects();
    if(!items.length){toast('Select something first');return;}
    var bb=selBBox(items),horiz=(axis==='h');
    items.forEach(function(x){
      if(horiz) placeAt(x,bb.l+bb.r-x.r.l-x.w,x.r.t);
      else placeAt(x,x.r.l,bb.t+bb.b-x.r.t-x.h);
      var a=x.a;
      /* an arrow's endpoints are its geometry, so they mirror too */
      if(a.k==='arrow'){
        if(horiz){var t1=a.x1;a.x1=bb.l+bb.r-a.x2;a.x2=bb.l+bb.r-t1;}
        else {var t2=a.y1;a.y1=bb.t+bb.b-a.y2;a.y2=bb.t+bb.b-t2;}
      } else if(a.k==='draw'&&Array.isArray(a.pts)){
        a.pts=a.pts.map(function(q){
          return horiz?[1-q[0],q[1]]:[q[0],1-q[1]];});
      }
    });
    rerenderSel();
    toast(horiz?'Flipped left to right':'Flipped top to bottom');
  }
  /* ---- quarter turns and straighten ----------------------------------- */
  function turnSel(deg){
    var n=0;
    fmtApply(function(a){
      n++;
      if(!deg){delete a.rot;return;}
      a.rot=(((+a.rot||0)+deg)%360+360)%360;
      if(!a.rot) delete a.rot;
    });
    if(!n) return;
    toast(!deg?'Straightened':(deg>0?'Turned right':'Turned left'));
  }
  /* ---- align / distribute --------------------------------------------
     Row and Grid RE-ARRANGE a selection into a formation. Aligning is the
     other thing, and the one poster work needs constantly: leave items
     where they are and make one edge agree. Everything is measured off
     the VISUAL rect, so a letterboxed figure aligns by the plot you can
     see rather than by its padded frame. */
  /* Arrange lives in a menu that also holds single-item actions, so it is
     offered whenever anything is selected — which means these four CAN be
     reached with nothing they are able to move. Say so rather than
     appearing to be broken (2026-08-07 audit). */
  function needTwo(items,what){
    if(items.length>=2) return false;
    toast('Select at least two items to '+what
      +' — arrows, locked and hidden items don’t count');
    return true;
  }
  /* The Arrange menu contains both one-object actions and multi-selection
     actions. Hide the latter until they can do something, so a single
     selected box does not open a wall of disabled-sounding choices. */
  function arrangeMenuSync(){
    var menu=$('#fmt-align-menu'); if(!menu) return;
    var n=selRects().length;
    $$('[data-al]',menu).forEach(function(b){
      var v=b.getAttribute('data-al')||'';
      var many=v==='o:row'||v==='o:grid'||v.indexOf('m:')===0
        ||v.indexOf('x:layout')===0
        ||v.indexOf('d:')===0||v.indexOf('g:')===0
        ||['left','hcenter','right','top','vmiddle','bottom']
          .indexOf(v)>=0;
      var three=v.indexOf('d:')===0;
      b.hidden=many&&(n<(three?3:2));
    });
  }
  function alignSel(edge){
    var items=selRects(); if(needTwo(items,'line up')) return;
    var bb=selBBox(items);
    items.forEach(function(x){
      if(edge==='left') placeAt(x,bb.l,x.r.t);
      else if(edge==='right') placeAt(x,bb.r-x.w,x.r.t);
      else if(edge==='hcenter') placeAt(x,(bb.l+bb.r)/2-x.w/2,x.r.t);
      else if(edge==='top') placeAt(x,x.r.l,bb.t);
      else if(edge==='bottom') placeAt(x,x.r.l,bb.b-x.h);
      else if(edge==='vmiddle') placeAt(x,x.r.l,(bb.t+bb.b)/2-x.h/2);
    });
    rerenderSel();
  }
  /* equal GAPS, not equal centres: with items of different sizes, even
     centres still look wrong — it is the whitespace between them the eye
     measures. The outermost two stay put and define the span. */
  function distributeSel(axis){
    var items=selRects();
    if(items.length<3){
      toast('Select at least three items to space them out evenly');
      return;
    }
    var horiz=(axis==='h');
    items.sort(function(p,q){
      return horiz?(p.r.l-q.r.l):(p.r.t-q.r.t);});
    var bb=selBBox(items),sum=0;
    items.forEach(function(x){sum+=horiz?x.w:x.h;});
    var span=horiz?(bb.r-bb.l):(bb.b-bb.t);
    var gap=(span-sum)/(items.length-1);
    var at=horiz?bb.l:bb.t;
    items.forEach(function(x){
      if(horiz) placeAt(x,at,x.r.t); else placeAt(x,x.r.l,at);
      at+=(horiz?x.w:x.h)+gap;
    });
    rerenderSel();
  }
  /* ---- MATCH ANOTHER SLIDE --------------------------------------------
     The single most tedious thing about building a deck is making slide 7
     sit exactly like slide 3 — the heading in the same place, the figure
     the same size, the caption the same style. PowerPoint's answer is to
     duplicate a slide and replace its contents, which loses the contents
     you already had (2026-08-20, user: "would be cool if there was a
     'match other slide' option ... the text style, locations and sizes of
     everything become that same").
     It works by KIND, in reading order: the first heading here takes the
     first heading there's box and look, the first figure takes the first
     figure's, and so on. That is enough to be right almost every time and
     simple enough to explain in one sentence — which matters more than
     cleverness for something that moves your work about.
     What it deliberately does NOT do is move content between slides.
     Nothing is added, nothing is deleted; only geometry and styling
     travel. */
  function matchKey(a){
    /* what counts as "the same kind of thing". A text box's ROLE is its
       named style when it has one, so a Heading 1 matches a Heading 1 and
       not just any old text. */
    if(!a) return '';
    if(a.k==='text') return 'text:'+(a.style||'body');
    if(a.k==='cell'){
      /* a placed figure and a placed table are not interchangeable */
      return 'cell:'+(a.part||'auto');
    }
    return a.k;
  }
  /* ---- WHAT COUNTS AS "ONE OF THESE" ----------------------------------
     matchKey answers a narrow question for Match slide: which item on
     THIS slide pairs with which item on THAT one. typeKeyOf answers the
     wider one the user asks out loud — "apply to all objects of this
     type" (2026-08-22) — and the two differ in exactly two places, which
     is why this is a sibling and matchKey is not touched.

     A placed frame is keyed by the part it ACTUALLY shows (partOf), not
     by the raw a.part: a figure left on 'auto' and a figure explicitly
     set to 'figure' are the same thing on the page, so a button that says
     "every figure in this deck" must not put them in two buckets. Match
     slide is right to keep the raw value — it is pairing, not counting.

     And an UNSTYLED text box is grouped by its SIZE rather than falling
     into Body. matchKey's 'body' default exists so a plain box still
     pairs with something on another slide; here it would take one
     hand-formatted heading and push its look onto every caption in the
     deck. That is not a corner case — most decks have never used a named
     style, which is the whole reason the standardise check exists — and
     it is exactly what happened the first time this was driven in a
     browser (2026-08-22).
     Quantised in LOG space at the same ~6% the standardise bands use,
     because a type scale is multiplicative: two sizes within 6% were
     nudged apart by hand and meant to be one size, and 12% apart is one
     press of A+ and is meant. */
  function textBand(a){
    return Math.round(Math.log((a&&a.size)||2.6)/Math.log(1.06));
  }
  function typeKeyOf(a){
    if(!a) return '';
    if(a.k==='text')
      return a.style?('text:'+a.style):('text:~'+textBand(a));
    if(a.k==='cell') return 'cell:'+partOf(a);
    return matchKey(a);
  }
  var TYPE_LABELS={
    'cell:figure':['figure','figures'],
    'cell:output':['output frame','output frames'],
    'cell:code':['code frame','code frames'],
    'cell:body':['placed note','placed notes'],
    table:['table','tables'],rect:['shape','shapes'],
    arrow:['arrow','arrows'],draw:['drawing','drawings'],
    image:['picture','pictures']
  };
  /* the words the dialog puts on its chip. A styled text box is named by
     its STYLE, read live out of the registry, so a type you invented
     yourself gets a correct chip for free and can never disagree with
     what the Styles list calls the same thing. */
  function typeLabel(key,plural,src){
    if(key&&key.indexOf('text:~')===0){
      /* an unstyled box has no name, so it is named by what it IS: its
         size, in the same pt the Styles menu prints. Read off the source
         item when there is one — reconstructing it from the quantised
         band would print a number a point or two off the box in front of
         you, which is worse than useless on a label. */
      var pt=src&&src.size
        ?Math.round(src.size*5.4)
        :Math.round(Math.pow(1.06,+key.slice(6))*5.4);
      return 'text box'+(plural?'es':'')+' at about '+pt+' pt';
    }
    if(key&&key.indexOf('text:')===0){
      var d=styleDef(key.slice(5));
      if(d) return d.label+(plural?' boxes':' box');
    }
    var p=TYPE_LABELS[key];
    if(p) return plural?p[1]:p[0];
    return plural?'objects':'object';
  }
  /* does this key name a STYLE, as against a size band or another kind?
     Only a styled bucket can drift away from a style definition, so only
     it needs the Re-apply warning. */
  function isStyleKey(key){
    return !!(key&&key.indexOf('text:')===0&&key.indexOf('text:~')!==0);
  }
  /* how many WOULD CHANGE over the slides in scope — which means the
     source item does not count, because applying a look to itself is not
     a change. Counting it made the button promise "Apply to 1" and then
     do nothing at all (2026-08-22, caught in the browser). */
  function typeCount(key,idxs,src){
    var n=0;
    (idxs||[]).forEach(function(i){
      var sl=(pres.slides||[])[i]; if(!sl) return;
      (sl.annots||[]).forEach(function(a){
        if(a&&a!==src&&!a.hide&&typeKeyOf(a)===key) n++;
      });
    });
    return n;
  }
  /* every distinct type present over these slides, in an order that
     reads: named styles in the deck's own style order first, then the
     unnamed size bands biggest first, then everything else.

     This is what makes the type CHOOSABLE rather than merely reported,
     and it is not a luxury. An unstyled box is grouped by its size, so
     the moment you make one heading bigger it is alone in its band and
     "apply to all of this type" has nothing left to apply to — which is
     precisely the flow the feature is for. Being able to say "no, THAT
     type" fixes it, and it answers the other half of the ask directly:
     "maybe should be highlighted which object type this is"
     (2026-08-22). */
  function deckTypeKeys(idxs,src){
    var seen={},list=[];
    (idxs||[]).forEach(function(i){
      var sl=(pres.slides||[])[i]; if(!sl) return;
      (sl.annots||[]).forEach(function(a){
        if(!a||a.hide) return;
        var k=typeKeyOf(a);
        if(!seen[k]){seen[k]={key:k,n:0,sample:a};list.push(seen[k]);}
        if(a!==src) seen[k].n++;
      });
    });
    var ord=styleOrder();
    function rank(e){
      if(e.key.indexOf('text:~')===0)
        return 1000-(e.sample.size||2.6);       /* biggest type first */
      if(e.key.indexOf('text:')===0){
        var at=ord.indexOf(e.key.slice(5));
        return at<0?900:at;
      }
      return 2000;
    }
    list.sort(function(x,y){return rank(x)-rank(y);});
    return list;
  }
  /* ---- SELECTING BY WHAT THINGS ARE ------------------------------------
     "Select all caption text boxes"; "select everything using this font,
     size or colour" (TASKS T5).

     A CRITERION is one named question about an object, answered off a
     REFERENCE object: key 'font', value 'georgia'. Keeping it a VALUE
     rather than a closure is the whole design: find & replace (T6) runs
     the identical question over every slide in the deck while the
     selection below runs it over one, and neither owns the question.

     `type` is not re-invented here. typeKeyOf / typeLabel already answer
     "what kind of thing is this" for the Apply dialog, in the deck's own
     vocabulary — including the styles you invented yourself, read live
     out of the registry. Everything else in the table is an APPEARANCE:
     one field, read raw, with the default folded in so two boxes nobody
     ever touched count as the same. */
  var SELECT_CRIT=[
    /* key,   read(a) -> value, or null when the question does not apply
                to this kind of object
              say(v,a) -> the whole menu row, minus its count */
    ['type',function(a){return typeKeyOf(a)||null;},
      function(v,a){return 'Every '+typeLabel(v,false,a);}],
    ['font',function(a){return a.k==='text'?(a.font||''):null;},
      function(v){return 'Everything in '+fontLabel(v);}],
    ['size',function(a){
        return (a.k==='text'||a.k==='table')?(a.size||2.6):null;},
      function(v){return 'Everything at '+Math.round(v*5.4)+' pt';}],
    ['color',function(a){
        return (a.k==='text'||a.k==='arrow'||a.k==='rect'||a.k==='draw')
          ?(a.color||''):null;},
      function(){return 'Everything in this colour';}],
    ['fillc',function(a){return a.k==='rect'?(a.fillc||''):null;},
      function(){return 'Every shape with this fill';}],
    ['sw',function(a){
        return (a.k==='arrow'||a.k==='rect'||a.k==='draw')
          ?(a.sw||SW_DEFAULT):null;},
      function(){return 'Every stroke at this thickness';}]
  ];
  /* does an object answer EVERY criterion in the set? The set is an
     AND, and an empty set matches nothing — "change everything" is a
     thing you should have to say another way. */
  function critsMatch(a,crit){
    if(!a||!crit||!crit.length) return false;
    for(var i=0;i<crit.length;i++)
      if(critRead(crit[i].key,a)!==crit[i].val) return false;
    return true;
  }
  function critRead(key,a){
    if(!a) return null;
    for(var i=0;i<SELECT_CRIT.length;i++)
      if(SELECT_CRIT[i][0]===key) return SELECT_CRIT[i][1](a);
    return null;
  }
  /* every index on ONE slide that answers a criterion the same way.

     Hidden items are out: they are not on the page you are looking at.
     FULLY LOCKED ones are out too — the same rule the marquee follows
     (T3), and the count in the menu is taken from this same function, so
     "Every Caption (4)" always selects exactly four. Position-locked
     items are ordinary here, as they are everywhere else. */
  function annotsBy(sl,key,val){
    var out=[];
    (sl&&sl.annots||[]).forEach(function(a,i){
      if(!a||a.hide||lockedAll(a)) return;
      if(critRead(key,a)===val) out.push(i);
    });
    return out;
  }
  /* the rows worth offering for the current selection: every criterion
     the reference object can answer, that more than one object on this
     slide answers the same way. A row that would select the one thing
     you already have selected is a row that does nothing. */
  function selectByRows(){
    var s2=pres.slides[cur];
    var idxs=selIdxs();
    var ref=s2&&(s2.annots||[])[idxs[idxs.length-1]];
    if(!ref) return [];
    var out=[];
    SELECT_CRIT.forEach(function(c){
      var v=c[1](ref);
      if(v==null) return;
      var hit=annotsBy(s2,c[0],v);
      if(hit.length<2) return;
      out.push({key:c[0],val:v,n:hit.length,idxs:hit,
        label:c[2](v,ref)});
    });
    return out;
  }
  function selectBy(key,val){
    var s2=pres.slides[cur]; if(!s2) return;
    var hit=annotsBy(s2,key,val);
    if(!hit.length) return;
    selectMany(stage.querySelector('.annot-layer'),hit);
    toast(hit.length+' selected');
  }
  /* the standalone menu, for the Arrange row. The canvas menu lists the
     same rows inline instead — it is already a menu, and burying them one
     level deeper there would cost a click for nothing. */
  function openSelectByMenu(anchor,ev){
    var old=$('#selby-menu'); if(old) old.remove();
    var rows=selectByRows();
    var m=document.createElement('div');
    m.className='sh-menu canvas-menu';m.id='selby-menu';
    menuHead(m,'select on this slide');
    if(!rows.length){
      var b0=document.createElement('button');
      b0.className='dbtn vw-opt';b0.disabled=true;
      b0.textContent='Nothing else on this slide is like it';
      m.appendChild(b0);
    }
    rows.forEach(function(r){
      var b=document.createElement('button');
      b.className='dbtn vw-opt';
      b.appendChild(document.createTextNode(r.label));
      var k=document.createElement('kbd');
      k.textContent=String(r.n);b.appendChild(k);
      b.addEventListener('click',function(e){
        e.stopPropagation();overlayDrop(m);selectBy(r.key,r.val);});
      m.appendChild(b);
    });
    if(ev) floatAt(m,ev);
    else overlayMount(anchor,m);        /* on the stack (T213) */
  }
  /* the geometry + look that travel; content never does.

     A LINE IS NOT AN x/y/w/h BOX. It is stored as its two endpoints
     (x1,y1,x2,y2) plus any corners dragged into it, so a list that named
     only the box properties copied nothing an arrow actually uses: Match
     slide reported the arrow as moved and left it exactly where it was
     (2026-08-22). The endpoints, the corner route, the curve and the
     heads all travel now.
     NOT here on purpose: `c1`/`c2` (which item each end is tied to —
     they name items on the OTHER slide, and an attached end is placed by
     arrowEnds from the tie, so copying the tie would drag the arrow onto
     a stranger); `pts` (a freehand stroke's points ARE its content);
     `shape` and `crop` (what a thing IS, not how it is laid out); and
     `anim`, which is behaviour rather than layout. */
  var MATCH_PROPS=['x','y','w','h','rot','size','b','i','u','strike',
    'align','font','color','bg','bgc','op','style','sw','fill','fillc',
    'grad','ts','txcol','bgcol','arc','list','thead','grid','cols',
    'lh','pspace','ind',
    /* lines and arrows */
    'x1','y1','x2','y2','mid','curve','bend','head','tail','nohead',
    'hsz','dash'];
  /* T275: THE COPY RULE, IN ONE PLACE. Undefined on the model means
     DELETE on the target — except `style`. A named style is a NAME the
     target chose, not a look: matching a typed heading against a box
     that never had one used to strip the name and keep the baked-on
     look, so the box still read as a heading and was no longer one,
     which the outline, "apply to all headings" and the standardiser
     cannot see. Matching means "look like this one", so a model with no
     name leaves the target's alone. Three loops share this. */
  function matchProp(from,to,p){
    if(from[p]===undefined){
      if(p!=='style') delete to[p];
      return;
    }
    to[p]=(typeof from[p]==='object'&&from[p])?deep(from[p]):from[p];
  }
  /* ---- WHICH PROPERTIES TRAVEL ----------------------------------------
     "It should do everything by default (text size, spacing, indentation,
     width, height, x and y position), but then you can unselect ones you
     don't want" (2026-08-22). So: every row starts ticked, and the list
     is the vocabulary the dialog speaks in.

     A row is a USER-FACING idea, not a model field — "Bold, italic,
     underline" is one decision and three fields, and nobody wants three
     checkboxes for it. `kinds` is what the row means anything for; rows
     that do not fit the selected item are greyed and explained rather
     than hidden, so the list does not reshuffle under you when you pick a
     different object.

     EVERY field named here must also appear in MATCH_PROPS, because that
     is the list the copy loop walks. A field named here and missing there
     is a checkbox that silently does nothing — which is why `ind` was
     added to MATCH_PROPS in the same edit that invented it. */
  var APPLY_PROPS=[
    /* key      label                        group        kinds                              fields */
    ['size',   'Text size',                 'Type',      'text table',                      ['size']],
    ['font',   'Typeface',                  'Type',      'text',                            ['font']],
    ['emph',   'Bold, italic, underline',   'Type',      'text',                            ['b','i','u','strike']],
    ['style',  'Named style',               'Type',      'text',                            ['style']],
    ['tbl',    'Table rules and header row','Type',      'table',                           ['thead','grid','cols']],
    ['lh',     'Line spacing',              'Spacing',   'text table',                      ['lh']],
    ['pspace', 'Space between paragraphs',  'Spacing',   'text table',                      ['pspace']],
    ['ind',    'Indentation',               'Spacing',   'text',                            ['ind']],
    ['align',  'Alignment',                 'Spacing',   'text',                            ['align']],
    ['list',   'Bullets and numbering',     'Spacing',   'text',                            ['list']],
    ['arc',    'Curve',                     'Spacing',   'text',                            ['arc']],
    ['w',      'Width',                     'Size',      'text cell rect image table draw', ['w']],
    /* HEIGHT IS NOT A TEXT PROPERTY. A text box auto-heights — the
       renderer reads a.w and never a.h for one — and sameSize has
       excluded text from height since it was written. A ticked Height on
       a heading would be a control that does nothing, which is worse
       than a control that is not offered. */
    ['h',      'Height',                    'Size',      'cell rect image table draw',      ['h']],
    ['rot',    'Rotation',                  'Size',      '*',                               ['rot']],
    ['ts',     'Content zoom',              'Size',      'cell',                            ['ts']],
    ['x',      'Left / right position',     'Position',  'text cell rect image table draw', ['x']],
    ['y',      'Up / down position',        'Position',  'text cell rect image table draw', ['y']],
    /* an arrow is its two ends, not a box: the same row of the picker, a
       completely different set of fields — the bug where Match slide
       reported an arrow moved and left it exactly where it was */
    ['ends',   'Where the line runs',       'Position',  'arrow',                           ['x1','y1','x2','y2','mid','curve','bend']],
    ['color',  'Text colour',               'Colour',    'text arrow rect',                 ['color']],
    ['txcol',  'Note text colour',          'Colour',    'cell',                            ['txcol']],
    ['stroke', 'Line style and thickness',  'Colour',    'arrow rect draw table',           ['sw','style','dash','head','tail','nohead','hsz']],
    ['fill',   'Shape fill',                'Background','rect',                            ['fill','fillc','grad']],
    ['bg',     'Box background',            'Background','text table',                      ['bg','bgc']],
    ['bgcol',  'Note background',           'Background','cell',                            ['bgcol']],
    ['op',     'See-through',               'Background','*',                               ['op']]
  ];
  var APPLY_GROUPS=['Type','Spacing','Size','Position','Colour','Background'];
  /* why a row is greyed, said in words rather than in kind names */
  var APPLY_WHYNOT={text:'a text box',cell:'a placed frame',rect:'a shape',
    image:'a picture',arrow:'an arrow',draw:'a drawing',table:'a table'};
  /* everything ticked EXCEPT "Named style". Ticking that one re-tags the
     target boxes, which is a bigger claim than "make these look alike" —
     it changes what they ARE, and the next Re-apply would then move them.
     Everything the user actually listed is on by default. */
  function applyPickAll(){
    var o={};
    APPLY_PROPS.forEach(function(r){if(r[0]!=='style') o[r[0]]=1;});
    return o;
  }
  /* SESSION-LOCAL, deliberately. This is a preference about the TOOL, not
     a property of the deck: sending someone a presentation must not send
     them my checkbox state, and everything on `pres` has to be argued
     into normPres and then into or out of the undo snapshot. Ticking a
     box is not an edit and must never become an undo step — but it MUST
     survive until the tab closes, because the complaint this answers is
     repetition, and re-ticking six boxes every time is that same tax in a
     new coat. deckZoom is session-local for the same reason. */
  var applyPick=applyPickAll();
  function applyRowFits(row,kind){
    return row[3]==='*'||row[3].split(' ').indexOf(kind)>=0;
  }
  /* the object handed to the action: keyed by MODEL FIELD, not by row, so
     the copy loop is the one matchSlide already uses with one guard
     added. Narrowed to what this kind can carry, so a ticked row that
     does not apply cannot smuggle a field through. */
  function applyFieldsFor(pick,kind){
    var out={};
    APPLY_PROPS.forEach(function(r){
      if(!pick[r[0]]||!applyRowFits(r,kind)) return;
      r[4].forEach(function(f){out[f]=1;});
    });
    return out;
  }
  /* ---- WHICH SLIDES ---------------------------------------------------
     "The default should be 'all slides', but you can unselect slides and
     sections" (2026-08-22). So this is an EXCLUSION set: absent from
     scopeOff means in scope, and a deck you have never touched the picker
     on is entirely in scope with no state at all.

     Keyed on the slide OBJECT, not its index. pres.slides is spliced by
     move, delete, duplicate and the strip's drop handler, and histRestore
     replaces the array wholesale — an index-keyed exclusion would
     silently re-point at whatever slid into the slot, so unticking slide
     4 and then dragging it would leave slide 4's neighbour excluded.
     Object identity survives all of them, and a WeakMap empties itself
     for free on undo and on switching decks. */
  var scopeOff=new WeakMap();
  function scopeHas(s){return !!s&&!scopeOff.has(s);}
  function scopeSet(s,on){
    if(!s) return;
    if(on) scopeOff['delete'](s); else scopeOff.set(s,1);
  }
  function scopeAll(){
    (pres.slides||[]).forEach(function(s){scopeOff['delete'](s);});
  }
  /* ALWAYS an array, never null. A bug that produced null would have to
     mean "the whole deck", which is the most destructive reading
     available — so the interface simply has no way to say it. */
  function scopeIdxs(){
    var out=[];
    (pres.slides||[]).forEach(function(s,i){if(scopeHas(s)) out.push(i);});
    return out;
  }
  function scopeNoun(n){
    var w=pageOf().poster?'page':'slide';
    return n===1?w:w+'s';
  }
  function scopeWords(){
    var all=(pres.slides||[]).length,idxs=scopeIdxs(),n=idxs.length;
    if(!n) return 'No '+scopeNoun(0)+' chosen';
    if(n===all) return 'All '+all+' '+scopeNoun(all);
    if(n===1&&idxs[0]===cur) return 'This '+scopeNoun(1)+' only';
    return n+' of '+all+' '+scopeNoun(all);
  }
  /* ---- THE ACTION -----------------------------------------------------
     One source item, one type key, one property set, one list of slides.
     The loop walks MATCH_PROPS rather than the caller's own keys so that
     undefined-means-delete and the deep copy of a.grad / a.cols are
     handled in exactly one place, the same place Match slide handles
     them.
     ONE markDirty() and ONE refresh() at the end, never per item: a sweep
     over forty slides has to be a single undo step, and markDirty only
     repaints the CURRENT slide's thumbnail, so the other thirty-nine need
     the refresh to catch up. */
  function applyToType(key,src,want,idxs){
    var n=0;
    (idxs||[]).forEach(function(i){
      var sl=(pres.slides||[])[i]; if(!sl) return;
      (sl.annots||[]).forEach(function(a){
        if(!a||a===src||typeKeyOf(a)!==key) return;
        MATCH_PROPS.forEach(function(p){
          if(want[p]) matchProp(src,a,p);
        });
        n++;
      });
    });
    markDirty();refresh();
    return n;
  }
  /* ---- WHAT AN UNSTYLED TEXT BOX IS FOR --------------------------------
     matchKey answers "what kind of thing is this", and for text it
     answers with the NAMED STYLE — which is right, and useless on the
     many decks that have never used one. There, every text box came back
     'text:body', so a heading and a caption were the same kind and got
     paired by position alone: the higher one won the higher slot and a
     heading could land where a caption belonged.

     The fix is to read the role the box is actually PLAYING, and the
     signal is RANK WITHIN ITS OWN SLIDE rather than absolute size. The
     biggest text on a slide is its heading whatever the number happens to
     be, the next is its body, the next its caption. Rank survives exactly
     the case that breaks a size threshold — a deck whose slides were
     formatted by hand and disagree about how big a heading is — which is
     precisely the deck that needed arranging in the first place
     (2026-08-22, user: "is there not a way for it to figure this out?").

     Sizes within ROLE_TOL of each other share a rank, so two paragraphs
     set the same size stay one bucket and pair between themselves in
     reading order, which is the right answer for them. */
  var ROLE_TOL=1.06;
  function inferRoles(sl){
    var list=[],out={};
    ((sl&&sl.annots)||[]).forEach(function(a,i){
      if(a&&a.k==='text'&&!a.hide
        &&!(a.style&&STYLE_DEFAULTS[a.style]))
        list.push({i:i,size:(a.size||2.6)});
    });
    if(!list.length) return out;
    list.sort(function(x,y){return y.size-x.size;});
    var rank=0,prev=null;
    list.forEach(function(e){
      if(prev!==null&&prev/e.size>ROLE_TOL) rank++;
      prev=e.size;
      out[e.i]=rank;
    });
    return out;
  }
  /* the bucket key one slide's items pair on. A box wearing a real style
     keeps it — a name you chose beats a rank we inferred — and everything
     that is not text is unchanged. */
  function slideRoleKey(sl){
    var roles=inferRoles(sl);
    return function(a,i){
      if(a&&a.k==='text'&&!a.style&&roles[i]!=null)
        return 'text:~'+roles[i];
      return matchKey(a);
    };
  }
  function matchSlide(fromIdx,toIdx){
    var src=pres.slides[fromIdx],dst=pres.slides[toIdx];
    if(!src||!dst) return null;
    /* buckets by kind, in reading order down the page then across */
    function bucket(sl){
      var m={},keyOf=slideRoleKey(sl);
      (sl.annots||[]).map(function(a,i){return {a:a,i:i};})
        .filter(function(p2){return p2.a&&!p2.a.hide;})
        .sort(function(p2,q2){
          var dy=(p2.a.y||0)-(q2.a.y||0);
          return Math.abs(dy)>4?dy:((p2.a.x||0)-(q2.a.x||0));})
        .forEach(function(p2){
          var k=keyOf(p2.a,p2.i);
          (m[k]=m[k]||[]).push(p2);});
      return m;
    }
    var sb=bucket(src),db=bucket(dst);
    var moved=0,missing=[];
    Object.keys(db).forEach(function(k){
      var from=sb[k]||[],to=db[k];
      if(!from.length){missing.push(k);return;}
      to.forEach(function(p2,n){
        /* run out of models? reuse the last one, so three bullets on this
           slide all take the styling of the one bullet on that one */
        var m=from[Math.min(n,from.length-1)].a;
        MATCH_PROPS.forEach(function(prop){matchProp(m,p2.a,prop);});
        moved++;
      });
    });
    return {moved:moved,missing:missing,
      spare:Object.keys(sb).filter(function(k){return !db[k];})};
  }
  /* ---- ARRANGE THIS SLIDE ----------------------------------------------
     (2026-08-22, user: "there could be like an 'arrange slide button',
     which based upon what is there (the main big things and text boxes,
     and then anything little like shapes stay where they are in reference
     to if they are on top of something, and arrows point to the same xy
     in one image to the same xy in another image). Then there can be
     presets based upon both the size of something, as well as the
     difference between things can be configured.")

     This is the arrangement library's twin: it needs no saved layout at
     all, because it reads the slide and works one out. Three kinds of
     thing, and the whole design is in how they are treated differently:

       MAJOR   figures, images, tables, flip books — and any shape big
               enough to be scenery rather than a mark. These are placed.
       TEXT    placed too, by the ROLE inferRoles gives it: the biggest
               text on the slide is its heading, the smallest under a
               figure is that figure's caption.
       MINOR   a circle round part of a plot, a tick, a small label. These
               are NOT placed. They are recorded as a FRACTION of whatever
               they sit on and put back on top of it afterwards, so the
               annotation still annotates the same pixel of the same plot.

     Arrow endpoints get the same treatment, one end at a time and by
     fraction rather than by the a.c1/a.c2 tie — that tie aims at an
     item's centre and lands on its border, which is right for "this
     points AT that figure" and wrong for "this points at the peak in the
     top-left of that figure", which is what is being preserved here. */
  var ARRANGE_PRESETS=[
    ['tight','Tight',{gap:1.6,big:7,textShare:0.30}],
    ['normal','Normal',{gap:3.0,big:9,textShare:0.34}],
    ['airy','Airy',{gap:5.0,big:12,textShare:0.38}]
  ];
  function arrangeOpts(id){
    var o=ARRANGE_PRESETS[1][2];
    ARRANGE_PRESETS.forEach(function(p){if(p[0]===id) o=p[2];});
    return o;
  }
  function rectOf(a){
    if(!a) return null;
    if(a.k==='arrow')
      return {l:Math.min(a.x1,a.x2),r:Math.max(a.x1,a.x2),
              t:Math.min(a.y1,a.y2),b:Math.max(a.y1,a.y2)};
    if(a.w==null||a.h==null) return null;
    return {l:a.x,r:a.x+a.w,t:a.y,b:a.y+a.h};
  }
  function rectArea(r){
    return r?Math.max(0,r.r-r.l)*Math.max(0,r.b-r.t):0;
  }
  function overlapArea(p,q){
    if(!p||!q) return 0;
    var w=Math.min(p.r,q.r)-Math.max(p.l,q.l);
    var h=Math.min(p.b,q.b)-Math.max(p.t,q.t);
    return (w>0&&h>0)?w*h:0;
  }
  /* is this item scenery or a mark? Size is the signal the user named,
     and it is configurable per preset because "big" on an A0 poster and
     "big" on a 16:9 slide are not the same number of percent. */
  function isMajorKind(a){
    return a&&(a.k==='cell'||a.k==='image'||a.k==='flip'||a.k==='table');
  }
  function arrangeSlide(sl,layer,opt){
    if(!sl) return 0;
    opt=opt||arrangeOpts('normal');
    var m=marginPct(),gap=opt.gap;
    var annots=sl.annots||[];
    /* EVERY rect is measured BEFORE anything moves. Text auto-heights and
       a figure frame hugs its plot, so the live layer is the only honest
       source for those — and it goes stale the moment we write. */
    var rects=annots.map(function(a,i){
      var r=(layer?annotRectPct(layer,sl,i):null)||rectOf(a);
      return r;
    });
    var majors=[],texts=[],minors=[],arrows=[];
    annots.forEach(function(a,i){
      if(!a||a.hide) return;
      if(a.k==='arrow'){arrows.push(i);return;}
      var r=rects[i]; if(!r) return;
      if(a.k==='text'){texts.push(i);return;}
      if(isMajorKind(a)||rectArea(r)>=opt.big*opt.big) majors.push(i);
      else minors.push(i);
    });
    if(!majors.length&&!texts.length) return 0;
    /* ---- record what rides on what, before anything moves ---- */
    function hostOf(r){
      var best=-1,bo=0;
      majors.forEach(function(j){
        var o=overlapArea(r,rects[j]);
        if(o>bo){bo=o;best=j;}
      });
      /* half of it has to be over the host, or a shape merely NEAR a
         figure would be dragged across the slide with it */
      return (best>=0&&bo>=rectArea(r)*0.5)?best:-1;
    }
    function frac(r,h){
      var hw=(h.r-h.l)||1,hh=(h.b-h.t)||1;
      return {x:(r.l-h.l)/hw,y:(r.t-h.t)/hh,
              w:(r.r-r.l)/hw,h:(r.b-r.t)/hh};
    }
    var ride=[];
    minors.forEach(function(i){
      var h=hostOf(rects[i]);
      if(h>=0) ride.push({i:i,host:h,f:frac(rects[i],rects[h])});
    });
    function pointHost(x,y){
      var best=-1;
      majors.forEach(function(j){
        var r=rects[j];
        if(x>=r.l&&x<=r.r&&y>=r.t&&y<=r.b) best=j;
      });
      return best;
    }
    var tips=[];
    arrows.forEach(function(i){
      var a=annots[i];
      [['1',a.x1,a.y1],['2',a.x2,a.y2]].forEach(function(e){
        var h=pointHost(e[1],e[2]);
        if(h<0) return;
        var r=rects[h];
        tips.push({i:i,end:e[0],host:h,
          fx:(e[1]-r.l)/((r.r-r.l)||1),
          fy:(e[2]-r.t)/((r.b-r.t)||1)});
      });
    });
    /* ---- who is a heading, who is a caption ---- */
    var roles=inferRoles(sl);
    var maxRank=0;
    texts.forEach(function(i){
      if(roles[i]!=null&&roles[i]>maxRank) maxRank=roles[i];});
    var head=-1,caps={},bodies=[];
    texts.forEach(function(i){
      var rk=roles[i];
      if(rk===0&&head<0&&maxRank>0){head=i;return;}
      /* a caption is the smallest text that sits UNDER a figure and
         overlaps it across — the same signal the standardise check uses */
      if(rk===maxRank&&maxRank>0){
        var r=rects[i],hit=-1;
        majors.forEach(function(j){
          var q=rects[j];
          if(r.t>=q.b-2&&r.t<=q.b+14&&r.r>q.l&&r.l<q.r) hit=j;});
        if(hit>=0&&caps[hit]==null){caps[hit]=i;return;}
      }
      bodies.push(i);
    });
    /* ---- the regions ---- */
    var L=m.x,T=m.y,R=100-m.x,B=100-m.y;
    var put={};
    function setBox(i,x,y,w,h){put[i]={x:x,y:y,w:w,h:h};}
    if(head>=0){
      var hh=Math.max(6,(rects[head].b-rects[head].t));
      setBox(head,L,T,R-L,null);
      T+=hh+gap;
    }
    var capH=Math.max(4,(maxRank>0?5:0));
    var nb=bodies.length,nm=majors.length;
    /* T468: STACKED BY THEIR OWN HEIGHT, the gap between them. Sharing
       the page's height among the boxes made Tight, Normal and Airy
       the same arrangement on a text slide -- every box widened to the
       full page and spread over the whole height, the three presets
       differing by 5px per gap -- and "Tight" closed nothing up
       (2026-09-15 review, measured). A box keeps its own width, within
       the margins; the gap is the preset's, so the three presets are
       three visibly different stacks. */
    function stackTexts(idxs,x,w,y0){
      var y=y0;
      idxs.forEach(function(i){
        var r=rects[i]||{};
        var h=Math.max(3,(r.b||0)-(r.t||0));
        var bw=w!=null?w:Math.min(R-L,Math.max(10,(r.r||0)-(r.l||0)));
        setBox(i,x,y,bw,null);
        y+=h+gap;
      });
    }
    if(!nm){
      /* text only: one column, stacked */
      stackTexts(bodies,L,null,T);
    } else {
      var fx=L,fw=R-L;
      if(nb&&nm<=2){
        /* a short slide reads best as text beside the figure. With three
           or more figures the text goes underneath instead — a 30% column
           beside a 2x2 grid is a gutter, not a paragraph. */
        var tw=(R-L)*opt.textShare;
        fx=L+tw+gap;fw=(R-L)-tw-gap;
        stackTexts(bodies,L,tw,T);
      }
      var fb=B;
      if(nb&&nm>2){
        var bandH=Math.max(8,(B-T)*0.24);
        fb=B-bandH-gap;
        var eachB=(R-L-gap*Math.max(0,nb-1))/Math.max(1,nb);
        bodies.forEach(function(i,k){
          setBox(i,L+k*(eachB+gap),fb+gap,eachB,null);});
      }
      var cols=nm<=1?1:(nm<=4?2:Math.ceil(Math.sqrt(nm)));
      var rows=Math.ceil(nm/cols);
      var cw=(fw-gap*(cols-1))/cols;
      var ch=(fb-T-gap*(rows-1))/rows;
      /* the caption strip is reserved for the whole ROW, not the one cell
         that has a caption. Charging it to that cell alone left two
         figures side by side at different heights, which reads as a
         mistake rather than as a caption (2026-08-22). */
      var rowCap={};
      majors.forEach(function(i,k){
        if(caps[i]!=null) rowCap[Math.floor(k/cols)]=1;});
      majors.forEach(function(i,k){
        var c=k%cols,r2=Math.floor(k/cols);
        var x=fx+c*(cw+gap),y=T+r2*(ch+gap);
        var mh=ch-(rowCap[r2]?(capH+gap*0.5):0);
        setBox(i,x,y,cw,mh);
        if(caps[i]!=null) setBox(caps[i],x,y+mh+gap*0.5,cw,null);
      });
    }
    /* ---- write it ---- */
    var moved=0;
    Object.keys(put).forEach(function(k){
      var i=+k,a=annots[i],b=put[i];
      if(!a) return;
      a.x=Math.round(b.x*10)/10;
      a.y=Math.round(b.y*10)/10;
      a.w=Math.round(b.w*10)/10;
      /* a text box auto-heights: writing a height on one would fix it at
         a size its words do not need (the rule MATCH_PROPS keeps too) */
      if(b.h!=null&&a.k!=='text') a.h=Math.round(b.h*10)/10;
      moved++;
    });
    /* ---- and put the marks back where they were, relative ---- */
    function newRect(i){
      var b=put[i];
      if(b) return {l:b.x,t:b.y,r:b.x+b.w,
        b:b.y+(b.h!=null?b.h:(rects[i].b-rects[i].t))};
      return rects[i];
    }
    ride.forEach(function(e){
      var h=newRect(e.host),a=annots[e.i];
      var hw=(h.r-h.l),hh=(h.b-h.t);
      a.x=Math.round((h.l+e.f.x*hw)*10)/10;
      a.y=Math.round((h.t+e.f.y*hh)*10)/10;
      a.w=Math.round(e.f.w*hw*10)/10;
      a.h=Math.round(e.f.h*hh*10)/10;
      moved++;
    });
    tips.forEach(function(e){
      var h=newRect(e.host),a=annots[e.i];
      var x=Math.round((h.l+e.fx*(h.r-h.l))*10)/10;
      var y=Math.round((h.t+e.fy*(h.b-h.t))*10)/10;
      if(e.end==='1'){a.x1=x;a.y1=y;} else {a.x2=x;a.y2=y;}
      /* a fractional tip is a POINT inside the figure, which is a
         different promise from a.c1/a.c2's "aim at this item and stop at
         its border" — so the tie is dropped for the end we just placed,
         or the render would immediately overrule us */
      if(e.end==='1') delete a.c1; else delete a.c2;
      moved++;
    });
    return moved;
  }
  /* ---- ARRANGEMENTS ----------------------------------------------------
     (2026-08-22, user: "there could be arrangements one has, that are
     like if the slide has heading, small paragraph, and large image ...
     I know there can be infinite numbers of these, but it would be cool
     if there was like a way to create ones of these, and like there was a
     view that had a list of what is being arranged, then like a little
     thumbnail of what it would be arranged to".)

     AN ARRANGEMENT IS JUST A SAVED SLIDE. That is the whole design, and
     it is why there is no new matching language here: matchSlide already
     buckets items by kind and pairs them in reading order, so applying an
     arrangement is matchSlide from a stored slide instead of from another
     slide in the deck. Creating one is therefore "make a slide look right
     and save it", which is the only authoring model that scales — and it
     dissolves the "infinite numbers of these" worry, because nobody
     enumerates them: you keep the five you actually use.

     They live in localStorage, not on the deck: an arrangement you only
     ever get to use on one presentation is not worth naming.

     WHAT IS DELIBERATELY NOT HERE is automatic application. Whether a
     paragraph is "small" is a consequence of the layout you have not
     applied yet, not a property of the content, so a rule keyed on it is
     circular and would rearrange slides you were happy with. The pane
     SUGGESTS: every slide, its best match, a thumbnail, and a tick you
     can clear. */
  var ARRKEY='jv-deck-arr:';
  /* THE THREE ROWS IN THE LAYOUTS MENU (T89). Wired from THE BOOT
     SEQUENCE, never mid-file: this walks the DOM and the deck's markup
     is only guaranteed real at the tail.

     Saving is done HERE rather than by reaching into the dialog, because
     arrList / arrFromSlide / arrSave are file-scope and the dialog's
     #ar-save handler is not. The dialog re-seeds on open, so an
     arrangement saved from the menu is in the library the next time it
     is looked at. */
  function initReuseDoors(){
    function shut(){
      var lm=$('#lay-menu'); if(lm) overlayHide(lm);
    }
    /* each row exists twice since Home gained parity (T131): same
       handler, both ids */
    function both(idA,idB,fn){
      [idA,idB].forEach(function(id){
        var el=id?$(id):null; if(!el) return;
        el.addEventListener('click',function(e){
          e.stopPropagation();shut();fn();});
      });
    }
    /* ONE DOOR EACH (T204). The Layouts menu's rows are gone -- the
       same verbs are the Layout group on Design, beside the menu --
       so `both` wires one id now, and Masters' only door is Page
       furniture's. */
    both('#hm-lay-arrs',null,function(){
      if(typeof window.SemDeckArrange==='function') window.SemDeckArrange();
    });
    both('#hm-lay-give',null,function(){
      if(typeof window.SemDeckMatchMany==='function')
        window.SemDeckMatchMany();
    });
    both('#hm-lay-ideas',null,function(){openLayoutIdeas();});
    /* the first-class doors (T144): the same verbs, on the ribbon */
    var dm2=$('#dsg-masters');
    if(dm2) dm2.addEventListener('click',function(e){
      e.stopPropagation();
      if(window.SemDeckMasters) window.SemDeckMasters();
    });
    /* the Chart button left the ribbon (T188; 2026-09-02, user: "I
       never wanted that... get rid of it"). The feature is still
       reachable from a placed table's right-click, Turn into a chart. */
    var sv=null;
    ['#hm-lay-arrsave'].forEach(function(id){
      var el=$(id); if(!el) return;
      el.addEventListener('click',function(e){
      e.stopPropagation();shut();
      var sl=pres.slides[cur];
      if(!sl||!(sl.annots||[]).length){
        toast('Lay something out on this slide first');return;}
      /* T475: the editor's own question, and the ribbon's word for it
         (T194: layout, not arrangement) */
      askText({title:'Save this slide\u2019s layout',label:'Call this layout',
        value:slideTitle(sl).slice(0,30)||'Layout',ok:'Save',
        note:'Offered on every deck you open here'},function(nm){
      if(nm==null) return;
      nm=nm.trim(); if(!nm) return;
      var l=arrList();
      l.push(arrFromSlide(sl,nm));
      arrSave(l);
      toast('“'+nm+'” saved — offered on every deck you '
        +'open here');
      });
    });
    });
  }
  /* ---- LAYOUT IDEAS (T131) -------------------------------------
     "There is no like slide designer thing, that gives you options of
     layouts for the objects you have." Every ingredient existed —
     content-aware arranging, a personal library with fit scores, the
     miniature renderer — and the defining gesture did not: nowhere did
     the app COMPUTE several candidates for THIS slide's objects and
     show them to pick from. Choice was three spacing presets applied
     blind, compared by Ctrl+Z.

     The candidates are the three tidy presets RUN on a clone of the
     slide, plus your best-fitting saved arrangements SIMULATED on a
     clone — real previews of your actual content, not wireframes of a
     template. The simulation is withDeck over a shallow copy whose
     slides array holds only the clone, so arrangeSlide and arrApply
     run exactly the code a click would run and the live deck cannot
     be touched. Built-in templates are not previewed here: they stay
     one row below in the same menu, and simulating the pane machinery
     for a preview would be a second implementation of it. */
  function ideaPreviewTidy(id,sl){
    var c=deep(sl);
    var scratch=Object.assign({},pres,{slides:[c]});
    withDeck(scratch,function(){
      arrangeSlide(c,null,arrangeOpts(id));});
    return c;
  }
  function ideaPreviewArr(arr,sl){
    var c=deep(sl);
    var scratch=Object.assign({},pres,{slides:[c]});
    withDeck(scratch,function(){arrApply(arr,0);});
    return c;
  }
  function closeLayoutIdeas(){
    var p=$('#lay-ideas');
    if(p){if(!p.hidden) overlayHide(p); p.remove();}
    document.removeEventListener('keydown',ideasKey,true);
  }
  function ideasKey(e){
    if(e.key!=='Escape') return;
    if(!$('#lay-ideas')) return;
    e.preventDefault();e.stopPropagation();closeLayoutIdeas();
  }
  function openLayoutIdeas(){
    closeLayoutIdeas();
    var sl=pres.slides[cur];
    if(!sl||!(sl.annots||[]).length){
      toast('Put something on this slide first — ideas are computed '
        +'from what is there');
      return;
    }
    /* FULL SCREEN (T209): a header like the other full-screen views,
       cards a third of the window wide, on the overlay stack so Escape
       and an outside click close it the same way everywhere */
    var p=document.createElement('div');
    p.className='sh-menu lay-ideas';p.id='lay-ideas';
    var h=document.createElement('div');h.className='img-ov-h';
    var ht=document.createElement('span');ht.className='img-ov-t';
    ht.textContent='Ways to lay this slide out';h.appendChild(ht);
    var hs=document.createElement('span');hs.className='img-ov-sub';
    hs.textContent='Worked out from what is on the slide. Click one; '
      +'Ctrl+Z undoes it.';
    h.appendChild(hs);
    var hc=document.createElement('button');hc.className='dbtn rbn-sm';
    hc.innerHTML=bic('exit')+' Close';hc.title='Close (Esc)';
    hc.addEventListener('click',function(e){
      e.stopPropagation();closeLayoutIdeas();});
    h.appendChild(hc);
    p.appendChild(h);
    var grid=document.createElement('div');
    grid.className='li-grid';
    p.appendChild(grid);
    var pg=pageOf();
    var ratio=pg.mm[1]/pg.mm[0];
    function card(prev,label,note,apply){
      var b=document.createElement('button');
      b.className='dbtn li-card';
      b.title=note||'';
      var W=Math.max(220,Math.min(420,Math.round(window.innerWidth*0.28)));
      var H=Math.round(W*ratio);
      /* T490: DRAWN AT THE CARD'S OWN SCALE. miniDiagram sizes type
         and strokes off miniHNow, the film strip's thumbnail height
         (66px) -- so a 442x279 card drew every text box as three 3px
         specks and text-only candidates were indistinguishable
         (2026-09-15 review). The card's height is the scale while it
         is drawn; the strip's is put back after. */
      var mh=miniHNow;miniHNow=H;
      var mini;
      try{mini=miniDiagram(prev);}finally{miniHNow=mh;}
      mini.style.width=W+'px';
      mini.style.height=H+'px';
      b.appendChild(mini);
      var t=document.createElement('span');
      t.className='li-lab';t.textContent=label;
      b.appendChild(t);
      b.addEventListener('click',function(e){
        e.stopPropagation();closeLayoutIdeas();apply();});
      grid.appendChild(b);
    }
    [['tight','Tight','tightly spaced'],['normal','Normal','normally spaced'],
     ['airy','Airy','with wide gaps']]   /* T490: a word, not "-ly" */
      .forEach(function(t){
        card(ideaPreviewTidy(t[0],sl),t[1],
          'Arrange what is on the slide, '+t[2]+'. Ctrl+Z undoes it.',
          function(){
            var n=arrangeSlide(pres.slides[cur],
              stage.querySelector('.annot-layer'),arrangeOpts(t[0]));
            if(!n){toast('There is nothing on this slide to arrange');
              return;}
            markDirty();refresh();
            toast(n+' item'+(n===1?'':'s')+' arranged \u2014 '
              +t[1]+'. Ctrl+Z undoes it.');
          });
      });
    /* the best of your own library, best fit first; a poor fit is an
       honest offer as long as the number says so */
    arrList().map(function(arr){
      return {arr:arr,fit:arrScore(arr,sl)};
    }).sort(function(x,y){return y.fit-x.fit;})
      .slice(0,3)
      .forEach(function(o){
        card(ideaPreviewArr(o.arr,sl),
          (o.arr.label||o.arr.name||'Arrangement')+' \u00b7 '+Math.round(o.fit*100)+'%',
          'Your saved arrangement, simulated on this slide\u2019s '
          +'objects',
          function(){
            var n=arrApply(o.arr,cur);
            markDirty();refresh();
            toast(n?(n+' item'+(n===1?'':'s')+' laid out like \u201c'
                +(o.arr.label||o.arr.name||'Arrangement')+'\u201d \u2014 Ctrl+Z undoes it')
              :'Nothing matched \u201c'+(o.arr.label||o.arr.name||'Arrangement')+'\u201d');
          });
      });
    ((typeof deckEl!=='undefined'&&deckEl)||document.body).appendChild(p);
    p.hidden=true;
    overlayShow($('#hm-lay-ideas'),p);
    new MutationObserver(function(){
      if(p.hidden&&p.parentNode) p.remove();
    }).observe(p,{attributes:true,attributeFilter:['hidden']});
  }
  function arrList(){
    try{
      var l=JSON.parse(lsGet(ARRKEY+SCOPE)||'[]');
      if(!Array.isArray(l)) return [];
      /* T494: a layout saved before the words were scrubbed still
         holds the first 18 characters of somebody's slide; it is read
         through the same generic-word rule arrFromSlide writes with,
         so an old store stops leaking without being rewritten. And an
         entry without an id gets a steady one, because a tile is
         remembered by id now. */
      l.forEach(function(arr,i){
        if(!arr) return;
        if(!arr.id) arr.id='arr'+i;
        (arr.annots||[]).forEach(function(a){
          if(a&&a.k==='text') a.text=arrWord(a);
        });
      });
      return l;
    }catch(e){return [];}
  }
  /* T494: THE WORD A SAVED SLOT WEARS -- the slot's kind, never the
     slide's words. "Only the shape is kept -- no words, no figures" is
     what the door promises. */
  function arrWord(a){
    return {title:'Title',h1:'Title',h2:'Heading',h3:'Heading',
      subtitle:'Subtitle',body:'Body text',small:'Small text',
      caption:'Caption'}[a&&a.style]||'Text';
  }
  function arrSave(list){
    lsSet(ARRKEY+SCOPE,JSON.stringify(list));
    syncSavedTiles();
  }
  /* ---- SAVED LAYOUTS IN THE STRIP (T201) --------------------------
     Each layout you saved is a tile after the built-in ones, drawn
     by the same miniDiagram the Saved layouts dialog uses, so the two
     cannot look like different things. Rebuilt whenever the store is
     written and whenever the picker is; picking one lays THIS slide
     out the way that one was (arrApply, the dialog's own verb). */
  function syncSavedTiles(){
    var strip=$('#layout-strip'); if(!strip) return;
    $$('.lay-saved',strip).forEach(function(t){t.remove();});
    if(pageOf().poster) return;
    arrList().forEach(function(arr,i){
      var b=document.createElement('button');
      b.type='button';b.className='dbtn lay lay-saved';
      /* T494: the tile is known by the arrangement's ID. It was its
         index, so Forget on an earlier one made the remembered 'arr:1'
         name one layout and build the next along (2026-09-15 review). */
      b.dataset.arrId=arr.id;
      var th=document.createElement('span');th.className='layico2 lay-savedth';
      th.appendChild(miniDiagram({layout:'blank',panes:[],annots:arr.annots||[]}));
      b.appendChild(th);
      var lb=document.createElement('span');lb.className='lay-lb';
      lb.textContent=arr.label||('Saved '+(i+1));
      b.appendChild(lb);
      b.title='New slide laid out like your saved \u201c'+(arr.label||'')
        +'\u201d';
      b.addEventListener('click',function(e){
        e.stopPropagation();
        /* chosen for the next New slide (T218); the dialog's Apply is
           what lays an EXISTING slide out like one */
        lsSet(newLayKey(),'arr:'+b.dataset.arrId);
        if(typeof syncNewSlideMarks==='function') syncNewSlideMarks();
      });
      strip.appendChild(b);
    });
    /* T494: rebuilt tiles are re-lit, so Forget (or a rename) in the
       Saved layouts dialog leaves the chosen one lit and New slide's
       readout saying what it will make */
    if(typeof syncNewSlideMarks==='function') syncNewSlideMarks();
  }
  function arrById(id){
    var hit=null;
    arrList().forEach(function(a){if(a&&a.id===id) hit=a;});
    return hit;
  }
  /* the shape of a slide, with the CONTENT stripped out. Only what
     matchSlide would ever copy is kept, so an arrangement cannot smuggle
     someone else's words or someone else's figure onto your slide. */
  function arrFromSlide(sl,name){
    var keep=[];
    (sl.annots||[]).forEach(function(a){
      if(!a||a.hide) return;
      var o={k:a.k};
      if(a.k==='text'&&a.style) o.style=a.style;
      if(a.k==='cell') o.part=a.part;
      MATCH_PROPS.forEach(function(p){
        if(a[p]===undefined) return;
        o[p]=(typeof a[p]==='object'&&a[p])
          ?deep(a[p]):a[p];
      });
      /* a placeholder word, so the saved slide can be DRAWN as a
         thumbnail without carrying the real text anywhere.
         T494: the word is the SLOT'S KIND -- "Title", "Body text" --
         never the slide's own words. annotLabel gave the first 18
         characters of what you typed, the store is project-wide, and
         New slide placed them as real text on every slide made from
         the layout, in every deck (2026-09-15 review: "Confidential
         resul" on a slide in another deck, at full ink, in the show). */
      if(a.k==='text') o.text=arrWord(o);
      keep.push(o);
    });
    return {id:'ar'+Date.now().toString(36),
      label:name||'Arrangement',
      page:pageOf().poster?'poster':'slide',
      annots:keep};
  }
  /* how well an arrangement fits a slide: the fraction of the slide's
     items it has somewhere to put. Reported, never acted on by itself. */
  function arrScore(arr,sl){
    /* the SAME key the pairing uses, or the percentage describes a
       different match from the one that would happen */
    function counts(sl){
      var m={},keyOf=slideRoleKey(sl);
      ((sl&&sl.annots)||[]).forEach(function(a,i){
        if(!a||a.hide) return;
        var k=keyOf(a,i);m[k]=(m[k]||0)+1;});
      return m;
    }
    var want=counts(sl),have=counts({annots:arr.annots});
    var nw=0,nh=0,hit=0;
    Object.keys(want).forEach(function(k){
      nw+=want[k];
      hit+=Math.min(want[k],have[k]||0);
    });
    Object.keys(have).forEach(function(k){nh+=have[k];});
    /* divided by the BIGGER of the two, so it is punished in both
       directions. Dividing by the slide's own count alone said a slide
       holding one text box fitted a three-item arrangement perfectly —
       every item it had could be placed, which is true and useless
       (2026-08-22, caught in the browser). */
    var tot=Math.max(nw,nh);
    return tot?(hit/tot):0;
  }
  function arrBest(sl){
    var best=null,bs=0;
    arrList().forEach(function(a){
      var s=arrScore(a,sl);
      if(s>bs){bs=s;best=a;}
    });
    return best?{arr:best,score:bs}:null;
  }
  /* applying one is matchSlide from the stored slide. It is spliced in as
     a temporary slide rather than matchSlide being re-signed, because
     matchSlide's pairing is characterised by tests and is the one thing
     here that must not change. */
  function arrApply(arr,idx){
    var sl=pres.slides[idx]; if(!sl||!arr) return 0;
    pres.slides.push({layout:'blank',panes:[],
      annots:deep(arr.annots||[])});
    var r=matchSlide(pres.slides.length-1,idx);
    pres.slides.pop();
    return r?r.moved:0;
  }
  /* ---- MATCHING ONE OBJECT TO ANOTHER ----------------------------------
     (2026-08-22, user: "click on an object, and be like 'match object to
     this', then if you click on something else it matches it to it ...
     then if you click on another slide it says in the ribbon something
     like 'matching to object on slide xx' with a cancel button as well.
     Would be good if there was the reverse as well".)

     Match slide answers "make this whole slide look like that one" and
     pairs items up by guessing. This answers the question that needs no
     guessing at all: you point at the two things yourself. It is the
     escape hatch for every case the bucket heuristic cannot get right —
     two paragraphs that belong the other way round, an item whose
     counterpart is a different kind, a look you want from three slides
     away.

     TWO DIRECTIONS, because which end you have selected depends on which
     one you noticed first:
       'to'   — the selection is the MODEL; click things to change them.
                Stays armed, so one look can be pushed to a dozen objects.
       'from' — the selection is what CHANGES; click the model once.
     Armed state lives here and nowhere else; the canvas reads it at the
     top of its mousedown handler. */
  var matchArm=null;
  var matchPick=applyPickAll();
  function matchLabelOf(sl,i){
    var a=(sl&&sl.annots||[])[i];
    return a?annotLabel(a):'object';
  }
  /* THE THREE POINT-AT-IT VERBS, as a menu of their own (T89).
     They ship as rows inside the Arrange menu, which lives on the
     CONTEXTUAL Object tab: select something, find the tab, open the
     menu, scroll past thirty alignment rows. That is three clicks and a
     scroll for the one gesture in this editor that is genuinely worth
     knowing about. The Objects pane is open while you work, so it gets
     the same three rows behind one button.

     Nothing new happens here: each row calls armMatch with the same
     direction string the Arrange menu passes it. */
  function matchMenuAt(btn){
    var old=$('#objmatch-menu'); if(old) old.remove();
    var m=document.createElement('div');
    m.className='sh-menu match-menu';m.id='objmatch-menu';
    menuHead(m,'point at what to match');
    [['to','Copy this look to objects I click…',
      'Then click each object that should take it'],
     ['from','Take the look of an object I click…',
      'Then click the one object whose look you want here'],
     ['layout','Lay these out like a group I click…',
      'Then click a group whose arrangement these should copy. The '
      +'look does not travel — only the positions and sizes']]
      .forEach(function(o){
        var b=document.createElement('button');
        b.className='dbtn vw-opt';
        /* the icon is trusted bic() markup; the LABEL stays a text node */
        b.innerHTML=bic('swap')+' ';
        b.appendChild(document.createTextNode(o[1]));
        b.title=o[2];
        b.addEventListener('click',function(e){
          e.stopPropagation();overlayDrop(m);armMatch(o[0]);});
        m.appendChild(b);
      });
    overlayMount(btn,m);               /* on the stack (T213) */
  }
  function armMatch(dir){
    var s=pres.slides[cur],idxs=selIdxs().filter(function(i){
      return (s&&s.annots||[])[i];});
    if(!idxs.length){
      toast('Select the object you want to match first');
      return;
    }
    /* 'to' pushes ONE look outwards, so it takes the primary selection —
       three models and one target is a question with no answer. 'from'
       genuinely wants the lot: several objects can all take one model. */
    if(dir==='to') idxs=[(typeof selAnnot==='number')?selAnnot:idxs[0]];
    if(dir==='layout'&&idxs.length<2){
      toast('Select the objects you want laid out \u2014 two or more');
      return;
    }
    matchArm={dir:dir,slide:cur,idxs:idxs,n:0};
    deckEl.classList.add('matching');
    syncMatchBar();
  }
  function cancelMatch(){
    if(!matchArm) return;
    var n=matchArm.n;
    matchArm=null;
    deckEl.classList.remove('matching');
    syncMatchBar();
    if(n) toast(n+' object'+(n===1?'':'s')+' matched. Ctrl+Z undoes it.');
  }
  /* ---- THE SAME VERB, ONE LEVEL UP (T66, 2026-08-29) -----------------
     Matching a slide worked, but you picked the other slide out of a
     menu that listed it by number and title -- so the gesture was read a
     name in a menu, find the same number in the strip, and hope they are
     the same slide ("you have to cross reference with the thumbnails on
     the side. It would be good if you just clicked it, then clicked the
     thumbnail of the slides you wanted to match").
     The menu stays -- it is still the fastest way when you know the
     number -- and this arms the pointing version instead. Deliberately
     the same shape as matchArm above: same bar, same Esc, same running
     count, both directions. Which end you have is again which one you
     noticed first:
       'from' -- THIS slide takes the layout of the thumbnail you click.
                 One shot; a slide has one layout, so a second click
                 would only undo the first.
       'to'   -- the thumbnails you click take THIS slide's layout.
                 Stays armed: that is the one that scales. */
  var slideArm=null;
  function armSlideMatch(dir){
    if((pres.slides||[]).length<2){
      toast('Add another slide first \u2014 there is nothing to match');
      return;
    }
    slideArm={dir:dir,slide:cur,n:0};
    deckEl.classList.add('matching','slide-matching');
    syncMatchBar();
    renderFilm();
  }
  function cancelSlideMatch(){
    if(!slideArm) return;
    var n=slideArm.n;
    slideArm=null;
    deckEl.classList.remove('matching','slide-matching');
    syncMatchBar();
    renderFilm();
    if(n) toast(n+' slide'+(n===1?'':'s')+' matched. Ctrl+Z undoes it.');
  }
  /* one click on one thumbnail. Returns true when it consumed the click,
     which is what stops the strip from also NAVIGATING to that slide. */
  function slideMatchHit(i){
    if(!slideArm) return false;
    var from=(slideArm.dir==='from')?i:slideArm.slide;
    var to=(slideArm.dir==='from')?slideArm.slide:i;
    if(from===to){
      toast('That is the slide you started from');
      return true;
    }
    var r=matchSlide(from,to);
    if(!r) return true;
    if(!r.moved){
      toast('Slide '+(i+1)+' and slide '+(slideArm.slide+1)
        +' have no matching items \u2014 nothing to copy a layout from');
      return true;
    }
    slideArm.n+=1;
    markDirty();
    var note='Matched '+r.moved+' item'+(r.moved===1?'':'s')
      +' on slide '+(to+1);
    if(r.missing.length)
      note+=' \u2014 '+r.missing.length+' kind'
        +(r.missing.length===1?'':'s')+' had nothing to match';
    if(slideArm.dir==='from'){
      cancelSlideMatch();
      refresh();
      toast(note+'. Ctrl+Z undoes it.');
    } else {
      syncMatchBar();
      refresh();
      toast(note+' \u2014 keep clicking, or press Esc');
    }
    return true;
  }
  /* the copy loop, once: matchProp's rule (undefined on the model means
     delete on the target, a name is never deleted) over the wanted keys */
  function matchCopy(from,to,want){
    if(!from||!to||from===to) return false;
    MATCH_PROPS.forEach(function(p){
      if(want[p]) matchProp(from,to,p);
    });
    return true;
  }
  function matchHit(idx){
    if(!matchArm) return;
    var s=pres.slides[cur];
    var hit=(s&&s.annots||[])[idx];
    var src=pres.slides[matchArm.slide];
    if(!hit||!src) return;
    var n=0;
    if(matchArm.dir==='layout'){
      /* A layout pattern needs the ARMED objects' rendered rectangles.
         The stage only contains the current slide, so matching elsewhere
         would apply their old array indexes to unrelated live objects.
         Keep the mode armed: going back to the named slide is the safe,
         predictable way to finish the gesture. */
      if(matchArm.slide!==cur){
        toast('Match layout works on the slide you armed it on \u2014 go '
          +'back to slide '+(matchArm.slide+1));
        return;
      }
      /* the reference is the group (or the run) the clicked object is
         part of, and the selection is what gets tidied to match it */
      var layer2=stage.querySelector('.annot-layer');
      var ref=refGroupAt(layer2,s,idx);
      var pat=readPattern(layer2,s,ref);
      if(!pat){
        toast('That object is not part of a row or a group \u2014 click '
          +'one that is');
        return;
      }
      n=applyPattern(layer2,s,matchArm.idxs,pat);
      if(!n){toast('Nothing to lay out');return;}
      matchArm.n+=n;
      markDirty();refresh();
      toast(n+' laid out like the '+pat.n+' you clicked \u2014 '
        +(pat.horiz?'across':'down')+', '
        +(pat.align==='mid'?'centres':pat.align==='near'
          ?(pat.horiz?'top edges':'left edges')
          :(pat.horiz?'bottom edges':'right edges'))
        +' agreeing, '+gapMm(pat.gap,pat.horiz)+' apart');
      cancelMatch();
      return;
    }
    if(matchArm.dir==='to'){
      var model=(src.annots||[])[matchArm.idxs[0]];
      /* the KIND of the thing being changed decides which properties are
         meaningful — pushing a text size onto a shape is a control that
         does nothing, and applyFieldsFor already knows that */
      if(matchCopy(model,hit,applyFieldsFor(matchPick,hit.k))) n++;
    } else {
      matchArm.idxs.forEach(function(i){
        var to=(src.annots||[])[i];
        if(matchCopy(hit,to,applyFieldsFor(matchPick,to.k))) n++;
      });
    }
    if(!n) return;
    matchArm.n+=n;
    markDirty();refresh();
    /* 'from' has exactly one model to find, so finding it finishes the
       job; 'to' stays armed so a look can be pushed to a dozen things
       without re-arming between each */
    if(matchArm.dir==='from') cancelMatch();
    else {syncMatchBar();
      toast(matchArm.n+' matched — keep clicking, or press Esc');}
  }
  /* ---- MATCHING A LAYOUT, NOT A LOOK -----------------------------------
     "Make these three look like the four above" (TASKS T8). Which is a
     third question, and none of the three neighbours above answers it:

       Match slide     copies a whole slide's arrangement, item for item.
       Match object    copies one object's PROPERTIES onto another.
       Arrangements    apply a saved slide's shape.

     This one copies neither properties nor positions. It copies the
     PATTERN — the axis a group runs along, the edge or centre its
     members agree on, the rhythm of the gaps between them, and where the
     run starts. Nothing about size or colour travels: two rows can look
     alike in the only sense that matters here while holding completely
     different things, and the counts need not even match, which is why
     "these three" can be laid out like "those four".

     The cross-axis position is NOT copied. Adopting it would drop the
     selection on top of the reference; what is adopted is the RULE (tops
     agree / centres agree / bottoms agree), applied to where the
     selection already is, so it tidies into its own band.

     Gaps are taken as the MEDIAN of the reference's gaps. One odd gap in
     a row of five is a mistake being copied, not a rhythm. */
  function patSpread(v){
    return Math.max.apply(null,v)-Math.min.apply(null,v);
  }
  function readPattern(layer,s,idxs){
    var rs=[];
    idxs.forEach(function(i){
      var r=annotRectPct(layer,s,i);
      if(r) rs.push(r);
    });
    if(rs.length<2) return null;
    /* the axis is whichever way the group actually runs */
    var cx=rs.map(function(r){return (r.l+r.r)/2;});
    var cy=rs.map(function(r){return (r.t+r.b)/2;});
    var horiz=patSpread(cx)>=patSpread(cy);
    rs.sort(function(p,q){return horiz?(p.l-q.l):(p.t-q.t);});
    var gaps=[];
    for(var k=1;k<rs.length;k++)
      gaps.push(horiz?(rs[k].l-rs[k-1].r):(rs[k].t-rs[k-1].b));
    gaps.sort(function(a,b){return a-b;});
    var gap=gaps[Math.floor(gaps.length/2)];
    /* which edge they agree on: the one they disagree about least */
    var near=rs.map(function(r){return horiz?r.t:r.l;});
    var mid=rs.map(function(r){
      return horiz?(r.t+r.b)/2:(r.l+r.r)/2;});
    var far=rs.map(function(r){return horiz?r.b:r.r;});
    var sn=patSpread(near),sm=patSpread(mid),sf=patSpread(far);
    var align=(sn<=sm&&sn<=sf)?'near':((sf<=sm)?'far':'mid');
    return {horiz:horiz,gap:gap,align:align,n:rs.length,
      start:horiz?rs[0].l:rs[0].t};
  }
  /* the value the TARGETS should agree on, read off where they are now
     by the reference's own rule — so they line up with each other, in
     their own band, rather than jumping onto the reference */
  function patCross(rs,pat){
    var v=rs.map(function(r){
      return pat.align==='near'?(pat.horiz?r.t:r.l)
        :pat.align==='far'?(pat.horiz?r.b:r.r)
        :(pat.horiz?(r.t+r.b)/2:(r.l+r.r)/2);});
    if(pat.align==='near') return Math.min.apply(null,v);
    if(pat.align==='far') return Math.max.apply(null,v);
    return v.reduce(function(a,b){return a+b;},0)/v.length;
  }
  function applyPattern(layer,s,idxs,pat){
    var rs=[];
    dropTiedCaptions(s,idxs).forEach(function(i){
      var a=(s.annots||[])[i];
      /* a pinned object is not moved by anything else on the canvas and
         is not moved by this either (T3) */
      if(!a||pinned(a)) return;
      var r=annotRectPct(layer,s,i);
      if(r) rs.push({i:i,a:a,r:r});
    });
    if(!rs.length) return 0;
    rs.sort(function(p,q){
      return pat.horiz?(p.r.l-q.r.l):(p.r.t-q.r.t);});
    var cross=patCross(rs.map(function(x){return x.r;}),pat);
    var pos=pat.start,n=0;
    rs.forEach(function(x){
      var len=pat.horiz?(x.r.r-x.r.l):(x.r.b-x.r.t);
      var da=pos-(pat.horiz?x.r.l:x.r.t);
      var now=pat.align==='near'?(pat.horiz?x.r.t:x.r.l)
        :pat.align==='far'?(pat.horiz?x.r.b:x.r.r)
        :(pat.horiz?(x.r.t+x.r.b)/2:(x.r.l+x.r.r)/2);
      var dc=cross-now;
      /* DELTAS, never absolute coordinates. An auto-sized text box and
         an aspect-fitted figure frame both answer annotRectPct with
         their RENDERED rect, which is not a.x/a.y — so moving by the
         difference is the only arithmetic that is right for every kind
         (the same reason snapping works on the bounding box). */
      shiftAnnot(x.a,pat.horiz?da:dc,pat.horiz?dc:da);
      pos+=len+pat.gap;
      n++;
    });
    return n;
  }
  /* WHAT COUNTS AS THE REFERENCE GROUP when you click one object. A real
     group is unambiguous and wins. Otherwise it is the run the object is
     part of: the items sharing its band, which is the same "is this next
     to that" test the equal-gap snapping uses (T7) — so the thing you
     see as a row is the thing that gets read as one. */
  function bandMates(layer,s,idx,horiz){
    var r0=annotRectPct(layer,s,idx); if(!r0) return [];
    var out=[];
    (s.annots||[]).forEach(function(a,i){
      if(!a||a.hide||a.k==='arrow') return;
      var r=annotRectPct(layer,s,i); if(!r) return;
      if(i===idx){out.push(i);return;}
      /* ACROSS the run, they must overlap generously — enough that a
         person would call them the same row */
      var ov=horiz?(Math.min(r.b,r0.b)-Math.max(r.t,r0.t))
                  :(Math.min(r.r,r0.r)-Math.max(r.l,r0.l));
      var ext=horiz?Math.min(r.b-r.t,r0.b-r0.t)
                   :Math.min(r.r-r.l,r0.r-r0.l);
      if(!(ext>0&&ov>=ext*0.5)) return;
      /* ALONG the run, they must sit BESIDE it rather than over it. A
         slide-wide background, or the empty cell frame a new slide
         starts with, overlaps every row's band and would otherwise be
         read as a member of all of them — caught in the browser
         2026-08-25, where the placeholder joined the reference row and
         dragged the run's start 92px to the left of where it looked. */
      var al=horiz?(Math.min(r.r,r0.r)-Math.max(r.l,r0.l))
                  :(Math.min(r.b,r0.b)-Math.max(r.t,r0.t));
      var alen=horiz?Math.min(r.r-r.l,r0.r-r0.l)
                    :Math.min(r.b-r.t,r0.b-r0.t);
      if(al>alen*0.5) return;
      out.push(i);
    });
    return out;
  }
  function refGroupAt(layer,s,idx){
    var mem=groupMembers(s,idx);
    if(mem.length>1) return mem;
    var row=bandMates(layer,s,idx,true);
    var col=bandMates(layer,s,idx,false);
    return (row.length>=col.length?row:col);
  }
  function syncMatchBar(){
    var bar=$('#matchbar'); if(!bar) return;
    bar.hidden=!matchArm&&!slideArm;
    /* WHAT TRAVELS is an object-level question -- a slide match pairs
       items up by kind and moves the arrangement, so there is no list of
       properties to tick */
    var mp=$('#match-props');
    if(mp) mp.hidden=!!slideArm;
    if(slideArm){
      var w0=$('#match-what');
      if(w0) w0.innerHTML=(slideArm.dir==='to')
        ? (bic('swap')+' Click the thumbnails that should be laid out '
          +'like <b>slide '+(slideArm.slide+1)+'</b>'
          +(slideArm.n?(' &middot; '+slideArm.n+' done'):''))
        : (bic('swap')+' Click the thumbnail whose layout <b>slide '
          +(slideArm.slide+1)+'</b> should take');
      return;
    }
    if(!matchArm) return;
    var w=$('#match-what');
    var src=pres.slides[matchArm.slide];
    var name=matchLabelOf(src,matchArm.idxs[0]);
    if(matchArm.idxs.length>1) name=matchArm.idxs.length+' objects';
    if(w&&matchArm.dir==='layout'){
      w.innerHTML=bic('align')+' <b>'+esc(name)
        +'</b> will be laid out like the group or row you click '
        +'&mdash; the axis, the alignment and the spacing, not the look';
      return;
    }
    if(w) w.innerHTML=(matchArm.dir==='to')
      ? (bic('swap')+' Copying the look of <b>'+esc(name)+'</b> on slide '
        +(matchArm.slide+1)+' &mdash; click an object to change it'
        +(matchArm.n?(' &middot; '+matchArm.n+' done'):''))
      : (bic('swap')+' <b>'+esc(name)+'</b> on slide '+(matchArm.slide+1)
        +' will take the look of the object you click');
  }
  (function(){
    var mc=$('#match-cancel');
    if(mc) mc.addEventListener('click',function(e){
      e.stopPropagation();cancelSlideMatch();cancelMatch();});
    var mb=$('#match-props'),mm=$('#match-props-menu');
    if(!mb||!mm) return;
    /* the same vocabulary the Apply dialog uses — "size, position, shape,
       colour" is exactly what APPLY_PROPS already groups, so this is that
       list rather than a second one that could disagree with it. Its own
       tick state, though: what you want carried between two objects you
       are pointing at is not the same question as what you want pushed
       across a whole deck. */
    function build(){
      mm.innerHTML='';
      var head=document.createElement('div');
      head.className='mp-head';
      [['All',function(){matchPick=applyPickAll();}],
       ['None',function(){matchPick={};}]].forEach(function(pr){
        var b=document.createElement('button');
        b.className='dbtn mp-b';b.textContent=pr[0];
        b.addEventListener('click',function(e){
          e.stopPropagation();pr[1]();build();});
        head.appendChild(b);
      });
      mm.appendChild(head);
      APPLY_GROUPS.forEach(function(g){
        var rows=APPLY_PROPS.filter(function(r){return r[2]===g;});
        if(!rows.length) return;
        menuHead(mm,g.toLowerCase());
        rows.forEach(function(r){
          var lab=document.createElement('label');
          lab.className='find-ck';
          var ck=document.createElement('input');
          ck.type='checkbox';ck.checked=!!matchPick[r[0]];
          ck.addEventListener('click',function(e){e.stopPropagation();});
          ck.addEventListener('change',function(){
            if(ck.checked) matchPick[r[0]]=1; else delete matchPick[r[0]];
          });
          lab.appendChild(ck);
          lab.appendChild(document.createTextNode(' '+r[1]));
          mm.appendChild(lab);
        });
      });
    }
    mb.addEventListener('click',function(e){
      e.stopPropagation();
      var open=mm.hidden;
      if(open) build();
      mm.hidden=!open;
      mb.setAttribute('aria-expanded',open?'true':'false');
    });
    document.addEventListener('click',function(e){
      if(!mm.hidden&&!mm.contains(e.target)&&e.target!==mb)
        mm.hidden=true;
    });
  })();
  (function(){
    /* both copies of the Layouts menu (T131): the Home one used to hide
       the tidy row entirely, so the same-named button did less work
       depending on the tab */
    var hosts=['#hm-lay-tidy'].map(function(sel){
      return $(sel);}).filter(Boolean);
    if(!hosts.length) return;
    var host={querySelectorAll:function(q){
      var out=[];hosts.forEach(function(h){
        out=out.concat([].slice.call(h.querySelectorAll(q)));});
      return out;}};
    $$('[data-tidy]',host).forEach(function(b){
      b.addEventListener('click',function(e){
        e.stopPropagation();
        var s=pres.slides[cur]; if(!s) return;
        var lm=$('#lay-menu'); if(lm) overlayHide(lm);
          var n=arrangeSlide(s,stage.querySelector('.annot-layer'),
          arrangeOpts(b.getAttribute('data-tidy')));
        if(!n){toast('There is nothing on this slide to arrange');return;}
        markDirty();refresh();
        toast(n+' item'+(n===1?'':'s')+' arranged. Ctrl+Z undoes it.');
      });
    });
  })();
  /* READING ORDER, once, for everyone who needs it. The array is the
     order you happened to draw things in, which is nobody's idea of a
     sequence: draw the bottom caption first and it would animate first,
     and be Figure 1. A 4% band counts as "the same line", so a row of
     items reads across before the next row down.

     Hoisted here from the animation pane it was written in, because
     figure numbering needs the same order and two sweeps that agreed
     today would not agree forever (2026-08-25, T18). */
  function orderedIdx(s2){
    var base=(s2.annots||[])
      .map(function(a,i){return {a:a,i:i};})
      .filter(function(p2){return p2.a&&!p2.a.hide;})
      .sort(function(p2,q2){
        var ay=(p2.a.k==='arrow')?Math.min(p2.a.y1,p2.a.y2):(p2.a.y||0);
        var by=(q2.a.k==='arrow')?Math.min(q2.a.y1,q2.a.y2):(q2.a.y||0);
        var ax=(p2.a.k==='arrow')?Math.min(p2.a.x1,p2.a.x2):(p2.a.x||0);
        var bx=(q2.a.k==='arrow')?Math.min(q2.a.x1,q2.a.x2):(q2.a.x||0);
        return Math.abs(ay-by)>4?(ay-by):(ax-bx);
      })
      .map(function(p2){return p2.i;});
    /* THE AUTHORED ORDER (T106). `s2.rord` is a list of oids,
       first-to-last, written by the Reading order panel; absent means
       the sweep above is the answer, which it was for every deck saved
       before this existed. Resolved HERE so all six consumers — builds,
       figure numbers, flip matching, the review export and its heading
       — inherit it from the one function they already call, and none
       can drift.
       Objects the list does not name (added after the order was set,
       or unhidden since) read LAST, in sweep order among themselves:
       predictable, and the panel shows the truth the moment it opens.
       A listed oid that no longer exists is simply ignored.
       DOM order stays STORAGE order on purpose: the annots array is
       z-order (Bring forward is a splice), and reading order must not
       reshuffle what overlaps what. */
    var rord=s2.rord;
    if(!Array.isArray(rord)||!rord.length) return base;
    var pos={};
    rord.forEach(function(id,n2){
      if(typeof id==='string'&&!(id in pos)) pos[id]=n2;});
    var ranked=[],rest=[];
    base.forEach(function(i){
      var a=(s2.annots||[])[i];
      var r=(a&&a.oid!=null)?pos[a.oid]:undefined;
      if(r!=null) ranked.push({i:i,r:r}); else rest.push(i);
    });
    ranked.sort(function(x,y){return x.r-y.r;});
    return ranked.map(function(x){return x.i;}).concat(rest);
  }
  /* ---- WHERE THIS FIGURE CAME FROM ------------------------------------
     (TASKS T19 and T20.) The deck already knows all of this and had no
     way to say it: a frame names a card by anchor, chains.py computed
     the lineage at parse time, the trace view already draws it, and the
     deck already keeps a saved copy of every placed card. What was
     missing was a door from a frame ON A SLIDE to any of it.

     STALENESS, and the honest version of it. There is no timestamp
     anywhere in this format — not on a card, not on an embedded
     snapshot — so "the notebook output is newer than the deck's
     snapshot" cannot be answered by comparing dates, and inventing a
     date at save time would only tell you when the deck was saved.
     What CAN be answered, exactly, is whether the live card and the
     deck's saved copy still say the same thing. That is the question
     that actually matters — a stale snapshot is one that DIFFERS — and
     it is answered by comparing the two bodies. Where the notebook is
     not open there is nothing to compare against, and it says that
     rather than guessing.

     RE-SYNC (T20) is the other half and is almost free once the first
     half exists: a frame resolves its content by ref at render time, so
     a re-executed notebook already shows through the moment it is
     reopened. What was missing was the deliberate act — "take the live
     version for THIS figure" — which replaces the deck's saved copy and
     leaves position, crop and size alone, because those live on the
     annotation and were never part of the snapshot. The renderer still
     never executes anything: the notebook is re-run by the user. */
  /* WHICH REFERENCE THIS OBJECT IS SHOWING. A placed cell has one;
     a FLIP BOOK has one per frame and shows the frame it is on — and
     isFigure counts a flip book as a figure, the save path treats its
     frames as refs exactly like a placed cell, and T18 numbers it. Only
     provOf disagreed, so six notebook figures in one object had no
     provenance, no staleness answer and no way to be re-synced
     (2026-08-26 audit, T58). */
  function provRef(a){
    if(!a) return '';
    if(a.k==='cell') return a.ref||'';
    /* a chart born from a table card keeps the card's ref (T117), so
       every door that asks "does this have a source" says yes for it */
    if(a.k==='chart') return a.ref||'';
    if(a.k==='flip'){
      var fr=flipFrames(a),sel=fr[a.at||0]||fr[0];
      return (sel&&sel.ref)||'';
    }
    return '';
  }
  /* T307: EVERY SOURCE THIS ANNOT HAS, not just the one on show.
     provRef answers for a flip book with whichever page `a.at` happens
     to be on, so "Update figures" on a seven-page book compared and
     refreshed exactly one page and left the other six stale with
     nothing said -- and embedIfAbsent kept the pixels of that one page
     only. The two picker doors hid it by setting `a.at` to the frame
     they had just pushed. */
  function provRefs(a){
    if(!a) return [];
    if(a.k==='flip'){
      var out=[];
      flipFrames(a).forEach(function(f){
        if(f&&f.ref&&out.indexOf(f.ref)<0) out.push(f.ref);});
      return out;
    }
    var r=provRef(a);
    return r?[r]:[];
  }
  function provOf(a){
    var ref=provRef(a);
    if(!ref) return null;
    var live=ITEMS[ref]||null;
    if(!live&&String(ref).indexOf('::')<0){
      for(var i=0;i<APP.order.length;i++){
        var k=nsKey(APP.order[i],ref);
        if(ITEMS[k]){live=ITEMS[k];break;}
      }
    }
    var saved=embFor(ref)||null;
    var it=resolveRef(ref);
    return {live:live,saved:saved,it:it,ref:ref};
  }
  /* EVERY figure on the deck whose notebook has moved on. provState
     could only ever answer for one annotation, because renderProvPane
     was its only caller — so there was no deck-wide staleness list and
     no deck-wide update, while the parallel feature for pictures got
     both doors (2026-08-26 audit, T58). */
  /* T280: `only` is a slide index, or undefined/-1 for the whole deck.
     Defaulted so every existing caller keeps the deck-wide answer. */
  function staleFigures(only){
    var out=[];
    (pres.slides||[]).forEach(function(sl,si){
      if(only>=0&&si!==only) return;
      (sl.annots||[]).forEach(function(a,ai){
        if(!a||a.hide) return;
        /* A native chart keeps its source in the annotation rather than
           EMBED. Ask the chart for a non-mutating candidate so it joins
           the same approval window instead of changing before the
           snapshots have even been shown (T328). */
        if(a.k==='chart'){
          if(typeof chartSourceVersion==='function'&&chartSourceVersion(a))
            out.push({si:si,ai:ai,a:a,st:'stale',ref:a.ref});
          return;
        }
        /* T307: one entry per SOURCE, so a flip book's other pages are
           not silently left behind by the refresh that claims to have
           covered them */
        provRefs(a).forEach(function(ref){
          var st=provState(provOf({k:'cell',ref:ref}));
          if(st==='stale'||st==='nosaved')
            out.push({si:si,ai:ai,a:a,st:st,ref:ref});
        });
      });
    });
    return out;
  }
  /* every source stem a placed frame points at, whatever kind of
     file it is -- provRef already answers "does this annot have a
     source" for cells and flip frames alike (T123) */
  function refSourceStems(only){
    var stems={};
    (pres.slides||[]).forEach(function(sl,si){
      if(only>=0&&si!==only) return;
      (sl.annots||[]).forEach(function(a){
        var ref=a&&provRef(a); if(!ref) return;
        var pr=splitRef(normRef(ref)||String(ref||''));
        if(pr[0]) stems[pr[0]]=1;
        if(a.k==='flip'&&Array.isArray(a.frames))
          a.frames.forEach(function(f){
            if(!f||!f.ref) return;
            var fr=splitRef(normRef(f.ref)||String(f.ref||''));
            if(fr[0]) stems[fr[0]]=1;
          });
      });
    });
    return Object.keys(stems);
  }
  /* The stem in a provenance ref is a display identity, not a path.  Keep
     the path remembered on the placed annotation beside it so a closed
     notebook can be reopened for an explicit refresh (T374). */
  function refSourcePaths(only){
    var paths={};
    (pres.slides||[]).forEach(function(sl,si){
      if(only>=0&&si!==only) return;
      (sl.annots||[]).forEach(function(a){
        function add(ref,holder){
          if(!ref||!holder||!holder.nbpath) return;
          var pr=splitRef(normRef(ref)||String(ref||''));
          if(pr[0]&&!paths[pr[0]]) paths[pr[0]]=String(holder.nbpath);
        }
        if(a&&a.k==='flip'){
          flipFrames(a).forEach(function(f){add(f&&f.ref,f);});
        } else if(a){
          add(provRef(a),a);
        }
      });
    });
    return paths;
  }
  /* THE TOAST, and it has to be true in all four outcomes (JVR-01):
     everything current, some updated, some failed, all failed. The
     failure clause comes FIRST and NAMES the sources, because "6
     figures updated" sitting beside a source that was never read is
     exactly the sentence that misleads — and because "a source" with no
     name is not enough to go and look at. `read` is how many sources
     the disk actually gave back, `bad` the stems whose read threw, `n`
     the figures updated, `tried` how many stale ones were found. Note
     what is NOT claimed when anything failed: "every figure matches its
     source" is narrowed to "the sources that could be read", and with
     nothing read at all it becomes "nothing was checked against disk". */
  function resyncMsg(read,bad,n,tried){
    var fail=bad.length?('Could not read '+bad.length+' source'
      +(bad.length===1?'':'s')+': '+bad.join(', ')):'';
    var rest;
    if(n) rest=n+' figure'+(n===1?'':'s')+' updated from '
      +(n===1?'its source':'their sources')
      +' \u2014 position, size and crop unchanged';
    else if(tried) rest='Could not read the live cards — are their '
      +'sources still open?';
    else if(fail) rest=read
      ?('The '+read+' source'+(read===1?'':'s')
        +' that could be read already match')
      :'Nothing was checked against disk';
    else rest=read
      ?('Re-read '+read+' source'+(read===1?'':'s')
        +' \u2014 every figure already matches')
      :'Every figure on this deck already matches its source';
    return fail?(fail+'. '+rest):rest;
  }
  /* T280: `only` scopes it to one slide; `quiet` hands the reporting to
     the merged verb, which has a picture half to report as well and only
     one #deck-toast to say it in. Both default to the old behaviour. */
  function resyncAllFigures(only,quiet){
    /* ONE VERB (T123). "Update figures" used to compare against
       whatever the open tabs happened to hold, so refreshing a figure
       whose FILE had changed was a four-step dance: close the deck,
       find the tab, press its reload button, come back. The re-read
       from disk is now the first half of this click -- each referenced
       tab reloads in place, then the comparison runs against what the
       disk actually says. Web mode skips the reload half honestly: a
       dropped file left no handle to re-read. */
    var sourcePaths=refSourcePaths(only);
    var jobs=refSourceStems(only).map(function(st){
      return (APP.reloadTab?APP.reloadTab(st,sourcePaths[st])
        :Promise.resolve({stem:st,ok:false,reason:'notapp'}));
    });
    return Promise.all(jobs).then(function(res){
      /* WHAT THE DISK ACTUALLY SAID (JVR-01). A failed read used to
         arrive as the same `false` a declined URL arrives as, and the
         count kept only the truthy ones. So a run in which every
         read threw went on to compare the saved copies against the SAME
         cached cards they were taken from, found nothing stale, and said
         "every figure already matches its source" — a statement about
         memory dressed as a statement about disk. Only reason 'failed'
         is a failure; 'notapp', 'url' and 'closed' are honest declines
         and stay silent, exactly as before. */
      var reread=0,bad=[];
      res.forEach(function(r){
        if(!r) return;
        if(r.ok){reread++;return;}
        if(r.reason==='failed') bad.push(r.stem);
      });
      var list=staleFigures(only);
      if(!list.length){
        if(!quiet) toast(resyncMsg(reread,bad,0,0),bad.length?7000:0);
        return {n:0,reread:reread,bad:bad,tried:0};
      }
      /* T328: re-reading sources is harmless; replacing the kept copies
         is not. The old and new renderings are put side by side before
         this loop is allowed to write either EMBED or chart data. */
      return reviewFigureUpdates(list).then(function(accepted){
        if(!accepted){
          if(!quiet) toast('Kept the current figure copies');
          return {n:0,reread:reread,bad:bad,tried:list.length,
            cancelled:true};
        }
        var n=0,touched=[];
        list.forEach(function(p){
          if(!resyncFigure(p.a,p.ref)) return;
          n++;
          if(p.a&&p.a.k==='chart') return;
          var k=normRef(p.ref||provRef(p.a));
          if(k&&touched.indexOf(k)<0) touched.push(k);
        });
      /* T301: THE BUTTON THE USER LEARNED TO FEAR. It rewrites every
         stale figure in the deck at once, nothing else in the editor can
         put one back, and it does not even leave an undo entry -- so
         Ctrl+Z after it rewinds the previous slide edit instead
         (2026-09-05: "just too dangerous and I have lost too many
         things"). The verb is unchanged; what changes is that the
         sentence announcing it now ends in a way out. */
      if(!quiet){
        if(touched.length)
          toastUndo(resyncMsg(reread,bad,n,list.length),
            'Put them back',
            function(){
              var back=embRestore(touched);
              /* T305: embRestore unlinks what it restores, so a switch
                 reading "Live link" after the toast says the opposite
                 turns the live link ON when pressed. renderImgPane
                 no-ops on a closed pane, so this is free. */
              if(typeof imgPaneRefresh==='function') imgPaneRefresh();
              toast(back.n
                ?('Back to the figures from before \u2014 '+back.n
                  +' of them'+(back.unlinked?(', and '
                    +(back.unlinked===back.n?'they are':
                      back.unlinked+' are')
                    +' kept copies again rather than live links'):''))
                :'Nothing left to put back');
            },bad.length?12000:9000);
        else toast(resyncMsg(reread,bad,n,list.length),
          bad.length?7000:0);
      }
      return {n:n,reread:reread,bad:bad,tried:list.length};
      });
    });
  }
  window.SemDeckStaleFigures=staleFigures;   /* test hook */
  /* the only staleness question this format can answer honestly: does
     the deck's saved copy still say what the notebook says? */
  function provState(p){
    if(!p) return 'none';
    if(!p.live&&!p.saved) return 'missing';
    if(!p.live) return 'nolive';
    if(!p.saved) return 'nosaved';
    var a=liveCardHtml(p.ref),b=(p.saved&&p.saved.html)||'';
    if(!a) return 'nolive';
    return (a===b)?'same':'stale';
  }
  /* the LIVE card's body, in exactly the shape the save path captures
     it (cloneBody(...).outerHTML) — so "has the notebook moved on" is a
     comparison of like with like, not of one rendering against another.

     cloneBody falls back to the deck's OWN copy when the notebook is
     shut, which would make every figure look permanently in step. So
     the presence of a real card is checked first, and no card means no
     answer rather than a wrong one. */
  function liveCardHtml(ref){
    try{
      if(!cardEl(ref)) return '';
      var b=cloneBody(ref,1);      /* the NOTEBOOK's answer (T302) */
      return b?b.outerHTML:'';
    }catch(e){return '';}
  }
  /* T328: THE DECISION BEFORE THE WRITE. A refresh used to replace the
     only kept copy and then offer an undo toast after the damage. This
     native dialog shows the exact saved and live bodies (or the two chart
     drawings) side by side, and resolves true only from the worded
     acceptance button. Escape, the backdrop and Keep current all decline.

     It is built on demand because it holds live figure DOM -- often
     megabytes -- and there is no reason to keep any of that after the
     choice. */
  function reviewFigureUpdates(list){
    var rows=[];
    (list||[]).forEach(function(p){
      if(!p||!p.a) return;
      if(p.a.k==='chart'){
        var newer=(typeof chartSourceVersion==='function')
          ?chartSourceVersion(p.a):null;
        if(newer) rows.push({p:p,old:p.a,newer:newer,chart:true});
        return;
      }
      var live=liveCardHtml(p.ref),saved=embFor(p.ref);
      if(!live||((saved&&saved.html)===live)) return;
      rows.push({p:p,old:saved&&saved.html||'',newer:live,chart:false});
    });
    if(!rows.length) return Promise.resolve(false);
    return new Promise(function(done){
      var dlg=document.createElement('dialog');
      dlg.className='fig-review';
      var head=document.createElement('div');head.className='fig-review-h';
      var title=document.createElement('div');title.className='fig-review-t';
      title.id='fig-review-title';dlg.setAttribute('aria-labelledby',title.id);
      title.textContent=rows.length===1?'Review figure update'
        :'Review '+rows.length+' figure updates';
      head.appendChild(title);
      var sub=document.createElement('div');sub.className='fig-review-sub';
      sub.textContent='Nothing changes until you use the new version.';
      head.appendChild(sub);
      var keep=document.createElement('button');
      keep.type='button';keep.className='dbtn';
      keep.innerHTML=bic('none')+' Keep current';head.appendChild(keep);
      var use=document.createElement('button');
      use.type='button';use.className='dbtn primary';
      use.innerHTML=bic('reload')+' Use '+(rows.length===1
        ?'new version':('all '+rows.length+' new versions'));
      head.appendChild(use);dlg.appendChild(head);
      var intro=document.createElement('div');intro.className='fig-review-note';
      intro.textContent='Saved in the deck is on the left; the source now '
        +'is on the right. Position, size and crop stay unchanged.';
      dlg.appendChild(intro);
      var body=document.createElement('div');body.className='fig-review-list';
      function frame(label,node,empty){
        var col=document.createElement('div');col.className='fig-review-col';
        var cap=document.createElement('div');cap.className='fig-review-cap';
        cap.textContent=label;col.appendChild(cap);
        var box=document.createElement('div');box.className='fig-review-frame';
        if(node) box.appendChild(node);
        else {
          var miss=document.createElement('div');
          miss.className='fig-review-empty';miss.textContent=empty;
          box.appendChild(miss);
        }
        col.appendChild(box);return col;
      }
      rows.forEach(function(r){
        var item=document.createElement('section');
        item.className='fig-review-item';
        var lab=document.createElement('div');lab.className='fig-review-label';
        var pr=splitRef(r.p.ref||'');
        lab.textContent='Slide '+(r.p.si+1)+' · '
          +(pr[0]?pr[0]+' · ':'')+(pr[1]||'chart');
        item.appendChild(lab);
        var pair=document.createElement('div');pair.className='fig-review-pair';
        if(r.chart){
          pair.appendChild(frame('Saved in the deck',chartSvg(r.old),''));
          pair.appendChild(frame('Source now',chartSvg(r.newer),''));
        } else {
          var part=r.p.a.k==='cell'?partOf(r.p.a):'figure';
          pair.appendChild(frame('Saved in the deck',r.old
            ?framePartFromSnap(r.old,part):null,'No copy has been kept yet'));
          pair.appendChild(frame('Source now',
            framePartFromSnap(r.newer,part),'Nothing to show'));
        }
        item.appendChild(pair);body.appendChild(item);
      });
      dlg.appendChild(body);document.body.appendChild(dlg);
      var settled=false;
      function finish(ok){
        if(settled) return;settled=true;
        if(dlg.open) dlg.close();
        if(dlg.parentNode) dlg.parentNode.removeChild(dlg);
        done(ok);
      }
      keep.addEventListener('click',function(){finish(false);});
      use.addEventListener('click',function(){finish(true);});
      dlg.addEventListener('cancel',function(e){
        e.preventDefault();finish(false);});
      dlg.addEventListener('click',function(e){
        if(e.target!==dlg) return;
        var r=dlg.getBoundingClientRect();
        if(e.clientX<r.left||e.clientX>r.right
           ||e.clientY<r.top||e.clientY>r.bottom) finish(false);
      });
      dlg.showModal();
      if(typeof typeset==='function') typeset(dlg);
      /* Enter must not accept a destructive update by accident. */
      keep.focus();
    });
  }
  function reviewOneFigure(a,ref){
    if(!a) return Promise.resolve({n:0,missing:true});
    var p={si:cur,ai:selAnnot,a:a,ref:ref||provRef(a)};
    if(a.k==='chart'){
      if(!cardEl(p.ref)) return Promise.resolve({n:0,missing:true});
      if(typeof chartSourceVersion!=='function'||!chartSourceVersion(a))
        return Promise.resolve({n:0,same:true});
    } else {
      var st=provState(provOf(ref?{k:'cell',ref:ref}:a));
      if(st==='same') return Promise.resolve({n:0,same:true});
      if(st!=='stale'&&st!=='nosaved')
        return Promise.resolve({n:0,missing:true});
    }
    return reviewFigureUpdates([p]).then(function(ok){
      if(!ok) return {n:0,cancelled:true};
      return {n:resyncFigure(a,p.ref)};
    });
  }
  function renderProvPane(){
    var list=$('#provpane-list'),head=$('#provpane-count');
    var ttl=$('#provpane-t');
    if(!list) return;
    var s2=pres.slides[cur];
    /* The clicked item is the inspector's subject. A group's last member
       can be a different annotation with different provenance. */
    var a=s2&&typeof selAnnot==='number'&&(s2.annots||[])[selAnnot];
    list.innerHTML='';
    var p=provOf(a);
    if(!p){
      if(head) head.textContent='';
      if(ttl) ttl.textContent='Where this came from';
      var g=document.createElement('div');
      g.className='pf-ok';
      g.textContent='Select a frame that shows a notebook card. A drawn '
        +'shape or a text box has no source to point at.';
      list.appendChild(g);
      return;
    }
    var st=provState(p);
    if(ttl) ttl.textContent=(p.it&&p.it.title)||'This figure';
    var pr=splitRef(p.ref);
    if(head) head.textContent=(pr[0]||'?')+' \u00b7 '+(pr[1]||'?');

    function line(cls,h,w){
      var d=document.createElement('div');
      d.className='std-find std-'+cls;
      var t1=document.createElement('div');
      t1.className='std-h';t1.textContent=h;d.appendChild(t1);
      if(w){var t2=document.createElement('div');
        t2.className='std-why';t2.textContent=w;d.appendChild(t2);}
      list.appendChild(d);
      return d;
    }
    var msg={
      same:['In step with its notebook',
        'The card in the notebook and the copy saved with this deck say '
        +'the same thing.'],
      stale:['The notebook has moved on',
        'The card in the notebook no longer matches the copy saved with '
        +'this deck \u2014 re-run it, or take the live version below.'],
      nolive:['Showing the deck\u2019s saved copy',
        'That notebook is not open, so there is nothing to compare '
        +'against. This is the copy saved with the deck.'],
      nosaved:['Live from the notebook',
        'No copy is saved with the deck yet; it will be written the '
        +'next time you save.'],
      missing:['Nothing to show',
        'Neither the notebook nor a saved copy can be found for this '
        +'reference.']
    }[st]||['Unknown',''];
    line(st==='stale'?'warn':(st==='missing'?'warn':'info'),
      msg[0],msg[1]);

    /* THE LINEAGE, from the chains the parser already computed */
    var group=p.it?lineageForItem(p.it.ns):null;
    var steps=(group&&group.steps)||[];
    if(steps.length){
      var lh=document.createElement('div');
      lh.className='hd-lab';lh.textContent='made by';
      list.appendChild(lh);
      steps.forEach(function(stp){
        var b=document.createElement('button');
        b.className='dbtn vw-opt';
        b.innerHTML=bic('locate')+' ';
        b.appendChild(document.createTextNode(
          stp.title||stp.card||'a cell'));
        b.title='Open this cell in its notebook (leaves the editor)';
        b.addEventListener('click',function(){
          /* LEAVE THE DECK FIRST. `.deck` is an opaque full-window
             overlay, so scrolling a card into view behind it produced
             no visible effect whatever — the button looked broken
             (2026-08-26 audit, T58). */
          provJumpOut(function(){
            if(window.SemApp&&window.SemApp.traceGoto)
              window.SemApp.traceGoto(stp.card);
          });
        });
        list.appendChild(b);
      });
    }
    var ah=document.createElement('div');
    ah.className='hd-lab';ah.textContent='go to';
    list.appendChild(ah);
    var jump=document.createElement('button');
    jump.className='dbtn vw-opt';
    jump.innerHTML=bic('route')+' Open the plot trace';
    jump.title='Every cell that built this figure, in execution order';
    jump.addEventListener('click',function(){
      provJumpOut(function(){
        if(window.SemTrace&&pr[0]) window.SemTrace.open(pr[0],pr[1]);
      });
    });
    list.appendChild(jump);

    /* T20: take the live version for THIS figure */
    if(st==='stale'||st==='nosaved'){
      var uh=document.createElement('div');
      uh.className='hd-lab';uh.textContent='update';
      list.appendChild(uh);
      var up=document.createElement('button');
      up.className='dbtn vw-opt';
      up.innerHTML=bic('reload')
        +' Take the notebook\u2019s version of this figure';
      up.title='Replaces the copy saved with the deck. Where it sits, '
        +'its size and its crop are on the frame, not the snapshot, so '
        +'none of them change.';
      up.addEventListener('click',function(){
        reviewOneFigure(a).then(function(r){
          if(r.n) toast('Updated from the notebook \u2014 position, size and '
            +'crop unchanged');
          else if(r.same) toast('This figure already matches the notebook');
          else if(r.missing) toast('Could not read the live card');
          else toast('Kept the current figure');
          renderProvPane();
        });
      });
      list.appendChild(up);
    }
  }
  /* T20. The snapshot is replaced; the ANNOTATION is not touched at all,
     which is why position, crop and size survive by construction rather
     than by being carefully copied back. */
  /* T297: THE ONE PLACE A LIVE CARD BECOMES A KEPT COPY.
     EMBED used to be written on a DELIBERATE save (embedAssets) or an
     import and nowhere else, so a deck that had only ever autosaved
     carried REFERENCES and no pixels: close the notebook, move the
     file, and every figure on it went blank (2026-09-05, user: "most
     of the images, e.g. from notebooks or paths can dissapear as they
     are kind of a sim lin").

     And embStore writes MEMORY only -- embSaveSoon is what reaches
     IndexedDB. resyncFigure never called it, so even a deliberate
     per-figure refresh was gone on the next reload. Both halves live
     here now, so there is one answer to "is this kept" rather than one
     per caller. */
  function embedCapture(ref,live){
    if(!ref||!live) return 0;
    var html=liveCardHtml(ref);
    if(!html) return 0;
    /* the same record shape the save path writes, keyed the same way —
       one snapshot format, not two */
    var e={title:live.title||'',kind:live.kind||'',html:html};
    var cc=live.hasCode?cloneCode(ref):null;
    if(cc) e.code=cc.outerHTML;
    embStore(normRef(ref)||ref,e);
    embSaveSoon();
    return 1;
  }
  /* PLACEMENT, and every other moment the deck first learns of a ref.
     Deliberately does NOT overwrite a copy we already hold: dropping
     the same figure onto a second slide must not silently re-read the
     notebook underneath the first one. Re-reading is what the explicit
     refresh is for, and it asks first. */
  /* T309: WHERE THE NOTEBOOK WAS, kept on the figure itself.
     The user asked for "the notebook url" on a figure's row and there
     was nowhere to read one from: a notebook's location lives only in
     APP.shells[stem].path for as long as its tab is open, it is not in
     the deck payload, and a ref's stem half is a DISPLAY NAME that
     stem_for disambiguates with -2/-3 by tab-open order, so it is not
     an identity either. Close the tab and the deck could only guess by
     matching that name against the ten-entry Recent list.

     Per-annot rather than a deck-level stem->path map, for that same
     reason -- and because annots pass through normPres and
     as_presentations wholesale (a deep copy and an isinstance filter,
     neither of which looks at keys), so this costs no Python and no
     schema sentinel. It is the same idea as `a.fname`, which the
     picture half has recorded at placement since T21.

     Absent means "we never knew", never "". `force` is for a refresh,
     which is the moment to learn that the notebook has moved. */
  function noteSource(a,force){
    if(!a) return;
    function put(o,ref){
      if(!o||!ref||(o.nbpath&&!force)) return;
      var pr=splitRef(normRef(ref)||String(ref));
      var p=(pr[0]&&typeof nbPathFor==='function')?nbPathFor(pr[0]):null;
      if(p) o.nbpath=String(p);
    }
    if(a.k==='flip'){
      flipFrames(a).forEach(function(f){put(f,f&&f.ref);});
      return;
    }
    put(a,provRef(a));
  }
  function embedIfAbsent(a){
    noteSource(a);
    /* T307: a flip book is N figures, and every one of them has to be
       kept -- otherwise closing the notebook empties every page but
       the one that happened to be showing when it was placed. */
    var n=0;
    provRefs(a).forEach(function(ref){
      if(!ref||embFor(ref)) return;
      var p=provOf({k:'cell',ref:ref});
      if(p&&p.live) n+=embedCapture(p.ref,p.live);
    });
    return n;
  }
  function resyncFigure(a,ref){
    /* T307: A CHART IS NOT ITS TABLE. provRef hands back the source
       table card's ref (T117), so this stored a snapshot of the TABLE
       and reported "Updated from the notebook" while the chart on
       screen had not moved -- and if that same card was placed as a
       cell frame on another slide, the capture refreshed THAT figure
       instead. The chart's numbers live in a.cats/a.series and only
       chartResyncOne reads them. */
    if(a&&a.k==='chart'){
      var cn=(typeof chartResyncOne==='function')?chartResyncOne(a):0;
      if(cn){markDirty();refresh();}
      return cn;
    }
    /* T307: `ref` names WHICH source, because a flip book has one per
       page and provRef only ever answers for the page on show. Absent,
       it means the annot's own single source, which is what every
       caller before staleFigures learned to enumerate wanted. */
    var p=ref?provOf({k:'cell',ref:ref}):provOf(a);
    if(!p||!p.live) return 0;
    if(!embedCapture(p.ref,p.live)) return 0;
    /* a refresh is the moment to learn the notebook has moved */
    noteSource(a,1);
    markDirty();
    var l=stage.querySelector('.annot-layer');
    if(l) renderAnnots(l,pres.slides[cur]);
    return 1;
  }
  /* ONE way out of the deck, used by both jumps. The editor is closed
     rather than merely hidden so that coming back is the ordinary
     "open the presentation" path and nothing is left half-torn-down. */
  function provJumpOut(fn){
    try{if(typeof closeDeck==='function') closeDeck();}catch(e){}
    setTimeout(fn,60);
  }
  function showProvPane(){
    var pane=$('#provpane'); if(!pane) return;
    paneShow('provpane');
    syncInspectorPanes(true);
  }
  (function(){
    var pb=$('#fmt-prov');
    if(pb) pb.addEventListener('click',showProvPane);
    var source=$('#fmt-src');
    if(source) source.addEventListener('click',function(){
      var a=pres.slides[cur]&&annotByIdx(pres.slides[cur],selAnnot);
      if(typeof provRef==='function'&&provRef(a)) showProvPane();
      else toast('The source path and refresh actions are beside this label');
    });
  })();
  /* ---- SIZE AND POSITION, IN NUMBERS (T65) ---------------------------
     "where are all the options that I said, like keep square, and also
     having the width, height, and position (x,y)" (2026-08-29, user).

     IN MILLIMETRES, because a percentage of an A0 means nothing to
     anyone; the model stays in page percent and this pane is a lens over
     it, never a second coordinate system.

     IT WRITES THROUGH anchorSet, ALWAYS. The four fields are PAGE
     coordinates of the item's top-left corner. A pinned item stores an
     offset from ITS OWN corner instead, so assigning a.x/a.y from a text
     field would reproduce the T43 teleport with no drag to blame it on.

     IT DESCRIBES THE PRIMARY SELECTION, the same subject the ribbon and
     the two inspector panes take -- group expansion belongs to bulk
     verbs, not to a readout. */
  function sizeSubject(){
    var s=pres.slides[cur];
    var a=(s&&typeof selAnnot==='number')?(s.annots||[])[selAnnot]:null;
    return (a&&a.k!=='arrow')?a:null;
  }
  function sizeIdx(a){
    var s=pres.slides[cur];
    return ((s&&s.annots)||[]).indexOf(a);
  }
  /* the box in page percent. annotRectPct is the one reader that already
     answers correctly for an auto-height text box and an aspect-fitted
     figure frame -- both of which have no stored h to read. */
  function sizeRect(a){
    var s=pres.slides[cur];
    var layer=stage.querySelector('.annot-layer');
    var i=sizeIdx(a);
    var r=(i>=0)?annotRectPct(layer,s,i):null;
    if(r) return r;
    var ap=anchorPos(a,a.w||0,a.h||0);
    return {l:ap.x,t:ap.y,r:ap.x+(a.w||0),b:ap.y+(a.h||0)};
  }
  /* is this item's shape held? Either because you said so, or because it
     is one of the two kinds startResize fits to its picture anyway. */
  function sizeArLocked(a){
    if(!a) return false;
    if(a.lockar) return true;
    if(a.k==='image'&&!a.crop) return true;
    var layer=stage.querySelector('.annot-layer');
    var i=sizeIdx(a);
    var el=(layer&&i>=0)
      ?layer.querySelector('.an-item[data-idx="'+i+'"]'):null;
    return !!(el&&el.classList.contains('an-figonly'));
  }
  /* fills the pane's fields AND the ribbon's (T207: #rb-x/y/w/h on the
     Object tab), so the ribbon is live whether or not the pane is open */
  var GEO_HOSTS=['#sz-','#rb-'];
  function geoEach(k,fn){
    GEO_HOSTS.forEach(function(pre){var el=$(pre+k); if(el) fn(el);});
  }
  function sizePaneSync(){
    var a=sizeSubject(),cb=$('#sz-lockar'),note=$('#sz-note');
    var keys=['w','h','x','y'];
    if(!a){
      keys.forEach(function(k){
        geoEach(k,function(el){el.value='';el.disabled=true;});});
      if(cb){cb.checked=false;cb.disabled=true;}
      if(note) note.textContent='Select one object on the page. An arrow '
        +'is two endpoints rather than a box, so it has none of these.';
      return;
    }
    var r=sizeRect(a);
    var v={w:r.r-r.l,h:r.b-r.t,x:r.l,y:r.t};
    var all=lockedAll(a),pos=pinned(a),isText=(a.k==='text');
    keys.forEach(function(k){
      var horiz=(k==='w'||k==='x');
      geoEach(k,function(el){
        el.disabled=all||(k==='h'&&isText)||((k==='x'||k==='y')&&pos);
        /* never overwrite the field you are typing in -- the rule every
           input in the notes pane already keeps */
        if(document.activeElement!==el)
          el.value=Math.round(pctMm(v[k],horiz)*10)/10;
      });
    });
    if(cb){cb.disabled=all;cb.checked=!!a.lockar;}
    if(note) note.textContent=
      (all?'Fully locked — unlock it to change any of these. ':'')
      +(!all&&pos?'Position locked — its size is still yours. ':'')
      +(isText?'A text box heights itself from its words, so Height is a '
        +'readout. ':'')
      +(a.anch?('Pinned '+((ANCHORS[a.anch]||[a.anch])[0]+'')
        .toLowerCase()+' — X and Y are still measured from the top '
        +'left of the page, and the pin is kept.'):'');
  }
  /* ONE write, whichever field you typed in. */
  function sizePaneWrite(k,mm){
    var a=sizeSubject(); if(!a||lockedAll(a)) return;
    var s=pres.slides[cur];
    var layer=stage.querySelector('.annot-layer');
    var r=sizeRect(a);
    var w=r.r-r.l,h=r.b-r.t,x=r.l,y=r.t;
    var horiz=(k==='w'||k==='x');
    var val=mmPct(mm,horiz);
    if(!isFinite(val)) return;
    if(k==='x'||k==='y'){
      if(pinned(a)) return;
      /* T487: A GROUP MOVES AS ONE, the way a drag moves it. The readout
         is the primary's, but typing X into it tore one member out of
         its group while the outline still said "one thing"
         (2026-09-15 review, driven). Inside a group (double-clicked
         in), an item is just an item, as everywhere else. */
      var gi=sizeIdx(a);
      if(a.grp!=null&&inGroup!==a.grp){
        var d=val-(k==='x'?x:y);
        dropTiedCaptions(s,selIdxs()).forEach(function(i){
          var m=(typeof i==='number')?s.annots[i]:null;
          if(!m||i===gi||m.grp!==a.grp||pinned(m)) return;
          shiftAnnot(m,k==='x'?d:0,k==='y'?d:0);
        });
      }
      if(k==='x') x=val; else y=val;
    } else if(k==='w'){
      if(!(val>0)) return;
      /* a locked shape keeps its shape here too -- typing a width that
         letterboxes the picture is the bug this task is about */
      if(w>0&&h>0&&sizeArLocked(a)) h=h*(val/w);
      w=val;
    } else {
      if(!(val>0)||a.k==='text') return;
      if(w>0&&h>0&&sizeArLocked(a)) w=w*(val/h);
      h=val;
    }
    a.w=w;
    if(a.k!=='text') a.h=h;
    anchorSet(a,x,y,w,h);
    /* quiet while you type, one undo entry when you leave the field --
       the pattern the notes editor settled on (T57) */
    markDirty(true);
    if(layer){renderAnnots(layer,s);paintSel(layer);}
    sizePaneSync();
  }
  function toggleAspectLock(v){
    var s=pres.slides[cur];
    var idxs=selIdxs().filter(function(i){return typeof i==='number';});
    if(!idxs.length){toast('Select an object first');return;}
    var a0=(s.annots||[])[idxs[0]];
    var on=(v===undefined)?!(a0&&a0.lockar):!!v;
    idxs.forEach(function(i){
      var a=(s.annots||[])[i];
      if(!a||a.k==='arrow') return;
      if(on) a.lockar=1; else delete a.lockar;
    });
    markDirty();showFmt();sizePaneSync();
    /* nothing is stored about WHAT the shape is: the ratio is read off
       the box when a drag starts, so locking never resizes anything */
    toast(on?'Shape kept — drag any handle and it stays this shape '
      +'(hold Shift to stretch it anyway)'
      :'Shape free — width and height move independently again');
  }
  function showSizePane(on){
    var p=$('#sizepane'); if(!p) return;
    if(on){paneShow('sizepane');sizePaneSync();}
    else paneHide('sizepane');
  }
  (function(){
    var sb=$('#fmt-sizepos'),p=$('#sizepane');
    if(sb&&p) sb.addEventListener('click',function(){
      showSizePane(p.hidden);});
    var cl=$('#sizepane-close');
    if(cl) cl.addEventListener('click',function(){showSizePane(false);});
    var lk=$('#fmt-lockar');
    if(lk) lk.addEventListener('click',function(){toggleAspectLock();});
    var cbx=$('#sz-lockar');
    if(cbx) cbx.addEventListener('change',function(){
      toggleAspectLock(cbx.checked);});
    ['w','h','x','y'].forEach(function(k){
      geoEach(k,function(el){
        /* the canvas owns arrows, Delete and every single-letter tool
           key; a number field has to keep its own keystrokes */
        el.addEventListener('keydown',function(e){
          e.stopPropagation();
          if(e.key==='Enter') el.blur();
        });
        el.addEventListener('input',function(){
          var n=parseFloat(el.value);
          if(isFinite(n)) sizePaneWrite(k,n);
        });
        el.addEventListener('blur',function(){
          /* T481: a COMMITTED edit, like the drag's end -- markDirty
             pushes the clones of a place-linked set along (cmpFollowSel)
             before it records history; a bare histPush moved this one
             alone and the next drag anywhere in the set snapped it back
             (2026-09-15 review, driven) */
          markDirty();});
      });
    });
  })();
  (function(){
    var cl=$('#provpane-close');
    if(cl) cl.addEventListener('click',function(){
      var pn=$('#provpane'); if(pn) pn.hidden=true;
      syncPaneDock();
    });
  })();
  /* ---- FIGURE NUMBERS, AND REFERENCES TO THEM -------------------------
     (TASKS T18.) "Figure 7" numbered by deck order, and "see Figure 7"
     in a sentence renumbering itself when the slides move.

     THE ONE DECISION THAT MATTERS: A NUMBER IS NEVER STORED. It is
     derived, every render, from where the figure sits in the deck. The
     alternative — stamping "Figure 7" into the caption's words — is the
     thing this task exists to abolish: it is right until somebody drags
     slide 9 above slide 4, and then it is wrong everywhere and silently.
     Nothing here writes a number into any text.

     So a caption says `{fig}` and a sentence says `{fig:id}`, and both
     are resolved at render exactly the way the header and footer already
     resolve `{n}` and `{N}` — furnText has done this since the page
     furniture landed, and this is the same idea one level down. Deleting
     a figure renumbers the rest on the next repaint, for free, because
     there was never a number to go and update.

     READING ORDER, not array order. The array is the order things were
     DRAWN in, which is nobody's idea of a sequence; orderedIdx already
     solved this for build steps, using a row-band then left-to-right
     sweep, and figure numbers use the same one so a figure's number and
     its build order can never disagree.

     A reference names a figure by its `cap` id — the same opaque id T17
     mints to tie a caption on — so a reference survives the figure being
     moved, restyled, or given a different caption. It only breaks if the
     figure is deleted, and then it says so in words rather than
     rendering a wrong number. */
  function figNumbers(){
    var map={},n=0;
    (pres.slides||[]).forEach(function(sl,si){
      var ord=orderedIdx(sl);
      ord.forEach(function(i){
        var a=(sl.annots||[])[i];
        if(!isFigure(a)||a.hide) return;
        n++;
        if(!a.cap) a.cap=figId();
        map[a.cap]={n:n,si:si};
      });
    });
    return map;
  }
  /* the words a figure token resolves to. `{fig}` in a caption means
     "the number of the figure I am tied to"; `{fig:id}` anywhere means
     "the number of that one". A reference to a figure that has gone
     says so — a silently wrong number is the failure this replaces. */
  function figSubst(txt,a,map){
    var t=String(txt||'');
    /* T325: a citation resolves wherever a figure number does. Both are
       paint-time substitutions of a marker into a number that comes from
       ORDER, so they belong on the same funnel -- every text box, note,
       caption and flip page already comes through here. */
    if(typeof citeSubst==='function') t=citeSubst(t);
    if(t.indexOf('{fig')<0) return t;
    map=map||figNumbers();
    return t.replace(/\{fig(?::([A-Za-z0-9_]+))?\}/g,function(_,id){
      var key=id||(a&&a.capOf)||(a&&a.cap);
      var hit=key?map[key]:null;
      if(hit) return String(hit.n);
      /* THREE MISSES, and they used to read as two: a caption whose
         figure was deleted or hidden got '[not a caption]', which is
         wrong on its face — it IS a caption — and is not what the review
         pane promises to say about it (2026-08-26 audit, T58). */
      if(id) return '[missing figure]';
      return key?'[figure not shown]':'[not a caption]';
    });
  }
