/* 60-saving-and-export.js — persistence, autosave, and every way a deck leaves: PDF, PowerPoint, a file.
   ONE FRAGMENT of deck.js's single IIFE, concatenated with its
   siblings in filename order by assets.deck_js(). It does not
   parse alone and is not meant to: see 00-page.js. */
  /* ---------- persistence ---------- */
  var toastTimer;
  function toast(msg,ms){
    var t=$('#deck-toast');t.textContent=msg;t.hidden=false;
    clearTimeout(toastTimer);
    /* a warning about lost work has to outlast a confirmation of saved
       work, so the duration is a parameter now (2026-08-22) */
    toastTimer=setTimeout(function(){t.hidden=true;},ms||3600);
  }
  /* T301: a toast that can be acted on. `toast` is text-only and
     stays that way -- this is for the one case where the message is
     "something was replaced" and the only useful reply is "put it
     back". Longer by default, because a reply needs reading time.
     T498: and for the one other -- "the ribbon is wider than the
     window", whose only useful reply is the Side toolbar. */
  function toastUndo(msg,label,fn,ms){
    var t=$('#deck-toast'); if(!t){toast(msg);return;}
    t.textContent=msg+' ';
    var b=document.createElement('button');
    b.type='button';b.className='toast-act';b.textContent=label;
    b.addEventListener('click',function(){t.hidden=true;fn();});
    t.appendChild(b);
    t.hidden=false;
    clearTimeout(toastTimer);
    toastTimer=setTimeout(function(){t.hidden=true;},ms||9000);
  }
  /* T600: the same, with more than one reply ([label, fn] pairs) */
  function toastActs(msg,acts,ms){
    var t=$('#deck-toast'); if(!t){toast(msg);return;}
    t.textContent=msg+' ';
    (acts||[]).forEach(function(a){
      var b=document.createElement('button');
      b.type='button';b.className='toast-act';b.textContent=a[0];
      b.addEventListener('click',function(){t.hidden=true;a[1]();});
      t.appendChild(b);
    });
    t.hidden=false;
    clearTimeout(toastTimer);
    toastTimer=setTimeout(function(){t.hidden=true;},ms||9000);
  }
  /* ---- T475: THE EDITOR'S OWN QUESTION ---------------------------------
     window.prompt was the browser's box: unstyled, un-themed, the one
     dialog in the editor that did not look like the editor, blocked
     outright in some embeddings, and unable to show what it was asking
     about. Thirty-six of them (2026-09-15 review: "three of them use
     the browser's native prompt" was the count for one group alone).
     One small dialog on the .aa-dlg shell asks every one of them now: a
     title, a line of help, a field pre-filled, a note under it, Cancel
     and a verb, Enter and Escape. cb(null) when cancelled, cb(text)
     otherwise -- so every caller is a callback, which is what a
     dialog that is not modal to the whole browser has to be. */
  var askCb=null,askWired=false;
  /* T488: A SMALL FORM. `o.rows` is a list of {k,label,type,value,...}
     -- text (default), number (min/max/step, unit), select (options
     [[value,label]]), check, color (clear:true adds a Default button;
     '' means default), range (min/max/step, pct:true reads as a
     percentage) -- and the callback receives {k:value} instead of a
     string. `o.alt` names a third button; it closes the question and
     calls back (null,'alt'). The page furniture's editor is the first
     taker: header, footer and watermark had size, colour, alignment,
     angle and "not on the first slide" in the model with no door
     (2026-09-15 review). */
  var askRows=null;
  function askRowsBuild(host,rows){
    host.innerHTML='';
    askRows=[];
    rows.forEach(function(r,i){
      var id='ask-r'+i;
      var lab=document.createElement('label');
      lab.className='ask-row-lab';lab.htmlFor=id;
      lab.textContent=r.label||'';
      var cell=document.createElement('span');
      cell.className='ask-row-cell';
      var el,readout=null,clearBtn=null;
      var t=r.type||'text';
      if(t==='select'){
        el=document.createElement('select');
        el.className='ask-in ask-sel';
        (r.options||[]).forEach(function(op){
          var o2=document.createElement('option');
          o2.value=op[0];o2.textContent=op[1];
          if(String(op[0])===String(r.value)) o2.selected=true;
          el.appendChild(o2);
        });
      } else if(t==='check'){
        el=document.createElement('input');
        el.type='checkbox';el.className='ask-check';
        el.checked=!!r.value;
      } else if(t==='color'){
        el=document.createElement('input');
        el.type='color';el.className='ask-color';
        var hex=/^#[0-9a-f]{6}$/i.test(String(r.value||''))?r.value:'';
        el.value=hex||'#888888';
        el.dataset.cleared=hex?'':'1';
        if(r.clear){
          clearBtn=document.createElement('button');
          clearBtn.type='button';clearBtn.className='dbtn ask-clear';
          clearBtn.textContent='Default';
          clearBtn.setAttribute('aria-pressed',hex?'false':'true');
          clearBtn.addEventListener('click',function(e){
            e.stopPropagation();
            el.dataset.cleared='1';
            clearBtn.setAttribute('aria-pressed','true');
          });
          el.addEventListener('input',function(){
            el.dataset.cleared='';
            clearBtn.setAttribute('aria-pressed','false');
          });
        }
      } else if(t==='range'){
        el=document.createElement('input');
        el.type='range';el.className='ask-range';
        if(r.min!=null) el.min=r.min;
        if(r.max!=null) el.max=r.max;
        if(r.step!=null) el.step=r.step;
        el.value=r.value==null?'':r.value;
        readout=document.createElement('span');
        readout.className='ask-unit';
        var say=function(){
          readout.textContent=r.pct?(Math.round(parseFloat(el.value)*100)+'%')
            :el.value+(r.unit?(' '+r.unit):'');};
        el.addEventListener('input',say);say();
      } else {
        el=document.createElement('input');
        el.type=(t==='number')?'number':'text';
        el.className='ask-in'+(t==='number'?' ask-num':'');
        if(t==='number'){
          if(r.min!=null) el.min=r.min;
          if(r.max!=null) el.max=r.max;
          if(r.step!=null) el.step=r.step;
        }
        /* the form's text rows are names and {codes}: unchecked, like
           #ask-in's own markup */
        el.setAttribute('spellcheck','false');el.autocomplete='off';
        el.value=(r.value==null)?'':String(r.value);
        el.placeholder=r.placeholder||'';
      }
      el.id=id;
      cell.appendChild(el);
      if(readout) cell.appendChild(readout);
      else if(r.unit&&t!=='range'){
        var u=document.createElement('span');
        u.className='ask-unit';u.textContent=r.unit;
        cell.appendChild(u);
      }
      if(clearBtn) cell.appendChild(clearBtn);
      host.appendChild(lab);host.appendChild(cell);
      if(r.note){
        var n=document.createElement('div');
        n.className='ask-row-note';n.textContent=r.note;
        host.appendChild(n);
      }
      askRows.push({r:r,el:el});
    });
  }
  function askRowsRead(){
    var out={};
    (askRows||[]).forEach(function(x){
      var r=x.r,el=x.el,t=r.type||'text';
      if(t==='check') out[r.k]=!!el.checked;
      else if(t==='color') out[r.k]=el.dataset.cleared?'':el.value;
      else if(t==='number'||t==='range'){
        var n=parseFloat(el.value);
        out[r.k]=isFinite(n)?n:(r.value==null?null:r.value);
      } else out[r.k]=el.value;
    });
    return out;
  }
  /* T527: THE QUESTION GOES WHERE YOU ARE LOOKING. The dialog lives in
     the editor, and the editor is hidden while the library, the Home
     screen or a notebook is on screen -- so a question asked from there
     would have been asked into a hidden box. It moves to the page body
     while the editor is hidden (its colours are :root tokens, so it looks
     the same there) and back inside the editor when it is not. */
  function askHost(dlg){
    var host=(deckEl&&!deckEl.hidden)?deckEl:document.body;
    /* T601: .deck is a stacking context under the Parts view, which sits
       on the body -- a question it asks has to come up over it */
    if($('#deck-parts')) host=document.body;
    var fs=document.fullscreenElement;
    if(fs&&fs!==document.documentElement&&!fs.contains(host)) host=fs;
    if(dlg.parentNode!==host) host.appendChild(dlg);
  }
  function askText(o,cb){
    var dlg=$('#ask-dlg');
    if(!dlg){cb(null);return;}
    o=o||{};
    askHost(dlg);
    /* T527: o.yes -- a question with no field at all, answered by its
       buttons (askYes); o.tell -- a notice with one button (askTell) */
    var yes=!!(o.yes||o.tell);
    dlg.classList.toggle('ask-yes',yes);
    var multi=!yes&&!!o.multi,rows=!yes&&Array.isArray(o.rows)&&o.rows.length;
    var inp=$('#ask-in'),area=$('#ask-area'),rowsEl=$('#ask-rows');
    $('#ask-t').textContent=o.title||'Name';
    var what=$('#ask-what');
    what.textContent=o.what||'';what.hidden=!o.what;
    var lab=$('#ask-lab');
    lab.textContent=o.label||'';lab.hidden=!o.label||rows||yes;
    var note=$('#ask-note');
    note.textContent=o.note||'';
    var okb=$('#ask-ok');
    okb.textContent=o.ok||'OK';
    okb.classList.toggle('dbtn-warn',!!o.danger);
    var cnb=$('#ask-cancel');
    cnb.textContent=o.cancel||'Cancel';cnb.hidden=!!o.tell;
    var alt=$('#ask-alt');
    if(alt){alt.textContent=o.alt||'';alt.hidden=!o.alt;}
    inp.hidden=multi||rows||yes;area.hidden=!multi||rows||yes;
    if(rowsEl){rowsEl.hidden=!rows;if(rows) askRowsBuild(rowsEl,o.rows);
      else askRows=null;}
    var field=yes?okb:rows?(askRows[0]&&askRows[0].el):multi?area:inp;
    if(!rows&&!yes){
      field.value=(o.value==null)?'':String(o.value);
      field.placeholder=o.placeholder||'';
    }
    askCb=cb;
    /* T601: the Parts view is one of the full-window views it asks over */
    dlg.classList.toggle('over-design',!!($('#deck-design')||$('#deck-parts')));
    dlg.classList.toggle('ask-form',!!rows);
    dlg.hidden=false;
    /* T546: NOW, and again a tick later only if the focus went. Chrome
       runs queued key input ahead of timers, so the answer typed straight
       after Ctrl+K landed in the text box being edited -- over the
       highlighted words -- and not in the question (driven). The late
       grab is for a caller inside a click, whose own default takes the
       focus back; it must not run when the focus stayed, or its select()
       would take whatever had been typed meanwhile and the next key
       would replace it. */
    function grab(){
      if(!field) return;
      try{field.focus();}catch(e){}
      if(!multi&&o.select!==false&&field.select&&field.type!=='color')
        field.select();
    }
    grab();
    setTimeout(function(){
      if(field&&document.activeElement!==field) grab();},0);
    if(askWired) return;
    askWired=true;
    function done(v,why){
      dlg.hidden=true;
      var f=askCb;askCb=null;
      if(f) f(v,why||'');
    }
    function ok(){
      done(askRows?askRowsRead():(area.hidden?inp:area).value);
    }
    if(alt) alt.addEventListener('click',function(e){
      e.stopPropagation();done(null,'alt');});
    $('#ask-ok').addEventListener('click',function(e){
      e.stopPropagation();ok();});
    $('#ask-cancel').addEventListener('click',function(e){
      e.stopPropagation();done(null);});
    $('#ask-close').addEventListener('click',function(e){
      e.stopPropagation();done(null);});
    dlg.addEventListener('click',function(e){
      /* the box, not the shade: a click on the shade cancels; a click
         inside must not reach the overlay owner underneath, which would
         pop the menu the question was asked from */
      e.stopPropagation();
      if(e.target===dlg) done(null);
    });
    dlg.addEventListener('mousedown',function(e){e.stopPropagation();});
    /* ON WINDOW, IN CAPTURE. A question asked from inside a menu sits
       over an overlay whose own Escape listener is on document in
       capture and wins against anything on the dialog (the
       overlay-panels-eat-keys trap): Escape closed the MENU under the
       question and left the question standing (driven 2026-09-15).
       Window capture fires before document capture, so while the
       dialog is open its keys are its own. */
    window.addEventListener('keydown',function(e){
      if(dlg.hidden) return;
      if(!dlg.contains(e.target)&&e.target!==document.body) return;
      e.stopImmediatePropagation();
      if(e.key==='Escape'){e.preventDefault();done(null);}
      else if(e.key==='Enter'&&(e.target===inp||(e.target===area&&e.ctrlKey)
        ||(askRows&&rowsEl&&rowsEl.contains(e.target)
          &&e.target.tagName!=='BUTTON'))){
        e.preventDefault();ok();}
    },true);
  }
  /* T527: the browser's confirm(), in the editor's own dialog. Verbs on
     the buttons -- "Delete" / "Keep it", never OK / Cancel with the
     meaning spelled out in a paragraph above them. cb(true) for the
     verb, cb(false) for cancel, Escape or the shade, cb('alt') for a
     third button when o.alt names one. */
  function askYes(o,cb){
    askText({yes:true,title:o.title,what:o.what,note:o.note,
      ok:o.ok||'OK',cancel:o.cancel,alt:o.alt,danger:o.danger},
      function(v,why){cb(why==='alt'?'alt':v!==null);});
  }
  /* ...and its alert(): one button, and whatever you do closes it */
  function askTell(o,cb){
    if(typeof o==='string') o={title:'Junoview',what:o};
    askText({tell:true,title:o.title||'Junoview',what:o.what,
      note:o.note,ok:o.ok||'OK'},function(){if(cb) cb();});
  }
  /* ---- T568: EVERY DIALOG ANSWERS THE SAME KEYS -----------------------
     Cancel on the left and the verb on the right was already the markup's
     habit; the keys were not. Each dialog wired its own Escape on its own
     box, and a box only hears a key when the focus is inside it -- which
     it never was after a ribbon door opened it -- so Escape in Saved
     layouts went past the dialog to the canvas behind (driven). Enter did
     the verb in two of them. One listener on window, in capture (before
     the canvas and the overlay owner), answers for whichever of these is
     open: Escape presses its Cancel (or its close), Enter in a field
     presses its verb -- a text area needs Ctrl+Enter, a button, link or
     list answers Enter itself -- and any other key aimed past the
     dialog stops there, so Delete cannot reach a shape under the shade.
     The question (#ask-dlg) has had these keys since T475 and keeps its
     own; while it is open, over one of these or not, this stands down. */
  var DLG_KEYED='#eq-dlg,#md-dlg,#aa-dlg,#ar-dlg,#ss-dlg,#ms-dlg,#ts-dlg,'
    +'#chart-data';
  function dlgShown(el){
    if(!el||el.hidden||el.closest('[hidden]')) return false;
    var r=el.getBoundingClientRect();
    return r.width>0&&r.height>0;
  }
  function dlgTop(){
    var list=[].slice.call(document.querySelectorAll(DLG_KEYED))
      .filter(dlgShown);
    return list.length?list[list.length-1]:null;
  }
  function dlgButton(d,which){
    var sel=which==='verb'?'.primary'
      :'[id$="-cancel"],[id$="-close"],[data-dlg-cancel]';
    var hit=null;
    [].slice.call(d.querySelectorAll(sel)).forEach(function(b){
      if(b.tagName==='BUTTON'&&dlgShown(b)&&!b.disabled&&!hit) hit=b;});
    return hit;
  }
  /* a dialog comes up with the focus in it: its first field, else its
     verb, else the box -- so Tab walks the dialog, not the ribbon behind */
  function dlgFocus(d){
    if(!d||d.contains(document.activeElement)) return;
    var f=null;
    [].slice.call(d.querySelectorAll('input,textarea,select'))
      .forEach(function(x){
        if(!f&&dlgShown(x)&&!x.disabled&&x.type!=='hidden') f=x;});
    f=f||dlgButton(d,'verb')||dlgButton(d,'cancel');
    if(!f){if(!d.hasAttribute('tabindex')) d.tabIndex=-1;f=d;}
    try{f.focus({preventScroll:true});}catch(e){}
  }
  function dlgKeysBoot(){
    if(typeof MutationObserver==='function'){
      [].slice.call(document.querySelectorAll(DLG_KEYED)).forEach(function(d){
        new MutationObserver(function(){
          if(dlgShown(d)) dlgFocus(d);
        }).observe(d,{attributes:true,attributeFilter:['hidden']});
      });
    }
    window.addEventListener('keydown',function(e){
      var ask=$('#ask-dlg');
      if(ask&&dlgShown(ask)) return;
      var d=dlgTop(); if(!d) return;
      var t=e.target,inside=d.contains(t);
      /* the chart's numbers are a popover beside the canvas, not a
         shade over it: only keys typed in it are its own */
      if(!inside&&d.id==='chart-data') return;
      /* a menu opened from inside the dialog answers its own keys */
      if(!inside&&t&&t.closest&&t.closest('.dc-menu,.sh-menu,.canvas-menu'))
        return;
      if(e.key==='Escape'){
        var c=dlgButton(d,'cancel');
        e.preventDefault();e.stopImmediatePropagation();
        if(c) c.click();
        else if(d.id==='chart-data') d.remove();
        else d.hidden=true;
        return;
      }
      if(e.key==='Enter'&&!e.shiftKey&&!e.altKey&&!e.isComposing){
        var tag=t&&t.tagName;
        var own=inside&&(tag==='BUTTON'||tag==='A'||tag==='SELECT'
          ||tag==='SUMMARY'||(t.isContentEditable)
          ||(tag==='TEXTAREA'&&!(e.ctrlKey||e.metaKey))
          /* T562: a grid moves down a column on Enter, as a sheet does;
             Ctrl+Enter is still the verb */
          ||(!(e.ctrlKey||e.metaKey)&&t.closest
            &&t.closest('[data-own-enter]')));
        if(own) return;
        var v=dlgButton(d,'verb');
        e.preventDefault();e.stopImmediatePropagation();
        if(v) v.click();
        return;
      }
      if(!inside){e.stopImmediatePropagation();}
    },true);
  }
  function mergedPresentations(){
    var out=allSaved().filter(function(p){return p.name!==pres.name;})
      .map(function(p){var c=deep(p);delete c.origin;return c;});
    var cp=deep(pres);delete cp.origin;out.push(cp);
    return out;
  }
  function deckSaveSig(p){
    try{
      var c=deep(p);delete c.origin;return JSON.stringify(c);
    }catch(e){return null;}
  }
  function stillSaved(name,sig){
    return !!sig&&pres&&pres.name===name&&deckSaveSig(pres)===sig;
  }
  /* strip "stem::" when only one notebook is open, so decks saved from a
     single tab stay compatible with sidecars and --embed-deck */
  function plainIfSingle(list){
    if(APP.order.length!==1) return list;
    var pfx=APP.order[0]+'::';
    function strip(a){
      return (a&&String(a).indexOf(pfx)===0)
        ?String(a).slice(pfx.length):a;
    }
    return list.map(function(p){
      var c=deep(p);
      c.slides=(c.slides||[]).map(function(s){
        s.panes=(s.panes||[]).map(strip);
        (s.annots||[]).forEach(function(a){
          if(a.k==='cell'&&a.ref) a.ref=strip(a.ref);
          /* a flip book's frames are refs too, and they were already
             being stripped nowhere -- see the same omission normPres
             had to fix (10-decks.js:262) */
          if(a.k==='flip'&&Array.isArray(a.frames))
            a.frames.forEach(function(f){
              if(f&&f.ref) f.ref=strip(f.ref);});
        });
        if(Array.isArray(s.hidden)) s.hidden=s.hidden.map(strip);
        return s;});
      /* T304: LIVENESS IS KEYED BY REF, so it has to be stripped with
         the refs. embedAssets runs after this and keys `emb` by the
         now-bare ref, so leaving `live` namespaced made the two halves
         of every single-notebook .junoview.html disagree about the same
         figure -- and refIsLive would answer "kept" for a ref the
         author had explicitly made live. */
      if(c.live&&typeof c.live==='object'){
        var lv={};
        Object.keys(c.live).forEach(function(k){
          if(c.live[k]) lv[strip(k)]=1;});
        c.live=lv;
      }
      return c;});
  }
  function requireName(){
    if(pres.name) return true;
    toast('Give the presentation a name first');
    var ni=$('#pres-name');ni.hidden=false;ni.focus();
    return false;
  }
  /* ---------- app mode: save to project + autosave ---------- */
  function projectSaved(next,silent,conflict,savedName,savedSig){
    /* The request wrote the click-time copy. If the user typed or renamed
       while it was in flight, that newer live deck is still a draft: do
       not delete its pending browser copy, report it as saved, OR replace
       projectPres with the stale request. The last point matters on a
       rename: doing so resurrects the old name beside the live new one. */
    var exact=stillSaved(savedName,savedSig);
    if(exact){
      projectPres=next;
      cancelDraftWrite();
      draftDel(savedName||'untitled');
      source='saved';
    } else {
      source='draft';scheduleDraftWrite();
    }
    saveStamp=new Date();saveKind=silent?'auto':'manual';
    saveWhere='project';   /* T483 */
    deckMetaSet(savedName,{saved:Date.now(),home:'project'});   /* T598 */
    status();renderPresRow();
    if(conflict){
      renderPresTabs();
      docToastOnce('Another window changed this project — merged '
        +'its changes in. Your "'+savedName+'" is intact.');
    } else if(!silent){
      toast('Saved "'+savedName+'" to junoview_project.json'+embNote());
    }
    return true;
  }
  function saveToProject(silent,embed){
    flushTextEdits();   /* the words still in the DOM are part of the save */
    /* Mint slide ids before both payloads are frozen. History and the
       successful file must describe the same bytes, not adjacent states. */
    var savedHist=!silent?histCapture():null;
    var savedName=pres.name||'untitled',savedSig=deckSaveSig(pres);
    var merged=mergedPresentations();
    /* a deliberate Save writes the self-contained form (figures inside)
       into junoview_project.json; the every-second autosave stays refs-
       only so editing does not rewrite megabytes to a synced disk each
       keystroke. `projectPres` keeps the lean copy either way.
       `embed` is the idle consolidation from scheduleAutosave: silent,
       but self-contained, so the file does not sit refs-only between a
       manual Save and the next one. */
    var body=(silent&&!embed)?merged:embedAssets(deep(merged));
    var op=APP.api('/api/save',{presentations:body,rev:projectRev})
      .then(function(j){
        if(j&&typeof j.rev==='number') projectRev=j.rev;
        return projectSaved(merged,silent,false,savedName,savedSig);
      }).catch(function(e){
        /* ANOTHER WINDOW GOT THERE FIRST. This whole payload is every
           presentation the tab knows about, so before the server grew a
           revision the loser of the race simply erased the winner's work
           — a deck created in one window vanished the moment the other
           typed a character (2026-08-22). Now: take their list, keep the
           one deck this window is actually editing, and write that. */
        if(e&&e.status===409&&e.data&&Array.isArray(e.data.presentations)){
          /* Reconcile the frozen request, not whichever deck/name happens
             to be live when the 409 arrives. A rename while the request
             is in flight must not make `mine` vanish from the retry. */
          var theirs=e.data.presentations.filter(function(p){
            return !p||p.name!==savedName;});
          var mine=merged.filter(function(p){
            return p&&p.name===savedName;});
          projectRev=e.data.rev;
          var reconciled=theirs.concat(mine);
          return APP.api('/api/save',
            {presentations:reconciled,rev:projectRev})
            .then(function(j2){
              if(j2&&typeof j2.rev==='number') projectRev=j2.rev;
              return projectSaved(reconciled,silent,true,
                savedName,savedSig);
            }).catch(function(e2){
              toast('Save failed after a conflict: '
                +((e2&&e2.message)||e2)+' — use File › Download a copy.',
                9000);
              return false;
            });
        }
        if(!silent)
          toast('Save failed: '+(e&&e.message?e.message:e));
        return false;
      });
    /* Enqueued immediately but gated on op=true: a rename after this
       click waits behind the saved snapshot and migrates it as one unit. */
    if(savedHist) snapTake('saved',savedHist,op);
    return op;
  }
  /* one conflict notice per settling period: the autosave retries every
     1.2s, and a notice per retry would be a strobe */
  var conflictT=null;
  function docToastOnce(msg){
    if(conflictT) return;
    toast(msg,7000);
    conflictT=setTimeout(function(){conflictT=null;},8000);
  }
  /* ---------- WHERE this presentation is saved -----------------------
     'project' (app mode: junoview_project.json), 'browser' (this browser,
     the default everywhere else) or 'file' (a .junoview file you pick).
     A picked file is REMEMBERED: the FileSystemFileHandle is stored in
     IndexedDB, so the next visit saves straight back to the same place
     without asking again (the browser only re-asks for permission). */
  var TGKEY='semopts:'+SCOPE+':savetarget';
  var HKEY='deck:'+SCOPE;
  /* T235: THE DEFAULT FOLDER. One directory handle, remembered like
     the file handle beside it, from which Junoview mints its own file
     the first time it needs one -- so "save on this computer" stops
     being a dialog you have to answer and starts being the default.
     Its NAME is kept in localStorage as well, because the menu has to
     be able to say which folder before IndexedDB has answered. */
  var DKEY='deckdir:'+SCOPE;
  var DNKEY='semopts:'+SCOPE+':savedirname';
  var canPickDir=!!window.showDirectoryPicker;
  var deckDir=null,deckDirName=lsGet(DNKEY)||'';
  var canPickFile=!!window.showSaveFilePicker;
  /* T598: TGKEY is the DEFAULT -- where a deck saves when it has no home
     of its own yet. `saveTarget` is the deck on screen's, set from its
     own record on every switch (fileSync). */
  function defaultSaveTarget(){
    var t=lsGet(TGKEY)||(APP.mode==='app'?'project':'browser');
    if(t==='project'&&APP.mode!=='app') t='browser';
    if(t==='file'&&!canPickFile) t='browser';
    return t;
  }
  var saveTarget=defaultSaveTarget();
  var fileHandle=null,fileName='';
  /* ---- T416: A FILE BELONGS TO ONE PRESENTATION -----------------------
     One remembered handle served every deck: switch to another deck
     with the target still "file" and the next autosave wrote THAT deck
     into the first deck's file -- and a deck too big for the draft
     store, which was nowhere but in that file, was gone from it. So a
     handle is bound to the deck it was saved from or opened into
     (fileFor), and fileSync() makes fileHandle/fileName the CURRENT
     deck's whenever the deck changes, on every status() -- a deck with
     no file of its own has none, and Save asks, or the folder mints
     one. The last binding is remembered (HKEY + HNKEY) so the next
     visit can offer the file back. */
  var HNKEY='semopts:'+SCOPE+':filefor';
  /* T598: and every deck's own handle, under its own key, so a reload
     loses none of them -- HKEY above is still the last one, whose deck
     the boot can reopen */
  var HKEYD=HKEY+'::';
  var fileFor='',fileHandles={};
  function bindFile(name,h){
    fileFor=name||'';
    fileHandles[fileFor]=h||null;
    fileHandle=h||null;fileName=h?(h.name||''):'';
    if(h){idbPut(HKEY,h).catch(function(){});lsSet(HNKEY,fileFor,true);}
    else {idbDel(HKEY).catch(function(){});lsDel(HNKEY);}
    /* T598: this deck's own, and its record names the file */
    if(fileFor){
      if(h){
        idbPut(HKEYD+fileFor,h).catch(function(){});
        deckMetaSet(fileFor,{file:h.name||'',home:'file'});
      } else {
        idbDel(HKEYD+fileFor).catch(function(){});
        deckMetaSet(fileFor,{file:null});
      }
    }
    /* T431: a file bound by hand settles what the boot readout was
       waiting on -- "click to reopen" went on showing after a file had
       been opened and saved, and its click then said "nothing to
       reopen" */
    if(fileWaits==='reopen') fileWaits='';
    if(fileReopen&&(!name||fileReopen.name===name)) fileReopen=null;
  }
  function fileSync(){
    var nm=(pres&&pres.name)||'';
    if(nm===fileFor) return;
    fileFor=nm;
    var h=fileHandles[nm]||null;
    fileHandle=h;fileName=h?(h.name||''):'';
    if(fileWaits!=='reopen') fileWaits='';
    /* T598: THE DECK SAVES WHERE IT LIVES. A deck kept in a file was
       followed by one kept here, and the second began asking for a file
       because the destination was one setting for every deck. */
    var home=deckHomeOf(nm);
    if(home!==saveTarget){
      saveTarget=home;
      if(typeof renderTargetBtn==='function') renderTargetBtn();
      if(typeof renderSaveBtn==='function') renderSaveBtn();
      if(typeof renderAutosaveItem==='function') renderAutosaveItem();
    }
  }
  /* a deck's home: the one it was given (a Save, a pick, a file opened
     into it), else the file it holds a handle to, else the default --
     each only where this page can save there */
  function deckHomeOf(nm){
    var m=(nm&&deckMeta(nm).home)||'';
    if(m==='project'&&APP.mode!=='app') m='';
    if(m==='file'&&!canPickFile&&!fileHandles[nm]) m='';
    if(!m&&fileHandles[nm]) m='file';
    return m||defaultSaveTarget();
  }
  /* idb / idbPut / idbDel / idbGet live in 10-decks.js since T429 (the
     draft store needs them too); the 'handles' store is their default */
  function permOK(h){
    if(!h||!h.queryPermission) return Promise.resolve(!!h);
    return h.queryPermission({mode:'readwrite'})
      .then(function(s){return s==='granted';}).catch(function(){
        return false;});
  }
  /* reading needs less than writing — a handle whose write grant lapsed
     can often still be read, which is enough to restore what it holds */
  function permReadOK(h){
    if(!h||!h.queryPermission) return Promise.resolve(!!h);
    return h.queryPermission({mode:'read'})
      .then(function(s){return s==='granted';}).catch(function(){
        return false;});
  }
  function permAsk(h){
    if(!h) return Promise.resolve(false);
    return permOK(h).then(function(ok){
      if(ok||!h.requestPermission) return ok;
      return h.requestPermission({mode:'readwrite'})
        .then(function(s){return s==='granted';})
        .catch(function(){return false;});
    });
  }
  /* a file name this deck can be found by, from the deck's own name */
  function deckFileName(){
    var n=String(pres.name||'presentation').trim()
      .replace(/[\\/:*?"<>|]+/g,'-').replace(/\s+/g,' ').slice(0,60);
    return (n||'presentation')+'.junoview.html';
  }
  function pickSaveFolder(){
    if(!canPickDir) return Promise.resolve(null);
    return window.showDirectoryPicker({mode:'readwrite',
      id:'junoview-decks'}).then(function(d){
      deckDir=d;deckDirName=d.name||'';
      lsSet(DNKEY,deckDirName);
      idbPut(DKEY,d).catch(function(){});
      return d;
    });
  }
  /* the file inside the default folder, made if it is not there yet.
     `silent` is an autosave, which has no user gesture behind it and
     so must never raise a permission prompt. */
  function folderFile(silent){
    if(!deckDir) return Promise.resolve(null);
    return (silent?permOK(deckDir):permAsk(deckDir)).then(function(ok){
      if(!ok) return null;
      return deckDir.getFileHandle(deckFileName(),{create:true})
        .then(function(h){
          bindFile(pres.name,h);   /* T416: this deck's file */
          if(!fileName) fileName=deckFileName();
          return h;
        }).catch(function(){return null;});
    });
  }
  function pickSaveFile(){
    if(!canPickFile) return Promise.resolve(null);
    return window.showSaveFilePicker({
      /* .junoview.html so double-clicking the file opens a browser; the
         picker API only takes single-dot extensions, so the double suffix
         goes in the suggested name */
      suggestedName:(pres.name||'presentation')+'.junoview.html',
      types:[{description:'Junoview presentation',
        accept:{'text/html':['.html']}}]
    }).then(function(h){
      /* REMEMBERING the file is best-effort: it must never delay or block
         the save itself, so it runs in the background (bindFile, T416) */
      bindFile(pres.name,h);
      followFileName();
      return h;
    });
  }
  /* ---- T398: THE FILE'S NAME IS THE PRESENTATION'S NAME ---------------
     Save as "my talk.junoview.html" and the deck went on being called
     "presentation-5" everywhere in Junoview -- the rail, the bar, the
     project file -- so the name you had just chosen was the one name
     nothing showed (2026-09-13, user: "Saving the presentation as a file
     name, doesn't change the name in junoview"). The stem of the file
     you picked becomes the presentation's name, by the one rename
     everything else uses. A name already taken stays as it was, and the
     rename says so. */
  function fileStem(name){
    return String(name||'').replace(/\.junoview\.html$/i,'')
      .replace(/\.(html|junoview|json)$/i,'').trim();
  }
  function followFileName(){
    var stem=fileStem(fileName);
    if(!stem||stem===pres.name) return false;
    return renamePresentation(stem);
  }
  /* ---- make the saved deck carry its own pictures ---------------------
     Every placed card's rendered body (figures are data: URIs already) is
     written into the presentation as `p.emb`, keyed by the ref exactly as
     it is saved — so a deck opened with no notebook, and no internet to
     re-fetch one, still shows every frame. Open notebooks are captured
     fresh at save time (the deck tracks the notebook, as ever); a card
     whose notebook is closed keeps its last saved copy instead of losing
     it. normPres absorbs `emb` back into the session store on load. */
  function embedAssets(list){
    list.forEach(function(p){
      if(p.kind==='view') return;
      var emb={};
      /* T606: a collection's cells are refs exactly as a frame's are, and
         travel the same way, so it too opens with no notebook */
      var refs=isColPres(p)?colRefsOf(p):[];
      (p.slides||[]).forEach(function(s){
        /* every notebook card this slide places, from BOTH the kinds that
           can hold one. A flip book's frames are refs exactly like a
           placed cell's, and leaving them out meant a self-contained deck
           opened with every frame blank — the one failure the embedded
           snapshots exist to prevent (2026-08-22). They dedupe by ref, so
           a flip book costs the same as placing its figures one by one. */
        (s.annots||[]).forEach(function(a){
          if(!a) return;
          if(a.k==='cell'&&a.ref) refs.push(a.ref);
          else if(a.k==='flip') flipFrames(a).forEach(function(f){
            if(f&&f.ref) refs.push(f.ref);});
        });
      });
      refs.forEach(function(ref){
          if(emb[ref]) return;
          var it=resolveRef(ref);
          if(it&&!it.emb){
            var b=cloneBody(ref);
            if(!b) return;
            var e={title:it.title||'',kind:it.kind||'',html:b.outerHTML};
            /* T303: html comes from cloneBody (kept) so the code must
               come from the same preference, or a deliberate save
               quietly advances half of the snapshot -- and embStore's
               guard compares only html, so it files no way back */
            var cc=it.hasCode?frameCode(ref):null;
            if(cc) e.code=cc.outerHTML;
            emb[ref]=e;
            embStore(normRef(ref),e);   /* keep the session copy fresh */
          } else {
            var e2=embFor(ref);
            if(e2){
              var cp={title:e2.title,kind:e2.kind,html:e2.html};
              if(e2.code) cp.code=e2.code;
              emb[ref]=cp;
            }
          }
      });
      if(Object.keys(emb).length) p.emb=emb;
      /* T321: the clips, from the session store -- the one copy a
         self-contained save can be made from */
      if(typeof mediaEmbed==='function') mediaEmbed(p);
    });
    /* how much rode along, for the save messages: embedding is automatic
       and was therefore INVISIBLE — with nothing ever saying the figures
       travelled, "save with images" read as a feature that did not exist
       (2026-08-21, user: "so there is no way to like 'save with
       images'"). Every save now says what it carried. */
    lastEmbCount=list.reduce(function(n,p){
      return n+(p.emb?Object.keys(p.emb).length:0);},0);
    embSaveSoon();
    return list;
  }
  var lastEmbCount=0;
  function embNote(){
    return lastEmbCount
      ?' — with '+lastEmbCount+' card'+(lastEmbCount===1?'':'s')
        +' embedded, so it opens without the notebook'
      :'';
  }
  /* ---- T433: A FILE HOLDS ONE PRESENTATION ----------------------------
     (2026-09-14, user: "The files on local keep seeming to just save to
     project junoview. Even though that is not the file name which gets
     confusing. Then project junoview doesn't appear in the list of
     recently opened files.") A .junoview.html used to carry EVERY deck
     the tab knew about, named after the one you were in. So opening a
     file brought all of them back under minted names ("talk-2",
     "talk-3", one more each time), Save from any of those wrote the
     whole library back into whichever file the first one had been
     bound to, and the readout named a file that was not this deck's.
     T416 already made a file belong to one deck; the file's contents
     now agree. The project file (app mode) is still the whole
     library -- that is what a project is. */
  function filePresentations(){
    var cp=deep(pres);delete cp.origin;
    return [cp];
  }
  function deckFileText(){
    return JSON.stringify({junoview:1,
      presentations:embedAssets(plainIfSingle(filePresentations()))},
      null,2);
  }
  /* how many decks a file's text holds, for the doors that open one */
  function fileDeckCount(txt){
    try{
      var obj=parseDeckText(txt);
      var list=(obj&&Array.isArray(obj.presentations))?obj.presentations
        :Array.isArray(obj)?obj:(obj&&Array.isArray(obj.slides))?[obj]:[];
      return list.filter(function(p){return p&&Array.isArray(p.slides);})
        .length;
    }catch(e){return 0;}
  }
  /* ---- the saved file is a real HTML page with the JSON inside it ----
     A bare-JSON ".junoview" was a dead end on disk: double-clicking it
     asked Windows to pick an app, and nothing said what it was
     (2026-08-18, user: "when opening it doesn't really recognise that
     this should be opened in a browser"). Saved as name.junoview.html the
     OS opens a browser, and the page identifies itself — the Junoview
     logo, the name, what it holds, and how to open it for editing. The
     data rides in a <script type="application/json"> block; both loaders
     (here and the Python sidecar reader) unwrap it, and plain old .junoview
     files still parse, so nothing already saved is stranded. `<` is
     escaped inside the JSON so no content can close the script block. */
  /* ---- T597: AND IT OPENS ---------------------------------------------
     (2026-09-30, user: "when I try and open a file from local that is a
     junoview, junoview opens, but it just says that this file can be
     opened with juno view, why can't it be opened?") The page told you
     to go and find Junoview. It carries Open in Junoview now
     (saved-file.js, the page's own copy of #jv-savedfile-js): a new tab
     on the Junoview this was saved from, or on the web, which asks and
     then opens the deck through File > Open's importer (handoffBoot,
     below). And it lists the slides by name, so which file is which can
     be told before anything opens. The Junoview app on this computer is
     not a place a file can send you back to -- its address carries a
     session token that is not written into files and changes on every
     start -- so a file saved there offers the web, and says how to open
     it in the app. Every closing tag below is split: this file runs
     inline in the page, and a whole one would end the script there. */
  var JV_WEB='https://junoview.com/';
  function handoffAppUrl(){
    if(APP.mode==='app') return '';
    var u=String(location.href||'').split('#')[0];
    return /^(https?|file):/i.test(u)?u:'';
  }
  var SAVED_FILE_CSS='body{margin:0;min-height:100vh;display:flex;'
    +'align-items:center;justify-content:center;background:#0b141d;'
    +'color:#dce6ee;font-family:system-ui,sans-serif}'
    +'main{text-align:center;padding:40px 24px;max-width:600px;width:100%;'
    +'box-sizing:border-box}img{width:88px;height:88px}h1{font-size:22px;'
    +'margin:16px 0 4px}p{color:#8ba0b2;font-size:14px;line-height:1.6;'
    +'margin:8px 0}code{background:#16273a;border-radius:4px;'
    +'padding:1px 6px;font-size:13px}[hidden]{display:none!important}'
    +'.jv-actions{display:flex;gap:8px;justify-content:center;'
    +'flex-wrap:wrap;margin:14px 0 4px}button{font:inherit;font-size:14px;'
    +'border-radius:8px;padding:9px 18px;cursor:pointer;'
    +'border:1px solid #2c4257;background:#16273a;color:#dce6ee}'
    +'button:hover{border-color:#39a9c0}.jv-primary{background:#39a9c0;'
    +'border-color:#39a9c0;color:#04222b;font-weight:600;font-size:15px;'
    +'padding:11px 26px}.jv-primary:hover{background:#56c1d6}'
    +'.jv-msg{min-height:1.6em;color:#dce6ee}.jv-warn{color:#f0a848}'
    +'.jv-ok{color:#46a892}.jv-slides{text-align:left;margin:20px auto 8px;'
    +'padding:12px 16px 12px 42px;max-height:38vh;overflow:auto;'
    +'background:#0f1c29;border:1px solid #1d3246;border-radius:10px;'
    +'font-size:13.5px;line-height:1.75;color:#b8c7d3}'
    +'.jv-slides i{color:#6f8597}.jv-small{font-size:12.5px;margin-top:16px}';
  /* the slides by what they are called in the strip -- a heading where
     there is one -- one line each */
  function savedSlideNames(){
    return (pres.slides||[]).map(function(s){
      var t='';
      try{t=(typeof slideHeading==='function'&&slideHeading(s))
        ||slideTitle(s)||'';}catch(e){t='';}
      return String(t).replace(/\s+/g,' ').trim().slice(0,90);
    });
  }
  function junoviewFileHtml(){
    var json=deckFileText().replace(/</g,'\\u003c');
    var list=plainIfSingle(filePresentations());   /* T433: this deck */
    var slides=(Array.isArray(list)?list:[list]).reduce(function(k,p2){
      return k+((p2&&p2.slides&&p2.slides.length)||0);},0);
    var icon=(document.querySelector('link[rel="icon"]')||{}).href||'';
    var nm=pres.name||APP.order[0]||'presentation';
    var name=esc(nm);
    var names=savedSlideNames();
    var cfg=JSON.stringify({name:nm,file:fileName||deckFileName(),
      app:handoffAppUrl(),web:JV_WEB,from:APP.mode||'page'})
      .replace(/</g,'\\u003c');
    var js=String(($('#jv-savedfile-js')||{}).textContent||'')
      .replace(/<\/(script)/gi,'<\\/$1');
    return '<!doctype html>\n<html lang="en"><head><meta charset="utf-8">'
      +'<meta name="viewport" content="width=device-width,initial-scale=1">'
      +'<title>'+name+' — Junoview presentation</title>'
      +(icon?'<link rel="icon" href="'+icon+'">':'')
      +'<style>'+SAVED_FILE_CSS+'</style></head><body><main>'
      +(icon?'<img src="'+icon+'" alt="Junoview">':'')
      +'<h1>'+name+'</h1>'
      +'<p>A saved <b>Junoview</b> presentation &mdash; '+slides+' slide'
      +(slides===1?'':'s')+'.</p>'
      +(js?'<p class="jv-actions"><button type="button" id="jv-open" '
        +'class="jv-primary">Open in Junoview</button></p>'
        +'<p class="jv-msg" id="jv-open-msg" role="status" '
        +'aria-live="polite"></p>'
        +'<p class="jv-actions"><button type="button" id="jv-open-next" '
        +'hidden></button><button type="button" id="jv-open-close" hidden>'
        +'Close this tab</button></p>':'')
      +(names.length?'<ol class="jv-slides">'+names.map(function(t,i){
          return '<li>'+(t?esc(t):'<i>slide '+(i+1)+'</i>')+'</li>';
        }).join('')+'</ol>':'')
      +'<p class="jv-small">This file <i>is</i> the presentation, and '
      +'Junoview reads it back from here: press <b>Open in Junoview</b>, '
      +'use <code>Open&hellip;</code> inside Junoview, or drop the file '
      +'onto a Junoview window'
      +(APP.mode==='app'?' &mdash; the Junoview app on this computer '
        +'included, once it is running':'')
      +'. Kept next to its notebook, <code>junoview notebook.ipynb</code> '
      +'loads it too.</p>'
      +'</main><script type="application/json" id="junoview-open">'+cfg
      +'</'+'script><script type="application/json" id="junoview-data">\n'
      +json+'\n</'+'script>'
      +(js?'<script>'+js+'</'+'script>':'')
      +'</body></html>\n';
  }
  /* both file forms — the HTML wrapper and a bare-JSON .junoview from
     before it existed — hand back the same object */
  function parseDeckText(txt){
    var t=String(txt||'').trim();
    if(t.charAt(0)==='<'){
      var m2=t.match(
        /<script type="application\/json" id="junoview-data">([\s\S]*?)<\/script>/);
      if(!m2) throw new Error('no Junoview data in that HTML file');
      t=m2[1];
    }
    return JSON.parse(t);
  }
  /* write to the remembered file. `silent` = an autosave: never pops a
     permission prompt (there is no user gesture behind it) */
  /* T406: WHY THE FILE IS NOT BEING WRITTEN, when it is not. An autosave
     to a file that stands down -- no file chosen yet, or the browser has
     not re-granted write permission since the reload -- used to stand
     down silently, so the readout said "unsaved — saving…" forever and
     the only visible noise was the draft copy's "browser full" toast,
     which read as "it is saving to the browser instead" (2026-09-13,
     user: "I think the auto-save is trying to save to browser and not
     local"). The readout names the reason now, and the one click that
     fixes it. */
  var fileWaits='';
  function saveToFile(silent){
    flushTextEdits();
    /* T235: an autosave with no file can still make one, if there is a
       default folder to make it in. Without one it stands down, as it
       always has -- an autosave must never open a file dialog. */
    if(!fileHandle&&!deckDir&&silent){
      fileWaits='pick';status();
      return Promise.resolve(false);
    }
    var savedHist=!silent?histCapture():null;
    var savedName=pres.name||'untitled',savedSig=deckSaveSig(pres);
    var fileText;
    try{fileText=junoviewFileHtml();}
    catch(e){
      if(!silent) toast('Save failed: '+((e&&e.message)||e));
      return Promise.resolve(false);
    }
    var op=(fileHandle?Promise.resolve(fileHandle)
      :(deckDir?folderFile(silent)
        :(silent?Promise.resolve(null):pickSaveFile())))
      .then(function(h){
        if(!h) return false;
        /* T398: picking a file may have renamed the deck after it, and
           the text was rendered before the pick */
        if(pres.name!==savedName){
          savedName=pres.name||'untitled';savedSig=deckSaveSig(pres);
          fileText=junoviewFileHtml();
        }
        return (silent?permOK(h):permAsk(h)).then(function(ok){
          if(!ok){
            if(!silent) toast('Junoview needs permission to write '
              +(fileName||'that file'));
            fileWaits='perm';status();   /* T406 */
            return false;
          }
          return h.createWritable().then(function(w){
            return Promise.resolve(w.write(fileText))
              .then(function(){return w.close();});
          }).then(function(){
            fileWaits='';
            /* the browser copy STAYS. Deleting it made the file the ONLY
               copy, and nothing ever read the file back at startup — save
               to file, close the browser, and the presentation was gone
               from the app (2026-08-20, user: "I made a presentation for
               tomorrow and now am locked out of it"). */
            saveStamp=new Date();saveKind=silent?'auto':'manual';
            saveWhere=fileName||'file';   /* T483 */
            deckMetaSet(savedName,{saved:Date.now(),home:'file',
              file:fileName||''});   /* T598 */
            if(stillSaved(savedName,savedSig)) source='saved';
            else {source='draft';scheduleDraftWrite();}
            status();renderTargetBtn();renderPresRow();
            if(!silent) toast('Saved to '+(fileName||'your file')+embNote());
            return true;
          });
        });
      }).catch(function(e){
        if(!silent&&(!e||e.name!=='AbortError'))
          toast('Save failed: '+((e&&e.message)||e));
        return false;
      });
    if(savedHist) snapTake('saved',savedHist,op);
    return op;
  }
  /* WHERE it goes, never WHICH file. The filename is the widest thing
     that could ever land in this bar, it changes under you when you pick
     a different file, and it answers a question nobody asked — the one
     you ask of a Save button is "is this going somewhere I will find it
     again?" (2026-08-20, user: "I don't want you to have 'save to
     <filename>' ... I want you to just say if it's save to local or
     browser"). The filename is in the tooltip. */
  function targetLabel(){
    if(saveTarget==='project') return 'This project';
    if(saveTarget==='file')
      return deckDirName?('Your '+deckDirName+' folder')
        :'On this computer';
    return 'In this browser';
  }
  /* T483: the same destination as a phrase after "to" -- "Saving to
     In this browser" read as two sentences */
  function targetPhrase(){
    if(saveTarget==='project') return 'this project';
    if(saveTarget==='file')
      return deckDirName?('your '+deckDirName+' folder')
        :'a file on this computer';
    return 'this browser';
  }
  function renderTargetBtn(){
    var b=$('#dc-target'); if(!b) return;
    /* the label is just the DESTINATION — "Saved to:" lives in the
       tooltip. The long form was the widest thing in the ribbon's File
       group and wrapped the whole toolbar to a third row (2026-08-05). */
    /* the chevron of a split button: "Save" is its label. The destination
       is named in the menu this opens, and in the tooltip — in the ribbon
       it was a second, wordier control that looked like a rival Save. */
    b.innerHTML='&#9662;';
    b.title='Saving to '+targetPhrase()+' — click to change where';
    var th=$('#tg-head');
    if(th) th.textContent='save to — now: '+targetLabel();
    b.classList.toggle('tg-file',saveTarget==='file');
    var pj=$('#tg-project'); if(pj) pj.hidden=(APP.mode!=='app');
    var pk=$('#tg-pick'); if(pk) pk.hidden=(saveTarget!=='file');
    /* T235: the folder row names the folder once there is one, and a
       second row appears to undo it */
    var fd=$('#tg-folder');
    if(fd){
      fd.hidden=!canPickDir;
      fd.textContent=deckDirName
        ?('Folder: '+deckDirName+' \u2014 change\u2026')
        :'A folder on this computer\u2026';
      fd.title=deckDirName
        ?('Every presentation saves itself into '+deckDirName
          +' as a .junoview.html file. Nothing to answer, and no '
          +'browser storage to run out of.')
        :'Pick one folder and Junoview keeps its own file in there '
          +'from now on \u2014 for this presentation and every one '
          +'after it. No dialog each time, and no browser storage to '
          +'run out of.';
      fd.setAttribute('aria-pressed',
        (saveTarget==='file'&&!!deckDirName).toString());
    }
    var ff=$('#tg-folder-forget');
    if(ff) ff.hidden=!deckDirName;
    var tf=$('#tg-file');
    if(tf) tf.textContent=canPickFile
      ?'A file on your computer…'
      :'A file (this browser can’t — use Download a copy)';
    if(tf) tf.disabled=!canPickFile;
    [['#tg-project','project'],['#tg-browser','browser'],
     ['#tg-file','file']].forEach(function(p){
      var el=$(p[0]);
      if(el) el.setAttribute('aria-pressed',(saveTarget===p[1]).toString());
    });
    b.setAttribute('data-tip',
      saveTarget==='file'
        ?'Saving writes '+(fileName||'a .junoview file')
          +(deckDirName?(' in your '+deckDirName+' folder'):'')
          +' — Junoview remembers it between visits'
        :saveTarget==='project'
          ?'Saving writes junoview_project.json next to your notebooks'
          :'Kept in this browser. Switch to a file to save it on your '
            +'computer as .junoview');
  }
  function setTarget(t){
    saveTarget=t;lsSet(TGKEY,t);
    /* T598: this deck's home, and the default for decks with none */
    if(pres&&pres.name) deckMetaSet(pres.name,{home:t});
    renderTargetBtn();renderSaveBtn();status();
    /* T483: the Autosave door's words name the destination too; they
       kept saying "to project" after the target changed */
    if(typeof renderAutosaveItem==='function') renderAutosaveItem();
  }
  /* PICK A FOLDER, ONCE, FOR EVERYTHING AFTER (T235). Lifted out of the
     menu row's handler by T283 so the first-run prompt runs the same
     code rather than a second copy of it -- three files each holding
     their own copy of one action is a shape this codebase already has
     too much of. */
  function chooseSaveFolder(){
    if(!canPickDir){
      toast('This browser cannot pick a folder \u2014 use File \u203a '
        +'Download a copy');
      return Promise.resolve(false);
    }
    if(!requireName()) return Promise.resolve(false);
    return pickSaveFolder().then(function(d){
      if(!d) return false;
      /* a new folder means a new file: forget the old handle, or
         the next save would write the file you just moved away from */
      bindFile(pres.name,null);
      setTarget('file');
      return saveToFile(false).then(function(){
        toast('Every presentation now saves itself into '
          +deckDirName+' \u2014 this one is '+(fileName||'there')
          +' already.',6000);
        return true;
      });
    }).catch(function(e){
      if(!e||e.name!=='AbortError')
        toast('Could not use that folder: '+((e&&e.message)||e));
      return false;
    });
  }
  /* ---- WHERE IS THIS GOING TO LIVE? (T283) ----------------------------
     (2026-09-05, user: "When opening a new file, it should prompt where
     to save to (local and then there can be a default you select), or
     browser, with the warning about the browser.")

     Every destination here already existed behind the chevron beside
     Save -- what did not exist was being ASKED. A deck defaulted to
     browser storage silently, and T235 records how that ends: "the save
     to browser thing isn't working too great ... I just got 'browser
     full' error". Finding out your work lives somewhere with a quota at
     the moment you exceed it is the worst possible time to learn it.

     Asked ONCE, on the first new deck, and never again: answering writes
     TGKEY, and the presence of TGKEY is the whole condition. Dismissing
     answers "this browser" rather than leaving it unset, because a
     prompt that comes back every time you press New is a nag. */
  function saveTargetAsked(){return !!lsGet(TGKEY);}
  /* held in the closure, NOT looked up by id: an id that only ever
     exists after this function runs is a phantom to
     test_every_id_the_js_looks_up_exists_somewhere, and it is right to
     say so -- the check is what catches doors onto nothing. */
  var saveAskEl=null;
  function askWhereToSave(){
    if(saveTargetAsked()) return;
    if(deckDirName) return;          /* a folder already answers it */
    if(saveAskEl){overlayHide(saveAskEl);saveAskEl.remove();}
    var m=document.createElement('div');
    m.className='sh-menu save-ask';saveAskEl=m;
    menuHead(m,'where should this be kept?');
    function row(label,note,fn){
      var b=document.createElement('button');
      b.className='dbtn vw-opt sa-opt';
      var t=document.createElement('span');
      t.className='sa-t';t.textContent=label;
      var n=document.createElement('span');
      n.className='sa-n';n.textContent=note;
      b.appendChild(t);b.appendChild(n);
      b.addEventListener('click',function(e){
        e.stopPropagation();overlayHide(m);fn();
      });
      m.appendChild(b);
      return b;
    }
    if(APP.mode==='app')
      row('This project','Beside the notebook it came from, on this '
        +'computer.',function(){
        setTarget('project');
        toast('Saving to this project. Change it beside Save.',5000);
      });
    if(canPickDir)
      row('A folder on this computer','Pick it once. Every presentation '
        +'after this one saves itself there too, with nothing to answer '
        +'and no size limit.',function(){chooseSaveFolder();});
    /* T296: FOR NOW, AND IT SAYS SO. This read as a third peer choice
       when it is the one answer that can lose your work -- and it is
       still the right default for somebody who just wants to start
       (2026-09-05, user: "an option 'keep in browser memory for now' or
       something with a warning attached to that"). The label carries
       the provisional, the note carries the warning, and the row is
       marked so it does not look like the two that keep a file. */
    var br=row('Keep it in this browser for now',
      'Nothing is written to a file. Clearing your browser\u2019s site '
      +'data loses the deck, and one with figures can fill the space a '
      +'browser allows. Change it beside Save whenever you like.',
      function(){
      setTarget('browser');
      toast('Kept in this browser for now \u2014 nothing is on disk. '
        +'Change it beside Save; a folder on your computer has no size '
        +'limit and cannot be cleared by accident.',7000);
    });
    if(br) br.classList.add('sa-warn');
    deckEl.appendChild(m);
    /* AFTER the click that opened the deck has finished bubbling. New
       presentation is reached BY a click -- the front door's New, the
       rail's, File > New -- and that click carries on to document,
       where overlayBoot's outside-click handler pops whatever is on the
       stack. Shown synchronously, this prompt was pushed and immediately
       closed: built correctly, hidden, zero width. Driven, 2026-09-05. */
    setTimeout(function(){
      if(saveTargetAsked()||deckDirName){m.remove();return;}
      overlayShow(null,m);
    },80);
  }
  var AUTOKEY='semopts:'+SCOPE+':autosave';
  /* HOW OFTEN, not just whether. The interval was a hardcoded 1200ms
     debounce: invisible, unsettable, and — being a debounce — restarted
     by every keystroke, so it only ever fired once you had stopped
     working. It is a countdown you can read and choose now (2026-08-29,
     T70, user: "please make there be an auto-save timer"). "Off" is the
     same fact as the old on/off flag, so the two doors write one setting
     and cannot disagree. */
  var AUTOSECKEY='semopts:'+SCOPE+':autosecs';
  var AUTO_STEPS=[2,5,15,30,60,300];
  var autosaveOn=lsGet(AUTOKEY)!=='0';
  var autoSecs=(function(){
    var n=parseInt(lsGet(AUTOSECKEY),10);
    return AUTO_STEPS.indexOf(n)>=0?n:15;
  })();
  var autoTimer=null,autoDue=0,autoTick=null;
  function autoSecsLabel(s){
    return s<60?(s+' seconds'):((s/60)+' minute'+(s>60?'s':''));
  }
  /* THE BROWSER IS A DESTINATION TOO. Its deck was already written to
     localStorage 300ms after every keystroke by scheduleDraftWrite, but
     nothing stamped that write — so the readout said "unsaved" about a
     deck that was on disk, and the autosave control, which returned
     early for every target but project and file, did nothing whatsoever
     on the target most people are on (T70). */
  function autoSaveBrowser(){
    flushTextEdits();
    flushDraftWrite();
    if(lsIsFull()){status();return;}
    saveStamp=new Date();saveKind='auto';source='saved';
    saveWhere='browser';   /* T483 */
    status();
  }
  function cancelAutosave(){
    clearTimeout(autoTimer);autoTimer=null;autoDue=0;
    clearInterval(autoTick);autoTick=null;
  }
  function autoSaveNow(){
    autoTimer=null;autoDue=0;
    clearInterval(autoTick);autoTick=null;
    if(saveTarget==='file') saveToFile(true);
    else if(saveTarget==='project'&&APP.mode==='app') saveToProject(true);
    else autoSaveBrowser();
    renderAutoTick();
  }
  function scheduleAutosave(){
    /* a remembered file autosaves too — silently, and only while the
       browser still grants write permission (after a reload it waits for
       the first Save click, which carries the user gesture it needs) */
    if(!autosaveOn||!autoSecs
      ||(saveTarget==='project'&&APP.mode!=='app')){
      cancelAutosave();renderAutoTick();return;
    }
    /* A TIMER, NOT A DEBOUNCE: a countdown already running is left to
       finish, or "every 5 minutes" would never arrive while you typed —
       which is the only stretch of time it is there for. */
    if(!autoTimer){
      autoDue=Date.now()+autoSecs*1000;
      autoTimer=setTimeout(autoSaveNow,autoSecs*1000);
      clearInterval(autoTick);
      /* The interval is visible in the label. A seconds countdown made
         the whole save area twitch once a second and added no useful
         information while somebody was typing. */
    }
    /* ...AND PUT THE FIGURES BACK. The 1.2s autosave is deliberately
       refs-only, because embedding rewrites megabytes to a synced disk on
       every keystroke. But it is also the LAST writer: you would click
       Save, get "with 37 cards embedded, so it opens without the
       notebook", nudge one text box, and 1.2 seconds later the project
       file held refs only again — self-contained until you touched it
       (2026-08-22). So a second, much lazier timer consolidates once you
       have actually stopped typing. The window in which the file is
       refs-only is now ~20s of idle rather than forever. */
    clearTimeout(embedTimer);
    embedTimer=setTimeout(function(){
      if(saveTarget==='project'&&APP.mode==='app'&&autosaveOn)
        saveToProject(true,true);
    },20000);
  }
  var embedTimer=null;
  function renderAutosaveItem(){
    /* Two doors, one state: the File menu (where it has always been) and
       the top bar, where you can READ it without opening a menu. A save
       setting you have to go looking for to check is a save setting you
       do not trust (2026-08-20, user asked for "autosave frequency" in
       the thin bar). */
    var on=autosaveOn&&!!autoSecs;
    var mi=$('#mi-autosave');
    if(mi){
      mi.hidden=false;
      mi.textContent='Autosave: '
        +(on?('every '+autoSecsLabel(autoSecs)):'off');
    }
    var qa=$('#qat-auto');
    if(qa){
      /* every target autosaves now — the project, a remembered file and
         the browser — so this is never a control with nothing to say */
      qa.hidden=false;
      /* the reload icon plus a two-width label: fitQat's compaction rung
         swaps "Autosave" for "Auto" — shortened, never hidden. The
         countdown is its own span so the tick can rewrite four
         characters a second without re-measuring the bar. */
      qa.innerHTML=bic('reload')
        +' <span class="qat-long">Autosave</span>'
        +'<span class="qat-short">Auto</span> '
        +(on?(autoSecs<60?(autoSecs+'s'):((autoSecs/60)+'m')):'off')
        +'<span class="qat-tick" id="qat-tick"></span>';
      qa.setAttribute('aria-pressed',on?'true':'false');
      qa.title=on
        ?('Saving to '+whereSaved()+' every '+autoSecsLabel(autoSecs)
          +' while you work. Click to change how often, or turn it off.')
        :'Autosave is off — your work is only written when you press '
          +'Save. Click to choose how often it should save itself.';
      renderAutoTick();
      /* the label just changed width — re-judge the thin bar */
      requestAnimationFrame(fitQat);
    }
  }
  /* the countdown, and ONLY the countdown: no innerHTML, no fitQat. A
     once-a-second re-measure of a fourteen-control bar is how a visible
     timer turns into a stutter. */
  function renderAutoTick(){
    var t=$('#qat-tick');
    if(!t) return;
    t.textContent='';
  }
  /* ONE writer for both doors. secs===0 is "off" and leaves the chosen
     interval remembered, so turning it back on restores it. */
  function setAutosave(secs){
    autosaveOn=!!secs;
    if(secs) autoSecs=secs;
    lsSet(AUTOKEY,autosaveOn?'1':'0');
    lsSet(AUTOSECKEY,String(autoSecs));
    cancelAutosave();
    renderAutosaveItem();renderSaveBtn();status();
    if(autosaveOn){
      scheduleAutosave();
      toast('Autosaving to '+whereSaved()+' every '
        +autoSecsLabel(autoSecs));
    } else toast('Autosave off — press Save to write your changes');
  }
  /* the picker. The button has carried aria-haspopup since it was added
     and had never had a menu behind it (T70). Floated like every other
     menu in this bar, so the qat's scroll floor cannot clip it. */
  (function(){
    var btn=$('#qat-auto'),menu=$('#qat-auto-menu');
    if(!btn||!menu) return;
    function close(){overlayHide(menu);}
    function build(){
      menu.innerHTML='';
      var h=document.createElement('div');
      h.className='dc-mhead';h.textContent='autosave every';
      menu.appendChild(h);
      AUTO_STEPS.forEach(function(s){
        var o=document.createElement('button');
        o.className='dc-mi';o.type='button';
        o.textContent='Every '+autoSecsLabel(s);
        if(autosaveOn&&autoSecs===s) o.setAttribute('aria-pressed','true');
        o.addEventListener('click',function(e){
          e.stopPropagation();close();setAutosave(s);});
        menu.appendChild(o);
      });
      var sep=document.createElement('div');
      sep.className='dc-msep';menu.appendChild(sep);
      var off=document.createElement('button');
      off.className='dc-mi';off.type='button';
      off.textContent='Off — only when I press Save';
      if(!autosaveOn) off.setAttribute('aria-pressed','true');
      off.addEventListener('click',function(e){
        e.stopPropagation();close();setAutosave(0);});
      menu.appendChild(off);
    }
    btn.addEventListener('click',function(e){
      e.stopPropagation();
      if(menu.hidden){
        build();overlayShow(btn,menu);floatMenu(btn,menu);
      } else overlayHide(menu);
    });
    /* T263: a leftover outside-click closer used to live here, testing
       an undeclared `wrap` -- so in this strict IIFE every click while
       the menu was open threw a ReferenceError. It was also redundant:
       overlayShow registers the menu with the single overlay owner,
       whose document-click handler closes it on an outside click and
       whose capture-phase Escape handler closes it on Escape. */
  })();
  var miAuto=$('#mi-autosave');
  if(miAuto) miAuto.addEventListener('click',function(){
    closeMenu();
    setAutosave(autosaveOn?0:autoSecs);
  });

  /* always-visible Save button; the File menu keeps the rest */
  var saveBtn=$('#dc-save');
  function renderSaveBtn(){
    if(!saveBtn) return;
    if(saveTarget==='file'){
      saveBtn.setAttribute('data-tip','Save now to '
        +(fileName||'the .junoview file you pick')
        +' — Junoview remembers it between visits');
    } else if(saveTarget==='project'&&APP.mode==='app'){
      saveBtn.setAttribute('data-tip','Save now to '
        +'junoview_project.json'
        +(autosaveOn
          ?' — autosave is ON: every change saves itself within '
            +(typeof autoSecsLabel==='function'?autoSecsLabel(autoSecs)
              :'a moment')   /* T483: the interval it actually is */
          :' — autosave is OFF, only this button saves'));
    } else {
      saveBtn.setAttribute('data-tip','Kept in this browser '
        +'automatically as you edit — Save confirms it. The \u25be beside '
        +'Save keeps it as a file on your computer instead');
    }
    saveBtn.removeAttribute('title');
  }
  /* ---- T434: CLOSING WITH CHANGES THAT ARE NOT SAVED YET ASKS --------
     (2026-09-14, user: "you can close things if they are not saved
     which is an issue. If there are unsaved changes it needs to warn
     you before closing.") The browser copy is written as you type, so
     inside this browser nothing is lost -- but a deck whose home is a
     file or the project file has changes that are not THERE until the
     next Save or autosave lands, and a full browser keeps nothing at
     all. Closing the tab or reloading, and closing the deck's row in
     the rail, ask in those cases and nowhere else. */
  function unsavedWhere(){
    if(!pres||!pres.slides||!editsThisVisit) return '';
    if(saveTarget==='file') return source==='draft'?(fileName||'a file'):'';
    if(saveTarget==='project'&&APP.mode==='app')
      return source==='draft'?'junoview_project.json':'';
    return draftsFull()?'nowhere':'';
  }
  function saveNow(){
    if(saveTarget==='file') return saveToFile(false);
    if(saveTarget==='project'&&APP.mode==='app') return saveToProject(false);
    return Promise.resolve(false);
  }
  /* resolves true when the deck may close: nothing unsaved, or saved
     now, or the loss accepted out loud */
  function closeGuard(nm){
    flushTextEdits();
    var w=unsavedWhere();
    if(!w) return Promise.resolve(true);
    nm=nm||pres.name||'this presentation';
    if(w==='nowhere')
      return new Promise(function(res){
        askYes({title:'Close \u201c'+nm+'\u201d and lose its changes?',
          what:'Its changes are kept NOWHERE \u2014 this browser is full.',
          ok:'Close and lose them',cancel:'Keep it open to save it',
          danger:true},function(y){res(y===true);});
      });
    return new Promise(function(res){
      askYes({title:'Save \u201c'+nm+'\u201d before closing?',
        what:'It has changes not yet saved to '+w+'.',
        ok:'Save and close',cancel:'Keep it open'},function(y){res(y===true);});
    }).then(function(y){
      if(!y) return false;
      return saveNow().then(function(ok){
        if(!ok) toast('Not closed \u2014 the save did not happen',6000);
        return !!ok;
      });
    });
  }
  window.addEventListener('beforeunload',function(e){
    try{flushTextEdits();}catch(err){}
    if(!unsavedWhere()) return;
    e.preventDefault();
    e.returnValue='';   /* the browser's own "leave site?" prompt */
  });
  if(saveBtn) saveBtn.addEventListener('click',function(){
    if(!requireName()) return;
    if(saveTarget==='project'&&APP.mode==='app'){saveToProject(false);return;}
    if(saveTarget==='file'){saveToFile(false);return;}
    /* the typed word first: a paragraph still in the DOM is not in the
       deck, and Save must not report a state it did not save */
    flushTextEdits();
    var savedHist=histCapture(); /* also mints ids before serialisation */
    /* T429: the draft store keeps it in memory at once and in IndexedDB
       a moment later; only a refused IndexedDB write can fail it */
    var ok=draftSet(pres.name||'untitled',JSON.stringify(pres))
      &&!draftsFull();
    /* The pointer is convenient, not the save. Its quota result must not
       reverse or clear the outcome of writing the actual deck. */
    if(ok){
      try{localStorage.setItem(PFX+'last',pres.name||'untitled');}
      catch(e){}
    }
    if(!ok){
      /* DO NOT stamp a save that did not happen. This branch used to set
         saveStamp/saveKind and toast success unconditionally, so a write
         that threw on quota still rendered "saved to browser · 14:32"
         (2026-08-22). */
      status();
      toast('NOT saved \u2014 this browser is full. The \u25be beside '
        +'Save \u203a "A folder on this computer" keeps every '
        +'presentation as a file instead, with no limit; File \u203a '
        +'Download a copy saves this one right now.',11000);
      return;
    }
    /* EVERY EXPLICIT SAVE is a point you might want back -- the
       same rule the notebook's snapshots follow (T32) */
    if(savedHist){
      var snapNm=pres.name||'untitled',snapLen=savedHist.txt.length;
      snapTake('saved',savedHist).then(function(){
        return histIndexAt(snapNm);
      }).then(function(ix){
        /* T569: in this browser the save and the autosave write the same
           draft, so the version a Save took IS the saved copy -- named
           here for Discard changes to go back to. A deduped snapshot
           leaves the newest entry holding the same words, so it is the
           one either way; a failed write names nothing. */
        var e=ix[ix.length-1];
        if(e&&e.len===snapLen) deckMetaSet(snapNm,{savedSnap:e.id});
      }).catch(function(){});
    }
    saveStamp=new Date();saveKind='manual';
    saveWhere='browser';   /* T483 */
    deckMetaSet(pres.name||'untitled',{saved:Date.now(),
      home:'browser'});   /* T598 */
    status();
    /* T266: a toast says what just happened. Where it is kept and what
       the caret beside Save does are on the button's own tooltip,
       which is there when you look rather than for four seconds. */
    toast('Saved to this browser');
  });
  /* ---- the "Saved to" picker ---- */
  (function(){
    var btn=$('#dc-target'),menu=$('#target-menu');
    if(!btn||!menu) return;
    function close(){overlayHide(menu);}
    btn.addEventListener('click',function(e){
      e.stopPropagation();
      if(menu.hidden){
        /* floated so the qat's scroll floor can never clip it */
        overlayShow(btn,menu);floatMenu(btn,menu);
      } else overlayHide(menu);
    });
    var pj=$('#tg-project');
    if(pj) pj.addEventListener('click',function(){
      close();setTarget('project');
      toast('Saving now writes junoview_project.json');
    });
    var br=$('#tg-browser');
    if(br) br.addEventListener('click',function(){
      close();setTarget('browser');
      toast('Kept in this browser from now on');
    });
    function chooseFile(){
      close();
      if(!canPickFile){
        toast('This browser can’t save straight to a file — '
          +'use File › Download a copy');
        return;
      }
      if(!requireName()) return;
      pickSaveFile().then(function(h){
        if(!h) return;
        setTarget('file');
        return saveToFile(false);
      }).catch(function(e){
        if(!e||e.name!=='AbortError')
          toast('Could not choose a file: '+((e&&e.message)||e));
      });
    }
    var tf=$('#tg-file');
    if(tf) tf.addEventListener('click',function(){
      if(saveTarget==='file'&&fileHandle){
        close();setTarget('file');
        toast('Saving writes '+fileName);
        return;
      }
      chooseFile();
    });
    var pk=$('#tg-pick');
    if(pk) pk.addEventListener('click',chooseFile);
    /* T235: pick the folder, and everything after it goes there */
    var fd=$('#tg-folder');
    if(fd) fd.addEventListener('click',function(){
      close();chooseSaveFolder();
    });
    var ff=$('#tg-folder-forget');
    if(ff) ff.addEventListener('click',function(){
      close();
      deckDir=null;deckDirName='';
      lsDel(DNKEY);idbDel(DKEY).catch(function(){});
      renderTargetBtn();renderSaveBtn();
      toast('Junoview will ask which file from now on. The file it '
        +'already made is still there.',6000);
    });
    /* the folder is remembered between visits, like the file */
    idbGet(DKEY).then(function(d){
      if(!d) return;
      return permReadOK(d).then(function(ok){
        if(!ok) return;
        deckDir=d;deckDirName=d.name||deckDirName;
        lsSet(DNKEY,deckDirName);
        /* THE POINT OF IT: a remembered folder means local IS the
           default, including for a presentation made after it was
           chosen. Only 'browser' is overridden -- a project build
           keeps writing junoview_project.json. */
        /* T598: the DEFAULT -- a deck given this browser as its home by
           name keeps it; the one on screen follows its own record */
        if(defaultSaveTarget()==='browser') lsSet(TGKEY,'file');
        var home0=deckHomeOf((pres&&pres.name)||'');
        if(home0!==saveTarget){saveTarget=home0;status();}
        renderTargetBtn();renderSaveBtn();
      });
    }).catch(function(){});
    /* a file chosen on an earlier visit is still remembered */
    idbGet(HKEY).then(function(h){
      if(!h) return;
      return rememberedFileBoot(h,lsGet(HNKEY)||lsGet(PFX+'last')||'');
    }).catch(function(){});
    fileHandlesBoot();   /* T598: and every other deck's */
    renderTargetBtn();
  })();
  /* ---- T416: THE REMEMBERED FILE, ON THE NEXT VISIT --------------------
     Bound to the deck it was for. Write permission lapsed (it always
     does after a reload) used to flip the target to the BROWSER --
     silently, and for a deck that only ever fitted in the file, which
     is how "saved to local" stopped being true. The target stays
     "file" and the readout asks for the one click that re-grants it
     (T406's readout). If the file can be read now, the deck it holds
     is restored: into the library when it fits, and opened from the
     object in hand when it is the deck this visit opened on and the
     store has no copy. If it cannot be read without a click, the
     readout offers "click to reopen", one click, no dialog. */
  var fileReopen=null;
  function deckHas(name){
    return !!(name&&(draftGet(name)||savedByName(name)));
  }
  function rememberedFileBoot(h,forName){
    if(!h) return Promise.resolve();
    forName=forName||'';
    fileHandles[forName]=h;
    var mine=(forName===((pres&&pres.name)||''));
    if(mine){fileHandle=h;fileName=h.name||'';fileFor=forName;}
    return permOK(h).then(function(ok){
      if(!ok&&mine&&saveTarget==='file') fileWaits='perm';
      renderTargetBtn();renderSaveBtn();status();
    }).then(function(){
      return permReadOK(h).then(function(ok){
        if(ok) return h.getFile().then(function(f){return f.text();})
          .then(function(txt){fileRestore(txt,forName);});
        fileReopen={h:h,name:forName};
        if(!deckHas(forName)){
          fileWaits='reopen';status();
          /* T431: SAID OUT LOUD. The page has just opened on a default
             deck in this one's place, and the pill beside Save was the
             only thing that knew where the real one was. */
          toast('\u201c'+forName+'\u201d is in '+(h.name||'its file')
            +' \u2014 click \u201cclick to reopen\u201d beside Save to '
            +'bring it back',12000);
        }
      });
    }).catch(function(){});
  }
  window.SemDeckFileBoot=rememberedFileBoot;   /* browser-verification hook */
  /* ---- T598: EVERY DECK'S FILE, BACK AFTER A RELOAD -------------------
     Only the handles; nothing is read (a read may need a click). A deck
     already bound this visit keeps the binding it has. When the deck on
     screen had none and now does, it re-syncs, so its readout and Save
     name its file. */
  function fileHandlesBoot(){
    return idbAll('handles').then(function(rows){
      (rows||[]).forEach(function(r){
        if(!r||typeof r.key!=='string'||r.key.indexOf(HKEYD)!==0) return;
        var nm=r.key.slice(HKEYD.length);
        if(nm&&r.value&&fileHandles[nm]===undefined) fileHandles[nm]=r.value;
      });
      var cur0=(pres&&pres.name)||'';
      if(cur0&&!fileHandle&&fileHandles[cur0]){fileFor='';fileSync();}
      status();
      if(typeof renderPresentationHub==='function') renderPresentationHub();
      if(APP.refreshChrome) APP.refreshChrome();
    }).catch(function(){});
  }
  /* T433: A REMEMBERED BUNDLE IS LET GO. A handle bound before a file
     held one deck may be a file of every deck; the next autosave would
     write one deck over all of them. Its decks come into the library
     and the binding is dropped, said out loud, so Save asks where. */
  function dropBundleHandle(txt,forName){
    var n=fileDeckCount(txt);
    if(n<2) return false;
    var h=fileHandles[forName]||null;
    var nm=(h&&h.name)||'that file';
    fileHandles[forName]=null;
    if(fileHandle===h){fileHandle=null;fileName='';}
    idbDel(HKEY).catch(function(){});lsDel(HNKEY);
    importDeckText(txt,true);
    if(saveTarget==='file'&&!fileHandle) fileWaits='pick';
    status();renderTargetBtn();renderSaveBtn();renderPresTabs();
    toast(nm+' holds '+n+' presentations. A file holds one now, so '
      +'they are in this browser and Save asks where to write '
      +'\u201c'+(forName||pres.name)+'\u201d.',12000);
    return true;
  }
  function fileRestore(txt,forName,force){
    var obj;
    try{obj=parseDeckText(txt);}catch(e){return false;}
    if(dropBundleHandle(txt,forName)) return false;
    var list=(obj&&Array.isArray(obj.presentations))?obj.presentations
      :Array.isArray(obj)?obj:(obj&&Array.isArray(obj.slides))?[obj]:[];
    /* everything that fits goes into the library, quietly */
    importDeckText(txt,true);
    var hit=null;
    list.forEach(function(pr){
      if(!hit&&pr&&Array.isArray(pr.slides)&&(pr.name||'')===forName) hit=pr;});
    if(!hit||(pres&&pres.name===forName)) return false;
    /* the deck this visit opened on, or nothing real is open yet --
       T483: or the click that asked for it, whatever else was touched
       since (it imported the file and said "already here") */
    var want=force||(lsGet(PFX+'last')||'')===forName||!pres||!pres.slides
      ||source==='auto';
    if(!want) return false;
    /* from the library when the silent import could keep it there,
       else from the object in hand */
    if(deckHas(forName)){lsSet(PFX+'last',forName,true);loadPresentation(forName);}
    else {var np=normPres(hit);np.name=forName;loadPresentationObj(np);}
    fileFor=forName;fileHandle=fileHandles[forName]||null;
    fileName=fileHandle?(fileHandle.name||''):'';
    cur=0;activePane=-1;
    if(saveTarget!=='file') setTarget('file');
    status();refresh();
    toast('Reopened \u201c'+forName+'\u201d from '+(fileName||'its file'),
      6000);
    return true;
  }
  function reopenFile(){
    if(!fileReopen) return Promise.resolve(false);
    var h=fileReopen.h,nm=fileReopen.name;
    return permAsk(h).then(function(ok){
      if(!ok){
        toast('Junoview was not allowed to read '+(h.name||'the file'));
        return false;
      }
      return h.getFile().then(function(f){return f.text();})
        .then(function(txt){
          fileReopen=null;fileWaits='';
          if(fileDeckCount(txt)>1){dropBundleHandle(txt,nm);return true;}
          if(!fileRestore(txt,nm,true)){status();toast('Nothing to reopen \u2014 '
            +'\u201c'+nm+'\u201d is already here');}
          return true;
        });
    }).catch(function(e){
      toast('Could not reopen: '+((e&&e.message)||e),8000);return false;});
  }
  window.SemDeckReopen=reopenFile;   /* browser-verification hook */

  /* direct save-into-.ipynb is parked for now (kept for later) */
  var ENABLE_SAVE_TO_IPYNB=false;
  var writeBtn=$('#mi-save');
  if(APP.mode==='app'){
    writeBtn.textContent='Save to project';
    writeBtn.addEventListener('click',function(){
      closeMenu();
      if(!requireName()) return;
      saveToProject(false);
    });
  } else if(ENABLE_SAVE_TO_IPYNB
      &&APP.order.length===1&&window.showOpenFilePicker){
    writeBtn.addEventListener('click',function(){
      closeMenu();
      if(!requireName()) return;
      var savedHist=histCapture();
      var savedName=pres.name||'untitled',savedSig=deckSaveSig(pres);
      var savedMerged=mergedPresentations();
      var op=(async function(){
        try{
          var picks=await window.showOpenFilePicker({types:[{
            description:'Jupyter notebook',
            accept:{'application/json':['.ipynb']}}]});
          var h=picks[0];
          var f=await h.getFile();
          var nb=JSON.parse(await f.text());
          nb.metadata=nb.metadata||{};
          nb.metadata.semantic=nb.metadata.semantic||{};
          nb.metadata.semantic.presentations=
            plainIfSingle(savedMerged);
          delete nb.metadata.semantic.deck;
          var w=await h.createWritable();
          await w.write(JSON.stringify(nb,null,1));
          await w.close();
          var stem0=APP.order[0];
          nbPres=savedMerged.map(function(p){
            var c=normPres(p,null);c.origin=stem0;return c;});
          if(stillSaved(savedName,savedSig)){
            cancelDraftWrite();
            draftDel(savedName);
            source='saved';
          } else {
            source='draft';scheduleDraftWrite();
          }
          saveStamp=new Date();saveKind='manual';
          saveWhere=f.name||'file';   /* T483 */
          status();renderPresRow();
          toast('Saved "'+savedName+'" into '+f.name);
          return true;
        }catch(e){
          if(!e||e.name!=='AbortError')
            toast('Save failed: '+(e&&e.message?e.message:e));
          return false;
        }
      })();
      if(savedHist) snapTake('saved',savedHist,op);
    });
  } else {
    writeBtn.hidden=true;
  }
  menuAction('#mi-dl',function(){
    var blob=new Blob([junoviewFileHtml()],{type:'text/html'});
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    /* T415: the deck's own name, not "project" (2026-09-13, user:
       "downloaded with shit name project.junoview, not the actual
       name"). T433: and it holds that one deck. */
    a.download=(pres.name||(APP.order.length===1?APP.order[0]:'project'))
      +'.junoview.html';
    a.click();
    setTimeout(function(){URL.revokeObjectURL(a.href);},2000);
    /* T487: the words say how the file IS opened. Since T415 it is
       named after the deck, and the loader looked for <notebook>
       .junoview.html alone, so "keep it next to the .ipynb and it loads
       itself" was a promise the file could not keep (2026-09-15
       review); loader.py now takes every .junoview.html beside the
       notebook that is not another notebook's, and the toast names
       the other door. */
    toast('Downloaded '+a.download+'. Next to its .ipynb it loads '
      +'itself; File \u2192 Open a .junoview file\u2026 opens it anywhere.'
      +embNote());
  });
  menuAction('#mi-load',openDeckFile);
  window.SemDeckOpenFile=openDeckFile;   /* the rail's "+ New" row */
  /* ---- Export PDF / print: render every slide at a fixed size (so text,
     which is sized from the layer height, comes out right) into off-screen
     pages, then hand off to the browser's Print -> Save as PDF ---- */
  /* build the fixed-size print/export pages off-screen. Shared by the
     PDF path (window.print) and the standalone-HTML export. */
  function buildPrintRoot(){
    var old=document.getElementById('print-root');
    if(old) old.remove();
    var savedMode=mode,savedReveal=revealCount,savedCur=cur;
    mode='view';revealCount=99999;              /* all builds fully revealed */
    /* T389: THE PAGES ARE A PICTURE OF THE DECK, NOT OF THE EDITOR.
       renderAnnots marks item selAnnot on WHATEVER slide it draws, so
       with the first box selected every exported page carried a dashed
       selection ring round its first box (seen on the scrolling
       version, but the PDF and the standalone export had it too). */
    var savedSel=selAnnot,savedSet=selSet;
    selAnnot=null;selSet=[];
    var root=document.createElement('div');root.id='print-root';
    /* attach the container FIRST (off-screen but laid out) so each slide has a
       real 720px height when its text is sized from the layer — otherwise a
       detached layer measures 0 and text bakes in ~17% too small */
    document.body.appendChild(root);
    /* a custom page (4:3 / A-series poster) exports at ITS size, not 16:9 */
    var pg=pageOf();
    /* Crop marks: some print shops ask for them, and they need somewhere
       to sit, so the SHEET grows by the bleed while the page inside keeps
       its exact size — an A0 poster stays 841x1189mm either way. */
    var bleed=(pres&&pres.cropMarks)?BLEED_MM:0;
    if(pg.id!=='16x9'||bleed){
      var sheetW=pg.mm[0]+2*bleed,sheetH=pg.mm[1]+2*bleed;
      var pw=Math.round(pg.mm[0]/25.4*96),ph=Math.round(pg.mm[1]/25.4*96);
      var bpx=Math.round(bleed/25.4*96);
      var pst=document.createElement('style');
      pst.textContent='#print-root{width:'+(pw+2*bpx)+'px;}'
        +'.print-page{width:'+pw+'px;height:'+ph+'px;'
        +(bleed?'margin:'+bpx+'px;':'')+'}'
        +'@media print{@page{size:'+sheetW+'mm '+sheetH+'mm;'
        +'margin:0;}}';
      root.appendChild(pst);
    }
    /* the page's own background rides into the export — a white poster
       prints white, not the app's navy (2026-08-04) */
    var bg=deckPageBg();
    root.classList.toggle('page-light',pageIsLight(bg));
    var bst=document.createElement('style');
    /* PRINT THE INK. Chrome and Edge default the print dialog's
       "Background graphics" box to OFF, and everything that carries this
       deck's colour is a CSS background: the page, the slide, every shape
       fill, every gradient, every text panel. Without this declaration
       File > Export PDF on the default dark deck produced white pages
       with white text on them — only <img> figures survived, because a
       picture is content rather than decoration. The A0 poster path
       escaped by luck alone (newPoster seeds a white page).
       Both spellings: the unprefixed property is the standard, the
       -webkit- one is what Chrome and Edge actually still honour
       (2026-08-22). */
    bst.textContent='.print-page,.print-page .slide{background:'+bg
      +'!important;}@media print{html,body{background:'+bg+'!important;}}'
      +'.print-page,.print-page *{-webkit-print-color-adjust:exact!important;'
      +'print-color-adjust:exact!important;}'
      +'@media print{html,body{-webkit-print-color-adjust:exact!important;'
      +'print-color-adjust:exact!important;}}';
    root.appendChild(bst);
    /* AN EXPORTED PAGE IS EVERY MOMENT AT ONCE (T162). mode='view' plus
       revealCount=99999 above means "fully built" -- which to a chart
       revealed one series at a time reads as the LAST stop, so an item
       tied to an earlier series would be missing from the PDF and the
       standalone HTML altogether. A flip book answers this by exploding
       into one page per frame; a chart exports as one plot and cannot,
       so every series tie fails open here instead (seriesShows).
       Cleared beside flipForce below, for the same reason and the same
       lifetime. */
    printAll=1;
    outputSlides().forEach(function(ent,i){
      var s=ent.s;
      cur=ent.i;
      /* the page renders for ITS frame, and the bindings follow */
      flipForce=ent.f;
      var page=document.createElement('div');page.className='print-page';
      var slideEl=document.createElement('div');
      if(s&&s.layout==='title'){
        slideEl.className='slide slide-titlefree';
        slideEl.innerHTML='<p class="ttl-eyebrow">'+esc(pres.name||'')+'</p>';
      } else slideEl.className='slide slide-blank';
      if(s&&s.bg)
        slideEl.style.setProperty('background',tokVal(s.bg),'important');
      if(s&&s.border) slideEl.style.boxShadow='inset 0 0 0 '
        +((s.border.w||4)/SW_REF_H*Math.round(pg.mm[1]/25.4*96)).toFixed(2)
        +'px '+(tokVal(s.border.c)||'#39a9c0');
      page.appendChild(slideEl);
      root.appendChild(page);            /* in the DOM before annots render */
      if(s) attachAnnots(slideEl,s);     /* view-style; fontPx reads 720px */
      paintFurniture(slideEl,i);
      if(pres.showNums){
        var pn=document.createElement('div');
        pn.className='slide-pageno';pn.textContent=(i+1);
        slideEl.appendChild(pn);
      }
      /* trim marks at the four corners, drawn OUTSIDE the page in the
         bleed so they never touch the artwork */
      if(bleed){
        page.classList.add('has-crop');
        ['tl','tr','bl','br'].forEach(function(c){
          var cm=document.createElement('span');
          cm.className='cropmark cm-'+c;
          page.appendChild(cm);
        });
      }
    });
    mode=savedMode;revealCount=savedReveal;cur=savedCur;
    selAnnot=savedSel;selSet=savedSet;
    /* ...and whatever a render path still marked, off: the ring is the
       editor's, and no page is the editor */
    $$('.sel,.grpsel',root).forEach(function(el){
      el.classList.remove('sel','grpsel','an-grouped');});
    $$('.an-grpframe',root).forEach(function(el){el.remove();});
    /* put the editor back on its own frame, or every flip book on screen
       would be left showing whatever the last exported page wanted */
    flipForce=null;
    printAll=0;
    if(typeset) typeset(root);
    return root;
  }
  /* wait for MathJax to actually FINISH on the built pages before using
     them — the print dialog tolerates late typesetting (the live DOM
     keeps working underneath it) but a serialised export is a hard
     cutoff: whatever maths was unfinished ships as raw TeX forever
     (2026-08-05 review) */
  /* SWAP IN THE ORIGINALS before an export takes the page. Every path
     that turns a print root into a file goes through afterTypeset, so
     this is the one place all of them share — the PDF, the standalone
     HTML and anything added later get it without asking (T21).

     The canvas keeps the display copy: a 6000px PNG drawn at 30% of a
     slide costs real time on every repaint for detail no screen can
     show. The export is the only consumer that wants the full bytes,
     and it is already asynchronous for MathJax, so waiting on
     IndexedDB costs it nothing it was not already paying. */
  function useOriginals(root){
    var jobs=[];
    function swap(o){
      if(!o||!o.okey||!o.src) return;
      jobs.push(originalOf(o).then(function(full){
        if(!full||full===o.src) return;
        $$('.an-imgel,img',root).forEach(function(im){
          if(im.getAttribute('src')===o.src) im.src=full;});
      }));
    }
    (pres.slides||[]).forEach(function(sl){
      (sl.annots||[]).forEach(function(a){
        if(!a) return;
        if(a.k==='image'){swap(a);return;}
        /* A FLIP BOOK'S FRAMES ARE PICTURES TOO. They are the fourth
           door a picture comes in by, and the only one that was not
           asked here — so a flip book printed its display copies while
           every other picture on the page printed at full resolution
           (2026-08-26 audit, T58). */
        if(a.k==='flip'&&Array.isArray(a.frames)) a.frames.forEach(swap);
      });
    });
    if(!jobs.length) return Promise.resolve();
    return Promise.all(jobs).catch(function(){});
  }
  function afterTypeset(root,fn){
    var go=function(){
      try{
        if(window.MathJax&&MathJax.typesetPromise)
          return MathJax.typesetPromise([root])
            .catch(function(){}).then(fn);
      }catch(e){}
      setTimeout(fn,200);
    };
    try{return useOriginals(root).then(go);}catch(e){}
    go();
    return undefined;
  }
  /* ---- T556: HANDOUTS AND NOTES PAGES --------------------------------
     PowerPoint's Print Layout, three of them beside Full page slides: a
     handout of three slides a sheet with lines to write beside each, one
     of six, and notes pages -- each slide above its speaker notes. They
     are LAYOUTS OF THE SAME PAGES: buildPrintRoot draws every slide
     exactly as the PDF does, and these lay those pages out, scaled, on A4
     sheets, so a handout can never show a slide the PDF would not. The
     sheets are white, with the deck's name and the page along the top. */
  var PRINT_LAYOUTS=[['slides','Full-page slides'],
    ['ho3','Handouts \u2014 3 slides a page, with lines for notes'],
    ['ho6','Handouts \u2014 6 slides a page'],
    ['notes','Notes pages \u2014 each slide above its speaker notes']];
  var SHEET_W=794,SHEET_H=1123;     /* A4 at 96 px to the inch */
  function handoutify(root,kind){
    var pages=$$('.print-page',root);
    if(!pages.length) return;
    var ents=outputSlides();
    var pw=pages[0].offsetWidth||1280,ph=pages[0].offsetHeight||720;
    var per=kind==='ho6'?6:kind==='ho3'?3:1;
    root.classList.add('ho-mode');
    var st=document.createElement('style');
    st.textContent='@media print{@page{size:A4 portrait;margin:0;}'
      +'html,body{background:#fff!important;}}';
    root.appendChild(st);
    var sheet=null,n=0,sheets=0,when=new Date().toLocaleDateString();
    function newSheet(){
      sheets++;
      sheet=document.createElement('div');sheet.className='ho-sheet ho-k-'+kind;
      var hd=document.createElement('div');hd.className='ho-head';
      var nm=document.createElement('span');nm.textContent=pres.name||'';
      var pg=document.createElement('span');
      pg.textContent=when+' \u00b7 page '+sheets;
      hd.appendChild(nm);hd.appendChild(pg);
      sheet.appendChild(hd);
      var body=document.createElement('div');body.className='ho-body';
      sheet.appendChild(body);
      root.appendChild(sheet);
      return body;
    }
    var body=null;
    var slotW=kind==='notes'?600:kind==='ho3'?330:320;
    var k=slotW/pw;
    pages.forEach(function(page,i){
      if(n%per===0) body=newSheet();
      n++;
      var row=document.createElement('div');row.className='ho-row';
      var slot=document.createElement('div');slot.className='ho-slot';
      slot.style.width=slotW+'px';slot.style.height=Math.round(ph*k)+'px';
      page.style.transformOrigin='0 0';
      page.style.transform='scale('+k.toFixed(4)+')';
      page.style.margin='0';
      slot.appendChild(page);
      row.appendChild(slot);
      if(kind==='ho3'){
        var lines=document.createElement('div');lines.className='ho-lines';
        for(var l=0;l<8;l++){
          var ln=document.createElement('div');ln.className='ho-line';
          lines.appendChild(ln);
        }
        row.appendChild(lines);
      }
      if(kind==='notes'){
        var ent=ents[i],sl=ent&&ent.s;
        var nt=document.createElement('div');nt.className='ho-notes';
        var txt=sl&&String(sl.notes||'').trim();
        if(txt) nt.innerHTML=notesHtml(sl.notes);
        else {nt.textContent='No notes for this slide.';
          nt.classList.add('ho-nonotes');}
        row.appendChild(nt);
      }
      body.appendChild(row);
    });
  }
  function printDeck(kind){
    if(!(pres.slides||[]).length){toast('No slides to export yet');return;}
    var root=buildPrintRoot();
    if(kind&&kind!=='slides') handoutify(root,kind);
    document.body.classList.add('printing');
    var done=false;
    function cleanup(){
      if(done) return;done=true;
      document.body.classList.remove('printing');
      /* remove OUR root by reference — an id lookup could tear down a
         newer root built by a crossing export/print (2026-08-05 review) */
      if(root.parentNode) root.remove();
      window.removeEventListener('afterprint',cleanup);
    }
    window.addEventListener('afterprint',cleanup);
    /* THROUGH afterTypeset, like every other export. This went straight
       to window.print() after a 120ms guess, so useOriginals never ran
       for the PDF — the one output that is printed on paper got the
       display copies, which is the whole of T21 undone. The comment
       above useOriginals claimed "every path that turns a print root
       into a file goes through afterTypeset"; this was the path that
       did not (2026-08-26 audit, T58). afterTypeset also waits for
       MathJax, which is what the 120ms was standing in for. */
    afterTypeset(root,function(){
      try{window.print();}catch(e){}
      setTimeout(cleanup,800);
    });
    return root;   /* returned for headless testing */
  }
  window.SemDeckPrint=printDeck;   /* test hook */
  /* T556: a handout's sheets, built and kept for a test to read */
  window.SemDeckHandout=function(kind){
    var root=buildPrintRoot();handoutify(root,kind);return root;};
  /* the pages an export will actually write, flip books already exploded.
     A hook rather than a guess: "one flip book of six figures becomes six
     slides" is the claim the whole feature rests on, and it is only
     checkable from outside (2026-08-22). */
  window.SemDeckRefreshImages=refreshImagesReport;   /* test hook */
  window.SemDeckLinkedImages=linkedImages;          /* test hook */
  window.SemDeckPlaceAddress=placeFromAddress;      /* browser-verification hook (T437) */
  window.SemDeckPages=outputSlides;
  window.SemDeckPrintRoot=buildPrintRoot;
  /* T236: History and Checkpoint are Home buttons now. They are
     things you do WHILE building, not ways of getting a file out of
     the door, which is what the File menu is left holding. */
  function versionDoorsBoot(){
    var hb=$('#hm-history');
    if(hb) hb.addEventListener('click',function(e){
      e.stopPropagation();openHistory();});
    var cb=$('#hm-check');
    if(cb) cb.addEventListener('click',function(e){
      e.stopPropagation();histCheckpoint(null);});
  }
  /* T225: the checkpoint row, through the same helper every other File
     row uses -- so it closes the menu the way its neighbours do */
  (function(){
    var b=$('#dsg-design-btn');
    /* a row of the Text styles window since T178: the window goes as
       the screen opens, the way the other rows there behave */
    if(b) b.addEventListener('click',function(){
      if(typeof overlayClose==='function') overlayClose();
      openDesign();});
  })();
  menuAction('#mi-review',openReview);
  /* T556: which layout, asked each time, the last answer first */
  menuAction('#mi-pdf',function(){
    var last='slides';
    try{last=localStorage.getItem('jv-print-layout')||'slides';}catch(e){}
    askText({title:'Export PDF / print',
      what:'What goes on each sheet. In the print dialog, choose "Save as '
        +'PDF" for a file.',
      rows:[{k:'lay',label:'Print',type:'select',value:last,
        options:PRINT_LAYOUTS}],ok:'Print\u2026'},function(v){
      if(!v) return;
      try{localStorage.setItem('jv-print-layout',v.lay);}catch(e){}
      printDeck(v.lay);
    });
  });
  /* ---- standalone HTML export (2026-08-04): ONE self-contained .html
     anyone can open without Junoview. The page styles are already inline
     in this document's <head>, and every notebook figure is a data: URI,
     so the file travels whole. It reads as stacked pages, arrow keys
     step through them, and Ctrl+P prints at true page size (the same
     @page rules ride along). ---- */
  /* T487: THE FONTS RIDE INSIDE. MathJax's stylesheet is copied into
     the standalone page with its @font-face url(https://cdn.jsdelivr
     .net/...woff) rules, so "opens anywhere" opened offline with every
     equation in a fallback face (2026-09-15 review, driven offline with
     a fresh profile: five fonts in error). The fonts the page used are
     fetched -- from the service worker's cache when there is no
     network -- and written in as data: URIs; one that cannot be fetched
     is left as its URL and the toast says so. */
  function inlineFontUrls(css){
    /* only the faces this page has actually LOADED -- MathJax declares
       all 22 up front and fetches per glyph, so packing every one in
       would add ~600KB for a deck with one equation. document.fonts
       .ready first: the print root was typeset a moment ago and its
       faces may still be on their way in. */
    var ready;
    try{ready=document.fonts.ready;}catch(e){}
    return Promise.resolve(ready).catch(function(){}).then(function(){
      return inlineFontUrls2(css);});
  }
  function inlineFontUrls2(css){
    var loaded={},anyLoaded=false;
    try{
      document.fonts.forEach(function(f){
        if(f.status==='loaded'||f.status==='loading'){
          loaded[String(f.family).replace(/^["']|["']$/g,'')]=1;anyLoaded=true;}
      });
    }catch(e){}
    var seen={},list=[];
    css.replace(/@font-face[^{]*\{([^}]*)\}/g,function(m,body){
      var fam=/font-family:\s*["']?([^;"']+)/.exec(body);
      var u=/url\((["']?)(https:\/\/cdn\.jsdelivr\.net\/[^)"']+?\.woff2?)\1\)/.exec(body);
      if(!u) return m;
      if(anyLoaded&&fam&&!loaded[fam[1].trim()]) return m;
      if(!seen[u[2]]){seen[u[2]]=1;list.push(u[2]);}
      return m;
    });
    if(!list.length) return Promise.resolve({css:css,missed:0});
    return Promise.all(list.map(function(u){
      return fetch(u).then(function(r){return r.ok?r.blob():null;})
        .then(function(b){
          if(!b) return null;
          return new Promise(function(res){
            var fr=new FileReader();
            fr.onload=function(){res(fr.result);};
            fr.onerror=function(){res(null);};
            fr.readAsDataURL(b);
          });
        }).catch(function(){return null;})
        .then(function(d){return [u,d];});
    })).then(function(pairs){
      var missed=0;
      pairs.forEach(function(p){
        if(p[1]) css=css.split(p[0]).join(p[1]); else missed++;});
      return {css:css,missed:missed};
    });
  }
  function exportDeckHtml(){
    if(!(pres.slides||[]).length){toast('No slides to export yet');return;}
    var root=buildPrintRoot();
    afterTypeset(root,function(){
      var css0='';
      $$('style',document.head).forEach(function(st){
        css0+=st.textContent+'\n';});
      inlineFontUrls(css0).then(function(fo){
      var css=fo.css;
      var nav='<scr'+'ipt>document.addEventListener("keydown",'
        +'function(e){'
        +'var p=[].slice.call(document.querySelectorAll(".print-page"));'
        +'if(!p.length)return;var y=window.scrollY,i=0;'
        +'for(var j=0;j<p.length;j++){if(p[j].offsetTop<=y+10)i=j;}'
        +'if(e.key==="ArrowRight"||e.key==="PageDown"||e.key===" "){'
        +'e.preventDefault();if(p[i+1])p[i+1].scrollIntoView();}'
        +'if(e.key==="ArrowLeft"||e.key==="PageUp"){'
        +'e.preventDefault();if(p[i-1])p[i-1].scrollIntoView();}'
        +'});</scr'+'ipt>';
      /* lang, because a screen reader has to pick a voice and this
         file is the artefact a colleague actually receives */
      var doc='<!doctype html><html lang="en"><head><meta charset="utf-8">'
        +'<meta name="viewport" content="width=device-width">'
        +'<title>'+esc(pres.name||'presentation')+'</title>'
        +'<style>'+css+'</style>'
        +'<style>body{margin:0;background:#20262c;}'
        +'#print-root{position:static!important;left:auto!important;'
        +'width:auto!important;}'
        /* NO max-width: the pages are fixed-px boxes and clamping the
           width alone broke their aspect (2026-08-05 review). A huge
           poster page simply scrolls — the browser's own zoom fits it. */
        +'.print-page{margin:18px auto;box-shadow:0 8px 40px #0008;}'
        +'@media print{body{background:none;}'
        +'.print-page{margin:0;box-shadow:none;}}'
        +'</style></head><body>'
        +nav+root.outerHTML
        /* T416: THE DECK RIDES INSIDE. A standalone page was pictures
           of slides and nothing else, so the one copy someone kept
           could never be opened for editing again. The same data block
           a .junoview.html carries, so Open a file takes this too. */
        +'<script type="application/json" id="junoview-data">\n'
        +deckFileText().replace(/</g,'\\u003c')+'\n</scr'+'ipt>'
        +'</body></html>';
      var blob=new Blob([doc],{type:'text/html'});
      var a=document.createElement('a');
      a.href=URL.createObjectURL(blob);
      a.download=(pres.name||'presentation')+'.html';
      document.body.appendChild(a);a.click();a.remove();
      setTimeout(function(){URL.revokeObjectURL(a.href);},4000);
      if(root.parentNode) root.remove();   /* by reference, never by id */
      toast(fo.missed
        ?('Standalone HTML saved \u2014 '+fo.missed+' equation font'
          +(fo.missed===1?'':'s')+' could not be packed in, so equations '
          +'need a network connection the first time it is opened')
        :'Standalone HTML saved — opens anywhere; Ctrl+P there '
          +'prints at page size');
      });
    });
  }
  menuAction('#mi-html',function(){exportDeckHtml();});
  /* ---- PowerPoint (.pptx) export: native shapes, not pictures of slides.
     Text becomes a real PowerPoint text box you can retype, figures and
     images become pictures, boxes and arrows become shapes — so a poster
     lands in PowerPoint editable rather than as one flat image.

     What CANNOT come across: a placed notebook cell showing code, a table
     or an xarray repr is arbitrary HTML with no PowerPoint equivalent, and
     rasterising it in the browser would need a library we deliberately do
     not ship. Those frames are counted and reported rather than silently
     dropped — the toast says how many, and PDF export carries them
     perfectly. Crops are dropped for the same reason (a CSS clip-path is
     not a PowerPoint crop), so a cropped item is reported too. ---- */
  /* textContent welds block elements together ("…reanalysiswould contain"),
     so read innerText instead. It is layout-dependent, which means the node
     must genuinely be RENDERED: display:none returns textContent and
     visibility:hidden returns "" outright (measured, 2026-08-07). Hence a
     real mount, merely parked off-screen. */
  function blockText(node){
    if(!node) return '';
    var host=document.createElement('div');
    host.style.cssText='position:absolute;left:-99999px;top:0;width:800px;';
    host.appendChild(node);
    document.body.appendChild(host);
    /* MathJax lays every glyph out as its own box, so innerText would put
       each character of an equation on its own line. Collapse each formula
       to one inline string instead.
       The characters come from the ASSISTIVE MathML, not the visible
       output: MathJax v3's CHTML draws glyphs through CSS ::before rules,
       so the container's own textContent is empty (measured, 2026-08-07). */
    $$('mjx-container',host).forEach(function(n){
      if(!n.parentNode) return;
      var mml=n.querySelector('mjx-assistive-mml');
      var t=String((mml&&mml.textContent)||n.textContent||'')
        .replace(/\s+/g,' ').trim();
      n.parentNode.replaceChild(
        document.createTextNode(t?' '+t+' ':' '),n);
    });
    var out='';
    try{out=String(host.innerText||host.textContent||'');}
    catch(e){out=String(host.textContent||'');}
    host.remove();
    return out.replace(/\n{3,}/g,'\n\n').trim();
  }
  /* ---- AN EQUATION, FLATTENED TO CHARACTERS ---------------------------
     A text box built by the Maths button went into the .pptx as the
     literal "$$ E = mc^2 $$", dollar signs and all, and the export's own
     "Equations came across as plain text" warning stayed silent, because
     it was only ever raised for maths inside a notebook CELL (2026-08-26
     audit, T53).

     Flattened FROM THE SOURCE, not from the rendered MathJax that
     blockText lifts for cells. Only the slide on screen has typeset
     output — typesetting is a promise and this export is synchronous —
     so reading the DOM would give real characters on one slide and raw
     LaTeX on the next, which is worse than either answer everywhere.

     The vocabulary is the equation palette's own: what the app offered
     to write is what it undertakes to read back. Anything else keeps its
     command word, spelled without the backslash, which is still the name
     of what it is.  */
  var TEX_CHAR={
    alpha:'α',beta:'β',gamma:'γ',delta:'δ',
    epsilon:'ε',varepsilon:'ε',zeta:'ζ',eta:'η',
    theta:'θ',vartheta:'ϑ',iota:'ι',kappa:'κ',
    lambda:'λ',mu:'μ',nu:'ν',xi:'ξ',pi:'π',
    rho:'ρ',sigma:'σ',tau:'τ',upsilon:'υ',
    phi:'φ',varphi:'φ',chi:'χ',psi:'ψ',
    omega:'ω',
    Gamma:'Γ',Delta:'Δ',Theta:'Θ',Lambda:'Λ',
    Xi:'Ξ',Pi:'Π',Sigma:'Σ',Phi:'Φ',Psi:'Ψ',
    Omega:'Ω',
    times:'×',div:'÷',pm:'±',mp:'∓',cdot:'·',
    ast:'∗',circ:'∘',leq:'≤',le:'≤',geq:'≥',
    ge:'≥',neq:'≠',ne:'≠',approx:'≈',
    equiv:'≡',sim:'∼',propto:'∝',ll:'≪',
    gg:'≫','in':'∈',notin:'∉',subset:'⊂',
    cup:'∪',cap:'∩',forall:'∀',exists:'∃',
    nabla:'∇',partial:'∂',infty:'∞',
    sum:'∑',prod:'∏',int:'∫',iint:'∬',
    oint:'∮',lim:'lim',
    to:'→',gets:'←',rightarrow:'→',leftarrow:'←',
    mapsto:'↦',Rightarrow:'⇒',Leftarrow:'⇐',
    Leftrightarrow:'⇔',uparrow:'↑',downarrow:'↓'
  };
  var TEX_SUP={'0':'⁰','1':'¹','2':'²','3':'³',
    '4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸',
    '9':'⁹','+':'⁺','-':'⁻','=':'⁼','(':'⁽',
    ')':'⁾',n:'ⁿ',i:'ⁱ'};
  var TEX_SUB={'0':'₀','1':'₁','2':'₂','3':'₃',
    '4':'₄','5':'₅','6':'₆','7':'₇','8':'₈',
    '9':'₉','+':'₊','-':'₋','=':'₌','(':'₍',
    ')':'₎',a:'ₐ',e:'ₑ',i:'ᵢ',j:'ⱼ',
    k:'ₖ',l:'ₗ',m:'ₘ',n:'ₙ',o:'ₒ',
    p:'ₚ',r:'ᵣ',s:'ₛ',t:'ₜ',u:'ᵤ',
    v:'ᵥ',x:'ₓ'};
  /* {a}{b} after a command, or the single token that stands in for a
     brace group ("x^2"). Returns [body, rest] or null. */
  function texGroup(src){
    if(src.charAt(0)!=='{'){
      if(!src) return null;
      return [src.charAt(0),src.slice(1)];
    }
    var d=0;
    for(var i=0;i<src.length;i++){
      var c=src.charAt(i);
      if(c==='{') d++;
      else if(c==='}'&&!--d) return [src.slice(1,i),src.slice(i+1)];
    }
    return null;
  }
  function texScript(body,table){
    var out='';
    for(var i=0;i<body.length;i++){
      var ch=table[body.charAt(i)];
      if(ch===undefined) return null;
      out+=ch;
    }
    return out;
  }
  function texPlain(src){
    var out='',rest=String(src||''),g;
    while(rest){
      var m=/^\\([A-Za-z]+)/.exec(rest);
      if(m){
        rest=rest.slice(m[0].length);
        var name=m[1];
        /* the wrappers whose whole job is how a thing is SET, not what
           it says: their contents are the text and they go away */
        if(/^(text|mathrm|mathbf|mathbb|mathcal|mathit|operatorname|bar|overline|hat|vec|dot|ddot|tilde|underline|left|right|displaystyle)$/
            .test(name)){
          if(name==='left'||name==='right'||name==='displaystyle') continue;
          g=texGroup(rest);
          if(g){out+=texPlain(g[0]);rest=g[1];}
          continue;
        }
        if(name==='frac'||name==='binom'){
          g=texGroup(rest);
          if(!g){out+=name;continue;}
          var num=texPlain(g[0]),g2=texGroup(g[1]);
          if(!g2){out+=num;rest=g[1];continue;}
          out+=(name==='frac')?('('+num+')/('+texPlain(g2[0])+')')
                              :('C('+num+', '+texPlain(g2[0])+')');
          rest=g2[1];
          continue;
        }
        if(name==='sqrt'){
          var root='';
          var rm=/^\[([^\]]*)\]/.exec(rest);
          if(rm){root=texPlain(rm[1]);rest=rest.slice(rm[0].length);}
          g=texGroup(rest);
          out+=root+'√('+(g?texPlain(g[0]):'')+')';
          if(g) rest=g[1];
          continue;
        }
        out+=(TEX_CHAR[name]!==undefined?TEX_CHAR[name]:name);
        /* THE SPACE AFTER A COMMAND WORD, which LaTeX reads as the
           delimiter that ends the name rather than as a space. Eaten
           only when it was doing that job and nothing else — that is,
           when a letter or digit follows ("\partial u" -> "∂u"). Eating
           it unconditionally welded the symbol to the next token
           ("\alpha + \beta" -> "α+ β", because the source's space before
           the + had already been spent). */
        if(/^ [A-Za-z0-9]/.test(rest)) rest=rest.slice(1);
        continue;
      }
      var c0=rest.charAt(0);
      if(c0==='\\'){
        /* \, \; \: \! and \\ : spacing and a line break */
        var c1=rest.charAt(1);
        out+=(c1==='!'||c1===undefined)?'':(c1==='\\'?' ':' ');
        rest=rest.slice(2);
        continue;
      }
      if(c0==='^'||c0==='_'){
        g=texGroup(rest.slice(1));
        if(!g){rest=rest.slice(1);continue;}
        var inner=texPlain(g[0]);
        var lifted=texScript(inner,c0==='^'?TEX_SUP:TEX_SUB);
        out+=(lifted!==null)?lifted:(c0+'('+inner+')');
        rest=g[1];
        continue;
      }
      if(c0==='{'||c0==='}'||c0==='&'){rest=rest.slice(1);continue;}
      out+=c0;rest=rest.slice(1);
    }
    return out;
  }
  /* WHICH DOLLARS ARE MATHS. "$5 and $10" is prose and has to leave the
     export exactly as it was typed, so an inline pair only counts when
     its body actually reads as TeX — a command, a power or a subscript.
     Display $$…$$ is never ambiguous, and neither is a box the Maths
     button built, which is what `sure` says. */
  function texish(b){return /\\[A-Za-z]|[\^_]/.test(b||'');}
  function mathsPlain(src,sure){
    var hit=false;
    var out=String(src||'').replace(
      /\$\$([\s\S]+?)\$\$|\$([^$\n]+)\$/g,
      function(all,disp,inline){
        var body=(disp!==undefined)?disp:inline;
        if(disp===undefined&&!sure&&!texish(body)) return all;
        hit=true;
        return texPlain(body).replace(/\s+/g,' ').trim();
      });
    return {text:out,hit:hit};
  }
  /* An unset colour means "whatever the page CSS says", which is dark ink on
     a light poster and white on a dark one. PowerPoint has no such cascade,
     so the default is resolved HERE — baking a plain '#ffffff' would put
     white text on a white poster, the exact bug the live view already had. */
  var PPTX_DIMS={text:[34,8],image:[30,24],rect:[20,14],draw:[10,10],
    table:[40,20],flip:[40,32],cell:[30,24],video:[40,22]};
  function pptxBox(a,centred){
    var d=centred?[80,8]:(PPTX_DIMS[a.k]||[0,0]);
    var w=a.w||d[0],h=a.h||d[1],p=anchorPos(a,w,h);
    return {x:p.x,y:p.y,w:w,h:h};
  }
  /* T486: THE BOX AS PARAGRAPHS AND RUNS. A Markdown box renders through
     notesHtml and a rich box through sanitizeRich -- the same HTML the
     slide shows -- and that HTML is walked into the writer's run model:
     block elements are paragraphs (an <li> a bullet, at its nesting
     level; an <hN> a heading), inline marks are per-run bold, italic,
     underline, strike and colour. Links keep their words. */
  function pptxParasFromHtml(html){
    var doc;
    try{doc=new DOMParser().parseFromString('<div>'+html+'</div>','text/html');}
    catch(e){return null;}
    var root=doc.body&&doc.body.firstChild; if(!root) return null;
    var paras=[],cur=null;
    function para(kind,lvl,head){
      cur={runs:[],bullet:kind==='ul',num:kind==='ol',lvl:lvl||0,head:head||0};
      paras.push(cur);return cur;
    }
    function colOf(n){
      var c=n.style&&n.style.color; if(!c) return '';
      var m=/^#([0-9a-f]{6})$/i.exec(c); if(m) return c;
      var r=rgbOf(c); return r?('#'+[r[0],r[1],r[2]].map(function(v){
        return ('0'+Math.round(v).toString(16)).slice(-2);}).join('')):'';
    }
    function walk(n,st,lvl){
      if(n.nodeType===3){
        var t=n.nodeValue.replace(/\s+/g,' ');
        if(!t.trim()&&!cur) return;
        if(!cur) para('',0,0);
        cur.runs.push({t:t,b:!!st.b,i:!!st.i,u:!!st.u,strike:!!st.s,
          color:st.color||'',sup:!!st.sup,sub:!!st.sub,hl:st.hl||'',
          link:st.link||null});
        return;
      }
      if(n.nodeType!==1) return;
      var tag=n.tagName.toLowerCase(),s2={};
      for(var k in st) s2[k]=st[k];
      if(tag==='b'||tag==='strong') s2.b=1;
      if(tag==='i'||tag==='em') s2.i=1;
      if(tag==='u') s2.u=1;
      if(tag==='s'||tag==='strike'||tag==='del') s2.s=1;
      if(tag==='sup'){s2.sup=1;s2.sub=0;}      /* T541 */
      if(tag==='sub'){s2.sub=1;s2.sup=0;}
      var col=colOf(n); if(col) s2.color=col;
      /* T543: a highlighter mark (only a marked run is one) */
      if(n.getAttribute&&n.getAttribute('data-hl')==='1'&&n.style
         &&n.style.backgroundColor){
        var hr=rgbOf(n.style.backgroundColor);
        if(hr) s2.hl='#'+[hr[0],hr[1],hr[2]].map(function(v){
          return ('0'+Math.round(v).toString(16)).slice(-2);}).join('');
      }
      /* T546: linked words -- a web address, or a slide by its index,
         turned into an output slide number with the objects' links */
      if(tag==='a'){
        var ws=n.getAttribute('data-sid'),wh=mdHref(n.getAttribute('href')||'');
        /* a Markdown box's [words](#7) says its slide by number */
        var wn=n.getAttribute('data-slide');
        if(ws){var wi=linkSlideIdx(ws); if(wi>=0) s2.link={to:'slide',si:wi};}
        else if(wn&&/^\d+$/.test(wn)&&+wn>=1&&+wn<=(pres.slides||[]).length)
          s2.link={to:'slide',si:+wn-1};
        else if(wh&&wh.charAt(0)!=='#') s2.link={to:'url',href:wh};
      }
      if(tag==='br'){cur=null;return;}
      var hd=/^h([1-6])$/.exec(tag);
      if(hd){para('',0,+hd[1]);[].forEach.call(n.childNodes,function(c){walk(c,s2,lvl);});cur=null;return;}
      if(tag==='p'||tag==='div'||tag==='blockquote'||tag==='pre'||tag==='hr'){
        para('',0,0);[].forEach.call(n.childNodes,function(c){walk(c,s2,lvl);});
        cur=null;return;
      }
      if(tag==='ul'||tag==='ol'){
        [].forEach.call(n.childNodes,function(c){
          if(c.nodeType!==1||c.tagName.toLowerCase()!=='li'){walk(c,s2,lvl);return;}
          para(tag,lvl,0);
          [].forEach.call(c.childNodes,function(g){walk(g,s2,lvl+1);});
          cur=null;
        });
        return;
      }
      [].forEach.call(n.childNodes,function(c){walk(c,s2,lvl);});
    }
    [].forEach.call(root.childNodes,function(c){walk(c,{},0);});
    paras=paras.filter(function(p){return p.runs.some(function(r){return r.t.trim();});});
    paras.forEach(function(p){
      if(p.runs.length){p.runs[0].t=p.runs[0].t.replace(/^\s+/,'');
        p.runs[p.runs.length-1].t=p.runs[p.runs.length-1].t.replace(/\s+$/,'');}
    });
    return paras.length?paras:null;
  }
  function pptxTextItem(a,centred,ink,box){
    var b=box||pptxBox(a,centred);
    return {t:'text',x:b.x,y:b.y,w:b.w,h:b.h,
      rot:a.rot,op:a.op,centred:!!centred,name:a.name||'',   /* T485 */
      text:a.text,sizePct:a.size,color:tokVal(a.color)||ink,
      b:a.b,i:a.i,u:a.u,strike:a.strike,align:a.align||(centred?'center':''),
      bullets:!!a.list,bgc:(a.bg!==0&&a.bgc)?tokVal(a.bgc):'',
      /* T571: which marker, its colour and size, where numbering starts */
      lkind:listOf(a)||'',lcol:a.lcol?tokVal(a.lcol):'',lsz:a.lsz||0,
      lstart:a.lstart||0,
      arc:a.arc,font:fontPpt(a.font),
      /* T542: a box that keeps its height, with its words placed in it */
      va:(a.fh&&(a.va==='m'||a.va==='b'))?a.va:'',
      /* T572: AutoFit -- 'shrink' (normAutofit), 'fixed' (noAutofit) or
         '' for a box that grows with its words (spAutoFit) */
      fit:!a.fh?'':(a.fit==='shrink'?'shrink':'fixed'),
      /* T547: its columns and the gap between them (em of its words);
         a curved box has none, as on the canvas */
      ncol:(a.ncol>1&&!a.arc)?Math.min(3,a.ncol):0,
      colGapEm:(a.ncol>1&&!a.arc)
        ?((a.cgap!=null)?+a.cgap:COL_GAP_DEF):0};
  }
  /* one slide's annots -> spec items, plus a tally of what could not go */
  /* `layer` is the rendered annotation layer for THIS slide, or null. It is
     a real parameter because it used to be a bare undeclared identifier:
     reading it threw ReferenceError, so exporting any deck or poster that
     contained a single line or arrow produced no file and — because the
     throw escaped before the toast — no message either (2026-08-10). */
  /* the retained original for a display copy, or the display copy when
     there is none — ONE lookup, so no branch can forget it */
  function pptxSrc(note,src){
    return (note&&note.orig&&note.orig[src])||src;
  }
  function pptxItems(s,note,ink,layer){
    var items=[];
    var fitHost=null;   /* T572: where a shrunk box's scale is read */
    /* which CLICK each annot appears on, the same grouping the badges
       and playback use \u2014 exported as real PowerPoint timing (T110) */
    var bsteps=slideBuildSteps(s).map;
    if(s.layout==='title'){
      ['t','s'].forEach(function(which){
        var p=titleProps(s,which),val=(which==='t')?s.title:s.sub;
        if(!String(val||'').trim()) return;
        var it=pptxTextItem(p,true,ink);
        /* a title carries LaTeX as readily as a text box does, and it
           went out with its dollar signs on (T53) */
        var mp=mathsPlain(val,false);
        if(mp.hit) note.maths++;
        it.text=mp.text;
        items.push(it);
      });
    }
    (s.annots||[]).forEach(function(a){
      if(!a) return;
      /* PowerPoint does not go through renderAnnots, so it asks the same
         question here rather than inheriting the answer -- and a private
         note reaching a .pptx is the exact failure T31 exists to
         prevent. */
      if(a.priv) return;
      if(a.hide) return;   /* T404: hidden is hidden, in PowerPoint too */
      /* T494: a placeholder is a hint about the shape of the slide,
         drawn nowhere in any export (T366) -- this writer does not go
         through renderAnnots, so "Title" and "Body text" went out to
         PowerPoint as real text (2026-09-15 review) */
      if(a.k==='text'&&a.ph) return;
      /* an item tied to a figure other than this page's does not belong
         on this page. note.frame is set by the exploding enumerator; with
         no flip book on the slide it is null and nothing is filtered. */
      if(a.fb){
        var fbk=flipById(s,a.fb);
        var atk=(note.frame!=null)?note.frame:(fbk?(fbk.at||0):0);
        if(!flipShowsFrame(s,a,atk)) return;
      }
      /* a crop is carried unless it is one of the two the writer
         cannot express: a hand-drawn outline (custGeom, not a preset)
         and a trim that leaves nothing. Counting only what is really
         lost is the point -- the toast used to say every crop was
         dropped, which stopped being true here (T107). */
      if(a.crop&&a.crop.path) note.cropped++;
      /* Every editable box leaves in PAGE coordinates. An anchored
         object's stored x/y are distances from an edge or centre, and
         its export fallback size matters to that conversion. */
      /* T572: a text box that keeps its height -- AutoFit's Shrink or
         Fixed, or words sat in its middle or at its foot -- leaves at
         that height, not at a guess */
      var box=(a.k==='arrow')?null:pptxBox((a.k==='text'&&a.fh>0)
        ?Object.assign({},a,{h:a.fh}):a,false);
      var pushedAt=items.length;
      if(a.k==='text'){
        var ti=pptxTextItem(a,false,ink,box);
        /* ...and a shrunk box takes the scale the slide drew it at, as
           PowerPoint's own fontScale: PowerPoint only works the shrink
           out again once the words are edited, so without it the words
           would open at full size, running out of the box. Only the
           slide on screen has a live layer; another is drawn off screen
           once, the way the presenter view draws its previews. */
        if(a.fit==='shrink'&&a.fh){
          if(!fitHost){
            var fsi=(pres.slides||[]).indexOf(s);
            fitHost=layer||(fsi>=0&&typeof buildSlideNode==='function'
              ?buildSlideNode(fsi):null)||false;
          }
          var fel=fitHost?fitHost.querySelector('div.an-item[data-idx="'
            +(s.annots||[]).indexOf(a)+'"]'):null;
          var fk=fel?parseFloat(fel.style.getPropertyValue('--an-fit')):NaN;
          if(fk>0&&fk<1) ti.fontScale=fk;
        }
        /* T483: THE PAGE THIS OUTPUT SLIDE IS ABOUT. A box with pages
           left as N identical slides of page one (2026-09-15 review);
           textAt honours flipForce, which the exporter sets per output
           page the way the print root does. And the numbers: {fig},
           {fig:id} and [@key] went out as the markers while the slide
           and the PDF show the numbers -- the same funnel every render
           path uses (figSubst), and a references box its list. */
        var _pn=(typeof textAt==='function')?textAt(s,a):0;
        var _pg=textPage(a,_pn<0?0:_pn);
        ti.text=a.bib&&typeof bibListText==='function'?bibListText()
          :figSubst(_pg.t,a,note.figs);
        /* `a.maths` means the Maths button built this box, so the whole
           of it is the equation and there is nothing to be careful about
           — an ordinary box has to earn the flattening (T53) */
        var tp=mathsPlain(ti.text,!!a.maths);
        if(tp.hit) note.maths++;
        ti.text=tp.text;
        /* T486: a Markdown or rich box leaves as paragraphs and runs,
           from the HTML the slide itself shows */
        if(!a.bib&&(a.md||_pg.h)){
          var html=a.md?notesHtml(figSubst(_pg.t,a,note.figs))
            :sanitizeRich(figSubst(_pg.h,a,note.figs)).html;
          var paras=pptxParasFromHtml(html);
          if(/<a\s[^>]*href/i.test(html)) note.links=(note.links||0)+1;
          if(paras){
            paras.forEach(function(p){p.runs.forEach(function(r){
              var t2=mathsPlain(r.t,!!a.maths); r.t=t2.text;});});
            ti.paras=paras;
            /* the writer's plain-text bullets flag is the box's list;
               with paragraphs it is per paragraph */
            ti.bullets=false;
          }
        }
        items.push(ti);
      } else if(a.k==='image'){
        if(a.src) items.push({t:'image',x:box.x,y:box.y,w:box.w,h:box.h,
          rot:a.rot,op:a.op,src:pptxSrc(note,a.src),
          /* what the picture shows, for PowerPoint's own accessibility
             checker and for a screen reader opening the deck (T105) */
          alt:a.alt,dec:a.dec,
          /* a path crop has no preset to become, so it is not sent;
             T387: a window onto the picture IS a crop in PowerPoint's
             terms -- srcRect trims the source to the window */
          crop:(a.crop&&!a.crop.path)?a.crop
            :(a.win&&a.win.w>0&&a.win.h>0
              ?{t:a.win.y||0,l:a.win.x||0,
                r:Math.max(0,100-(a.win.x||0)-a.win.w),
                b:Math.max(0,100-(a.win.y||0)-a.win.h)}:null),
          cropShape:(a.crop&&!a.crop.path)?a.crop.shape:''});
        else note.skipped++;
      } else if(a.k==='video'){
        /* T321: the clip and its poster travel as PowerPoint's own
           media shape. The bytes were fetched by pptxOriginals; an
           audio clip has no frame, so it is given a tile to stand on. */
        var vsrc=note.orig&&note.orig[a.vkey];
        var vpost=a.poster||(a.audio?mediaTile(a):'');
        if(vsrc&&vpost) items.push({t:'video',x:box.x,y:box.y,w:box.w,
          h:box.h,rot:a.rot,op:a.op,src:vsrc,poster:vpost,
          audio:!!a.audio,name:a.name||'',alt:a.alt});
        else note.skipped++;
      } else if(a.k==='rect'){
        /* `a.fill` is a BOOLEAN — "tint with my own line colour" — so the
           actual paint has to be resolved here. Passing the boolean
           through made every filled shape export solid black. */
        var lineCol=tokVal(a.color)||'#ff6b57';
        var grad=tokenGradient(a.grad,lineCol);
        var fillCol='';
        if(grad) fillCol='';
        else if(a.fill) fillCol=tokVal(a.fillc)||shapeFill(lineCol,
          0x2b/255);
        /* T560: an icon goes as its own lines, in the square it is
           drawn in (meet), so PowerPoint does not stretch it */
        var lic=(typeof lineIcon==='function')?lineIcon(a.shape):null;
        var ibox=box;
        if(lic){
          var pgI=pageOf();
          var wmm=box.w/100*pgI.mm[0],hmm=box.h/100*pgI.mm[1];
          var side=Math.min(wmm,hmm);
          var nw=side/pgI.mm[0]*100,nh=side/pgI.mm[1]*100;
          ibox={x:box.x+(box.w-nw)/2,y:box.y+(box.h-nh)/2,w:nw,h:nh};
        }
        items.push({t:'rect',x:ibox.x,y:ibox.y,w:ibox.w,h:ibox.h,rot:a.rot,
          op:a.op,color:lineCol,fill:lic&&!a.fill?'':fillCol,grad:grad,
          swPct:swOf(a)/SW_REF_H*100,
          dash:LINE_PPT[lineStyle(a)],shape:a.shape,
          icon:lic?lic[3]:null});
      } else if(a.k==='draw'){
        items.push({t:'draw',x:box.x,y:box.y,w:box.w,h:box.h,rot:a.rot,
          op:a.op,color:tokVal(a.color),swPct:swOf(a)/SW_REF_H*100,
          dash:LINE_PPT[lineStyle(a)],pts:a.pts||[]});
      } else if(a.k==='arrow'){
        var ea=arrowEnds(layer,s,a,0);
        var hz=headSize(a);
        items.push({t:'line',x1:ea.x1,y1:ea.y1,x2:ea.x2,y2:ea.y2,
          color:tokVal(a.color),swPct:swOf(a)/SW_REF_H*100,
          dash:LINE_PPT[lineStyle(a)],op:a.op,
          head:(HEAD_BY[headEnd(a)]||{}).ppt||'none',
          tail:(HEAD_BY[headStart(a)]||{}).ppt||'none',
          hsz:hz.ppt,curve:a.curve,bend:a.bend});
      } else if(a.k==='table'){
        /* PowerPoint has a real table shape, so pptx.js grew a builder
           for it rather than flattening a table into a grid of
           rectangles - which is not much of an export for anyone who
           then wants to edit the deck (2026-08-20) */
        /* T324: the FORMATTED rows, with the group row on top and the
           footer underneath -- the .pptx shows the table the slide
           shows, rather than the raw cells with the structure dropped */
        var tgs=tableGroups(a);
        items.push({t:'table',x:box.x,y:box.y,w:box.w,h:box.h,
          rot:a.rot,op:a.op,rows:tableViewRows(a),
          cols:tableCols(a),thead:!!a.thead,grid:a.grid!==0,
          /* the spans of the group row, so PowerPoint merges it too */
          spans:tgs?tgs.map(function(g){return g.n;}):null,
          sizePct:a.size||2.2,color:tokVal(a.color)||ink,
          font:fontPpt(a.font)});
      } else if(a.k==='chart'){
        /* the numbers travel, so PowerPoint gets a REAL chart it can
           restyle and recolour \u2014 the point of T117. chartParse
           resolves palette colours so a re-export stays consistent. */
        var cd=chartParse(a);
        /* T322: the switches travel as real chart XML; a confidence
           band has no PowerPoint twin and is counted instead */
        cd.series.forEach(function(se){
          if(se.band&&!se.hide) note.bands=(note.bands|0)+1;});
        items.push({t:'chart',x:box.x,y:box.y,w:box.w,h:box.h,
          ct:a.ct||'bar',cats:cd.cats,
          series:cd.series.map(function(se){
            var o={name:se.name,ys:se.ys,color:se.color};
            if(se.axis) o.axis=se.axis;
            if(se.trend) o.trend='linear';
            if(se.ct) o.ct=se.ct;
            if(se.hide) o.hide=1;
            if(se.err) o.err=se.err;
            return o;}),
          numeric:cd.numeric,title:a.title||'',leg:a.leg!==0,ink:ink,
          stack:cd.stack,ylog:cd.ylog,labels:cd.labels,
          xlab:cd.xlab,ylab:cd.ylab,y2lab:cd.y2lab,
          alt:a.alt,dec:a.dec});   /* T552 */
      } else if(a.k==='flip'){
        /* the frame this exported page is FOR. pptxItems is handed the
           slide plus, for an exploded page, which frame it represents —
           so one flip book of six figures becomes six real PowerPoint
           slides, which is the pile of slides the user was building by
           hand (2026-08-22). A placed notebook figure already exports as
           a picture, so this reuses that path rather than inventing one. */
        var fsel=flipFrames(a)[(note.frame!=null)?note.frame:(a.at||0)];
        var fsrc=null;
        if(fsel&&fsel.src) fsrc=fsel.src;
        else if(fsel&&fsel.ref){
          var fit=resolveRef(fsel.ref);
          var fnd=fit?framePart(fit.ns,fsel.part):null;
          var fig=fnd?fnd.querySelector('img'):null;
          if(fig&&fig.src&&fig.src.indexOf('data:')===0) fsrc=fig.src;
        }
        if(fsrc) items.push({t:'image',x:box.x,y:box.y,w:box.w,h:box.h,
          rot:a.rot,op:a.op,src:pptxSrc(note,fsrc),
          name:(fsel&&fsel.label)||'Figure',alt:a.alt,dec:a.dec});
        /* T403: a page that is its own object is exported AS that
           object (it is tied to this page), so the blank leaf is not
           a figure that went missing */
        else if(!(fsel&&fsel.own)) note.skipped++;
      } else if(a.k==='web'){
        /* T388: PowerPoint has no shape for a live page */
        note.web=(note.web||0)+1;
      } else if(a.k==='cell'){
        var it=a.ref?resolveRef(a.ref):null;
        var node=it?framePart(it.ns,a.part):null;
        var img=node?node.querySelector('img'):null;
        if(img&&img.src&&img.src.indexOf('data:')===0){
          items.push({t:'image',x:box.x,y:box.y,w:box.w,h:box.h,
            rot:a.rot,op:a.op,src:img.src,name:(it&&it.title)||'Figure',
            alt:a.alt||img.alt||'',dec:a.dec});   /* T552 */
          return;
        }
        /* no figure to lift — but prose and code ARE just text, and a text
           box beats an empty slide. A rich repr is neither: its meaning
           is in a layout PowerPoint cannot rebuild, so it is reported
           instead of being flattened into gibberish. A TABLE is the
           exception, and used to be counted with them: pptx.js has had a
           real table builder since the deck's own table kind, and it
           already tolerates the shape a scrape produces — a missing
           `cols` falls back to an equal split and a short row yields ''
           per cell. So the meaning survives, editable, and the biggest
           single entry in the "could not convert" tally goes with it
           (T109). */
        var tbl=node&&node.querySelector('table');
        var isTable=!!tbl;
        if(isTable){
          var rows=scrapeTable(tbl);
          if(rows.length){
            items.push({t:'table',x:box.x,y:box.y,w:box.w,h:box.h,
              rot:a.rot,op:a.op,rows:rows,
              /* grid:1 or the rules vanish and a scraped table arrives
                 as loose text in a box */
              thead:!!tbl.querySelector('thead th, thead td'),grid:1,
              sizePct:1.6,color:tokVal(a.txcol)||ink,
              name:(it&&it.title)||'Table'});
            return;
          }
        }
        /* a <pre> means the frame IS code; a bare inline <code> is just
           prose with a code span in it, and setting the whole note in
           monospace for one `groupby(...)` reads as a bug */
        var code=node&&node.querySelector('pre');
        /* typeset maths survives only as its flattened characters — legible,
           but no longer an equation. Counted so the toast can say so. */
        if(node) note.maths+=node.querySelectorAll('mjx-container').length;   /* T483 */
        var txt=(node&&!isTable)?blockText(node):'';
        if(txt){
          items.push({t:'text',x:box.x,y:box.y,w:box.w,h:box.h,
            rot:a.rot,op:a.op,text:txt,sizePct:code?1.3:1.8,
            color:tokVal(a.txcol)||ink,font:code?'Consolas':'',
            name:(it&&it.title)||'Text'});
        } else note.skipped++;
      }
      /* build timing and click actions ride on WHATEVER the branch
         above pushed for this annot (T110). rise/zoom have no honest
         entrance twin, so they leave as fades \u2014 counted in the
         export dialog, never silently. A link to a slide leaves as the
         DECK index here; the builder maps it to the output page,
         because a flip book explodes one slide into several. */
      /* A SERIES TIE LEAVES AS A REAL BUILD (T173), not as a line in
         the loss report. "Show from this series onwards" is exactly
         PowerPoint's own model -- the words arrive on the click that
         plots that series and stay -- so it survives the round trip;
         the arithmetic is the one seriesShows uses, base+i, so the
         click you rehearsed is the click PowerPoint gives you.
         'only' and 'until' need the words to LEAVE again, which this
         writer has no exit animation for, so those are counted and
         land whole. Failing open beats a paragraph nobody can find. */
      /* AN EXIT IS COUNTED, NOT SILENTLY DROPPED (T174). PowerPoint
         has exit animations, but this writer only emits entrances --
         and a swap that exported as two pictures stacked on top of each
         other would be worse than being told. */
      if(typeof animOut==='function'&&animOut(a)!=null)
        note.exits=(note.exits|0)+1;
      var xt=(typeof seriesTie==='function')?seriesTie(a):null;
      var xstep=null;
      if(xt&&!a.anim){
        var xch=annotByOid(s,xt.id);
        if(xch&&xch.k==='chart'&&xch.anim&&xch.anim.by==='series'){
          var xi=chartSeriesNames(xch).indexOf(xt.at);
          var xb=(xi<0)?null:stepBase(s,xch);
          if(xb!=null){
            if((xt.m||'from')==='from') xstep=xb+xi;
            else note.tied=(note.tied|0)+1;
          }
        }
      }
      for(var pq=pushedAt;pq<items.length;pq++){
        /* T549: a mirrored picture, shape or clip is PowerPoint's own
           flipH / flipV (a notebook figure or a book's page leaves as a
           picture, and takes them the same way) */
        var fpt=items[pq].t;
        /* T550: a picture's corrections; a saturation between none and
           double has no PowerPoint twin the writer can trust, and says so */
        if(fpt==='image'&&a.pfx){
          items[pq].pfx=a.pfx;
          if(a.pfx.s!=null&&a.pfx.s!==0&&a.pfx.s!==100)
            note.sat=(note.sat|0)+1;
        }
        /* T548: its shadow, as fractions of the page's height */
        var shp=SHADOWABLE[a.k]&&SHADOWS[a.shadow];
        if(shp&&(fpt==='image'||fpt==='rect'||fpt==='text'))
          items[pq].shadow={dx:shp.x/SW_REF_H,dy:shp.y/SW_REF_H,
            blur:shp.b/SW_REF_H,alpha:shp.a};
        if(fpt==='image'||fpt==='rect'||fpt==='video'){
          if(a.flipH) items[pq].flipH=1;
          if(a.flipV) items[pq].flipV=1;
        }
        if(xstep!=null){
          items[pq].animStep=xstep;
          items[pq].animType=(a.anim&&a.anim.type)||'fade';
        }
        if(a.anim){
          items[pq].animStep=bsteps[a.anim.order||0];
          items[pq].animType=a.anim.type||'fade';
          /* a build that runs itself carries its wait out to PowerPoint,
             which has the same idea (after-previous with a delay), so it
             survives the round trip instead of becoming a loss line */
          if(a.anim.after) items[pq].after=a.anim.after|0;
        }
        if(a.link&&a.link.to==='url'&&a.link.href){
          items[pq].link={to:'url',href:a.link.href};
        } else if(a.link&&a.link.to==='slide'&&a.link.sid){
          var lsi=-1;
          (pres.slides||[]).forEach(function(s9,i9){
            if(lsi<0&&s9.sid===a.link.sid) lsi=i9;});
          if(lsi>=0) items[pq].link={to:'slide',si:lsi};
        }
      }
    });
    return items;
  }
  /* A RENDERED TABLE, back into rows of strings. Deliberately the
     visible text and nothing else: colspans, nested markup and the
     pandas index are all layout, and a scrape that tried to keep them
     would produce a table that is wrong rather than plain. The cap is
     what PowerPoint stays usable at; past it the frame is better as a
     picture, and says so. */
  var SCRAPE_ROWS=60, SCRAPE_COLS=20;
  function scrapeTable(tbl){
    var out=[],n=0;
    var trs=tbl.querySelectorAll('tr');
    for(var i=0;i<trs.length&&out.length<SCRAPE_ROWS;i++){
      var cells=trs[i].querySelectorAll('th,td');
      if(!cells.length) continue;
      var row=[];
      for(var j=0;j<cells.length&&j<SCRAPE_COLS;j++)
        row.push((cells[j].textContent||'').trim());
      if(row.join('')==='') continue;
      n=Math.max(n,row.length);
      out.push(row);
    }
    /* tableShape reads the column count off row 0, so a header shorter
       than its body would truncate every row under it */
    return out.map(function(r){
      while(r.length<n) r.push('');
      return r;
    });
  }
  /* EVERY ORIGINAL THIS EXPORT WILL NEED, resolved before the build.
     JunoPptx.build is synchronous and pptxItems with it, so the
     IndexedDB lookup cannot happen inside them — it happens once, here,
     and is handed down as a plain {displaySrc: fullBytes} map. */
  function pptxOriginals(){
    var jobs=[],out={};
    function want(o){
      if(!o||!o.okey||!o.src||out[o.src]!==undefined) return;
      out[o.src]=null;
      jobs.push(originalOf(o).then(function(full){
        if(full&&full!==o.src) out[o.src]=full;}));
    }
    (pres.slides||[]).forEach(function(sl){
      (sl.annots||[]).forEach(function(a){
        if(!a) return;
        if(a.k==='image') want(a);
        else if(a.k==='flip'&&Array.isArray(a.frames)) a.frames.forEach(want);
        /* T321: a clip's bytes, keyed by its vkey */
        else if(a.k==='video'&&a.vkey&&out[a.vkey]===undefined){
          out[a.vkey]=null;
          jobs.push(mediaGet(a.vkey).then(function(r){
            if(r&&r.src) out[a.vkey]=r.src;}));
        }
      });
    });
    if(!jobs.length) return Promise.resolve(out);
    return Promise.all(jobs).then(function(){return out;},
      function(){return out;});
  }
  function exportDeckPptx(){
    if(!(pres.slides||[]).length){toast('No slides to export yet');return;}
    if(!window.JunoPptx){toast('.pptx export unavailable here');return;}
    /* what this will cost, BEFORE the file is in the downloads folder
       (T109). Silent when there is nothing to lose. */
    /* a .pptx leaves this machine and is re-scaled by whoever opens it,
       so it is one of the two consumers that most wants the full bytes —
       and it was embedding a.src, which is the shrunk display copy
       (2026-08-26 audit, T58) */
    return pptxConfirmLosses().then(function(go){
      if(!go) return;
      return pptxOriginals().then(pptxBuildAndSave);
    });
  }
  /* WHAT THIS EXPORT WILL COST, said before it happens. The tally
     already existed and was read out in a toast AFTERWARDS, which is
     the wrong end: by then the file is in the downloads folder and the
     choice — export the PDF instead — has been made for you. This runs
     the same enumeration dry and, only when something really will be
     lost, asks. Nothing to lose means no dialog, so the ordinary export
     is still one click (T109). */
  function pptxLosses(){
    var note={skipped:0,cropped:0,maths:0,tied:0,exits:0,orig:{}};
    var lost=[];
    /* T483: the tallies count SOURCE slides -- an exploded flip book
       multiplied every count on its slide by its frames (three live
       web pages for one, 2026-09-15 review); the figure numbers are
       computed once, they depend on order */
    note.figs=(typeof figNumbers==='function')?figNumbers():null;
    (pres.slides||[]).forEach(function(s,i){
      if(slideIsAlt(i)) return;
      note.frame=null;flipForce=null;
      paintSlide=s;                                         /* T316 */
      pptxItems(s,note,'#ffffff',null);
    });
    if(note.skipped) lost.push(note.skipped+' placed cell'
      +(note.skipped===1?'':'s')+' with no .pptx shape to become');
    if(note.web) lost.push(note.web+' live web page'
      +(note.web===1?'':'s')+' \u2014 a .pptx cannot carry a live page; '
      +'add a screenshot if it matters');
    if(note.maths) lost.push(note.maths+' equation'
      +(note.maths===1?'':'s')+' — this writer has no LaTeX-to-.pptx '
      +'path, so they arrive as plain characters');
    /* T486: Markdown and rich boxes travel as paragraphs and runs now;
       only a link inside the words is still words alone */
    if(note.links) lost.push(note.links+' link'+(note.links===1?'':'s')
      +' inside the words of a text box \u2014 the words arrive, the '
      +'link does not');
    if(note.exits) lost.push(note.exits+' object'
      +(note.exits===1?'':'s')+' set to GO on a later click \u2014 this '
      +'writer emits entrances only, so they arrive and then stay, '
      +'stacked over whatever was meant to replace them');
    if(note.tied) lost.push(note.tied+' item'+(note.tied===1?'':'s')
      +' tied to a chart series with “only” or “until” '
      +'— the .pptx is given no way to take them away again, so '
      +'they stay on the slide once shown');
    if(note.cropped) lost.push(note.cropped+' hand-drawn crop outline'
      +(note.cropped===1?'':'s')+' — the trim is carried, the outline '
      +'is not');
    if(note.bands) lost.push(note.bands+' confidence band'
      +(note.bands===1?'':'s')+' on a chart — a .pptx chart has no band, '
      +'so the line arrives without it');
    /* builds TRAVEL now (T110) \u2014 what is still approximate is
       the entrance on the two effects PowerPoint spells differently */
    var soft=0;
    (pres.slides||[]).forEach(function(sl){
      (sl.annots||[]).forEach(function(a){
        if(a&&a.anim&&(a.anim.type==='rise'||a.anim.type==='zoom'))
          soft++;});
    });
    if(soft) lost.push(soft+' rise/zoom build'
      +(soft===1?'':'s')+' — the click timing is kept, the entrance '
      +'plays as a fade');
    /* TEXT BUILDS. Bullet by bullet TRAVELS -- it leaves as a real
       PowerPoint paragraph build. The other two are named. */
    var sent=0,mdpara=0;
    (pres.slides||[]).forEach(function(sl){
      (sl.annots||[]).forEach(function(a){
        if(!a||a.k!=='text'||!a.anim) return;
        if(a.anim.by==='sent') sent++;
        else if(a.anim.by==='para'&&a.md
                &&/(^|\n)[ \t]*(\n|$)/.test(String(a.text||''))) mdpara++;
      });});
    if(sent) lost.push(sent+' sentence-by-sentence text build'
      +(sent===1?'':'s')+' — a .pptx builds text by PARAGRAPH and '
      +'has no smaller unit, so each of these arrives as a whole box on '
      +'one click');
    if(mdpara) lost.push(mdpara+' Markdown box'+(mdpara===1?'':'es')
      +' built bullet by bullet — a blank line in the source is a '
      +'paragraph in the .pptx and not a bullet here, so it takes a few '
      +'more clicks there than it does on this slide');
    return lost;
  }
  function pptxConfirmLosses(){
    var lost=pptxLosses();
    if(!lost.length) return Promise.resolve(true);
    return new Promise(function(res){
      askYes({title:'Export .pptx?',
        what:'Everything else comes across, but this will not:\n\n\u2022 '
          +lost.join('\n\u2022 '),
        note:'Export PDF keeps all of it exactly as you see it.',
        ok:'Export .pptx',cancel:'Not now'},function(y){res(y===true);});
    });
  }
  /* ---- T600: A .pptx THAT OPENS READY TO EDIT -----------------------
     (2026-09-30, user, with PowerPoint refusing edits: "when downloading
     a junoview as pptx for some reason it is downloaded in protected
     view".) The file is sound -- every part, type and relationship
     checks out -- but Windows marks everything a browser downloads as
     from the internet, and PowerPoint opens every such file in
     Protected View. No page can download a file without that mark. The
     Junoview app on this computer does not need to: the server writes
     the bytes into Downloads the way a desktop program writes a file,
     unmarked (server/exports.py), and the toast can open it or show it
     in its folder. In a browser the download is all there is, so the
     first one on Windows says why PowerPoint will ask, and how to make
     it stop asking. */
  var PV_TOLD_KEY='semopts:pptx-protected-told';
  function pptxDownload(blob,fname){
    var a=document.createElement('a');
    a.href=URL.createObjectURL(blob);
    a.download=fname;
    document.body.appendChild(a);a.click();a.remove();
    setTimeout(function(){URL.revokeObjectURL(a.href);},4000);
  }
  function pptxProtectedHelp(){
    askTell({title:'Why PowerPoint opens it in Protected View',
      what:'Windows marks every file a web browser downloads as coming '
        +'from the internet, and PowerPoint opens those read-only until '
        +'you press Enable Editing. Nothing is wrong with the file.\n\n'
        +'To stop it for good, either:\n'
        +'\u2022 in PowerPoint, File \u203a Options \u203a Trust Center '
        +'\u203a Trust Center Settings\u2026 \u203a Trusted Locations '
        +'\u203a Add new location\u2026, and add your Downloads folder; or\n'
        +'\u2022 right-click the file \u203a Properties \u203a tick '
        +'Unblock \u203a OK (that file only).',
      note:'The Junoview app on your computer writes the .pptx itself, '
        +'so its files open ready to edit.'});
  }
  function pptxDeliver(blob,fname,msg){
    if(APP.mode==='app'&&APP.api){
      readAsDataURL(blob).then(function(url){
        return APP.api('/api/export',{name:fname,
          b64:String(url).split(',')[1]||''});
      }).then(function(j){
        function reveal(how){
          APP.api('/api/reveal',{path:j.path,how:how}).catch(function(e){
            toast('Could not open it: '+((e&&e.message)||e),8000);});
        }
        toastActs(msg.replace('.pptx saved','Saved '+j.name+' in '
          +(j.folder||'Downloads'))+' \u2014 it opens ready to edit.',
          [['Open it',function(){reveal('open');}],
           ['Show in folder',function(){reveal('folder');}]],12000);
      }).catch(function(e){
        /* the server could not write it: the browser still can */
        pptxDownload(blob,fname);
        toast(msg+' (downloaded by the browser: '
          +((e&&e.message)||e)+')',9000);
      });
      return;
    }
    pptxDownload(blob,fname);
    var windows=/Windows/i.test(String(navigator.userAgent||''));
    if(windows&&lsGet(PV_TOLD_KEY)!=='1'){
      lsSet(PV_TOLD_KEY,'1',true);
      toastActs(msg+'. PowerPoint will open it in Protected View \u2014 '
        +'press Enable Editing there.',
        [['Why, and how to stop it\u2026',pptxProtectedHelp]],14000);
      return;
    }
    toast(msg);
  }
  function pptxBuildAndSave(orig){
    var pg=pageOf(),
      note={skipped:0,cropped:0,maths:0,tied:0,exits:0,
        orig:orig||{}};
    var bg=deckPageBg();
    var ink=pageIsLight(bg)?'#0b141d':'#ffffff';
    /* a slide-jump names a DECK slide; the .pptx page it lands on is
       the first output page that slide produced (flip books explode) */
    /* T554: a hidden slide goes too, hidden there as well (show="0") */
    var ents=outputSlides(true);
    var firstOut={};
    ents.forEach(function(ent,oi){
      if(!(ent.i in firstOut)) firstOut[ent.i]=oi+1;});
    note.figs=(typeof figNumbers==='function')?figNumbers():null;   /* T483 */
    var out=JunoPptx.build({
      title:pres.name||'presentation',
      widthMm:pg.mm[0],heightMm:pg.mm[1],bg:bg,
      slides:ents.map(function(ent){
        /* only the slide on screen has a live layer; the rest resolve
           attached arrow ends from their stored coordinates */
        var lay=(ent.i===cur)?stage.querySelector('.annot-layer'):null;
        note.frame=ent.f;
        flipForce=ent.f;   /* T483: the page this output slide is about */
        paintSlide=ent.s;                                   /* T316 */
        var its=pptxItems(ent.s,note,ink,lay);
        note.frame=null;flipForce=null;
        /* the master's look is BAKED into the export (T115): furniture
           items first (under the content) and the inherited
           background. PowerPoint-side inheritance would mean real
           slideLayout parts per master; the flattening is the recorded
           cut -- the pixels are right, the linkage does not travel. */
        var mm3=mastOf(ent.s);
        if(mm3&&mm3.cmp){
          var msyn3=mastSynth(mm3);
          if(msyn3) its=pptxItems(msyn3,note,ink,null).concat(its);
        }
        its.forEach(function(it){
          if(it.link&&it.link.to==='slide')
            it.link=(it.link.si in firstOut)
              ?{to:'slide',slide:firstOut[it.link.si]}:null;
          /* T546: and the words' own */
          (it.paras||[]).forEach(function(p){
            (p.runs||[]).forEach(function(r){
              if(r.link&&r.link.to==='slide')
                r.link=(r.link.si in firstOut)
                  ?{to:'slide',slide:firstOut[r.link.si]}:null;
            });
          });
        });
        if(ent.s.border) its.unshift({t:'rect',x:0,y:0,w:100,h:100,
          color:tokVal(ent.s.border.c)||'#39a9c0',
          swPct:(ent.s.border.w||4)/SW_REF_H*100,fill:'',name:'Border'});
        /* transFor() reads the slide's own transition, else its
           section's -- the same answer present mode uses. ent.i is the
           SOURCE slide index, which matters because a flip book
           explodes one slide into several output slides. */
        /* sl.notes is what the Notes pane writes and the presenter
           console reads; PowerPoint's Notes page is plain text, so it
           goes across as it is. A flip book's extra output slides share
           the source slide's notes, which is the same thing the
           presenter sees on each of them. */
        return {bg:bgSolid(tokVal(ent.s.bg)
            ||(mm3&&tokVal(mm3.bg))||bg),items:its,
          trans:transFor(ent.i),notes:ent.s.notes||'',
          /* T553: and how long, so PowerPoint plays it at that length */
          tdur:transFor(ent.i)?transDurMs(ent.i):0,
          /* T485: the slide's section, by name, for the writer's list */
          section:(ent.s.sec&&typeof secName==='function')?secName(ent.s.sec):'',
          hide:!!ent.s.hide};
      }),
    });
    var fname=(pres.name||'presentation')+'.pptx';
    var msg='.pptx saved — text stays editable'+outputNote();
    var noted=outputSlides(true).filter(function(e){
      return e.s&&e.s.notes&&e.s.notes.trim();}).length;
    if(noted) msg+='. Speaker notes came across on '+noted+' slide'
      +(noted===1?'':'s');
    /* tables convert now (T109), so naming them here would send
       people to the PDF for something that already worked */
    if(note.skipped) msg+='. '+note.skipped+' cell'
      +(note.skipped===1?'':'s')+' could not convert (a rich output with '
      +'no picture and no text — use Export PDF for those)';
    if(note.exits) msg+='. '+note.exits+' object'
      +(note.exits===1?'':'s')+' meant to leave on a later click will '
      +'stay \u2014 the .pptx gets entrances only from here';
    if(note.tied) msg+='. '+note.tied+' series-tied item'
      +(note.tied===1?'':'s')+' will stay once shown — '
      +'“only” and “until” need an exit this '
      +'writer does not have';
    if(note.sat) msg+='. '+note.sat+' picture'+(note.sat===1?'':'s')
      +' keep their colour saturation only here \u2014 the .pptx has the '
      +'brightness, contrast and greyscale';
    if(note.cropped) msg+='. '+note.cropped+' hand-drawn crop'
      +(note.cropped===1?'':'s')+' not carried (the .pptx keeps the '
      +'trim, not the outline)';
    if(note.maths) msg+='. '+note.maths+' equation'
      +(note.maths===1?'':'s')+' came across as plain text \u2014 '
      +'this writer has no LaTeX-to-.pptx path, so they were flattened';
    pptxDeliver(out.blob,fname,msg);
    /* one honest tally for the caller: the builder counts items IT could not
       write, this counts cells that never became items — reporting only one
       of the two reads as "nothing was lost" when something was */
    return {blob:out.blob,slides:out.slides,cropped:note.cropped,
      skipped:note.skipped+out.skipped};
  }
  /* ---- T479: BACKGROUND, ON THE SHELF. This slide's colour and
     border, every slide's colour, and the one deck-wide verb -- built
     into the Design tab's Background block on every slide change
     (bgSync from renderSlide), so the runs and the door's readout are
     always this slide's. It was a pop-up over the slide (bg-menu). */
  var BG_BORDER_COLS=[['#39a9c0','Teal'],['#ff6b57','Coral'],
    ['#f0a848','Amber'],['#46a892','Jade'],['#16202b','Ink'],
    ['#ffffff','White']];
  function bgSync(){
    var r1=$('#bg-run-this'); if(!r1) return;
    var BWS=[[0,'Off'],[2,'Thin'],[4,'Medium'],[9,'Thick']];
    function apply(fn){
      var s2=pres.slides[cur]; if(!s2) return;
      fn(s2);markDirty();applyPageBg();applyZoom();renderSlide();
    }
    function build(){
      var s2=pres.slides[cur]||{};
      r1.innerHTML='';
      bgChips(r1,s2.bg||'',function(v){
        apply(function(x){if(v) x.bg=v; else delete x.bg;});
      },true);
      /* the WHOLE deck's default, in the same menu as the one slide's
         override, so you can see the two against each other. It used to
         be a row in the File menu, which is where you open, save and
         export things (2026-08-20, user). */
      var r0=$('#bg-run-every'); r0.innerHTML='';
      /* T465: the same switch the Deck colours panel's Page background
         row moves -- one store, so the two doors always agree */
      bgChips(r0,(tokens().c.page)||'',function(v){
        setToken('c','page',v);
        applyPageBg();applyZoom();renderSlide();
        toast('Background for every slide set');
      },false);
      /* the deck default only shows through on slides that have no
         override of their own, so on any slide that HAS one the row
         above silently did nothing at all — you set the background for
         every slide and watched the one in front of you not change
         (2026-08-22). This is the verb that clears them. */
      var push=$('#bg-push');
      var over=(pres.slides||[]).filter(function(x){return x&&x.bg;});
      push.disabled=!over.length;
      push.title=over.length
        ?('Give every slide this slide\u2019s background \u2014 the '
          +over.length+' slide'+(over.length===1?'':'s')+' set '
          +'individually follow it')
        :'Every slide already shares the one background';
      var r2=$('#bg-run-border'); r2.innerHTML='';
      BWS.forEach(function(p){
        var b=document.createElement('button');
        b.className='sh-opt bg-w';b.textContent=p[1];
        var on=p[0]===((s2.border&&s2.border.w)||0);
        b.setAttribute('aria-pressed',on.toString());
        b.addEventListener('click',function(e){e.stopPropagation();
          apply(function(x){
            if(!p[0]) delete x.border;
            else x.border={w:p[0],c:(x.border&&x.border.c)||'#39a9c0'};
          });});
        r2.appendChild(b);
      });
      var bc=$('#bg-bcol-cell'),r3=$('#bg-run-bcol');
      bc.hidden=!s2.border;
      r3.innerHTML='';
      if(s2.border){
        BG_BORDER_COLS.forEach(function(pr){
          var c=pr[0];
          var b=document.createElement('button');
          b.className='sh-opt bg-chip';b.title=pr[1];   /* T479: its name */
          b.style.background=c;
          b.setAttribute('aria-pressed',(s2.border.c===c).toString());
          b.addEventListener('click',function(e){e.stopPropagation();
            apply(function(x){x.border.c=c;});});
          r3.appendChild(b);
        });
      }
      /* the door wears this slide's answer */
      var g=r1.closest('.rbn-grp')||$('.rbn-grp.rbn-slide');
      if(g){
        var name='Auto';
        PAGE_BGS.forEach(function(q){if(q[0]===s2.bg) name=q[1];});
        if(s2.bg&&name==='Auto') name='Custom';
        var bw=(s2.border&&s2.border.w)||0;
        g.setAttribute('data-say',name+(bw?' \u00b7 border':''));
      }
    }
    build();
  }
  (function(){
    var push=$('#bg-push');
    if(push) push.addEventListener('click',function(e){
      e.stopPropagation();
      var s2=pres.slides[cur]||{};
      var use=s2.bg||tokens().c.page||'';
      if(use) setToken('c','page',use);
      (pres.slides||[]).forEach(function(x){if(x) delete x.bg;});
      markDirty();applyPageBg();applyZoom();renderSlide();
      toast('Every slide now uses the one background');
    });
  })();
  window.SemDeckPptx=exportDeckPptx;   /* test hook */
  menuAction('#mi-pptx',function(){exportDeckPptx();});
  /* page background swatches (File menu) */
  /* one importer for every way a saved file comes back in: the File-menu
     picker, the launcher's "+ New… → Open a .junoview file…" row, and the
     silent startup restore from a remembered file handle. `silent` never
     renames, never toasts and never steals the view — it only fills in
     presentations the browser does not already have. */
  /* the copy here (the deck on screen, a draft's JSON, or a saved deck)
     against a deck just read from a file: the same presentation, or
     not. The deck on screen first: a Save mints slide ids into it
     that the draft written before the click does not carry. */
  function sameDeck(have,np){
    try{
      var h=typeof have==='string'?JSON.parse(have):have;
      return deckSaveSig(normPres(h))===deckSaveSig(np);
    }catch(e){return false;}
  }
  /* T527: a file of a deck that is already here asks, in the editor's
     dialog, BEFORE the import -- the import itself never asks. The
     answer goes back in as `choice`; no answer (a caller that did not
     ask) keeps both, which never destroys anything. */
  function importDeckTextAsk(txt){
    var obj=parseDeckText(txt);
    var list=(obj&&Array.isArray(obj.presentations))?obj.presentations
      :Array.isArray(obj)?obj:(obj&&Array.isArray(obj.slides))?[obj]:null;
    var pr=list&&list.length===1?list[0]:null;
    if(pr&&Array.isArray(pr.slides)){
      var np=normPres(pr),nm=np.name||'imported';
      var clash=(savedByName(nm)||draftGet(nm));
      if(clash&&!sameDeck((pres&&pres.name===nm)?pres:clash,np))
        return new Promise(function(res){
          askYes({title:'\u201c'+nm+'\u201d is already here',
            what:'Replace the copy in this browser with the file\u2019s '
              +'version, or keep both \u2014 the file\u2019s copy then '
              +'opens under a new name.',
            ok:'Replace it',cancel:'Keep both',danger:true},function(y){
            res(importDeckText(txt,false,y===true?'replace':'keep'));});
        });
    }
    return Promise.resolve(importDeckText(txt,false));
  }
  function importDeckText(txt,silent,choice){
    var obj=parseDeckText(txt);
    var list=(obj&&Array.isArray(obj.presentations))
      ?obj.presentations
      :Array.isArray(obj)?obj
      :(obj&&Array.isArray(obj.slides))?[obj]:null;
    if(!list||!list.length){
      if(!silent) toast('That file does not look like a saved deck');
      return 0;
    }
    var imported=0,dropped=0,first=null,loose=null;
    list.forEach(function(pr){
      if(!pr||!Array.isArray(pr.slides)) return;
      var np=normPres(pr);
      var base=np.name||'imported',nm=base,k=1;
      if(silent&&(savedByName(nm)||draftGet(nm))) return;
      /* T430: A FILE OF A DECK THAT IS ALREADY HERE ASKS. Opening an
         older file of "talk" silently minted "talk-2" and put it on the
         screen, so the old version appeared to have replaced the current
         one -- "everything got reverted back to before the save"
         (2026-09-14). Replace, or keep both under a new name: the one
         question, asked once, on a file you chose yourself. */
      var clash=(savedByName(nm)||draftGet(nm));
      /* T433: THE SAME DECK IS NOT A NEW DECK. A file of a deck that is
         here already, unchanged, opens that deck -- no question, no
         "talk-2". Opening the file you saved a minute ago used to mint
         a copy every time. */
      if(clash&&sameDeck((pres&&pres.name===nm)?pres:clash,np)){
        imported++;
        if(!first) first={name:nm,pres:np,kept:true};
        return;
      }
      if(clash&&!silent&&list.length===1){
        if(choice==='replace'){
          np.name=nm;
          draftSet(nm,JSON.stringify(np),true);
          imported++;first={name:nm,pres:np,kept:true};
          return;
        }
      }
      while(savedByName(nm)||draftGet(nm)){
        k++;nm=base+'-'+k;
      }
      np.name=nm;
      /* T263: the store answers whether it kept the deck, so this cannot
         lie (T429: in memory it always does; a refused IndexedDB write
         shows on the readout) */
      var kept=draftSet(nm,JSON.stringify(np),true);
      if(kept){
        imported++;
        if(!first) first={name:nm,pres:np,kept:true};
        return;
      }
      /* T414: NO ROOM IN THE BROWSER IS NOT "CANNOT OPEN" (2026-09-13,
         user: "I am trying to open a junoview file from my computer.
         it will not open ... I have to present it soon"). A deck with
         a few pasted pictures is bigger than localStorage will take,
         and this refused to open it at all -- while the one copy that
         matters, the file, was in hand the whole time. A deck that did
         not fit opens from the object in hand; only the browser copy
         is what did not fit. And it is the one that OPENS even when
         smaller decks in the same file did fit: those are in the
         library now and lose nothing, while a deck that is nowhere
         but in this object would be gone with the next click. A file
         written by Download a copy holds every deck, the current one
         last, which is exactly how the big one came to be dropped. */
      if(!silent&&!loose){loose={name:nm,pres:np,kept:false};imported++;}
      else dropped++;
    });
    if(loose) first=loose;
    if(!imported){
      if(!silent)
        toast(dropped
          ?'There was no room to store them \u2014 free some space '
            +'by deleting a draft you no longer need'
          :'No presentations found in that file');
      return 0;
    }
    if(silent){renderPresTabs();return imported;}
    if(first.kept){
      lsSet(PFX+'last',first.name,true);
      loadPresentation(first.name);
    } else loadPresentationObj(first.pres);   /* T414 */
    cur=0;activePane=-1;
    /* picked from the launcher: go straight into the editor — the whole
       point of opening a file is to get back to the presentation in it */
    if(deckEl.hidden) openDeck('edit');
    status();refresh();
    if(first.kept)
      toast('Imported '+imported+' presentation'
        +(imported>1?'s':'')+' (as drafts)'
        +(dropped?(' \u2014 '+dropped+' would not fit and '
          +(dropped>1?'were':'was')+' not kept'):''));
    else
      toast('Opened \u201c'+first.name+'\u201d \u2014 too big for a '
        +'browser copy, so it lives in its file: Save writes it there'
        +(imported>1?(' \u2014 '+(imported-1)+' smaller deck'
          +(imported>2?'s':'')+' from the file went into the library'):'')
        +(dropped?(' \u2014 '+dropped+' other'+(dropped>1?'s':'')
          +' in the file '+(dropped>1?'were':'was')+' not kept'):''),
        9000);
    return imported;
  }
  window.SemDeckImport=importDeckText;       /* browser-verification hook */
  window.SemDeckImportAsk=importDeckTextAsk; /* ...and the asking door (T527) */
  window.SemDeckFileHtml=function(){return junoviewFileHtml();};
  /* ---- T597: A SAVED FILE HANDS ITS PRESENTATION OVER ------------------
     The other end of a saved file's Open in Junoview (saved-file.js). It
     opens this page at #junoview-handoff and waits. Once the draft store
     has answered -- a deck of the same name kept here is only visible
     after it has, and T430's question depends on seeing it -- this tab
     says it is ready and the file posts its deck. The deck is taken only
     from the window that opened this one, only once, and only after one
     question, because any web page could open Junoview this way: the
     click that opens a presentation is always the person's. After that
     it is File > Open's importer, T527's question included, and the deck
     is bound to the file's name -- and to the file itself when it sits in
     the folder Junoview already saves into. A page cannot be handed a
     file it did not pick, so otherwise the first Save asks where, and
     the toast says to pick the same file. */
  var handoffTaken=false;
  function handoffBoot(){
    if(!/^#junoview-handoff/.test(String(location.hash||''))) return;
    try{history.replaceState(null,'',location.pathname+location.search);}
    catch(e){}
    var src=window.opener;
    if(!src){
      toast('Nothing was handed over \u2014 to open a saved presentation, '
        +'use Open\u2026 or drop the file onto this window',9000);
      return;
    }
    window.addEventListener('message',function(e){
      if(handoffTaken||e.source!==src) return;
      var d=e.data||{};
      if(d.junoview!=='deck'||typeof d.text!=='string') return;
      handoffTaken=true;
      handoffOpen(d,function(word){
        try{src.postMessage({junoview:word},'*');}catch(err){}
      });
    });
    handoffReady(src,0);
  }
  /* "ready" waits for the draft store, up to eight seconds */
  function handoffReady(src,n){
    if(APP.draftsPending&&APP.draftsPending()&&n<80){
      setTimeout(function(){handoffReady(src,n+1);},100);
      return;
    }
    try{src.postMessage({junoview:'ready'},'*');}catch(e){}
  }
  /* the one deck a handed-over file holds, or null */
  function handoffDeck(text){
    try{
      var obj=parseDeckText(text);
      var list=(obj&&Array.isArray(obj.presentations))?obj.presentations
        :Array.isArray(obj)?obj:(obj&&Array.isArray(obj.slides))?[obj]:[];
      return list.filter(function(p){
        return p&&Array.isArray(p.slides);})[0]||null;
    }catch(e){return null;}
  }
  function handoffOpen(d,reply){
    var one=handoffDeck(d.text);
    if(!one){
      reply('declined');
      toast('That file holds no presentation Junoview can read',8000);
      return;
    }
    var file=String(d.file||'').replace(/[\\/]/g,'').slice(0,160);
    var k=one.slides.length;
    askYes({title:'Open \u201c'+String(one.name||'presentation')+'\u201d?',
      what:'From '+(file||'a saved presentation file')+', '+k+' slide'
        +(k===1?'':'s')+'. Opened by that file\u2019s Open in Junoview '
        +'button \u2014 if you did not just press it, choose Cancel.',
      ok:'Open it',cancel:'Cancel'},function(y){
      if(y!==true){reply('declined');return;}
      Promise.resolve(importDeckTextAsk(d.text)).then(function(got){
        if(!got){reply('declined');return;}
        handoffBind(file,String(d.path||''),one);
        reply('opened');
      }).catch(function(e){
        reply('declined');
        toast('Could not open that file: '+((e&&e.message)||e),9000);
      });
    });
  }
  /* the name of the folder a file: address is in */
  function handoffFolder(path){
    var p=String(path||'').split('?')[0].split('#')[0];
    try{p=decodeURIComponent(p);}catch(e){}
    var parts=p.split(/[\\/]/).filter(Boolean);
    return parts.length>1?parts[parts.length-2]:'';
  }
  function handoffBind(file,path,one){
    if(!pres||!file) return;
    var dir=handoffFolder(path);
    /* a file whose deck was kept beside one of the same name ("keep
       both") is not the file of the deck on screen */
    var same=(pres.name===String(one&&one.name||''));
    var stem=fileStem(file);
    /* T398: the file's name is the deck's name, when it is free */
    if(same&&stem&&stem!==pres.name&&!savedByName(stem)&&!draftGet(stem))
      renamePresentation(stem);
    bindFile(pres.name,null);
    if(deckDir){
      /* the folder Junoview saves into mints this deck's file there */
      setTarget('file');
      if(same&&dir&&dir===deckDirName&&file===deckFileName())
        toast('Opened \u2014 Save writes back to '+file+' in your '+dir
          +' folder',8000);
      else
        toast('Opened from '+file+'. It saves into your '+deckDirName
          +' folder as '+deckFileName()+' \u2014 to keep using '+file
          +' instead, choose it under Save \u25be \u203a A file on your '
          +'computer\u2026',12000);
      return;
    }
    fileName=file;
    if(canPickFile){
      setTarget('file');
      toast('Opened from '+file+'. A browser page cannot write to a file '
        +'it did not pick itself, so the first Save asks where \u2014 '
        +'choose '+file+(dir?(' in '+dir):'')+' to keep saving to it.',
        12000);
    } else {
      setTarget('browser');
      toast('Opened from '+file+' \u2014 kept in this browser. Use '
        +'Download a copy to write it back out.',10000);
    }
  }
  /* ---- OPENING A .junoview FILE ---------------------------------------
     Opening a file used to import its contents and then carry on saving
     to the BROWSER, so the file you opened never changed again and your
     work quietly went somewhere else (2026-08-20, user: "when loading
     presentation from computer, it then starts saving to browser, should
     save to the same file").
     Where the File System Access API exists we ask for a real handle, so
     Save writes straight back to the file you opened. Where it does not
     (Firefox, Safari) an <input type=file> gives contents but no handle —
     nothing can write back to it — so the target is still set to "on this
     computer" and the first Save asks once where to put it. Either way
     the answer to "where is this going?" stops being "somewhere else". */
  /* T433: a file of several decks is a bundle from before a file held
     one. Its decks go into the library; nothing binds to it, and the
     toast says where each one saves from now on. */
  function bundleOpened(n,name){
    if(n<2) return false;
    if(saveTarget==='file'&&!fileHandle) fileWaits='pick';
    status();renderTargetBtn();renderSaveBtn();
    toast('Opened '+n+' presentations from '+(name||'that file')
      +' into this browser. A file holds one presentation now, so each '
      +'saves to its own file \u2014 Save asks where the first time.',
      10000);
    return true;
  }
  /* T436: SEVERAL AT ONCE (2026-09-14, user: "the ability to open
     multiple notebook/presentations at once would be a slay out of
     10"). The picker takes many; each file is opened in turn -- its
     deck lands, and a single-deck file binds to the deck it opened,
     the way one file always did -- and the last one is on screen. */
  function openDeckHandles(hs){
    var opened=0,last='';
    return hs.reduce(function(chain,h){
      return chain.then(function(){
        return h.getFile().then(function(f){
          return f.text().then(function(txt){
            var n=fileDeckCount(txt);
            return importDeckTextAsk(txt).then(function(got){
              if(got) landed(n,f,h);});
          });
        });
      });
    },Promise.resolve()).then(function(){
      if(opened>1)
        toast('Opened '+opened+' files \u2014 each presentation saves '
          +'back to its own file',7000);
      else if(opened&&last)
        toast('Opened \u2014 Save now writes back to '+last);
    });
    /* T527: what landing one file does, once its question (if it had
       one) is answered */
    function landed(n,f,h){
            opened++;
            if(bundleOpened(n,f.name||'')) return;
            /* the handle is what makes Save write back to this very
               file -- bound to the deck it opened (T416; T261 before
               it: HKEY, not 'deckFile', so the next visit remembers) */
            bindFile(pres.name,h);
            if(!fileName) fileName=f.name||'';
            /* T433: the file's name is the deck's name through this
               door too (T398 gave it to the picked and the dropped
               file; the opened one kept whatever name was inside) */
            followFileName();
            setTarget('file');
            last=fileName;
    }
  }
  /* T597: a dropped file with a handle goes through the same door */
  APP.deckOpenHandles=openDeckHandles;
  function openDeckFile(){
    if(window.showOpenFilePicker){
      window.showOpenFilePicker({
        types:[{description:'Junoview presentation',
          accept:{'text/html':['.html','.junoview'],
            'application/json':['.json']}}],
        multiple:true
      }).then(function(hs){
        if(!hs||!hs.length) return;
        return openDeckHandles(hs);
      }).catch(function(e){
        /* T414: a cancelled picker is silent; anything else is SAID.
           This swallowed every failure, so a file that would not open
           gave no clue why. */
        if(e&&e.name==='AbortError') return;
        toast('Could not open that file: '+((e&&e.message)||e),9000);
      });
      return;
    }
    var fi=document.getElementById('deckfile');
    if(fi) fi.click();
  }
  (function(){
    var fi=document.getElementById('deckfile');
    if(!fi) return;
    fi.addEventListener('change',function(){
      var files=Array.prototype.slice.call(this.files||[]);
      this.value='';
      /* T436: several at once, one after the other */
      files.reduce(function(chain,f){
        return chain.then(function(){return openDeckInputFile(f);});
      },Promise.resolve());
    });
    function openDeckInputFile(f){
      var nm=f.name||'';
      return f.text().then(function(txt){
        var n=fileDeckCount(txt);
        return importDeckTextAsk(txt).then(function(got){
          if(got) landedInput(n,nm);});
      }).catch(function(e){
        toast('Import failed: '+((e&&e.message)||e));
      });
    }
    /* T527: the input door's landing, after any question */
    function landedInput(n,nm){
        if(bundleOpened(n,nm)) return;   /* T433 */
        /* no handle from an <input>, so we cannot write back to the file
           itself - but the DESTINATION is still "a file on your
           computer", and the first Save asks where once. T416: bound to
           the deck it opened, and the deck takes the file's name the
           way a picked file gives it (T398). */
        bindFile(pres.name,null);
        fileName=nm;
        followFileName();
        /* T263: ...and it can only ask where if this browser HAS a save
           picker. Without one, pickSaveFile resolves null, so every Save
           and every autosave did nothing at all and said nothing. This
           door is also Chrome's "+ New > Open a .junoview file", where
           the picker exists and the promise above holds. */
        if(canPickFile){
          setTarget('file');
          toast('Opened \u2014 Save keeps it as a file on your '
            +'computer');
        } else {
          setTarget('browser');
          toast('Opened \u2014 this browser cannot save straight back '
            +'to a file, so it is kept here as a draft. Use Download to '
            +'write it out.');
        }
    }
  })();
  menuAction('#mi-discard',function(){
    /* T483: DISCARD GOES BACK TO THE SAVED COPY. A deck kept in a file
       is re-read from it; a deck with no saved copy at all was simply
       deleted and replaced with the notebook's own deck, with no
       question asked (2026-09-15 review) -- it asks now. */
    var nm=pres.name||'untitled';
    /* T569: DISCARD ASKS, EVERY TIME. It asked only when there was no
       saved copy; with one, a single click on a row beside Rename threw
       away every change since the last save. It says what it goes back
       to, and there is nothing to ask about when nothing has changed. */
    if(source==='saved'||saveKind==='manual'){
      toast('Nothing to discard — “'+nm+'” is as it was '
        +'last saved');
      return;
    }
    if(saveTarget==='file'&&fileHandle&&fileHandle.getFile){
      askYes({title:'Discard your changes to “'+nm+'”?',
        what:'It goes back to the copy saved in '+(fileName||'its file')
          +'. Everything changed since then is lost.',
        ok:'Discard changes',cancel:'Keep editing',danger:true},
        function(y){if(y===true) discardFromFile(nm);});
      return;
    }
    /* kept in this browser: back to the version the last Save took. It
       used to find no "saved copy" here at all, and offered to delete a
       deck that had just been saved -- or, for a deck that came with the
       notebook, threw every save away and went back to the notebook's. */
    var sp=saveTarget==='browser'?deckMeta(nm).savedSnap:null;
    if(sp){
      var at=deckMeta(nm).saved;
      askYes({title:'Discard your changes to “'+nm+'”?',
        what:'It goes back to how it was when you last saved it'
          +(at&&typeof histWhen==='function'?' ('+histWhen(at)+')':'')
          +'. Everything changed since then is lost.',
        ok:'Discard changes',cancel:'Keep editing',danger:true},
        function(y){
          if(y!==true) return;
          snapRead(sp).then(function(then){
            if(!then||!Array.isArray(then.slides)){
              toast('That save is no longer in this browser’s '
                +'history — History has the versions it still has');
              return;
            }
            histRestoreDeck(then,sp);
            toast('Changes discarded — “'+nm+'” is as you '
              +'last saved it. Ctrl+Z brings the changes back');
          });
        });
      return;
    }
    if(!savedByName(nm)){
      askYes({title:'Discard “'+nm+'”?',
        what:'It has no saved copy to go back to, so discarding its '
          +'changes deletes it from this browser.',
        ok:'Delete it',cancel:'Keep it',danger:true},function(y){
        if(y===true) discardNow(nm);});
      return;
    }
    askYes({title:'Discard your changes to “'+nm+'”?',
      what:'It goes back to its last save. Everything changed since '
        +'then is lost.',
      ok:'Discard changes',cancel:'Keep editing',danger:true},
      function(y){
        if(y!==true) return;
        discardNow(nm);
        toast('Changes discarded — “'+nm+'” is as it was '
          +'last saved');
      });
  });
  /* a deck kept in a file is re-read from it */
  function discardFromFile(nm){
    if(!fileHandle||!fileHandle.getFile) return;
    fileHandle.getFile().then(function(f){return f.text();}).then(function(txt){
      var obj=parseDeckText(txt);
      var list=(obj&&Array.isArray(obj.presentations))?obj.presentations
        :(obj&&Array.isArray(obj.slides))?[obj]:[];
      var hit=list.filter(function(p){return p&&(p.name||'')===nm;})[0]||list[0];
      if(!hit){toast('The file has no copy of \u201c'+nm+'\u201d to go back to');return;}
      cancelDraftWrite();draftDel(nm);
      var np=normPres(hit);np.name=nm;loadPresentationObj(np);
      cur=0;activePane=-1;status();refresh();
      toast('Back to \u201c'+nm+'\u201d as saved in '+(fileName||'the file'));
    }).catch(function(){toast('Could not read '+(fileName||'the file'));});
  }
  function discardNow(nm){
    cancelDraftWrite();   /* a pending write would resurrect the discard */
    draftDel(nm);
    loadPresentation(pres.name);
    cur=0;activePane=-1;
    status();
    refresh();
  }
  /* ONE project save, shared by rename and delete. embedAssets, not the
     lean list: `projectPres` can never carry `emb` (normPres absorbs it
     into the session store), so posting it raw made a rename or a delete
     quietly strip every embedded figure out of junoview_project.json —
     the file stopped being self-contained without anything being said
     (2026-08-22). */
  /* ---- T451: A RENAME AND A DELETE HONOUR THE REVISION TOO -----------
     This posted the whole project list with NO `rev`, which the server
     reads as "do not check" (it is what an old page still in a tab
     sends), and then swallowed every error. So the one thing the
     revision was added for in 2026-08-22 — a second window creating a
     deck while this one writes — was still broken through this door:
     renaming or deleting anything here erased that deck without a
     word. It also left this tab's projectRev a revision behind, so the
     very next autosave paid for a 409 round trip it did not need.
     `change` says what the write was FOR, so a conflict can re-apply
     the same intent to the list the other window wrote rather than
     losing it or flattening them: {drop:name} or {from:old,to:new}. */
  /* A 409 hands back everything on disk, including the decks this window
     has never heard of. saveToProject already learns them (projectSaved
     takes the reconciled list as the new projectPres); this door did not,
     and that was the difference between a conflict resolved ONCE and one
     resolved never: the retry wrote the other window's deck back, and
     then the next full-list write from this tab -- now that the revision
     had caught up, so nothing refused it -- erased it for good. They come
     in through normPres, the same door the boot list uses, so nothing
     carries `emb` into projectPres. */
  function adoptUnknownPresentations(theirs){
    if(!Array.isArray(theirs)) return 0;
    var known={};
    projectPres.forEach(function(p){if(p&&p.name) known[p.name]=1;});
    var n=0;
    theirs.forEach(function(p){
      if(!p||!p.name||known[p.name]) return;
      known[p.name]=1;projectPres.push(normPres(deep(p)));n++;
    });
    return n;
  }
  function projectApply(list,change){
    if(!change||!Array.isArray(list)) return null;
    if(change.drop!=null)
      return list.filter(function(p){return !p||p.name!==change.drop;});
    if(change.from!=null)
      return list.map(function(p){
        if(p&&p.name===change.from) p.name=change.to;
        return p;});
    return null;
  }
  function saveProject(change){
    if(APP.mode!=='app') return Promise.resolve(false);
    return APP.api('/api/save',
      {presentations:embedAssets(deep(projectPres)),rev:projectRev})
      .then(function(j){
        if(j&&typeof j.rev==='number') projectRev=j.rev;
        return true;
      }).catch(function(e){
        if(!(e&&e.status===409&&e.data&&Array.isArray(e.data.presentations)))
          return false;
        projectRev=e.data.rev;
        /* their list, with this window's rename or delete re-applied.
           projectPres itself is left alone: it is the normalised form
           (normPres has absorbed `emb` out of it) and the server's is
           the embedded one, so adopting theirs here is exactly the
           swap that used to strip every embedded figure. */
        var merged=projectApply(e.data.presentations,change);
        if(!merged) return false;
        adoptUnknownPresentations(merged);
        return APP.api('/api/save',{presentations:merged,rev:projectRev})
          .then(function(j2){
            if(j2&&typeof j2.rev==='number') projectRev=j2.rev;
            return true;
          }).catch(function(){return false;});
      });
  }
  /* one delete, callable for ANY presentation — the File menu and the
     rail rows' bins both land here (2026-08-18, user: "an easier way to
     delete presentation ... a delete option when something is selected") */
  function deletePresByName(nm){
    if(pres&&nm===pres.name) cancelDraftWrite();
    draftDel(nm);
    /* T598: the handle to its file goes too; the file itself stays */
    delete fileHandles[nm];
    idbDel(HKEYD+nm).catch(function(){});
    if(typeof forgetRememberedPresentation==='function')
      forgetRememberedPresentation(nm);
    /* embedded-in-a-notebook presentations come back on reload — say so,
       whichever door the delete came through */
    var wasEmbedded=nbPres.some(function(p){return p.name===nm;});
    projectPres=projectPres.filter(function(p){return p.name!==nm;});
    nbPres=nbPres.filter(function(p){return p.name!==nm;});
    saveProject({drop:nm});
    if(nm===pres.name){
      var names=allSaved().map(function(p){return p.name;})
        .concat(draftNames());
      names=names.filter(function(x){return x!==nm;});
      if(names.length) loadPresentation(names[0]);
      else {pres=defaultPres();source='auto';}
      if(pres&&typeof notePresentationOpen==='function')
        notePresentationOpen(pres.name);
      cur=0;activePane=-1;
      status();refresh();
    } else renderPresTabs();
    toast(wasEmbedded
      ?('Deleted "'+nm+'" (it will return if it is embedded in a '
        +'notebook’s metadata)')
      :('Deleted "'+nm+'"'));
  }
  (function(){
    var b=$('#pr-newbtn'),m=$('#pr-newmenu');
    if(!b||!m) return;
    b.addEventListener('click',function(e){
      e.stopPropagation();
      m.hidden=!m.hidden;
      b.setAttribute('aria-expanded',(!m.hidden).toString());
    });
    $$('.pr-mi',m).forEach(function(mi){
      mi.addEventListener('click',function(e){
        e.stopPropagation();
        m.hidden=true;b.setAttribute('aria-expanded','false');
        var real=$('#'+mi.dataset.for);
        if(real) real.click();
      });
    });
    document.addEventListener('click',function(e){
      if(!m.hidden&&!m.contains(e.target)&&e.target!==b){
        m.hidden=true;b.setAttribute('aria-expanded','false');}
    });
  })();
  window.SemDeckDelete=deletePresByName;   /* rail rows + tests */
  /* ---- ONE rename, for every door into it -----------------------------
     There are three (the title bar, File ▸ Rename…, and the rail), and
     before this there was no shared implementation at all: each one poked
     pres.name and #pres-name directly. The result was renaming that
     appeared to do nothing in the primary flow, drafts orphaned under
     every prefix of the new name, no collision guard, and a project entry
     that kept the old name (2026-08-20 diagnosis).
     A rename moves the WORK, not just the label: the browser draft, the
     project entry, and the folder the presentation was filed in. */
  function renamePresentation(nm){
    nm=String(nm||'').trim();
    var old=pres&&pres.name;
    if(!nm||!old||nm===old) return false;
    var taken=allSaved().map(function(p){return p.name;})
      .concat(draftNames());
    if(taken.indexOf(nm)>=0){
      toast('There is already something called “'+nm+'” — pick another '
        +'name');
      return false;
    }
    /* the draft moves with the name, rather than being deleted under the
       old one and re-created under the new one on the next save */
    flushTextEdits();
    flushDraftWrite();   /* migrate the CURRENT state, not a stale draft */
    /* Rename itself is an unsaved edit, even when this deck had no draft
       before. Put the complete current state under the new key NOW; the
       debounced markDirty below is redundancy, not the only copy. */
    var moved=deep(pres);moved.name=nm;
    /* T429: the draft store keeps it whatever its size, so the old key
       is only ever dropped once the new one holds the deck (T416 used
       to drop it on faith for a file-homed deck, which left a deck too
       big for localStorage nowhere but in memory) */
    if(!draftSet(nm,JSON.stringify(moved),true)){
      toast('Could not rename — this browser could not keep the moved '
        +'draft. Your presentation is still called “'+old+'”.',9000);
      return false;
    }
    draftDel(old);
    /* the folder rides on the presentation object itself (p.folder), so
       it needs no separate move — but the SAVED copies are matched by
       name and do */
    projectPres.forEach(function(p){if(p.name===old) p.name=nm;});
    nbPres.forEach(function(p){if(p.name===old) p.name=nm;});
    /* Queued behind any Save already in flight. Snapshot JSON can keep
       its historical name because restore deliberately preserves `nm`. */
    histRename(old,nm);
    pres.name=nm;
    if(typeof renameRememberedPresentation==='function')
      renameRememberedPresentation(old,nm);
    saveProject({from:old,to:nm});
    fileRename(old,nm);   /* T416: the file follows the name */
    partRenamed(old,nm);   /* T601: and so does every talk showing it */
    markDirty();status();renderPresTabs();renderPresRow();
    toast('Renamed to “'+nm+'”');
    return true;
  }
  /* ---- T450: RENAMING ONE YOU ARE NOT IN ------------------------------
     (2026-09-14, user: "you can't duplicate a presentation or delete it
     from the main menu, there is very little controls".) The library
     lists every saved presentation, not just the one on screen, so its
     rename cannot be the one above -- that one moves `pres`. The deck
     on screen still goes through it, because only it can carry the
     unflushed edits, the dirty mark and the title bar with the name.
     Everything else is the same moves without them: the draft, the
     project entries, the history, the remembered name and the file
     binding. */
  function renamePresByName(old,nm){
    old=String(old||'');nm=String(nm||'').trim();
    if(!old||!nm||nm===old) return false;
    if(pres&&pres.name===old) return renamePresentation(nm);
    var taken=allSaved().map(function(p){return p.name;})
      .concat(draftNames());
    if(taken.indexOf(nm)>=0){
      toast('There is already something called \u201c'+nm+'\u201d \u2014 pick another '
        +'name');
      return false;
    }
    var raw=draftGet(old);
    if(raw){
      var moved;
      try{moved=JSON.parse(raw);}catch(e){moved=null;}
      if(moved){moved.name=nm;raw=JSON.stringify(moved);}
      if(!draftSet(nm,raw,true)){
        toast('Could not rename \u2014 this browser could not keep the moved '
          +'draft. It is still called \u201c'+old+'\u201d.',9000);
        return false;
      }
      draftDel(old);
    }
    projectPres.forEach(function(p){if(p.name===old) p.name=nm;});
    nbPres.forEach(function(p){if(p.name===old) p.name=nm;});
    histRename(old,nm);
    if(typeof renameRememberedPresentation==='function')
      renameRememberedPresentation(old,nm);
    if(typeof renameOpenPresentation==='function')
      renameOpenPresentation(old,nm);
    saveProject({from:old,to:nm});
    fileRename(old,nm);
    partRenamed(old,nm);   /* T601 */
    status();renderPresTabs();renderPresRow();
    toast('Renamed \u201c'+old+'\u201d to \u201c'+nm+'\u201d');
    return true;
  }
  window.SemDeckRename=renamePresByName;   /* library rows + tests */
  /* ---- T416: THE FILE FOLLOWS THE NAME, the other half of T398 --------
     (2026-09-13, user: "when you save it as a name the presentation
     name becomes this and vice-versa"). In the default folder the file
     is Junoview's own, so it is renamed outright: the new name is
     written, the old file removed. A file picked elsewhere is moved
     where the browser can move a file; where it cannot, the old file
     keeps being written and a toast says which click renames it. */
  function fileRename(old,nm){
    var had=(fileHandles[old]!==undefined)||fileFor===old;
    if(!had) return Promise.resolve(false);
    var h=fileHandles[old]||null;
    delete fileHandles[old];fileHandles[nm]=h;
    /* T598: its own key moves with it */
    idbDel(HKEYD+old).catch(function(){});
    if(h) idbPut(HKEYD+nm,h).catch(function(){});
    if(fileFor===old){fileFor=nm;fileHandle=h;fileName=h?(h.name||''):'';}
    if(h) lsSet(HNKEY,nm,true);
    if(!h||fileStem(fileName)===nm) return Promise.resolve(false);
    var oldFile=fileName,newName=deckFileName();
    /* T447: THE OLD FILE IS LET GO, NOT WRITTEN ON (2026-09-14, user:
       "autosaved to project.junovie... Changed file name, but it still
       says it is saving to the above. Why?????? How to get around
       this???"). Where the browser cannot move a picked file -- Chrome
       cannot -- the deck went on autosaving into the file with the OLD
       name, and an eight-second toast was the only clue. Now the
       binding is dropped: the old file keeps what it had under its old
       name, the readout says "click Save to choose the file", and the
       next Save asks where to write the NEW name (an autosave never
       opens a dialog). Junoview's own folder still renames outright. */
    function say(){
      fileHandles[nm]=null;
      if(fileFor===nm){fileHandle=null;fileName='';}
      idbDel(HKEY).catch(function(){});lsDel(HNKEY);
      idbDel(HKEYD+nm).catch(function(){});   /* T598 */
      deckMetaSet(nm,{file:null});
      if(saveTarget==='file') fileWaits='pick';
      renderTargetBtn();renderSaveBtn();status();
      toast('Renamed to \u201c'+nm+'\u201d. '+oldFile+' keeps the old '
        +'name \u2014 press Save once and it asks where to write '
        +newName+'; every autosave after that goes there.',10000);
      return false;
    }
    function moveOrSay(){
      if(typeof h.move!=='function') return say();
      return h.move(newName).then(function(){
        fileName=h.name||newName;
        renderTargetBtn();renderSaveBtn();status();
        toast('The file is '+fileName+' now');
        return true;
      }).catch(function(){return say();});
    }
    if(!deckDir) return moveOrSay();
    return deckDir.getFileHandle(oldFile).then(function(oh){
      return (h.isSameEntry?h.isSameEntry(oh):Promise.resolve(false));
    }).then(function(same){
      if(!same) return moveOrSay();
      return permOK(deckDir).then(function(ok){
        if(!ok) return say();
        /* ours: write the new file, then drop the old */
        bindFile(nm,null);
        return saveToFile(true).then(function(wrote){
          if(!wrote) return false;
          return deckDir.removeEntry(oldFile).catch(function(){})
            .then(function(){toast('The file is '+fileName+' now');
              return true;});
        });
      });
    }).catch(function(){return moveOrSay();});
  }
  menuAction('#mi-del',function(){
    /* T483: the same question the library asks before it deletes */
    var nm=pres.name;
    askDeleteDeck(nm,function(){deletePresByName(nm);});
  });
  /* T527: the one "delete a presentation" question, for the File menu,
     the library and the open list alike */
  function askDeleteDeck(nm,go){
    askYes({title:'Delete \u201c'+nm+'\u201d?',
      what:'This cannot be undone.',
      ok:'Delete presentation',cancel:'Keep it',danger:true},function(y){
      if(y===true) go();});
  }

  /* ---- FIND AND REPLACE ------------------------------------------------
     Searches the MODEL, not the rendered page: every text box, list item,
     slide title and subtitle on every slide, whether or not that slide is
     the one on screen. A browser find can only ever see the one slide
     that is rendered, which for a deck is the wrong answer almost all of
     the time (2026-08-20, user: "needs to be a search and replace of text
     and stuff, that is pretty standard").
     A placed notebook card is deliberately NOT searchable: its words
     belong to the notebook, and rewriting them here would put the slide
     and its source out of step with no way to tell. */
  (function(){
    var pop=$('#find-pop');
    if(!pop) return;
    var qi=$('#find-q'),ri=$('#find-r'),listEl=$('#find-list');
    var cntEl=$('#find-count'),ckCase=$('#find-case'),ckWord=$('#find-word');
    var hits=[],at=-1;
    /* every writable string in the deck, as {si, idx, get, set, label} */
    function fields(){
      var out=[];
      (pres.slides||[]).forEach(function(s,si){
        if(s.layout==='title'){
          out.push({si:si,idx:'t',label:'Title',
            get:function(){return s.title||'';},
            set:function(v){s.title=v;}});
          out.push({si:si,idx:'s',label:'Subtitle',
            get:function(){return s.sub||'';},
            set:function(v){s.sub=v;}});
        }
        (s.annots||[]).forEach(function(a,i){
          if(!a) return;
          if(a.k==='table'){
            /* A table is many independent strings, not one blob: a hit
               names the exact cell, selects its table on arrival, and a
               replacement cannot spill across a cell boundary. */
            tableNormalise(a);
            a.rows.forEach(function(row,r){
              row.forEach(function(_,c){
                out.push({si:si,idx:i,label:itemLabel(s,i)+' · row '
                  +(r+1)+', column '+(c+1),
                  get:function(){
                    var v=a.rows[r][c];
                    return v==null?'':String(v);
                  },
                  set:function(v){a.rows[r][c]=v;}});
              });
            });
            return;
          }
          if(a.k!=='text') return;
          out.push({si:si,idx:i,label:itemLabel(s,i),
            get:function(){return a.text||'';},
            set:function(v){
              a.text=v;
              /* rich markup cannot survive a plain-text substitution
                 without a mapping from characters to runs, so a replaced
                 box drops back to plain text — and says so in the toast
                 rather than silently losing a colour */
              if(a.html){delete a.html;
                if(listOf(a)) setListStyle(a,listOf(a));}
            }});
        });
      });
      return out;
    }
    function rx(){
      var q=qi.value;
      if(!q) return null;
      var esc2=q.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
      if(ckWord.checked) esc2='\\b'+esc2+'\\b';
      try{return new RegExp(esc2,ckCase.checked?'g':'gi');}
      catch(e){return null;}
    }
    function scan(){
      hits=[];
      var re=rx();
      if(re) fields().forEach(function(f){
        var txt=f.get(),m;re.lastIndex=0;
        while((m=re.exec(txt))){
          hits.push({f:f,start:m.index,len:m[0].length});
          if(!m[0].length) re.lastIndex++;   /* never loop on an empty match */
        }
      });
      if(at>=hits.length) at=hits.length-1;
      render();
    }
    function preview(h){
      var t=h.f.get();
      var a=Math.max(0,h.start-24),b=Math.min(t.length,h.start+h.len+24);
      var frag=document.createDocumentFragment();
      if(a>0) frag.appendChild(document.createTextNode('…'));
      frag.appendChild(document.createTextNode(t.slice(a,h.start)));
      var mk=document.createElement('mark');
      mk.textContent=t.substr(h.start,h.len);
      frag.appendChild(mk);
      frag.appendChild(document.createTextNode(t.slice(h.start+h.len,b)));
      if(b<t.length) frag.appendChild(document.createTextNode('…'));
      return frag;
    }
    function render(){
      cntEl.textContent=hits.length
        ?((at>=0?at+1:1)+' of '+hits.length)
        :(qi.value?'no matches':'');
      listEl.innerHTML='';
      hits.slice(0,120).forEach(function(h,k){
        var b=document.createElement('button');
        b.className='find-hit'+(k===at?' cur':'');
        var n=document.createElement('span');n.className='fh-n';
        n.textContent=(h.f.si+1)+' · '+h.f.label;
        b.appendChild(n);b.appendChild(preview(h));
        b.addEventListener('click',function(){at=k;goHit();});
        listEl.appendChild(b);
      });
      if(hits.length>120){
        var more=document.createElement('div');
        more.className='selpane-empty';
        more.textContent='…and '+(hits.length-120)+' more';
        listEl.appendChild(more);
      }
    }
    /* land on the hit: go to its slide and select the item, so you can SEE
       what you are about to change */
    function goHit(){
      var h=hits[at]; if(!h) return;
      if(cur!==h.f.si){cur=h.f.si;refresh();}
      var l=stage.querySelector('.annot-layer');
      if(l) selectAnnot(l,h.f.idx);
      render();
    }
    function step(d){
      if(!hits.length) return;
      at=(at+d+hits.length)%hits.length;
      goHit();
    }
    function replaceOne(){
      var h=hits[at]||hits[0]; if(!h) return;
      var t=h.f.get();
      h.f.set(t.slice(0,h.start)+ri.value+t.slice(h.start+h.len));
      markDirty();refresh();scan();
      toast('Replaced 1');
    }
    function replaceAll(){
      var re=rx(); if(!re) return;
      var n=0;
      fields().forEach(function(f){
        var t=f.get();re.lastIndex=0;
        if(!re.test(t)) return;
        re.lastIndex=0;
        f.set(t.replace(re,function(m){n++;return ri.value;}));
      });
      if(!n){toast('Nothing to replace');return;}
      markDirty();refresh();scan();
      toast('Replaced '+n+(n===1?' match':' matches'));
    }
    /* ---- FIND & REPLACE: FORMATTING ------------------------------
       Text replace above answers "every 'SST' becomes 'sea surface
       temperature'". This answers "every 18pt Georgia heading becomes
       20pt Inter" — the sweep you need when a deck has to change face,
       and the one that otherwise costs an afternoon of clicking
       (TASKS T6).

       FIND is T5's criteria table, used and not duplicated: the ticked
       rows AND together, and every one of them is read off the object
       you have SELECTED. Describing a look in the abstract is a form
       nobody fills in correctly — picking an example of it is one
       click, and it is the same gesture T5 already taught.

       CHANGE is a short list of fields, not a whole look. Copying a
       whole look onto everything of a type is the Apply dialog's job
       and it already does it well; this is the surgical one — change
       exactly these fields, on exactly the things that answer this
       description, and leave the rest alone. Nothing here writes
       a.style, for the reason the Apply dialog gives: re-tagging a box
       changes what it IS, not how it looks. */
    var FMT_CHANGES=[
      /* key, label, kinds it means anything for, write(a,v) */
      ['font','Typeface','text',function(a,v){
        if(v) a.font=v; else delete a.font;}],
      ['size','Text size','text table',function(a,v){a.size=v/5.4;}],
      ['color','Colour','text arrow rect draw',function(a,v){
        a.color=v;}]
    ];
    var fmtPanel=$('#find-fmt'),mode='text',fmtBuiltFor=null;
    function fmtRef(){
      var s2=pres.slides[cur];
      /* The ribbon and every inspector describe the PRIMARY selection.
         In a multi-selection, clicking another selected member changes
         selAnnot without reordering selSet, so selSet's last index can
         point at a different object from the one the user just chose. */
      return (s2&&typeof selAnnot==='number')
        ?((s2.annots||[])[selAnnot]||null):null;
    }
    /* WHICH OBJECTS A SWEEP TOUCHES — and it is NOT annotsBy's rule.
       annotsBy answers "what can I select", so it leaves out hidden
       items: you cannot select what is not on the page. A sweep is a
       different question. `hide` means "hidden while EDITING, still
       shown when presenting", so an item skipped here would keep the
       old face through the whole talk — the exact failure the sweep
       exists to prevent. Fully locked items are still out: a lock is an
       explicit "not this one". */
    function sweep(crit,scope){
      var out=[];
      var ids=(scope==='deck')
        ?(pres.slides||[]).map(function(_,i){return i;}):[cur];
      ids.forEach(function(i){
        var sl=(pres.slides||[])[i]; if(!sl) return;
        (sl.annots||[]).forEach(function(a,j){
          if(!a||lockedAll(a)) return;
          if(critsMatch(a,crit)) out.push({si:i,i:j,a:a});
        });
      });
      return out;
    }
    function fmtBuild(){
      if(!fmtPanel) return;
      fmtPanel.innerHTML='';
      var ref=fmtRef();
      fmtBuiltFor=ref;
      if(!ref){
        var p0=document.createElement('div');
        p0.className='ff-none';
        p0.textContent='Select an object on the page first \u2014 this '
          +'half describes what to find BY EXAMPLE, the same way '
          +'"select everything like this" does.';
        fmtPanel.appendChild(p0);
        return;
      }
      function head(t){menuHead(fmtPanel,t);}
      function ck(label,on){
        var l=document.createElement('label');
        l.className='find-ck';
        var b=document.createElement('input');
        b.type='checkbox';b.checked=!!on;
        l.appendChild(b);
        l.appendChild(document.createTextNode(' '+label));
        return {el:l,box:b};
      }
      /* ---- what to find ---- */
      head('find objects that are');
      var crits=[];
      SELECT_CRIT.forEach(function(c,n){
        var v=c[1](ref);
        if(v==null) return;
        /* the FIRST row (the type) starts ticked: on its own it is
           already a useful sweep, and a dialog that starts matching
           nothing reads as broken */
        var r=ck(c[2](v,ref),crits.length===0);
        crits.push({key:c[0],val:v,box:r.box});
        fmtPanel.appendChild(r.el);
        r.box.addEventListener('change',recount);
      });
      /* ---- what to change ---- */
      head('and change');
      var chs=[];
      FMT_CHANGES.forEach(function(c){
        var row=document.createElement('div');row.className='ff-row';
        var r=ck(c[1],false);
        row.appendChild(r.el);
        var inp;
        if(c[0]==='font'){
          inp=document.createElement('select');
          var o0=document.createElement('option');
          o0.value='';o0.textContent='(default)';inp.appendChild(o0);
          FONTS.forEach(function(fo){
            var o=document.createElement('option');
            o.value=fo.id;o.textContent=fo.label;inp.appendChild(o);});
          inp.value=ref.font||'';
        } else if(c[0]==='size'){
          inp=document.createElement('input');
          inp.type='number';inp.min='6';inp.max='240';
          inp.value=String(Math.round((ref.size||2.6)*5.4));
        } else {
          inp=document.createElement('input');
          inp.type='color';
          inp.value=/^#[0-9a-f]{6}$/i.test(ref.color||'')
            ?ref.color:'#ffffff';
        }
        inp.className='ff-in';
        row.appendChild(inp);
        fmtPanel.appendChild(row);
        chs.push({key:c[0],kinds:c[2],write:c[3],box:r.box,inp:inp});
        r.box.addEventListener('change',recount);
      });
      /* ---- over what ---- */
      head('over');
      var scope=document.createElement('select');
      scope.className='ff-in';scope.style.width='100%';
      [['deck','The whole deck'],['slide','This slide only']]
        .forEach(function(o){
          var e=document.createElement('option');
          e.value=o[0];e.textContent=o[1];scope.appendChild(e);});
      scope.addEventListener('change',recount);
      fmtPanel.appendChild(scope);
      /* ---- the count, and the button ---- */
      var foot=document.createElement('div');foot.className='find-foot';
      var cnt=document.createElement('span');cnt.className='find-count';
      foot.appendChild(cnt);
      var spring=document.createElement('span');
      spring.className='deck-spring';foot.appendChild(spring);
      var go=document.createElement('button');
      go.className='dbtn';go.textContent='Change them';
      foot.appendChild(go);
      fmtPanel.appendChild(foot);
      function picked(){
        return crits.filter(function(c){return c.box.checked;})
          .map(function(c){return {key:c.key,val:c.val};});
      }
      function edits(){
        return chs.filter(function(c){return c.box.checked;});
      }
      function recount(){
        var crit=picked();
        var hitn=crit.length?sweep(crit,scope.value):[];
        var sl={};hitn.forEach(function(h){sl[h.si]=1;});
        var ns=Object.keys(sl).length;
        cnt.textContent=!crit.length
          ?'tick what to find'
          :hitn.length
            ?(hitn.length+' object'+(hitn.length===1?'':'s')
              +' on '+ns+' slide'+(ns===1?'':'s'))
            :'nothing matches';
        go.disabled=!hitn.length||!edits().length;
      }
      go.addEventListener('click',function(){
        var crit=picked(),ed=edits();
        if(!crit.length||!ed.length) return;
        var hitn=sweep(crit,scope.value);
        var n=0;
        hitn.forEach(function(h){
          var did=false;
          ed.forEach(function(c){
            /* a field that means nothing for this kind is not written:
               a `size` on a shape would be a junk key that every export
               then has to ignore */
            if(c.kinds.indexOf(h.a.k)<0) return;
            var v=(c.key==='size')?(+c.inp.value||0):c.inp.value;
            if(c.key==='size'&&!(v>0)) return;
            c.write(h.a,v);did=true;
          });
          if(did) n++;
        });
        if(!n){toast('Nothing to change \u2014 those fields mean '
          +'nothing for what you matched');return;}
        markDirty();refresh();
        toast('Changed '+n+' object'+(n===1?'':'s'));
        fmtBuild();
      });
      recount();
    }
    /* showFmt runs for every real selection change, but also for hover
       previews and continuous gestures that reselect the SAME object.
       Rebuilding for those would erase the criteria and edits a person
       has already ticked into this non-modal popover. */
    function fmtSync(){
      if(pop.hidden||mode!=='fmt') return;
      if(fmtRef()===fmtBuiltFor) return;
      fmtBuild();
    }
    function setMode(m){
      mode=m;
      $$('#find-pop [data-fmode]').forEach(function(el){
        el.hidden=(el.getAttribute('data-fmode')!==m);});
      if(fmtPanel) fmtPanel.hidden=(m!=='fmt');
      var bt=$('#find-m-text'),bf=$('#find-m-fmt');
      if(bt){bt.classList.toggle('on',m==='text');
        bt.setAttribute('aria-selected',String(m==='text'));}
      if(bf){bf.classList.toggle('on',m==='fmt');
        bf.setAttribute('aria-selected',String(m==='fmt'));}
      if(m==='fmt') fmtBuild();
    }
    (function(){
      var bt=$('#find-m-text'),bf=$('#find-m-fmt');
      if(bt) bt.addEventListener('click',function(){setMode('text');});
      if(bf) bf.addEventListener('click',function(){setMode('fmt');});
    })();
    function open(){
      /* T482: on the overlay owner's stack, so a top-bar menu closes it
         rather than opening underneath it (2026-09-15 review) */
      if(typeof overlayShow==='function') overlayShow($('#qat-find'),pop);
      pop.hidden=false;
      /* a re-open re-reads the selection: the whole find half is
         seeded by example, and a stale example is worse than none */
      if(mode==='fmt') fmtBuild();
      /* seed from whatever text box you had selected — the thing you were
         looking at is usually the thing you want to find */
      qi.focus();qi.select();
      scan();
    }
    function close(){
      if(typeof overlayHide==='function') overlayHide(pop);
      pop.hidden=true;at=-1;}
    [qi,ri].forEach(function(el){
      el.addEventListener('keydown',function(e){
        e.stopPropagation();
        if(e.key==='Enter'){e.preventDefault();
          if(el===ri) replaceOne(); else step(e.shiftKey?-1:1);}
        else if(e.key==='Escape'){e.preventDefault();close();}
      });
    });
    qi.addEventListener('input',function(){at=-1;scan();});
    [ckCase,ckWord].forEach(function(c){
      c.addEventListener('change',function(){at=-1;scan();});});
    $('#find-next').addEventListener('click',function(){step(1);});
    $('#find-prev').addEventListener('click',function(){step(-1);});
    $('#find-rep').addEventListener('click',replaceOne);
    $('#find-repall').addEventListener('click',replaceAll);
    $('#find-close').addEventListener('click',close);
    /* ONE door: the top bar (or Ctrl+F). The ribbon copy is gone */
    ['#qat-find'].forEach(function(sel){
      var b=$(sel);
      if(b) b.addEventListener('click',function(){
        if(pop.hidden) open(); else close();});
    });
    window.SemDeckFind=open;       /* the Ctrl+F binding, below */
    window.SemDeckFindSync=fmtSync;/* selection bridge from showFmt */
  })();

  /* ---------- tabs opened / closed while the page lives ---------- */
  /* T440: THE NOTEBOOK DOORS GREY OUT WITHOUT A NOTEBOOK (2026-09-14,
     user: "calling the 'notebook cell' figures is confusing. It should
     be 'from notebook', and be greyed out if there are no notebooks
     that are open"). The Insert button and the flip book's "+ Figures"
     both pick from an open notebook's cards; with none open they led
     to an empty picker. The title says what to do instead. */
  function nbDoorsSync(){
    var open=!!(APP.order&&APP.order.length);
    [['#et-cell','Draw a frame, then pick a figure from a notebook to '
        +'fill it \u2014 or a picture from this computer, the clipboard, '
        +'or a path'],
     ['#fp-add-cells','Pick figures from your notebook \u2014 click as '
        +'many as you want, in order'],
     ['#fmt-figures','Pick figures from a notebook \u2014 click as many '
        +'as you want, in order \u2014 and each becomes a page of this '
        +'book']].forEach(function(d){
      var b=$(d[0]); if(!b) return;
      b.disabled=!open;
      b.title=open?d[1]:('Open a notebook first \u2014 this places its '
        +'figures, tables and notes');
    });
  }
  document.addEventListener('sem:shell',function(e){
    if(typeof storyInvalidate==='function') storyInvalidate();
    nbDoorsSync();
    if(e.detail.replaced){
      /* the notebook was reloaded: what every frame showed until now
         becomes the "previous figure" it can revert to */
      var pfx=e.detail.stem+'::';
      Object.keys(frameSnaps).forEach(function(k){
        if(k.indexOf(pfx)===0){
          frameSnapsPrev[k]=frameSnaps[k];delete frameSnaps[k];}
      });
    }
    /* invalidation point 1 (see frameNodeCache): the notebook's cards
       changed (reload) or just became the live source (fresh open) —
       cached frame nodes for this stem must rebuild, which also refills
       frameSnaps for the next revert */
    dropFrameCache(e.detail.stem);
    /* T306: a reload can add or remove figures, and a close ends
       the card list entirely, so the ordinal the Images rows quote
       has to be recomputed with the frames */
    if(typeof figOrderMemo!=='undefined') delete figOrderMemo[e.detail.stem];
    registerShell(e.detail.stem,e.detail.data||{});
    if(source==='auto'&&(!pres.slides||!pres.slides.length))
      pres=defaultPres();
    if(!deckEl.hidden) refresh();
    else renderPresTabs();
  });
  document.addEventListener('sem:shellclosed',function(e){
    if(typeof storyInvalidate==='function') storyInvalidate();
    nbDoorsSync();
    /* invalidation point 2: frames fall back to the embedded copy */
    dropFrameCache(e.detail.stem);
    /* T306: a reload can add or remove figures, and a close ends
       the card list entirely, so the ordinal the Images rows quote
       has to be recomputed with the frames */
    if(typeof figOrderMemo!=='undefined') delete figOrderMemo[e.detail.stem];
    unregisterShell(e.detail.stem);
    if(!deckEl.hidden) refresh();
    else renderPresTabs();
  });

  /* embedded card snapshots from earlier sessions (IndexedDB, per scope):
     without this, a deck imported from a self-contained file kept its
     figures only until the tab closed — the drafts it left behind are
     refs-only by design, so the next session opened to empty frames. A
     copy absorbed THIS session is fresher and is never overwritten. */
  idbGet('emb:'+SCOPE).then(function(m){
    if(!m||typeof m!=='object') return;
    var added=0;
    Object.keys(m).forEach(function(k){
      var e=m[k];
      if(EMBED[k]||!e||typeof e.html!=='string'||!e.html) return;
      embStore(k,e);added++;
    });
    if(!added) return;
    if(!deckEl.hidden) refresh(); else renderPresTabs();
  }).catch(function(){});
