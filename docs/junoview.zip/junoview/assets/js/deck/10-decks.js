/* 10-decks.js — every open notebook's cards, saved decks, drafts, undo and redo.
   ONE FRAGMENT of deck.js's single IIFE, concatenated with its
   siblings in filename order by assets.deck_js(). It does not
   parse alone and is not meant to: see 00-page.js. */
  /* ---------- registry: every open notebook's cards ----------
     Refs are namespaced "stem::anchor" so one deck can mix cards from
     every open tab; plain legacy anchors still resolve. */
  var ITEMS={};        /* ns -> item {..., nb, ns} */
  var SHELLITEMS={};   /* stem -> [ns, ...] in document order */
  var nbPres=[];       /* presentations embedded in notebooks (namespaced) */
  function nsKey(stem,anchor){return stem+'::'+anchor;}
  function splitRef(ref){
    var i=String(ref).indexOf('::');
    return i<0?[null,String(ref)]:[String(ref).slice(0,i),String(ref).slice(i+2)];
  }
  /* ---------- embedded snapshots: the deck's own copy of its cards ----
     A saved deck used to be refs only, so opening it without the source
     notebook (or without the internet to re-fetch one) showed empty
     frames. Saving now writes each placed card's rendered body into the
     file (`p.emb`, figures already data: URIs), and this store carries
     those copies at runtime. The live notebook ALWAYS wins — resolveRef
     tries ITEMS first — so an open tab still drives its frames, and the
     embedded copy is the understudy, not a fork. Kept OUT of the pres
     object on purpose: drafts are written to localStorage on every edit,
     and megabytes of figures there would hit the quota and silently kill
     autosave. IndexedDB holds them between sessions instead. */
  var EMBED={};          /* ns -> {title,kind,html,code} */
  var embItems={};       /* ns -> the virtual item resolveRef hands out */
  var embSaveT=null;
  /* the prepared-frame caches (see the invalidation essay above
     dropFrameCache). Declared HERE, not beside their functions,
     because embStore -- which dropFrameCache serves -- already runs
     during EVAL via `var projectPres=...map(normPres)` when a saved
     deck carries inline emb. On 2026-08-31 that path met the
     declarations sitting six hundred lines later: hoisted names,
     unassigned values, Object.keys(undefined), and the whole editor
     silently gone at boot (T133). Same trap 99-boot.js documents. */
  var frameNodeCache={};
  var snapNodeCache=new Map();      /* snapshot html -> {part: node} */
  var verNodeCache=new WeakMap();   /* version card -> {part: node} */
  /* cardEl's memo (2026-10-09), which dropFrameCache empties at once --
     so a closed or reloaded notebook's cards are never held after it.
     Declared here for the reason frameNodeCache is: normPres stores
     copies at eval time, through embStore and dropFrameCache, and a
     hoisted `undefined` has no clear(). (What a placed figure shows is
     counted by deckViewGen, which dropFrameCache bumps too.) */
  var cardElMemo=new Map();
  /* WHERE WHAT A FIGURE IS DRAWN FROM CHANGED (2026-10-09, speed).
     deckViewGen (below) counts every change to what a placed figure is
     drawn from; this keeps beside that count WHERE each one happened --
     one notebook (its stem: opened, reloaded, closed, a note added), one
     card (its ref: a copy stored or put back, a link made or cut) or
     everything -- so a row of the slide strip is drawn again only when
     one of ITS figures may have changed (refViewGen, filmRefGens in
     55-sections-and-strip.js). Without it the first figure placed on a
     slide, or a notebook reloaded under a deck that shows another's,
     redrew every row. Declared up here for cardElMemo's reason:
     dropFrameCache runs at eval time, and a hoisted `undefined` has no
     fields to write. */
  var viewGens={n:0,all:0,of:Object.create(null)};
  /* ---- THE SAVED DECKS' COPIES ARRIVE AFTER THE PAGE (2026-10-09) -----
     (owner: "if this is not able to load quick, and not be laggy, then no
     matter how good the features are no one will ever use this".) The
     app page carried every saved deck's `emb` inline in its boot JSON --
     10 MB for an 18-deck project, the same figure once per deck that
     shows it -- parsed, deep-copied and absorbed here before anything on
     screen could answer, and the cost grew with every deck you kept. The
     server now boots the decks lean and serves their copies, each one
     once, from /api/emb (server/state.py emb_payload); APP.project.lazyEmb
     says there is something to fetch.

     THE RULE THAT MAKES IT SAFE: NOTHING READS OR WRITES A COPY BEFORE
     THEY ARE HERE. Every reader goes through embKey, which calls
     embEnsure() -- free once they have arrived, and before that a
     same-origin synchronous fetch, so a deck opened in the first second
     renders, captures and saves exactly as it did when the copies were
     inline. The ordinary path is the idle fetch (embFetch, from THE
     BOOT SEQUENCE), and nothing waits for it. Only the boot itself is
     exempt (embBootDone), because normPres runs over the lean decks
     there and fetching then would put the cost right back.
     Order is kept too: the project's copies used to be absorbed first
     (at eval), so a copy absorbed before they arrive -- a notebook's own
     deck, a file opened at boot -- is WEAK and gives way to the
     project's, while anything you did yourself since boot is fresher and
     stays (T305). IndexedDB's copies come after both, as before. */
  var embLazy=!!(APP.mode==='app'&&APP.project&&APP.project.lazyEmb);
  var embLoaded=!embLazy;      /* the project's copies are in EMBED */
  var embBootDone=false;       /* set by THE BOOT SEQUENCE */
  var embAsync=null,embFailedAt=0,embSyncN=0;
  var embMissed=false;         /* a reader went without during the boot */
  /* the clips on the slide on screen that have their bytes to play */
  function embClipsShown(){
    var s=(typeof pres!=='undefined'&&pres&&pres.slides)?pres.slides[cur]:null;
    if(!s||typeof mediaStore!=='function') return 0;
    var n=0,st=mediaStore();
    (s.annots||[]).forEach(function(a){
      if(a&&a.k==='video'&&a.vkey&&st[a.vkey]&&st[a.vkey].src) n++;});
    if(s.narr&&s.narr.vkey&&st[s.narr.vkey]&&st[s.narr.vkey].src) n++;
    return n;
  }
  var embWeak={};              /* keys absorbed before the project's */
  /* what the project file is KNOWN to hold, per deck: {ref: copy} and
     {vkey: 1}. Read off /api/emb, kept current by every embedded save,
     and what the idle consolidation asks before re-sending a deck
     (embNeedsSend). A name with no entry is one the file holds no
     copies for -- a project with none, or a deck it has not seen. */
  var embHeld={},embHeldClips={};
  var embSettle=null,embSettled=new Promise(function(r){embSettle=r;});
  if(embLoaded) embSettle(true);
  /* the IndexedDB copies have been read back (or there were none): the
     whole-store write in embSaveSoon waits for this, so a write made
     before the read cannot replace the stored set with a smaller one */
  var embIdbSettle=null,embIdbDone=new Promise(function(r){embIdbSettle=r;});
  function embApply(j){
    if(embLoaded) return;
    var snaps=(j&&j.snaps)||[],clips=(j&&j.clips)||[];
    ((j&&j.decks)||[]).forEach(function(d){
      if(!d||!d.name) return;
      var p={name:d.name,emb:{},media:{}},held={},heldC={};
      Object.keys(d.emb||{}).forEach(function(r){
        var s=snaps[d.emb[r]];
        if(s&&typeof s.html==='string'&&s.html){p.emb[r]=s;held[r]=s;}
      });
      Object.keys(d.media||{}).forEach(function(k){
        var c=clips[d.media[k]];
        if(c&&typeof c.src==='string'&&c.src){p.media[k]=c;heldC[k]=1;}
      });
      embHeld[d.name]=held;embHeldClips[d.name]=heldC;
      /* the key the eval-time absorb used: ITEMS was still empty then,
         so a namespaced ref is itself and a plain one finds its
         namespace among the copies absorbed before it */
      Object.keys(p.emb).forEach(function(k){
        var e=p.emb[k],key=embKeyRaw(k)||k;
        if(EMBED[key]&&EMBED[key].html&&!embWeak[key]) return;
        embPut(key,e);
      });
      if(typeof mediaAbsorb==='function') mediaAbsorb(p);
    });
    embLoaded=true;embWeak={};
    embSettle(true);
    embSaveSoon();
  }
  function embUrl(){
    return '/api/emb?t='+encodeURIComponent(APP.token||'');
  }
  /* the idle fetch (THE BOOT SEQUENCE schedules it) */
  function embFetch(){
    if(embLoaded) return Promise.resolve(true);
    if(embAsync) return embAsync;
    embAsync=APP.api('/api/emb').then(function(j){
      var was=embLoaded,clips=embClipsShown();
      embApply(j);
      /* whatever was drawn before they came (only the boot itself can
         draw a figure without asking; a clip's player never asks) is
         drawn again from the kept copies -- and ONLY that: a redraw
         throws the caret out of a box being typed in, and the words
         typed after it went nowhere. A box being typed in redraws
         itself on its blur. */
      if(!was&&(embMissed||embClipsShown()>clips)) embRedraw();
      return true;
    }).catch(function(){
      if(embLoaded) return true;
      embFailedAt=Date.now();embSettle(false);
      return false;
    }).then(function(ok){embAsync=null;return ok;});
    return embAsync;
  }
  function embRedraw(){
    if(typeof deckEl==='undefined'||!deckEl||deckEl.hidden
       ||typeof refresh!=='function') return;
    var ae=document.activeElement;
    if(ae&&ae.isContentEditable&&deckEl.contains(ae)){
      ae.addEventListener('blur',function(){setTimeout(embRedraw,0);},
        {once:true});
      return;
    }
    refresh();
  }
  /* the synchronous door, for a reader that cannot wait. Never during
     the boot, and not again within five seconds of a failure. */
  function embEnsure(){
    if(embLoaded) return true;
    if(!embBootDone){embMissed=true;return false;}
    /* a reader refused here draws without its copies, so the idle
       arrival has to redraw (embFetch) */
    if(embFailedAt&&Date.now()-embFailedAt<5000){embMissed=true;return false;}
    try{
      var x=new XMLHttpRequest();
      x.open('GET',embUrl(),false);
      x.send(null);
      if(x.status!==200) throw new Error('HTTP '+x.status);
      embSyncN++;
      embApply(JSON.parse(x.responseText));
      return true;
    }catch(e){
      embFailedAt=Date.now();embSettle(false);embMissed=true;
      return false;
    }
  }
  function embKey(ref){
    if(!embLoaded) embEnsure();
    return embKeyRaw(ref);
  }
  function embKeyRaw(ref){
    if(!ref) return null;
    if(EMBED[ref]) return ref;
    /* plain legacy anchor: find it under any namespace, like resolveRef */
    if(String(ref).indexOf('::')>=0) return null;
    var suf='::'+ref,ks=Object.keys(EMBED);
    for(var i=0;i<ks.length;i++)
      if(ks[i].slice(-suf.length)===suf) return ks[i];
    return null;
  }
  function embFor(ref){var k=embKey(ref);return k?EMBED[k]:null;}
  function embItem(ref){
    var k=embKey(ref); if(!k) return null;
    if(!embItems[k]){
      var e=EMBED[k],pr=splitRef(k);
      embItems[k]={title:e.title||'',kind:e.kind||'note',
        hasCode:!!e.code,nb:pr[0]||'',anchor:pr[1],ns:k,emb:true};
    }
    return embItems[k];
  }
  /* the parsed body node, cached — cellFacets asks often */
  function embBody(ref){
    var e=embFor(ref); if(!e||!e.html) return null;
    if(!e._node){
      var t=document.createElement('template');t.innerHTML=e.html;
      e._node=t.content.firstElementChild||null;
    }
    return e._node;
  }
  /* T301: WHAT THE REFRESH IS ABOUT TO DESTROY, KEPT FOR ONE STEP.
     This store has one slot per ref and no history, and nothing else in
     the deck can put a figure back: histState (the undo snapshot) does
     not carry EMBED, so Ctrl+Z cannot recover one -- and worse, a
     resync changes nothing inside `pres`, so histPush's `st===histSnap`
     early return means NO undo entry is pushed at all and Ctrl+Z
     silently rewinds whatever slide edit came before. The version
     timeline is refs-only for the same reason. Until today the only
     recovery was reloading the page before the 20-second autosave wrote
     the bad copy over the good one on disk, which is an accident rather
     than a feature -- and T297 made that window shorter, not longer, by
     persisting every capture.

     One step deep, in memory, per ref. Not a history: the thing being
     answered is "I have lost too many things" (2026-09-05), and the
     answer to that is the click you just made, taken back. */
  var EMBPREV={};
  function embStore(key,e){
    delete embWeak[key];   /* written on purpose: fresher than the file's */
    /* T-speed (2026-10-09): THE SAME COPY AGAIN IS NOT A NEW COPY. Every
       embedded save re-stores what it just read, and each store threw
       away the parsed body, the virtual item and every frame built from
       it -- so the first slide change after each save re-parsed and
       re-decoded its figures (+100-180 ms at 4x). Same four fields, same
       entry: keep it. */
    var was=EMBED[key];
    if(was&&was.html===String(e.html||'')
       &&was.code===(typeof e.code==='string'?e.code:'')
       &&was.title===String(e.title||'')&&was.kind===String(e.kind||''))
      return;
    /* a write that changes nothing is not a step to undo: embedAssets
       re-stores what it just read on every deliberate save, and each of
       those would otherwise overwrite the one slot that holds the copy
       a real refresh replaced */
    if(EMBED[key]&&EMBED[key].html
       &&!sameCardHtml(EMBED[key].html,String(e.html||'')))
      EMBPREV[key]={title:EMBED[key].title,kind:EMBED[key].kind,
        html:EMBED[key].html,code:EMBED[key].code||''};
    embPut(key,e);
  }
  /* the store itself, with no step to undo: what embStore does after
     its EMBPREV bookkeeping, and how the project's copies take the place
     of a weak one (embApply) -- which the boot order used to do by
     absorbing them first, and which was never a step either */
  function embPut(key,e){
    delete embWeak[key];
    EMBED[key]={title:String(e.title||''),kind:String(e.kind||''),
      html:String(e.html||''),code:typeof e.code==='string'?e.code:''};
    delete embItems[key];
    /* invalidation point 3 (see frameNodeCache): a frame rendered from
       the OLD embedded copy of this ref must rebuild from the new one */
    dropFrameCache(key);
  }
  /* the other half: put back what the named refs replaced. Returns
     {n, unlinked} -- how many actually had something to go back to, so
     a caller can say nothing rather than claim a restore it did not
     make, and how many stopped being live links on the way.

     THE UNLINKING IS THE POINT, not a side effect. "Put it back" is a
     promise about what you SEE, and a live link renders from the
     notebook -- so restoring the snapshot under one changed the store
     and nothing on the screen, and the toast said it had worked. Found
     by driving it: a 74,606-character figure was replaced by a 122-
     character one, "Put them back" reported success, and the wrong
     figure stayed on the slide. Undo and "always show me the notebook's
     current version" are in direct conflict; the click just made is the
     more explicit of the two, and the caller says so. */
  function embRestore(keys){
    var n=0,unlinked=0;
    (keys||Object.keys(EMBPREV)).forEach(function(k){
      var p=EMBPREV[k]; if(!p||!p.html) return;
      delete embWeak[k];
      EMBED[k]={title:p.title,kind:p.kind,html:p.html,code:p.code||''};
      delete embItems[k];
      if(refIsLive(k)){setRefLive(k,0);unlinked++;}
      dropFrameCache(k);
      delete EMBPREV[k];
      n++;
    });
    if(n){
      embSaveSoon();
      var l=stage.querySelector('.annot-layer');
      if(l&&pres.slides[cur]) renderAnnots(l,pres.slides[cur]);
      markDirty();
    }
    return {n:n,unlinked:unlinked};
  }
  function embSaveSoon(){
    clearTimeout(embSaveT);
    embSaveT=setTimeout(function(){
      /* the whole store replaces the stored one, so it waits until the
         stored one has been read back into it (embRehydrate) -- and,
         through that, until the project's copies are in too */
      embIdbDone.then(function(){
        /* plain copies only — the cached _node is a DOM element and
           would make the structured clone throw */
        var plain={};
        Object.keys(EMBED).forEach(function(k){
          var e=EMBED[k];
          plain[k]={title:e.title,kind:e.kind,html:e.html,code:e.code||''};
        });
        idbPut('emb:'+SCOPE,plain).catch(function(){});
      });
    },1000);
  }
  function resolveRef(ref){
    if(!ref) return null;
    if(ITEMS[ref]) return ITEMS[ref];
    if(String(ref).indexOf('::')>=0) return embItem(ref);
    for(var s=0;s<APP.order.length;s++){
      var k=nsKey(APP.order[s],ref);
      if(ITEMS[k]) return ITEMS[k];
    }
    return embItem(ref);
  }
  function normRef(ref){
    if(!ref) return null;
    var it=resolveRef(ref);
    return it?it.ns:String(ref);
  }
  /* normPres runs while projectPres is initialised, before the style
     registry fragment's var initialisers. Keep the built-in ids here so
     a saved deck with custom types can be normalised without reaching an
     as-yet undefined BUILTIN_STYLE_IDS (and keep one canonical list). */
  var BUILTIN_STYLE_IDS=[
    'title','subtitle','h1','h2','h3','body','small','caption'];
  function normPres(p,stem){
    /* deep-copy a presentation, namespacing plain anchors (against
       `stem` when it came from one notebook, else best-effort);
       folder, title-slide text and free annotations ride along.
       Legacy grid-pane slides convert to preset cell-frame layouts. */
    /* A CUSTOM VIEW has no slides to normalise — and it must keep kind /
       nb / style / view or it comes back as a plain deck and clicking its
       row opens the slide editor instead (that was the bug where a custom
       view "took you to the presentation below it"). */
    /* T606: a collection is cells and notes, not slides (64-collections) */
    if(p&&p.kind==='collection') return colNorm(p,stem);
    if(p&&p.kind==='view'){
      var v={name:String(p.name||'view'),kind:'view',slides:[],
        nb:typeof p.nb==='string'?p.nb:'',
        style:p.style?deep(p.style):{},
        view:p.view?deep(p.view):{}};
      if(typeof p.folder==='string'&&p.folder) v.folder=p.folder;
      return v;
    }
    function ns(a){
      if(!a) return null;
      if(String(a).indexOf('::')>=0) return a;
      return stem?nsKey(stem,a):(normRef(a)||a);
    }
    var out={name:String(p.name||'presentation'),
      slides:(p.slides||[]).map(function(s){
        var o={layout:s.layout,
          panes:(s.panes||[]).map(ns)};
        /* Applying a template turns the old pane skeleton into free
           annotations (`layout: blank`). `lay` is the template id the
           gallery needs to keep its applied card selected after reload. */
        if(typeof s.lay==='string'&&s.lay) o.lay=s.lay;
        /* the name you gave a poster version. Not carrying it here meant
           it survived until the next load and then silently became
           "empty slide" again (2026-08-10) */
        if(typeof s.label==='string'&&s.label) o.label=s.label;
        /* which section this slide sits in. The ORDER of the sections is
           not stored anywhere — it is read back off the slide list, which
           is why reordering slides can never desynchronise it
           (2026-08-22) */
        if(typeof s.sec==='string'&&s.sec) o.sec=s.sec;
        /* T601: the part this slide was copied from -- the section it
           came in with, whose link names the presentation */
        if(typeof s.lk==='string'&&s.lk) o.lk=s.lk;
        /* optional, and which named cuts this slide is in. Membership
           lives on the SLIDE so it survives every splice and drag for
           free — the same argument s.sec makes above (T24). */
        if(s.opt) o.opt=1;
        /* T554: hidden -- in the deck, never played (PowerPoint's Hide
           Slide). Not the same as optional, which plays unless you are
           running late. */
        if(s.hide) o.hide=1;
        /* T318: which version group this slide belongs to -- the first
           of a contiguous run is the main, so nothing else is stored */
        if(typeof s.alt==='string'&&s.alt) o.alt=s.alt;
        /* how this slide ARRIVES. Per slide because that is how anyone
           thinks about it, and because a deck-wide setting cannot say
           "this one flies in from the last" (T27).
           '' IS AN ANSWER (T494): Cut inside a section that fades is
           stored as '' -- the override T57 made real -- and the
           truthiness test here dropped it on every reload, so the slide
           faded again and every readout said Fade. */
        if(typeof s.trans==='string') o.trans=s.trans;
        /* T553: how long it takes, in seconds; absent is its kind's own */
        if(+s.tdur>0) o.tdur=+s.tdur;
        if(Array.isArray(s.cuts)&&s.cuts.length)
          o.cuts=s.cuts.filter(function(c){
            return typeof c==='string'&&c;});
        /* per-slide look + pane organisation. A field not listed here
           silently dies on the next load — exactly what happened to
           `label` before it was added (2026-08-10) */
        if(typeof s.bg==='string'&&s.bg) o.bg=s.bg;
        /* speaker notes and the per-slide time goal: yours, never drawn
           on the page, and lost on every reload until they were
           whitelisted here (2026-08-20) */
        if(typeof s.notes==='string'&&s.notes) o.notes=s.notes;
        /* T563: comments, pinned to the slide or an object -- the working
           deck's, like the notes, and never drawn in the talk */
        if(Array.isArray(s.comments)){
          var cms=s.comments.filter(function(c){
            return c&&typeof c==='object'&&typeof c.text==='string'
              &&c.text;}).map(deep);
          if(cms.length) o.comments=cms;
        }
        if(typeof s.goal==='number'&&s.goal>0) o.goal=s.goal;
        /* T564: the slide's recorded narration -- a reference into the
           media store, the bytes riding in p.media like a clip's */
        if(s.narr&&typeof s.narr==='object'&&typeof s.narr.vkey==='string'
           &&s.narr.vkey){
          o.narr={vkey:s.narr.vkey};
          if(+s.narr.dur>0) o.narr.dur=+s.narr.dur;
        }
        /* the slide's durable name. Minted on first rehearsal, and the
           only reason a run made on Tuesday can be compared with one
           made on Friday after you reordered the deck (T29, 2026-08-25).
           The TIMES are not here on purpose -- they live beside the deck,
           because your rehearsal is not a property of the document. */
        if(typeof s.sid==='string'&&s.sid) o.sid=s.sid;
        if(s.border) o.border=deep(s.border);
        if(s.grpmeta) o.grpmeta=deep(s.grpmeta);
        /* which MASTER this slide wears (T115): a look it inherits
           live -- background + furniture -- resolved at render time,
           never stamped. Absent = none, which is every deck saved
           before masters existed, so there is no migration. */
        if(typeof s.mast==='string'&&s.mast) o.mast=s.mast;
        /* the authored reading order (T106): oids, first-to-last.
           Absent = automatic (top-to-bottom, left-to-right). Unlisted
           here it dies on the next load, like label before it. */
        if(Array.isArray(s.rord)&&s.rord.length){
          var ro=s.rord.filter(function(x){
            return typeof x==='string'&&x;});
          if(ro.length) o.rord=ro;
        }
        if(s.layout==='title'){
          o.title=String(s.title||'');o.sub=String(s.sub||'');
          if(s.tprops) o.tprops=deep(s.tprops);
          if(s.sprops) o.sprops=deep(s.sprops);
        }
        if(Array.isArray(s.annots)&&s.annots.length)
          o.annots=deep(s.annots);
        (o.annots||[]).forEach(function(a){
          if(a.k==='cell'&&a.ref) a.ref=ns(a.ref);
          /* a flip book's frames hold the same kind of ref, one per
             frame. Missing this line is not a subtle bug: the deck
             reloads with every frame blank. */
          if(a.k==='flip'&&Array.isArray(a.frames))
            a.frames.forEach(function(f){
              if(f&&f.ref) f.ref=ns(f.ref);});
        });
        /* steps hidden in the code trace (namespaced refs) */
        if(Array.isArray(s.hidden)&&s.hidden.length)
          o.hidden=s.hidden.map(ns).filter(Boolean);
        /* legacy pane layouts -> cell frames at the preset rects */
        if(o.layout!=='title'){
          if(PRESETS[o.layout]){
            var rects=PRESETS[o.layout];
            o.annots=o.annots||[];
            for(var i=0;i<rects.length;i++){
              o.annots.push({k:'cell',x:rects[i][0],y:rects[i][1],
                w:rects[i][2],h:rects[i][3],
                ref:o.panes[i]||null});
            }
          }
          o.layout='blank';
        }
        o.panes=[];
        return o;
      })};
    if(typeof p.folder==='string'&&p.folder) out.folder=p.folder;
    if(p.showNums) out.showNums=1;   /* keep the slide-numbers preference */
    if(p.tapzoom) out.tapzoom=1;     /* tap-to-enlarge, same rule */
    /* the code trail under the slide, switched off (T69). Same truthy
       -> 1 storage as the two flags above; suppression rather than an
       opt-in so an old deck keeps the trail it already had. */
    if(p.hideTrace) out.hideTrace=1;
    if(typeof p.page==='string'&&p.page) out.page=p.page;  /* page preset */
    /* the page background survives every load path — normPres dropping
       it turned saved white posters navy again (2026-08-05 review).
       T465: it survives as tokens.c.page, below, after the tokens
       object itself has been copied in. */
    /* trim marks are a print decision and were being forgotten on every
       reload, because nothing carried them across (2026-08-10) */
    if(p.cropMarks) out.cropMarks=1;
    if(typeof p.talkMins==='number'&&p.talkMins>0) out.talkMins=p.talkMins;
    if(typeof p.notes==='string'&&p.notes) out.notes=p.notes;
    if(Array.isArray(p.pad)&&p.pad.length)
      out.pad=deep(p.pad);
    /* the text types this deck invented. Filtered on the way IN: an entry
       with no id is unusable, and one claiming a built-in id would
       silently redefine Heading 1 for everybody who opened the file.
       It cannot ride the ['wmark','head','foot','styles'] loop below —
       that loop takes objects and this is a list. */
    /* T226: the slide layouts this deck designed. Filtered the same
       way as types: an entry with no id or no slot list is unusable,
       and one claiming a built-in id would redefine "Title" for
       everyone who opened the file. */
    if(Array.isArray(p.layouts)&&p.layouts.length){
      var lys=[];
      p.layouts.forEach(function(l){
        if(!l||typeof l!=='object'||!l.id) return;
        if(!Array.isArray(l.items)) return;
        if(LAYOUTBYID&&LAYOUTBYID[l.id]) return;
        lys.push(deep(l));
      });
      if(lys.length) out.layouts=lys;
    }
    if(Array.isArray(p.types)&&p.types.length){
      var tps=[];
      p.types.forEach(function(t){
        if(!t||typeof t!=='object'||!t.id) return;
        if(BUILTIN_STYLE_IDS.indexOf(t.id)>=0) return;
        tps.push(deep(t));
      });
      if(tps.length) out.types=tps;
    }
    /* the section NAMES, filtered to ids a slide actually uses. A blind
       deep copy — the shape the wmark/head/foot/styles line uses — would
       hoard entries for sections that no longer have a single slide in
       them, and the key would never empty again. Dropping it entirely
       when it does empty is what keeps a deck that never used sections
       serialising exactly as it did before the feature existed. */
    if(p.sections&&typeof p.sections==='object'){
      var used={},keep={},anySec=false;
      out.slides.forEach(function(s2){if(s2.sec) used[s2.sec]=1;});
      Object.keys(p.sections).forEach(function(k){
        if(!used[k]) return;
        var d=p.sections[k]; if(!d) return;
        keep[k]={name:String(d.name||'Untitled section')};
        if(d.fold) keep[k].fold=1;
        /* a section's default arrival, which is what makes T23's
           "section transitions" a real thing rather than a note */
        if(typeof d.trans==='string'&&d.trans) keep[k].trans=d.trans;
        /* T316: a section's own colour, when the author chose one */
        if(/^#[0-9a-f]{6}$/i.test(d.color||'')) keep[k].color=d.color;
        /* T601: the presentation this section shows, when it is a part */
        if(d.link&&typeof d.link==='object'&&typeof d.link.deck==='string'
           &&d.link.deck){
          keep[k].link={deck:d.link.deck,sig:String(d.link.sig||''),
            at:+d.link.at||0};
        }
        anySec=true;
      });
      if(anySec) out.sections=keep;
    }
    /* deck-level furniture, same rule as the page background: forget it on
       load and a saved deck quietly loses its footer (2026-08-20).
       `tokens` joins them: an item that references '@accent' and a deck
       that has forgotten what accent means renders the fallback, which
       is the quiet failure this list exists to prevent (T12). */
    /* `guides` joins them, and is the sixth instance of exactly the bug
       this list exists to stop. normPres REBUILDS `out` field by field,
       so a deck-level key it does not name does not survive -- and
       guides were named in histRestore's key list but not here, twelve
       lines of code away. The effect: a guide survived Ctrl+Z and
       survived the localStorage draft, and vanished the moment the deck
       was re-opened from the saved copy, the project file or a loaded
       JSON. T4 shipped that; T52 made it worse by putting guides in the
       undo snapshot and writing a comment saying they belong to the
       deck (2026-08-29). */
    /* T325: `bib` (the deck's own bibliography) and `cite` (how it
       cites) join the list, and T368 adds `slot` -- which type a
       layout's slot actually gets, so a variation you chose survives
       into the next new slide. KEEP THIS A CLEAN ARRAY LITERAL -- the
       schema parity test reads these names straight out of it to learn
       what normPres keeps, and a comment between the brackets hides
       every one of them from it. */
    ['wmark','head','foot','styles','tokens',
     'components','cuts','guides','masters','bib','cite','slot','scale']
      .forEach(function(k){
      if(p[k]&&typeof p[k]==='object') out[k]=deep(p[k]);
    });
    /* T465: A SAVED pres.pageBg BECOMES THE PAGE TOKEN. It was the
       second store for one colour and it won over the token at render
       time, so it takes the token's place here -- a deck renders
       exactly as it did, and from now on there is one answer
       (deckPageBg). '@page' was a theme's way of saying "the token",
       which is the default. */
    if(typeof p.pageBg==='string'&&p.pageBg&&p.pageBg!=='@page'){
      out.tokens=out.tokens||{};
      out.tokens.c=out.tokens.c||{};
      out.tokens.c.page=p.pageBg;
    }
    /* embedded card snapshots ride the FILE, not the object: they are
       absorbed into the session store (and IndexedDB) here, so frames
       still render when the notebook never opens — while drafts written
       on every edit stay ref-sized. Keys are namespaced like refs are. */
    /* T298: WHICH FIGURES ARE LIVE LINKS. Ref-keyed and namespaced
       exactly as the emb keys below are, so the two agree about what
       "this figure" means after a notebook is re-registered. Absence
       means KEPT, which is what every deck written before today wants:
       they already hold snapshots, and rendering those is the whole
       point of having them. */
    out.live={};
    if(p.live&&typeof p.live==='object')
      Object.keys(p.live).forEach(function(k){
        if(p.live[k]) out.live[ns(k)||k]=1;});
    embAbsorb(p,ns);
    /* T321: the clips ride the same rule as `emb` -- absorbed into the
       session store and IndexedDB on the way in, never kept on `out` */
    if(p.media&&typeof p.media==='object'&&typeof mediaAbsorb==='function')
      mediaAbsorb(p);
    return out;
  }
  /* a saved thing's embedded copies into the session store -- a deck's
     (normPres) and a collection's (colNorm) by the one rule */
  function embAbsorb(p,ns){
    if(p.emb&&typeof p.emb==='object'){
      /* T305: A COPY THIS SESSION ALREADY HOLDS IS THE FRESHER ONE.
         EMBED is session-global and keyed by ref, not per deck, and
         this absorb had no existence check -- unlike its sibling, the
         IndexedDB rehydrate, whose comment already states the rule.
         So importing a .junoview that shares a ref with the deck you
         have open silently replaced your kept pixels with the file's,
         with no toast and no way back; and it fired before every one
         of importDeckText's bail-outs, so even a deck that was NOT
         imported -- a startup restore of one you already have, or one
         the localStorage budget dropped -- overwrote them. Two decks
         in one project file holding different snapshots of one ref did
         it at page load, before any UI existed. */
      Object.keys(p.emb).forEach(function(k){
        var e=p.emb[k];
        if(!e||typeof e.html!=='string'||!e.html) return;
        var key=ns(k)||k;
        if(EMBED[key]&&EMBED[key].html) return;
        embStore(key,e);
        /* absorbed ahead of the project's copies, which this order used
           to put first: theirs wins when they arrive (embApply) */
        if(!embLoaded) embWeak[key]=1;
      });
      embSaveSoon();
    }
  }
  function registerShell(stem,data){
    deckViewChanged(stem);   /* its cards are what a frame resolves to */
    Object.keys(ITEMS).forEach(function(k){
      if(ITEMS[k].nb===stem) delete ITEMS[k];});
    SHELLITEMS[stem]=[];
    (data.items||[]).forEach(function(it){
      var o={};for(var k in it) o[k]=it[k];
      o.nb=stem;o.ns=nsKey(stem,it.anchor);
      ITEMS[o.ns]=o;SHELLITEMS[stem].push(o.ns);
      /* also resolve by the card slug so decks saved before anchors
         became positional still find their frames (unchanged cards) */
      if(it.card){
        var alias=nsKey(stem,it.card);
        if(alias!==o.ns&&!ITEMS[alias]) ITEMS[alias]=o;
      }
    });
    nbPres=nbPres.filter(function(p){return p.origin!==stem;});
    (data.presentations||[]).forEach(function(p){
      var cp=normPres(p,stem);cp.origin=stem;nbPres.push(cp);
    });
  }
  function unregisterShell(stem){
    deckViewChanged(stem);
    Object.keys(ITEMS).forEach(function(k){
      if(ITEMS[k].nb===stem) delete ITEMS[k];});
    delete SHELLITEMS[stem];
    nbPres=nbPres.filter(function(p){return p.origin!==stem;});
  }
  /* ingest every notebook the page carries. Called from THE BOOT
     SEQUENCE at the end of the file — nothing executes here at load. */
  function initShellRegistry(){
    APP.order.forEach(function(stem){
      registerShell(stem,APP.shells[stem].data||{});});
  }

  /* ---------- saved presentations: project file + notebook-embedded --- */
  /* the project revision this page was built from; echoed back on every
     save so the server can refuse a write that has not seen another
     window's changes (see the 409 branch in saveToProject) */
  var projectRev=(APP.project&&typeof APP.project.rev==='number')
    ?APP.project.rev:0;
  /* normPres builds every deck afresh and copies each object it keeps,
     so the boot list needs no deep() of its own first -- that was a
     whole stringify-and-parse of the boot JSON (2026-10-09). The boot
     copy is let go once read: nothing else reads it, and holding it kept
     every byte the page arrived with alive for the session. */
  var projectPres=(APP.project&&Array.isArray(APP.project.presentations))
    ?APP.project.presentations.map(function(p){return normPres(p);})
    :[];
  if(APP.project) APP.project.presentations=null;
  function allSaved(){
    var out=[],seen={};
    projectPres.forEach(function(p){out.push(p);seen[p.name]=1;});
    nbPres.forEach(function(p){
      var n=p.name;
      if(seen[n]) n=p.name+' ('+p.origin+')';
      if(seen[n]) return;
      var cp=deep(p);cp.name=n;out.push(cp);seen[n]=1;
    });
    return out;
  }
  function savedByName(name){
    return allSaved().filter(function(p){return p.name===name;})[0]||null;
  }

  /* ---------- draft persistence scope ---------- */
  var SCOPE=APP.mode==='app'?'proj:'+(APP.root||'')
    :APP.mode==='web'?'web:'+location.pathname
    :(APP.order.length>1
      ?'bundle:'+APP.order.slice().sort().join('+')
      :(APP.order[0]||document.title));
  var PFX='sempres:'+SCOPE+':';
  function lsGet(k){try{return localStorage.getItem(k);}catch(e){return null;}}
  /* A SILENT PERSISTENCE LAYER IS WORSE THAN NONE. This swallowed
     QuotaExceededError and returned nothing, and all seventeen callers
     ignored it — so once a draft outgrew the ~5MB budget every later
     write was discarded while the Save button went on toasting "Kept in
     this browser" and the readout went on saying "saved". In the browser
     and static builds that store IS the presentation, so what was lost
     was the only copy (2026-08-22).
     It reports now, and lsFull records that it happened so the readout
     and the Save button can stop lying. */
  var lsFull=false;
  /* `quiet` (T406): the write is a CONVENIENCE COPY -- the deck's real
     home is a file or the project -- so a full browser is not "that edit
     was NOT kept" and must not say so (2026-09-13, user: "Still getting
     error that it can't be saved as browser is full even though rn it
     is saved to local"). The flag is still recorded, so the readout can
     tell the truth for a deck whose only home IS the browser. */
  function lsSet(k,v,quiet){
    try{
      localStorage.setItem(k,v);
      if(lsFull){lsFull=false;if(typeof status==='function') status();}
      return true;
    }catch(e){
      /* Firefox reports NS_ERROR_DOM_QUOTA_REACHED, Safari a bare
         QuotaExceededError with code 22, Chrome code 22 with a name.
         Anything that threw here failed to store, whatever it is called. */
      if(!lsFull){
        lsFull=true;
        if(typeof status==='function') status();
        if(!quiet&&typeof toast==='function')
          toast('Browser full — edit NOT kept. File › Download '
            +'.junoview',9000);
      }
      return false;
    }
  }
  function lsIsFull(){return lsFull;}
  function lsDel(k){try{localStorage.removeItem(k);}catch(e){}}
  /* ---- T429: THE DRAFT STORE IS INDEXEDDB, NOT localStorage -----------
     (2026-09-14, user: "I tried to save a presentation ... the
     presentation seems to just have disappeared and it wasn't in
     recents and didn't save at all ... There seems to be a lot of bugs
     around saving.")
     The library WAS localStorage: every draft a PFX-keyed string inside
     a ~5 MB budget shared by everything. A deck with a few pasted
     pictures is bigger than that, and everything downstream treated
     "no draft" as "no deck": Recents filtered it out, a rename deleted
     the old key and could not write the new one, and a reload opened a
     default deck in its place with only a small "click to reopen" pill
     saying where the real one was. Every save bug the user hit is this
     one cap.
     Now the drafts live in ONE in-memory map, read synchronously by
     everything that used to read localStorage, and written through to
     IndexedDB, which takes hundreds of megabytes. localStorage keeps
     only the small things (the last name, the recents list) and any
     draft older code left there is read once at boot, copied into
     IndexedDB and dropped, which also frees the quota those decks were
     choking on. draftSet always succeeds in memory; an IndexedDB write
     that is refused (a private window, a disk that is really full) is
     the only thing that can make the readout say "browser full" now. */
  var DRAFTS={},draftsDbFull=false,draftsLoaded=false;
  var draftsUnsure={},draftsInLs={};   /* draftsLastChance */
  var DRAFT_META={'last':1,'recent-presentations':1,
    'pinned-presentations':1,    /* T435 */
    'deck-meta':1};              /* T598: not a draft, a record of them */
  function draftGet(name){
    var v=DRAFTS[name]; return (v==null)?null:v;
  }
  function draftSet(name,json,quiet){
    if(!name) return false;
    DRAFTS[name]=json;
    draftsUnsure[name]=json;   /* until IndexedDB says it has it */
    delete draftsInLs[name];
    idbPut(PFX+name,json,'drafts').then(function(){
      if(draftsUnsure[name]===json){
        delete draftsUnsure[name];
        /* the last chance's copy of it is not needed now */
        if(draftsInLs[name]===json){delete draftsInLs[name];lsDel(PFX+name);}
      }
      if(draftsDbFull){draftsDbFull=false;if(typeof status==='function') status();}
    }).catch(function(){
      if(!draftsDbFull){
        draftsDbFull=true;
        if(typeof status==='function') status();
        if(!quiet&&typeof toast==='function')
          toast('Browser full \u2014 edit NOT kept. File \u203a Download '
            +'.junoview',9000);
      }
    });
    lsDel(PFX+name);   /* the legacy copy: one source, and its quota back */
    return true;
  }
  function draftDel(name){
    if(!name) return;
    delete DRAFTS[name];
    delete draftsUnsure[name];delete draftsInLs[name];
    lsDel(PFX+name);
    idbDel(PFX+name,'drafts').catch(function(){});
  }
  function draftsFull(){return draftsDbFull;}
  /* ---- THE PAGE'S LAST CHANCE: WHAT IS NOT KEPT YET, KEPT NOW ---------
     (2026-10-11) IndexedDB is asynchronous, and a page that is going
     does not wait for it. The last chance flushed the debounced draft
     write (flushDraftWrite) into IndexedDB as the page went, and the
     page was gone before the write finished: a slide added, or words
     typed in a box, and the page reloaded at once -- the edit was not
     there. So the last chance
     (pagehide, or the tab hidden: 20-notes-and-tables.js) also puts
     every draft IndexedDB has not yet confirmed into localStorage,
     which is synchronous -- the legacy key, which boot already reads
     first (draftsLoadLocal), opens on, moves into IndexedDB and drops.
     Nothing here runs per edit: draftSet only notes the string it was
     handed (draftsUnsure), and drops the note when IndexedDB has it;
     any later write of the same draft drops the copy too, so the
     localStorage copy is never the older of the two. */
  function draftsLastChance(){
    Object.keys(draftsUnsure).forEach(function(nm){
      var json=draftsUnsure[nm];
      if(draftsInLs[nm]===json) return;   /* hidden twice: there already */
      /* not lsSet: a copy refused here is not "the browser is full"
         for the readout -- IndexedDB may yet have it */
      try{localStorage.setItem(PFX+nm,json);draftsInLs[nm]=json;}
      catch(e){}
    });
  }
  /* the legacy localStorage drafts, synchronously, so boot can open on
     one; each is moved into IndexedDB and dropped from localStorage */
  function draftsLoadLocal(){
    try{
      for(var i=0;i<localStorage.length;i++){
        var k=localStorage.key(i);
        if(!k||k.indexOf(PFX)!==0) continue;
        var nm=k.slice(PFX.length);
        if(!nm||DRAFT_META[nm]) continue;
        var raw=lsGet(k);
        if(raw!=null&&DRAFTS[nm]==null) DRAFTS[nm]=raw;
      }
    }catch(e){}
    Object.keys(DRAFTS).forEach(function(nm){
      if(lsGet(PFX+nm)!=null) draftSet(nm,DRAFTS[nm],true);
    });
  }
  /* ...and the real store, asynchronously. A draft already in memory
     (legacy, or written since boot) wins over the stored one. Resolves
     with the names that were only in IndexedDB. */
  function draftsLoadDb(){
    return idbAll('drafts').then(function(rows){
      var fresh=[];
      (rows||[]).forEach(function(r){
        if(!r||typeof r.key!=='string'||r.key.indexOf(PFX)!==0) return;
        var nm=r.key.slice(PFX.length);
        if(!nm||DRAFT_META[nm]||DRAFTS[nm]!=null) return;
        if(typeof r.value==='string'){DRAFTS[nm]=r.value;fresh.push(nm);}
      });
      draftsLoaded=true;
      return fresh;
    }).catch(function(){draftsLoaded=true;return [];});
  }
  /* T494: the router asks this before it gives up on a #/pres route --
     a browser-kept deck is invisible to deckOpen until the store answers */
  APP.draftsPending=function(){return !draftsLoaded;};
  /* ---- IndexedDB, one door for every store (moved here from the save
     fragment in T429 so the draft store above can use it; function
     declarations hoist, `var` initialisers do not, and this runs from
     initFirstPresentation in THE BOOT SEQUENCE). Version 2 adds the
     'drafts' store beside 'handles'. */
  /* ONE CONNECTION, kept (2026-10-09): every put, get and delete
     opened the database afresh -- a draft write after each edit, the
     copies, the history -- and the open is the slow part. The promise is
     kept while the connection is good and dropped when the browser
     closes it or another tab upgrades it, so the next call opens again;
     a failed open is not kept either. */
  var idbConn=null;
  function idb(){
    if(idbConn) return idbConn;
    var p=idbOpen();
    idbConn=p;
    p.then(function(db){
      function drop(){if(idbConn===p) idbConn=null;}
      db.onclose=drop;
      db.onversionchange=function(){drop();try{db.close();}catch(e){}};
    },function(){if(idbConn===p) idbConn=null;});
    return p;
  }
  /* a kept connection the browser has since closed answers its next
     transaction with InvalidStateError: open a fresh one and try once
     more, rather than report a refused write that was never refused */
  function idbDo(fn){
    return idb().then(fn).catch(function(e){
      if(!(e&&e.name==='InvalidStateError')) throw e;
      idbConn=null;
      return idb().then(fn);
    });
  }
  function idbOpen(){
    return new Promise(function(res,rej){
      var r,done=false;
      function fail(e){if(!done){done=true;rej(e);}}
      function okd(v){if(!done){done=true;res(v);}}
      /* a blocked or wedged open must never leave the caller hanging */
      setTimeout(function(){fail(new Error('indexeddb timeout'));},4000);
      try{r=indexedDB.open('junoview',2);}catch(e){fail(e);return;}
      r.onupgradeneeded=function(){
        var db=r.result;
        try{if(!db.objectStoreNames.contains('handles'))
          db.createObjectStore('handles');}catch(e){}
        try{if(!db.objectStoreNames.contains('drafts'))
          db.createObjectStore('drafts');}catch(e){}
      };
      r.onsuccess=function(){okd(r.result);};
      r.onerror=function(){fail(r.error);};
      r.onblocked=function(){fail(new Error('indexeddb blocked'));};
    });
  }
  function idbPut(k,v,store){
    store=store||'handles';
    return idbDo(function(db){
      return new Promise(function(res,rej){
        var t=db.transaction(store,'readwrite');
        /* .put can throw synchronously (DataCloneError) */
        try{t.objectStore(store).put(v,k);}catch(e){rej(e);return;}
        t.oncomplete=function(){res();};
        t.onerror=function(){rej(t.error);};
        t.onabort=function(){rej(t.error);};
      });
    });
  }
  function idbDel(k,store){
    store=store||'handles';
    return idbDo(function(db){
      return new Promise(function(res,rej){
        var t=db.transaction(store,'readwrite');
        try{t.objectStore(store).delete(k);}catch(e){rej(e);return;}
        t.oncomplete=function(){res();};
        t.onerror=function(){rej(t.error);};
        t.onabort=function(){rej(t.error);};
      });
    });
  }
  function idbGet(k,store){
    store=store||'handles';
    return idbDo(function(db){
      return new Promise(function(res,rej){
        var t=db.transaction(store,'readonly');
        var q=t.objectStore(store).get(k);
        q.onsuccess=function(){res(q.result);};
        q.onerror=function(){rej(q.error);};
      });
    });
  }
  /* every row of a store, as [{key,value}] */
  function idbAll(store){
    return idbDo(function(db){
      return new Promise(function(res,rej){
        var t=db.transaction(store,'readonly'),os=t.objectStore(store);
        var out=[],q;
        try{q=os.openCursor();}catch(e){rej(e);return;}
        q.onsuccess=function(){
          var c=q.result;
          if(c){out.push({key:c.key,value:c.value});c.continue();}
          else res(out);
        };
        q.onerror=function(){rej(q.error);};
      });
    });
  }
  function loadDraft(name){
    var raw=draftGet(name); if(!raw) return null;
    try{var d=JSON.parse(raw);
      /* a custom view kept by a build with the Save-as-view bug has no
         `slides` (newCustomView wrote it by hand): normPres gives it
         its []; refused here, it opened as the automatic deck */
      return (d&&(Array.isArray(d.slides)||d.kind==='view'))
        ?normPres(d):null;
    }catch(e){return null;}
  }
  /* whether there is a draft that loads -- asked once per draft WRITTEN,
     not once per question. The library, Home's rows and every tab asked
     it by loading the whole draft (a parse and a normPres of the deck)
     just to throw it away (2026-10-09). Memoised on the stored string
     itself, which every write replaces. */
  var draftOkMemo={};
  function draftOk(name){
    var raw=draftGet(name);
    if(!raw){delete draftOkMemo[name];return false;}
    var m=draftOkMemo[name];
    if(m&&m.raw===raw) return m.ok;
    var ok=!!loadDraft(name);
    draftOkMemo[name]={raw:raw,ok:ok};
    return ok;
  }
  /* THE DRAFT WRITE IS DEBOUNCED (2026-08-23 perf). markDirty runs on
     every keystroke and every gesture commit, and JSON.stringify(pres)
     plus a synchronous localStorage write per call was the single
     biggest fixed cost of an edit. Only the serialisation waits (~300ms
     trailing, stringifying the CURRENT pres when it fires) — status(),
     scheduleAutosave and histPush stay immediate, so the readout and
     undo behave exactly as before.
     flushDraftWrite() runs a pending write NOW — called wherever a fresh
     draft matters: pagehide/visibilitychange (after the text flush),
     entering Present, loading another presentation, and a rename (which
     migrates the draft by key).
     cancelDraftWrite() drops a pending write instead — called where the
     draft was just deleted on purpose (project/notebook save success,
     Discard, Delete), matching the old order in which the write always
     preceded the lsDel. */
  var draftT=null;
  function writeDraftNow(){
    draftT=null;
    if(!pres) return;
    /* quiet when the browser is not where this deck lives (T406) */
    var spare=(typeof saveTarget!=='undefined'&&saveTarget!=='browser');
    draftSet(pres.name||'untitled',JSON.stringify(pres),spare);
    lsSet(PFX+'last',pres.name||'untitled',spare);
    deckMetaSet(pres.name||'untitled',{edited:Date.now(),
      slides:(pres.slides||[]).length});   /* T598 */
  }
  function scheduleDraftWrite(){
    if(draftT) clearTimeout(draftT);
    draftT=setTimeout(writeDraftNow,300);
  }
  function flushDraftWrite(){
    /* bookkeeping still owed (notes typed a moment ago, editor #12) is
       counted first, so the write it would have scheduled happens here
       -- a deck switch by address (Back, a link) blurs nothing, and the
       switch flushes the OUTGOING deck's draft with this */
    if(typeof quietSettle==='function') quietSettle();
    if(draftT){clearTimeout(draftT);writeDraftNow();}
  }
  function cancelDraftWrite(){
    if(draftT){clearTimeout(draftT);draftT=null;}
  }
  function draftNames(){
    /* T429: the map, not a walk of localStorage */
    return Object.keys(DRAFTS).filter(function(nm){
      return nm&&!DRAFT_META[nm];}).sort();
  }
  /* A browser session is not the saved library. The drawer used while
     presenting answers "what do I have open right now?" -- and since T382
     that is the presentation on screen plus the open notebooks, read live
     (pres, APP.order), not a list kept here. What IS kept here is the
     handful recently used across sessions, for Home and the drawer's
     Recents button (2026-09-12, user: "it should show only open items,
     not all recents, with a separate recents button"). */
  var PRESENT_RECENT_KEY=PFX+'recent-presentations';
  function presentationByName(name){
    if(pres&&pres.name===name) return pres;
    return loadDraft(name)||savedByName(name)||null;
  }
  /* WHAT A LIST NEEDS TO KNOW ABOUT A DECK IS NOT THE DECK (2026-10-09,
     speed). Every tab, every library and Home row and the drawer asked
     presentationByName for each deck it listed -- a whole draft parsed
     and normalised, or every notebook deck deep-copied (allSaved) --
     two or three times a row, to read its kind, page, folder and slide
     count, on every deck opened, closed or switched to. presFacts reads
     the same deck presentationByName would return and keeps only those
     facts: memoised on the stored draft string itself (every write
     replaces it), and read straight off the saved list, which is never
     copied for it. Read-only, for listing; presentationByName stays the
     door for anything that uses the deck. */
  var presFactsMemo={};
  function presFactsOf(p){
    return {name:p.name,page:p.page||'',kind:p.kind||'',
      slides:(p.slides||[]).length,folder:p.folder||'',
      items:Array.isArray(p.items)?p.items.length:0};
  }
  /* the saved deck allSaved() would list under this name, uncopied --
     the project's first, then a notebook's, whose clash with a name
     already taken is listed as "name (notebook)" exactly as there */
  function savedRawByName(name){
    var seen={},i,p,n;
    for(i=0;i<projectPres.length;i++){
      p=projectPres[i];
      if(p.name===name) return p;
      seen[p.name]=1;
    }
    for(i=0;i<nbPres.length;i++){
      p=nbPres[i];n=p.name;
      if(seen[n]) n=p.name+' ('+p.origin+')';
      if(seen[n]) continue;
      if(n===name) return p;
      seen[n]=1;
    }
    return null;
  }
  /* allSaved()'s names, in its order, with nothing copied */
  function savedNameList(){
    var out=[],seen={};
    projectPres.forEach(function(p){out.push(p.name);seen[p.name]=1;});
    nbPres.forEach(function(p){
      var n=p.name;
      if(seen[n]) n=p.name+' ('+p.origin+')';
      if(seen[n]) return;
      out.push(n);seen[n]=1;
    });
    return out;
  }
  function presFacts(name){
    if(pres&&pres.name===name) return presFactsOf(pres);
    var raw=draftGet(name);
    if(raw){
      var m=presFactsMemo[name];
      if(!m||m.raw!==raw){
        var d=loadDraft(name);
        m=presFactsMemo[name]={raw:raw,f:d?presFactsOf(d):null};
      }
      if(m.f) return m.f;
    } else delete presFactsMemo[name];
    var s=savedRawByName(name);
    if(!s) return null;
    var f=presFactsOf(s);f.name=name;
    return f;
  }
  function presentationSummary(name){
    var p=presFacts(name);
    if(!p) return null;
    var w=deckWhere(name),m=deckMeta(name);
    return {name:name,slides:p.slides,
      poster:/^a\d/.test(String(p.page||'')),view:isViewPres(p),
      col:isColPres(p),items:isColPres(p)?p.items:0,
      /* T483: a deck whose home IS this browser is not an "unsaved
         draft" -- Home tagged every browser-kept deck DRAFT */
      /* T598: nor is a deck kept in a file (the browser copy always
         stays beside it, T234): a browser copy means changes not yet
         where the deck lives only for the project, a notebook, or a
         deck with no home yet -- whatever the deck on screen saves to */
      folder:p.folder||'',
      draft:draftOk(name)&&w.kind!=='browser'&&w.kind!=='file',
      where:w.text,whereKind:w.kind,
      at:Math.max(m.edited||0,m.saved||0,m.opened||0)};
  }
  /* ---- T598: WHERE EACH PRESENTATION LIVES, AND WHEN IT WAS TOUCHED ---
     (2026-09-30, user: "the file saving is and recents is confusing".)
     Recent and the library listed names and nothing else, so two decks
     called "talk" -- one in a file, one in this browser -- were two
     identical rows, and nothing said which was last week's. And where a
     deck saved to was ONE setting for every deck, beside ONE remembered
     file handle: open a deck that lives in a file, then one that lives
     here, and the second began asking for a file; reload, and only the
     last deck still knew its file. Each deck keeps a small record now --
     its home (file / project / browser), the name of its file, and when
     it was last edited, saved and opened -- in localStorage beside the
     recent list (a few hundred bytes a deck), and each deck's file handle
     is remembered under its own key (60-saving-and-export.js). Nothing
     here is a copy of the deck. */
  var DECK_META_KEY=PFX+'deck-meta';
  /* the line a row prints under a deck's name: where it lives, when it
     was last touched, how long it is -- "talk.junoview.html · 2 h ago ·
     12 slides" */
  function deckRowWords(p){
    if(!p) return '';
    var bits=[];
    if(p.where) bits.push(p.where);
    if(p.at&&typeof histWhen==='function') bits.push(histWhen(p.at));
    if(p.slides!=null) bits.push(p.slides+' slide'+(p.slides===1?'':'s'));
    return bits.join(' \u00b7 ');
  }
  function deckMetaAll(){
    var m=null;
    try{m=JSON.parse(lsGet(DECK_META_KEY)||'{}');}catch(e){m=null;}
    return (m&&typeof m==='object'&&!Array.isArray(m))?m:{};
  }
  function deckMeta(name){return deckMetaAll()[name]||{};}
  /* write fields; a null deletes one. Quiet: this is bookkeeping, and a
     full browser has already said so about the draft it came with. */
  function deckMetaSet(name,patch){
    if(!name) return;
    var all=deckMetaAll(),m=all[name]||{};
    Object.keys(patch||{}).forEach(function(k){
      if(patch[k]==null) delete m[k]; else m[k]=patch[k];});
    all[name]=m;
    lsSet(DECK_META_KEY,JSON.stringify(all),true);
  }
  function deckMetaMove(oldName,newName){
    var all=deckMetaAll();
    if(!all[oldName]) return;
    all[newName]=all[oldName];delete all[oldName];
    lsSet(DECK_META_KEY,JSON.stringify(all),true);
  }
  function deckMetaDrop(name){
    var all=deckMetaAll();
    if(!all[name]) return;
    delete all[name];
    lsSet(DECK_META_KEY,JSON.stringify(all),true);
  }
  /* where a deck lives, in words a row can print. `kind` is file,
     project, notebook, browser -- or none: a deck with no home but this
     browser's convenience copy, on a page whose default is elsewhere. */
  function deckWhere(name){
    var h=(typeof fileHandles!=='undefined'&&fileHandles)?fileHandles[name]:null;
    var m=deckMeta(name);
    if((h&&h.name)||m.file)
      return {kind:'file',text:(h&&h.name)||m.file};
    if(projectPres.some(function(p){return p.name===name;}))
      return {kind:'project',text:'this project'};
    var nb=nbPres.filter(function(p){return p.name===name;})[0];
    if(nb&&nb.origin) return {kind:'notebook',text:'in '+nb.origin};
    /* the rest are only in this browser: that is their home when it was
       chosen for them, or when nothing else is the default */
    var dflt=(typeof defaultSaveTarget==='function')?defaultSaveTarget()
      :'browser';
    if(m.home==='browser'||(!m.home&&dflt==='browser'))
      return {kind:'browser',text:'this browser'};
    return {kind:'none',text:'not saved yet'};
  }
  /* ---- T435: PINS (2026-09-14, user: "would be cool to be able to pin
     files to recent. I feel like I am always losing files and hard to
     keep track of"). A pinned presentation heads Recent, on Home and
     in the library, and never falls off the end of the list however
     many others are opened after it. Kept beside the recent list in
     localStorage; a rename or a delete follows it. */
  var PRESENT_PIN_KEY=PFX+'pinned-presentations';
  function pinnedPresentationNames(){
    var names=[];
    try{names=JSON.parse(lsGet(PRESENT_PIN_KEY)||'[]');}catch(e){}
    return Array.isArray(names)?names:[];
  }
  function isPinnedPresentation(name){
    return pinnedPresentationNames().indexOf(name)>=0;
  }
  function setPinnedPresentation(name,on){
    if(!name) return;
    var names=pinnedPresentationNames().filter(function(n){return n!==name;});
    if(on) names.unshift(name);
    lsSet(PRESENT_PIN_KEY,JSON.stringify(names.slice(0,40)));
    if(typeof renderPresentationHub==='function') renderPresentationHub();
    if(typeof renderDeckPresentationDrawer==='function')
      renderDeckPresentationDrawer();
    if(APP.refreshChrome) APP.refreshChrome();
  }
  function togglePinPresentation(name){
    setPinnedPresentation(name,!isPinnedPresentation(name));
    return isPinnedPresentation(name);
  }
  function savedRecentPresentationNames(){
    var names=[];
    try{names=JSON.parse(lsGet(PRESENT_RECENT_KEY)||'[]');}catch(e){}
    if(!Array.isArray(names)) names=[];
    /* T435: the pinned ones first, then the rest in recent order */
    var pins=pinnedPresentationNames();
    names=pins.concat(names.filter(function(n){return pins.indexOf(n)<0;}));
    return names.filter(function(name){return !!presFacts(name);})
      .map(function(name){
        var p=presentationSummary(name);
        if(p) p.pinned=pins.indexOf(name)>=0;
        return p;
      }).filter(Boolean);
  }
  function notePresentationOpen(name){
    if(!name) return;
    var recent=[];
    try{recent=JSON.parse(lsGet(PRESENT_RECENT_KEY)||'[]');}catch(e){}
    if(!Array.isArray(recent)) recent=[];
    recent=recent.filter(function(n){return n!==name;});
    recent.unshift(name);
    lsSet(PRESENT_RECENT_KEY,JSON.stringify(recent.slice(0,12)));
    deckMetaSet(name,{opened:Date.now()});   /* T598 */
    noteSessionOpen(name);
    if(typeof renderDeckPresentationDrawer==='function')
      renderDeckPresentationDrawer();
    if(typeof renderPresentationHub==='function') renderPresentationHub();
  }
  function renameRememberedPresentation(oldName,newName){
    function rename(names){
      return names.map(function(name){
        return name===oldName?newName:name;
      }).filter(function(name,index,all){return all.indexOf(name)===index;});
    }
    var recent=[];
    try{recent=JSON.parse(lsGet(PRESENT_RECENT_KEY)||'[]');}catch(e){}
    if(!Array.isArray(recent)) recent=[];
    lsSet(PRESENT_RECENT_KEY,JSON.stringify(rename(recent).slice(0,12)));
    lsSet(PRESENT_PIN_KEY,JSON.stringify(rename(pinnedPresentationNames())));
    deckMetaMove(oldName,newName);   /* T598: its home goes with it */
    renameOpenPresentation(oldName,newName);
    if(typeof renderDeckPresentationDrawer==='function')
      renderDeckPresentationDrawer();
    if(typeof renderPresentationHub==='function') renderPresentationHub();
  }
  function forgetRememberedPresentation(name){
    var recent=[];
    try{recent=JSON.parse(lsGet(PRESENT_RECENT_KEY)||'[]');}catch(e){}
    if(!Array.isArray(recent)) recent=[];
    recent=recent.filter(function(n){return n!==name;});
    lsSet(PRESENT_RECENT_KEY,JSON.stringify(recent));
    lsSet(PRESENT_PIN_KEY,JSON.stringify(pinnedPresentationNames()
      .filter(function(n){return n!==name;})));
    deckMetaDrop(name);   /* T598 */
    closeOpenPresentation(name);
    if(typeof renderDeckPresentationDrawer==='function')
      renderDeckPresentationDrawer();
    if(typeof renderPresentationHub==='function') renderPresentationHub();
  }
  /* ---- T394: WHAT IS OPEN, as distinct from what is recent -----------
     The rail listed every saved presentation, every draft and every deck
     embedded in an open notebook, under a label that said "presentations"
     -- twenty rows of a notebook's embedded decks on a fresh visit, none
     of them anything you had opened -- while Home's Recent column showed
     the one you had (2026-09-13, user: "the side bar shows all recents
     where the main screen shows no recents???? the side bar should only
     show what is open, not all recents. That should be something
     separate"). Open is a TAB LIST: the presentations you have opened in
     this browser tab, in the order you opened them, each closable, kept
     in sessionStorage so a reload keeps them and a new tab starts clean --
     the same life a notebook tab has. Recent and the whole library are
     the two doors under it. */
  var OPEN_PRES_KEY='sempres-open:'+SCOPE;
  function ssGet(k){try{return sessionStorage.getItem(k);}catch(e){return null;}}
  function ssSet(k,v){try{sessionStorage.setItem(k,v);}catch(e){}}
  function rawOpenNames(){
    var names=[];
    try{names=JSON.parse(ssGet(OPEN_PRES_KEY)||'[]');}catch(e){}
    return Array.isArray(names)?names:[];
  }
  function openPresentationNames(){
    return rawOpenNames().filter(function(n){return !!presFacts(n);});
  }
  function noteSessionOpen(name){
    if(!name) return;
    var names=rawOpenNames();
    if(names.indexOf(name)<0){
      names.push(name);
      ssSet(OPEN_PRES_KEY,JSON.stringify(names));
    }
  }
  function closeOpenPresentation(name){
    var names=rawOpenNames().filter(function(n){return n!==name;});
    ssSet(OPEN_PRES_KEY,JSON.stringify(names));
  }
  function renameOpenPresentation(oldName,newName){
    var names=rawOpenNames().map(function(n){return n===oldName?newName:n;});
    ssSet(OPEN_PRES_KEY,JSON.stringify(names.filter(function(n,i){
      return names.indexOf(n)===i;})));
  }
  function fullFrame(ref){
    var r=PRESETS.full[0];
    return {k:'cell',x:r[0],y:r[1],w:r[2],h:r[3],ref:ref||null};
  }
  function emptySlide(){
    /* EMPTY. Every new slide used to arrive already carrying one
       full-page notebook frame, so a deck began by deleting something
       nobody asked for, and the frame read as the only kind of thing a
       slide could hold (2026-08-29, user: "new slides that have just
       the notebook cell ... please don't make that the default").
       Nothing downstream needs the frame to exist in advance:
       applyLayout lays its own, the strip's card-click path makes one
       when a slide has none, and the Object tool draws one where you
       want it rather than where the template guessed. */
    return {layout:'blank',panes:[],annots:[]};
  }
  function autoSlides(withDocs){
    var out=[];
    APP.order.forEach(function(stem){
      (SHELLITEMS[stem]||[]).forEach(function(ns){
        var it=ITEMS[ns];
        var fig=it.kind==='figure'||it.kind==='diagnostic';
        if(fig||(withDocs&&it.kind==='note'))
          out.push({layout:'blank',panes:[],
            annots:[fullFrame(ns)]});
      });
    });
    return out;
  }
  /* T305: THE DECK NOBODY PLACED STILL HAS TO KEEP ITS PIXELS.
     autoSlides builds one slide per figure straight out of SHELLITEMS,
     so the deck a first-time user is handed held N refs and no copies:
     the four placement doors T297/T300 closed are doors this path never
     goes through. Edit one box and markDirty writes a refs-only draft;
     close the notebook or open the page elsewhere and every slide is
     blank. Capturing here covers all five callers at once, and the
     notebook is open by construction -- autoSlides read it to build
     these refs a line ago. */
  function defaultPres(){
    var p={name:'presentation',slides:autoSlides(false)};
    (p.slides||[]).forEach(function(s){
      (s.annots||[]).forEach(function(a){
        if(typeof embedIfAbsent==='function') embedIfAbsent(a);});
    });
    return p;
  }

  var pres=null, source='auto', mode='view', cur=0, activePane=0;
  function loadPresentation(name){
    flushDraftWrite();   /* the outgoing deck's last edits reach its draft */
    /* a DIFFERENT deck has a different history: the head and the
       branch belong to the one being closed, and carrying them
       across would parent the new deck's first snapshot onto the
       old deck's tree (T90) */
    histHead=null;histBranch='';
    saveStamp=null;saveKind='';saveWhere='';   /* T483: this deck's, not the last one's */
    deckZoom=0;   /* zoom is per-session, reset per presentation */
    /* ...and then the NEW deck's stored head is read back, through the
       history queue so any snapshot queued after this waits for it
       (T127). The nulls above stay: they are the safe answer while the
       read is in flight. */
    histSeed();
    var d=loadDraft(name);
    if(d){pres=d;source='draft';}
    else {
      var s=savedByName(name);
      if(s){pres=normPres(deep(s));source='saved';}
      else {pres=defaultPres();source='auto';}
    }
    histReset();
    /* T321: the deck's clips into the session cache, so a save made
       before any of its slides was looked at still carries them */
    if(typeof mediaWarm==='function') mediaWarm(pres);
    /* T601: its parts as they are now -- the state undo starts from */
    if(typeof partsOnLoad==='function'&&partsOnLoad()) histReset();
  }
  /* T414: A DECK OPENED FROM A FILE THAT IS TOO BIG FOR THE DRAFT STORE
     STILL OPENS -- from the object in hand, with no browser copy. Its
     home is the file it came from; the caller points Save at it. The
     same steps as loadPresentation, minus the read from localStorage
     that had nothing to read. */
  function loadPresentationObj(np){
    flushDraftWrite();
    histHead=null;histBranch='';
    deckZoom=0;
    histSeed();
    pres=np;source='draft';
    histReset();
    if(typeof mediaWarm==='function') mediaWarm(pres);
    if(typeof partsOnLoad==='function'&&partsOnLoad()) histReset();   /* T601 */
  }
  /* which presentation the page opens with. Called from THE BOOT
     SEQUENCE at the end of the file — never from here: loadPresentation
     → histReset() → syncCustomTypes() reaches STYLE_DEFAULTS, which is
     assigned thousands of lines below this point (see the 2026-08-22
     incident record at the boot sequence). */
  function initFirstPresentation(){
    /* T429: the legacy localStorage drafts first, synchronously, so the
       page can open on one of them right now... */
    draftsLoadLocal();
    var last=lsGet(PFX+'last');
    if(last&&(loadDraft(last)||savedByName(last))) loadPresentation(last);
    else if(allSaved().length) loadPresentation(allSaved()[0].name);
    /* the other two branches sync via histReset; this one must too —
       "every path that installs a new pres", as syncCustomTypes says */
    else {pres=defaultPres();source='auto';syncCustomTypes();}
    /* ...then the store proper. A deck that was only there -- the big
       one, which is the one that matters -- takes the screen back from
       the default deck the lines above had to open on, and every list
       that names drafts is drawn again. */
    var bootName=(pres&&pres.name)||'';
    /* T494: ...and whether that deck came from the store. The default
       deck is called "presentation", and so is the first deck anyone
       makes: boot opened the notebook's automatic deck under the saved
       one's name, the name test below read "same deck, do nothing",
       and the saved one never took the screen back. */
    var bootStored=(source==='draft');
    draftsLoadDb().then(function(fresh){
      if(!fresh.length) draftsDbFull=false;
      var want=lsGet(PFX+'last')||'';
      /* the deck you were on, if the lines above had to open on
         something else and you have not moved since */
      if(fresh.indexOf(want)>=0&&pres&&pres.name===bootName
         &&(bootName!==want||!bootStored)){
        loadPresentation(want);
        cur=0;activePane=-1;
        if(typeof status==='function') status();
        if(typeof refresh==='function'&&!deckEl.hidden) refresh();
        /* ...and a collection open in its tab is drawn again from it: its
           feed was drawn from the copy the lines above opened, so a
           collection reordered and the page reloaded three seconds later
           showed its old order -- and the next change went to the copy
           on screen (2026-10-11) */
        else if(isColPres(pres)) colRefresh(pres.name);
      }
      /* T494: the URL's #/pres route, which the router held back
         until now because the deck it names could be one of these.
         Before the chrome is painted, so Home is judged with the deck
         open; and when the store does not hold it either, the router
         stamps the view that is showing, as it always did. */
      if(typeof APP.tryRoute==='function') APP.tryRoute();
      /* T601: the parts of the talk on screen, now they can be found */
      if(typeof partsAfterDrafts==='function') partsAfterDrafts();
      if(!fresh.length) return;
      if(typeof renderPresTabs==='function') renderPresTabs();
      if(typeof renderPresentationHub==='function') renderPresentationHub();
      if(typeof renderDeckPresentationDrawer==='function')
        renderDeckPresentationDrawer();
      /* T449: AND HOME (2026-09-14, user's screenshot: "No recent
         presentations" on Home while the library's Recent listed
         seven). Home is painted before the store has answered, and
         the recent list drops every name it cannot find yet -- so
         it has to be painted again now that the drafts are here. */
      if(APP.refreshChrome) APP.refreshChrome();
    });
  }

  var saveStamp=null,saveKind='';
  /* T483: WHERE the last write for this deck went -- 'project',
     'browser' or a file's name -- rather than where the NEXT one is
     set to go: File > Save to project with the browser as the target
     read "saved to browser", and the stamp survived a switch to
     another deck (2026-09-15 review) */
  var saveWhere='';
  function fmtT(d){
    var h=d.getHours(),m=d.getMinutes();
    return (h<10?'0':'')+h+':'+(m<10?'0':'')+m;
  }
  /* the readout is a SAVE BUTTON when saves only live in this browser —
     it used to open the save-to-file picker, which is not what a thing
     that says "autosaved" invites you to do (2026-08-19, user: "clicking
     the autosave button should save") */
  function markSaveClickable(el){
    var toBrowser=(saveTarget!=='file'&&saveTarget!=='project');
    el.classList.toggle('clickable',toBrowser);
    /* the pill ellipsises when the bar is tight, so the sentence it is
       showing has to survive somewhere — the tooltip is that place, and
       the click hint used to replace it wholesale (T70) */
    var txt=el.textContent?el.textContent+' — ':'';
    el.title=toBrowser
      ?txt+'Saves stay in this browser. Click to save now — use the ▾ '
        +'beside Save to keep a .junoview.html file on your computer '
        +'instead.'
      :txt;
  }
  function whereSaved(){
    if(saveWhere) return saveWhere;   /* T483: the last write, not the target */
    if(saveTarget==='project') return 'project';
    /* T414: WHICH file, and WHERE. An autosave into the default folder
       writes <name>.junoview.html THERE -- not into a file you opened
       from somewhere else -- and "autosaved to talk.junoview.html" let
       you look in the wrong place for your work. */
    if(saveTarget==='file')
      return (fileName||'file')
        +((typeof deckDirName!=='undefined'&&deckDirName&&!fileHandle)
          ?(' in your '+deckDirName+' folder'):'');
    return 'browser';
  }
  /* ---- the name, in the title bar ------------------------------------
     Rename used to be a File-menu item that un-hid an input living inside
     a display:none block, so in the ordinary editing flow it did nothing
     visible at all. The name now sits in the middle of the top bar the
     way a title bar shows a document's name, and you rename it by
     clicking it. It commits on Enter or blur, never per keystroke. */
  function syncQatName(){
    var b=$('#qat-name');
    if(!b) return;
    var nm=(pres&&pres.name)||'';
    if(b.textContent!==nm){
      b.textContent=nm;
      /* T487: a longer name widens the bar, and nothing re-judged it --
         at 1300px a deck opened by name overflowed by 16px, clipping
         the Present chevron, until the window was next resized */
      if(typeof fitQat==='function') requestAnimationFrame(fitQat);
    }
    b.title=nm?('“'+nm+'” — click to rename'):'Click to name this';
  }
  function startQatRename(){
    var b=$('#qat-name'),inp=$('#qat-nameedit');
    if(!b||!inp) return;
    inp.value=(pres&&pres.name)||'';
    b.hidden=true;inp.hidden=false;
    inp.focus();inp.select();
    var done=false;
    function commit(ok){
      if(done) return; done=true;
      inp.hidden=true;b.hidden=false;
      var v=inp.value.trim();
      if(ok&&v&&v!==pres.name){renamePresentation(v);}
      syncQatName();
    }
    inp.addEventListener('blur',function(){commit(true);},{once:true});
    inp.addEventListener('keydown',function(e){
      if(e.key==='Enter'){e.preventDefault();commit(true);}
      else if(e.key==='Escape'){e.preventDefault();commit(false);}
    });
  }
  function status(){
    if(typeof fileSync==='function') fileSync();   /* T416: this deck's file */
    syncQatName();
    /* the bar names what it belongs to; for a poster this is the only
       place the name is shown, since the panel that normally carries it
       is hidden */
    var ti=$('#deck-title');
    if(ti) ti.textContent=(mode==='edit'&&pres&&pres.name)?pres.name:'';
    var el=$('#deck-status');
    /* every target autosaves now, not just the app build's project file
       (T70), so the "saving…" half of the readout is no longer gated on
       the mode — only on the setting itself */
    var auto=(typeof autosaveOn==='undefined'||autosaveOn)
      &&(typeof autoSecs==='undefined'||autoSecs>0);
    /* A FULL BROWSER OUTRANKS EVERY OTHER READING. Once localStorage has
       refused a write, "saved" is a lie about the only copy there is, so
       it says so and keeps saying so until a write succeeds. */
    if(draftsFull()&&saveTarget==='browser'){
      el.textContent='NOT saved — browser full';
      el.className='deck-status unsaved lsfull';
      el.title='Browser storage is full, so edits are not being kept. '
        +'Use File \u203a Download .junoview, or the \u25be beside Save to '
        +'save to a file.';
      return;
    }
    /* T416: the remembered file the browser must be allowed to read
       again -- one click, and the deck in it is back */
    if(typeof fileWaits!=='undefined'&&fileWaits==='reopen'){
      var rf=(typeof fileReopen!=='undefined'&&fileReopen&&fileReopen.h
        &&fileReopen.h.name)||'the file';
      el.textContent='click to reopen '+rf;
      /* clickable by its own hand: markSaveClickable only marks a
         browser-kept deck, and this click is a read, not a save */
      el.className='deck-status unsaved clickable';
      el.title='\u201c'+((typeof fileReopen!=='undefined'&&fileReopen
        &&fileReopen.name)||'the presentation')+'\u201d lives in '+rf
        +'. After a reload the browser waits for one click before it '
        +'lets a page read a file again \u2014 this is that click.';
      return;
    }
    /* T406: a file that is waiting on ONE click says so, instead of
       "unsaved \u2014 saving\u2026" for the rest of the session */
    if(saveTarget==='file'&&typeof fileWaits!=='undefined'&&fileWaits
       &&source==='draft'){
      el.textContent=fileWaits==='pick'
        ?'unsaved \u2014 click Save to choose the file'
        :'unsaved \u2014 click Save to keep writing '+(fileName||'the file');
      el.className='deck-status unsaved';
      el.title=fileWaits==='pick'
        ?'No file has been chosen yet, and an autosave never opens a '
          +'file dialog. Press Save once and pick the file; every '
          +'autosave after that writes to it.'
        :'After a reload the browser waits for one click before it lets '
          +'a page write to a file again. Press Save once; every '
          +'autosave after that writes to '+(fileName||'the file')+'.';
      markSaveClickable(el);
      return;
    }
    if(source==='draft'){
      /* web/static Save writes to the browser but keeps source='draft';
         show a plain 'saved' — the Save button tooltip explains where */
      /* T483: in the app too -- a browser Save toasted "Saved to this
         browser" while the readout kept saying "unsaved" */
      if(saveKind==='manual'&&saveStamp){
        el.textContent='saved to '+whereSaved()+' · '+fmtT(saveStamp);
        el.className='deck-status saved';
        markSaveClickable(el);   /* this branch returns before the shared
                                    tail below would run */
        return;
      }
      /* T494: A DECK THE STORE HOLDS, UNTOUCHED SINCE IT WAS OPENED, IS
         SAVED. Reopening a browser-kept deck after a reload (or
         switching to it) read "unsaved — saving…" for as long as you
         did not edit: the per-deck reset T483 added put the phrase back
         on every reopen, no autosave was armed to make it true, and the
         close guard agreed nothing was unsaved. The store is this
         deck's home, so it says so; and "saving…" is only promised
         once an edit this visit has armed the autosave. */
      var toBrowser=(saveTarget!=='file'&&saveTarget!=='project');
      if(!deckEdited()&&toBrowser&&pres&&draftGet(pres.name)!=null){
        el.textContent='saved to browser';
        el.className='deck-status saved';
        markSaveClickable(el);
        return;
      }
      el.textContent=(auto&&deckEdited())?'unsaved — saving…':'unsaved';
    } else if(source==='saved'){
      /* WHERE, not just when: "autosaved · 12:18" answered the question
         nobody asked and skipped the one that matters — into the browser?
         the project? which file? (2026-08-18, user: "in the little
         autosave button, say where saved to") */
      el.textContent=saveStamp
        ?((saveKind==='auto'?'autosaved to ':'saved to ')+whereSaved()
          +' · '+fmtT(saveStamp))
        :'saved to '+whereSaved();
    } else el.textContent='';

    el.className='deck-status '+source;
    /* T526: AN AUTOSAVE ON ITS WAY IS NOT A WARNING. Every edit painted
       the readout in the warning colour for the fifteen seconds until
       the timer fired, so the bar flashed orange all day for the one
       state that needs nothing from you (2026-09-29 audit). The colour
       is kept for the states that do: autosave off, a file waiting on a
       click, a full browser. */
    if(source==='draft'&&auto&&deckEdited()) el.classList.add('pending');
    /* AFTER the className assignment, which would wipe the class */
    markSaveClickable(el);
    /* the readout RENAMES ITSELF between fits ("" -> "autosaved to
       presentation.junoview.html · 12:41"), and a wider readout after
       the last fit is exactly how it ended up printed across other
       controls (2026-08-18, user: "the autosave button hides the color
       options"). Any text change re-judges the bar, which drops the
       readout whole when the row is tight. */
    if(el.textContent!==el._lastTxt){
      el._lastTxt=el.textContent;
      /* the readout lives in the thin bar now, so a wider text has to
         re-judge THAT row too — fitQat drops it whole when tight */
      scheduleQatFit();
    }
    if(!el.classList.contains('clickable')) el.title=el.textContent;
  }
  (function(){
    var el=$('#deck-status');
    if(el) el.addEventListener('click',function(){
      if(!el.classList.contains('clickable')) return;
      /* T416: the reopen click is a read, not a save */
      if(typeof fileWaits!=='undefined'&&fileWaits==='reopen'
         &&typeof reopenFile==='function'){reopenFile();return;}
      var sb=$('#dc-save'); if(sb) sb.click();
    });
  })();
  /* `quiet` persists WITHOUT recording an undo step. The debounced commit
     that now runs while you type uses it, so a paragraph still costs one
     undo entry (taken on blur, as before) instead of one per phrase —
     which would evict real slide edits from the 50-deep stack. */
  /* T434: whether anything was edited on this visit -- the close guard
     asks only about work done here, never about a deck merely opened */
  var editsThisVisit=false;
  /* T494: ...and WHICH decks, by name, so the readout can tell a deck
     merely switched to from the one that was worked on */
  var editedDecks={};
  /* bumped by every edit: the strip moves only its mark on a slide
     change while this still says what it said when it was built (see
     filmMoveMark, 55-sections-and-strip.js) */
  var filmGen=0;
  /* ...and bumped by everything ELSE that changes what a slide draws
     without being an edit: a notebook opened, reloaded or closed (its
     figures are what the frames show), an embedded copy stored, a
     version's card arriving (dropFrameCache, registerShell and
     unregisterShell bump it, and the hidden-deck branches of their
     callers with them). A deck hidden behind a notebook skips the
     refresh such a change asks for, so the way back (setUIMode's strip,
     filmStampKey) reuses what it drew only while this has not moved. */
  var deckViewGen=0;
  function deckViewChanged(src){
    deckViewGen++;
    /* ...and where (viewGens, beside cardElMemo): a notebook's stem, a
       card's ref, or -- named by nothing -- everything */
    var g=viewGens;g.n++;
    if(src==null) g.all=g.n; else g.of[String(src)]=g.n;
  }
  /* WHETHER THE DECK HAS CHANGED SINCE A SAVE WAS SENT is this counter,
     not a re-serialisation (2026-10-09). The save path used to deep-copy
     and stringify the deck twice per save to compare it with itself --
     150 ms of a 3.6 MB picture deck's 350 ms autosave at 4x, every 15 s.
     Both doors that change the deck for keeps bump it: markDirty, and
     histRestore, which writes without one. A save is "still exact" when
     the deck on screen is the same object at the same count (60-saving
     stillSaved) -- a change that went through neither door was missed
     by the draft write as well, so the old serialised comparison caught
     nothing the drafts kept. embDirtyAt says which deck, for the idle
     consolidation (embNeedsSend). */
  var deckGen=0,embDirtyAt={},embSentAt={};
  function deckChanged(){
    deckGen++;
    if(pres&&pres.name) embDirtyAt[pres.name]=deckGen;
  }
  function deckEdited(){return !!(pres&&editedDecks[pres.name]);}
  function markDirty(quiet){
    filmGen++;
    deckChanged();
    /* T409: a committed edit to a clone reaches its clones FIRST, so
       the history entry and the draft below hold the synced deck */
    if(!quiet&&typeof cmpFollowSel==='function') cmpFollowSel();
    source='draft';editsThisVisit=true;
    if(pres&&pres.name) editedDecks[pres.name]=1;
    saveKind='';
    scheduleDraftWrite();   /* the stringify+localStorage cost, debounced */
    if(typeof storyInvalidate==='function') storyInvalidate();
    status();
    scheduleAutosave();
    if(!quiet) histPush();
    /* T237: a version at a natural break in the work, which is what
       makes a timeline readable -- see 46-history.js */
    if(!quiet) histIdleTick();
    renderSelPane();   /* keep the Objects pane in step (no-op if closed) */
    /* and the numbers, which are the same fact about the same slide
       (T65). Same no-op-when-closed contract. */
    if(typeof sizePaneSync==='function') sizePaneSync();
    /* Object history is derived on demand from undo plus the live model.
       When its pane is open, a COMMITTED edit must redraw that final
       "now" row; quiet slider/typing previews would otherwise parse 24
       whole-deck snapshots per input event. */
    var ohp=$('#objhist');
    if(!quiet&&ohp&&!ohp.hidden) renderObjHist();
    /* ...and the full-screen view, if that is the one open (T220) */
    var ohv=$('#oh-ov');
    if(!quiet&&ohv&&!ohv.hidden) renderObjHistOverview();
    refreshThumb(cur);
  }
  /* ---- keep the CURRENT slide's thumbnail live -------------------------
     The strip was only rebuilt by refresh() — a slide change, a layout, a
     reorder. Editing the slide you are looking at never touched it, so its
     thumbnail showed the slide as it was when you arrived and every slide
     you had worked on looked wrong. That is the other half of "thumbnails
     do now show text, or anything else for that matter" (2026-08-20,
     user): the first half was miniDiagram drawing only cells.
     Just the one row, and debounced: renderFilm() rebuilds every row with
     its drag wiring, which is far too much to do on each edit. */
  var thumbT=null;
  function refreshThumb(i){
    clearTimeout(thumbT);
    var deck=pres,slide=pres.slides[i];
    thumbT=setTimeout(function(){
      if(pres!==deck||pres.slides[i]!==slide) return;
      var s=pres.slides[i]; if(!s) return;
      var row=$('#film-list .film-row[data-idx="'+i+'"]');
      if(!row) return;
      /* redrawn here, so no longer what the strip filed it under: the
         next build draws it afresh rather than keeping it (renderFilm) */
      row._key=null;
      var old=row.querySelector('.mini-diagram');
      /* the CURRENT row in notebook view is the big inline pane editor,
         not a thumbnail — leave that alone. In headings mode there is no
         thumbnail at all, and this correctly does nothing. */
      if(old&&old.parentNode){
        miniHNow=miniH();
        filmUnlazy(row);   /* a box still waiting to be drawn is drawn now */
        old.parentNode.replaceChild(miniDiagram(s),old);
      }
      var tt=row.querySelector('.film-t');
      /* filmText, not slideTitle: in headings mode the row is named by
         the slide's heading, and refreshing it with the other function
         would rename it back on the first edit */
      if(tt) tt.textContent=filmStripText(s);
      row.dataset.lvl=headLevel(s);
      syncFilmBuild(i);
    },140);
  }
  /* ---------- undo / redo (snapshots of the slide content) ---------- */
  var undoStack=[],redoStack=[],histSnap=null,histHeadMarks=[];
  /* the section names alone, or null when there are none — the same
     empty-is-null trick pres.styles uses, so a deck with no sections
     serialises into the snapshot exactly as it did before they existed */
  function secNames(){
    var m=pres&&pres.sections,out=null;
    if(m) Object.keys(m).forEach(function(k){
      if(!m[k]) return;
      out=out||{};
      /* the NAME and the arrival are content; whether a section is
         folded is a way of looking at the strip and stays out (T23) */
      if(m[k].trans||m[k].color||m[k].link){
        out[k]={name:(m[k].name)||'Untitled section'};
        if(m[k].trans) out[k].trans=m[k].trans;
        if(m[k].color) out[k].color=m[k].color;   /* T316 */
        /* T601: linking and unlinking a part are edits like any other */
        if(m[k].link) out[k].link=m[k].link;
      } else out[k]=(m[k].name)||'Untitled section';
    });
    return out;
  }
  /* WHAT UNDO CAN SEE. Anything left out of this object is not merely
     un-undoable — it goes INCONSISTENT, because the things that are in it
     are derived from the things that are not.

     The type scale was the bad case. `scaleStyles()` rewrites pres.styles
     and then writes the new sizes into every text box; only the boxes were
     snapshotted, so Ctrl+Z put the boxes back and left the style
     definitions scaled. The deck looked restored until anything called
     applyStyleTo — editing a box, Re-apply, Match slide — at which point
     the scaling silently returned. And because scaleStyles multiplies the
     CURRENT definition, scale/undo/scale drifted the type a little further
     every time, with no way back short of resetting each style by hand
     (2026-08-22).
     Page size and page background were the quiet case: annots are stored
     in percentages, so changing either leaves this object identical,
     histPush's "nothing actually changed" guard fires, and no undo entry
     is created at all.

     pres.notes and pres.pad stay OUT, deliberately: they are written on
     every keystroke, so snapshotting them would fill the 50-entry stack
     with single characters and evict the slide edits undo is for. Per
     SLIDE notes live on the slide and are covered. */
  /* ---- A PICTURE IS NAMED IN THE SNAPSHOT, NOT COPIED (2026-10-09) ----
     A pasted picture is a data: URL inside the slide, so every snapshot
     -- one per committed edit, fifty deep -- carried every picture in
     the deck: 50 copies of a 3.6 MB deck held 180 MB, and each edit
     spent 85-90 ms at 4x serialising pictures that had not changed. A
     string this long is the same picture from one snapshot to the next,
     so the snapshot carries a short name for it (NUL + "jvpic<n>": a
     NUL is not something a deck's text holds) and histParse puts the
     picture back. V8 caches a string's hash, so
     naming the same string object again is a lookup. Whatever parses a
     snapshot goes through histParse: histRestore and Object history
     (00-page.js), and nothing else reads them. The names are forgotten
     with the stack (histReset) and pruned as the stack moves on. */
  var HIST_BIG=8192,histBig=new Map(),histBigBack=new Map(),histBigN=0;
  function histBigRep(k,v){
    if(typeof v==='string'&&v.length>HIST_BIG){
      var id=histBig.get(v);
      if(!id){
        id='\u0000jvpic'+(++histBigN);histBig.set(v,id);histBigBack.set(id,v);}
      return id;
    }
    return v;
  }
  function histParse(snap){
    if(snap.indexOf('\\u0000jvpic')<0) return JSON.parse(snap);
    return JSON.parse(snap,function(k,v){
      return (typeof v==='string'&&v.charCodeAt(0)===0&&histBigBack.has(v))
        ?histBigBack.get(v):v;});
  }
  function histBigForget(){
    histBig=new Map();histBigBack=new Map();histBigLast=null;}
  /* A deck of words has nothing to name, and a replacer costs every
     snapshot V8's fast path (2026-10-09: a 60-slide deck of text paid
     ~2 ms an edit at 4x for nothing). So the snapshot is written plain
     and kept when no quoted run in it is longer than HIST_BIG: an
     unescaped quote opens and closes every string, so no such run means
     no string the replacer would name, and the plain text IS what the
     replacer writes. One that has a run goes through the replacer, and
     the deck is remembered (histBigLast) so its next snapshot goes
     straight there. Either way the same deck gives the same text. */
  var histBigLast=null;
  function histHasBig(s){
    if(s.length<=HIST_BIG) return false;
    var i=-1,j=s.indexOf('"');
    while(j>=0){
      var n=0;
      while(s.charCodeAt(j-1-n)===92) n++;
      if(!(n&1)){if(i>=0&&j-i>HIST_BIG) return true;i=j;}
      j=s.indexOf('"',j+1);
    }
    return false;
  }
  function histJson(o){
    if(histBigLast!==pres){
      var s=JSON.stringify(o);
      if(!histHasBig(s)) return s;
      histBigLast=pres;
    }
    return JSON.stringify(o,histBigRep);
  }
  /* the names no snapshot still uses go, now and then: a picture
     cropped twenty times leaves nineteen it no longer needs */
  function histBigPrune(){
    if(histBigBack.size<=24) return;
    var used={},re=/\\u0000jvpic\d+/g;
    undoStack.concat(redoStack,[histSnap]).forEach(function(s){
      var m=String(s||'').match(re);
      if(m) m.forEach(function(x){used[x]=1;});
    });
    histBigBack.forEach(function(v,id){
      if(used[JSON.stringify(id).slice(1,-1)]) return;
      histBigBack.delete(id);histBig.delete(v);
    });
  }
  function histState(){
    return histJson({slides:pres.slides||[],
      layouts:pres.layouts||[],
      talkMins:pres.talkMins||0,
      showNums:pres.showNums||0,tapzoom:pres.tapzoom||0,
      hideTrace:pres.hideTrace||0,wmark:pres.wmark||null,
      head:pres.head||null,foot:pres.foot||null,
      /* an empty styles object and no styles object are the same deck —
         serialise them the same way or merely READING a style (which
         lazily creates {}) would record a phantom undo step */
      styles:(pres.styles&&Object.keys(pres.styles).length)
        ?pres.styles:null,
      /* T278: the page's type scale is read under the styles, so it is
         as undoable as they are (a template applied, then Ctrl+Z) */
      scale:pres.scale||null,
      /* the types you invented are as undoable as the boxes wearing
         them, and for the same reason the styles are: delete a type and
         Ctrl+Z must bring back both the type AND the a.style tags that
         deleteCustomType stripped. Empty serialises as null on the same
         argument as styles - merely READING the list lazily creates it,
         and a phantom undo step for reading is worse than none. */
      types:(pres.types&&pres.types.length)?pres.types:null,
      /* a token change repaints every item referencing it, so it is an
         edit like any other and Ctrl+Z has to reach it. Empty
         serialises as null on the same argument styles makes: merely
         READING the registry must not record a phantom step. */
      tokens:(pres.tokens&&Object.keys(pres.tokens).length)
        ?pres.tokens:null,
      /* the definitions are as undoable as the instances wearing them:
         Ctrl+Z after a push has to put BOTH back, or the deck is left
         with instances stamped from a definition that no longer says
         that (the same argument styles and types make above) */
      components:(pres.components&&Object.keys(pres.components).length)
        ?pres.components:null,
      /* T261: a master is a look slides inherit LIVE, and sl.mast points
         at it, so it is content exactly as components are. histRestore
         has always had 'masters' in its delete-what-is-absent list while
         this never saved it -- so every undo, after any edit at all,
         destroyed the whole registry and left every wearer tagged at
         nothing. Empty-is-null like its neighbours, so merely opening
         the Masters panel (mastStore() creates pres.masters={} lazily)
         does not record a phantom step. */
      masters:(pres.masters&&Object.keys(pres.masters).length)
        ?pres.masters:null,
      /* T304: WHICH FIGURES ARE LIVE LINKS IS AN EDIT. T301's own
         comment describes this trap for EMBED -- a change that leaves
         `pres` untouched makes histPush's `st===histSnap` return early,
         so NO entry is pushed and Ctrl+Z rewinds whatever came before
         instead. T298's new key walked straight back into it from the
         other side: setRefLive DOES mutate pres.live, but histState did
         not serialise it, so the snapshot was identical and the same
         early return fired. Flip a figure to Live, press Ctrl+Z, and
         the text box you moved a minute ago jumps back while the switch
         stays flipped. Empty-serialises-as-null like its neighbours,
         because setRefLive creates pres.live={} lazily and merely
         turning a link off must not record a phantom step. */
      live:(pres.live&&Object.keys(pres.live).length)?pres.live:null,
      /* the cut NAMES are content; which cut you happen to be
         rehearsing is not, and lives in a session variable (T24) */
      cuts:(pres.cuts&&Object.keys(pres.cuts).length)?pres.cuts:null,
      /* section NAMES are content and are undoable; whether a section is
         COLLAPSED is a way of looking at the strip, so it is stripped out
         here — Ctrl+Z must never open or close one (2026-08-22). The
         tags themselves ride inside `slides`. */
      sections:secNames(),
      /* the guides you drew are content: they belong to the deck, they
         are saved and re-opened with it, and drawing one is an edit like
         any other. They were left out, so a mis-drawn guide box and a
         mis-clicked "Clear every guide" were both unreachable by Ctrl+Z —
         the only edits in the editor that were (2026-08-29, audit T52).
         WHETHER THEY ARE SHOWN stays out, on the same argument that keeps
         a section's fold state out: that is a way of looking at the page,
         and lives in the browser's view state. */
      guides:pres.guides||null,
      /* T494: HOW THE DECK CITES, ITS LIBRARY, AND WHICH TYPE A SLOT
         GETS are edits like any other -- the Citations pane and the
         "new slides get" chooser each call markDirty(), and each walked
         into the trap T304's comment above describes: pres.cite,
         pres.bib and pres.slot were not serialised, so the snapshot
         came out identical, histPush's early return fired, and Ctrl+Z
         after "(Smith 2020)" put the box you had moved back while the
         style stayed (2026-09-15 review, driven: undo depth +0).
         Deleting a library entry was not undoable at all. Empty-is-null
         like their neighbours: bibOf() creates pres.bib={} lazily, and
         merely opening the pane must not record a phantom step. */
      cite:(pres.cite&&Object.keys(pres.cite).length)?pres.cite:null,
      bib:(pres.bib&&Object.keys(pres.bib).length)?pres.bib:null,
      slot:(pres.slot&&Object.keys(pres.slot).length)?pres.slot:null,
      page:pres.page||null,
      cropMarks:pres.cropMarks||0});
  }
  /* T494: the same slide, with the identity renderAnnots mints left
     out -- a box drawn since the last snapshot carries an oid the
     snapshot does not, and that is not a change to the slide */
  function histSlideSig(s){
    return JSON.stringify(s||null,function(k,v){
      return k==='oid'?undefined:v;});
  }
  /* T494: SETTLE WHAT IS BEING TYPED BEFORE A FORMAT LANDS ON IT.
     Bold, a colour swatch and the other keep-the-caret controls mutate
     the box and push their entry FIRST; the words you had typed in the
     900 ms before the click were only committed afterwards, by the
     blur renderAnnots' rebuild fires -- so the history read
     [.., words-less+bold] under [words+bold], and the first Ctrl+Z
     after Bold removed the sentence and kept the bold (2026-09-15
     review, driven with real input). The flush is quiet, so the push
     here is what gives the typing its own entry; it is a no-op when
     nothing was typed. */
  function histSettle(){
    if(typeof flushTextEdits==='function') flushTextEdits();
    histPush();
  }
  function histReset(){
    /* the one funnel every newly installed `pres` passes through, which
       makes it the only safe place to graft this deck's own text types
       into the shared STYLE_DEFAULTS registry. Miss it and deck A's
       "Quote" is still on the menu after you open deck B. */
    syncCustomTypes();
    histBigForget();
    histSnap=histState();undoStack=[];redoStack=[];histHeadMarks=[];
    updateUndoBtns();
  }
  function histPush(){
    var st=histState();
    if(st===histSnap) return;         /* nothing actually changed */
    undoStack.push(histSnap);
    if(undoStack.length>50){undoStack.shift();histMarksShift();}
    redoStack.length=0;histSnap=st;updateUndoBtns();
    /* the stack moved on -- pruned only now, when the snapshot just
       taken is histSnap: a picture that first appears in it is named
       nowhere else yet, and pruning before would orphan its name */
    if(undoStack.length>=50) histBigPrune();
    /* T499: a restore that had been undone is now past reaching */
    histHeadMarks=histHeadMarks.filter(function(m){
      return m.depth<undoStack.length;});
  }
  /* ---- THE IDS A RENDER MINTED, TAKEN INTO THE BASELINE (2026-10-09) --
     renderAnnots names each object it draws (oid) without calling that
     an edit, and undo finds the selection again by those names (T494).
     A plain click used to be a markDirty, whose histPush took the names
     into the snapshot -- as an undo step of its own that changed
     nothing. The click is no longer an edit (25-selecting.js), so it
     takes them here instead: when the deck differs from the snapshot by
     minted names ALONE, the snapshot becomes the deck, and no step is
     pushed. Anything else pending (a typed word, a held nudge) is a
     real difference and is left for its own commit. */
  function histNoIds(snap){
    return JSON.stringify(JSON.parse(snap),function(k,v){
      return k==='oid'?undefined:v;});
  }
  function histAdoptIds(){
    if(!pres||histSnap==null) return;
    var st=histState();
    if(st===histSnap) return;
    try{if(histNoIds(st)===histNoIds(histSnap)) histSnap=st;}catch(e){}
  }
  /* ---- T499: WHERE IN THE TREE, ACROSS AN UNDO ------------------------
     "Go back to this version" said "so this is undoable" and then
     emptied the stack (histReset), so Ctrl+Z was disabled the moment
     the toast appeared (2026-09-15 review, driven). The stack is kept
     now -- its entries are JSON text, not references into the replaced
     deck, and histRestore reads every whole-deck key -- so the undo
     entry markDirty pushes IS the deck you had. What the entry cannot
     carry is the head pointer: a restore moves it to the version you
     went back to, and an undo that put the content back while the head
     stayed there would make the next save a child of the old version
     -- the lie about what came before that T90 exists to prevent. So a
     restore leaves a mark at its depth in the stack: undo across it
     moves the head back where it was, redo moves it on again. */
  function histMarkHead(from,to){
    histHeadMarks.push({depth:undoStack.length,from:from,to:to});
  }
  function histMarkHeadNow(){
    /* the branch flow takes its own snapshot after the restore, and that
       is where a redo should land the head */
    var m=histHeadMarks[histHeadMarks.length-1];
    if(m&&m.depth===undoStack.length) m.to={h:histHead,br:histBranch};
  }
  function histMarksShift(){
    histHeadMarks=histHeadMarks.map(function(m){
      return {depth:m.depth-1,from:m.from,to:m.to};
    }).filter(function(m){return m.depth>0;});
  }
  function histHeadTo(p){
    histHead=p.h||null;histBranch=p.br||'';
    histPtrSave(pres.name);
    var chip=$('#deck-history .dh-onbr');
    if(chip) chip.innerHTML=bic('route')+' on '+esc(histBranch||'main');
  }
  function histRestore(snap){
    var d;try{d=histParse(snap);}catch(e){return;}
    /* T494: WHERE THE CHANGE WAS, AND WHAT WAS SELECTED. This restored
       the model and left `cur` alone, so an edit made on another slide
       was undone out of sight -- press Ctrl+Z, see nothing move, press
       it again and two things are gone -- and Redo of "New slide" put
       the slide back without showing it. PowerPoint jumps to the slide
       it changed; so does this: the first slide that differs between
       the deck you had and the one coming back. And the selection was
       dropped, which cost every undo of a move a re-select and threw
       the ribbon off the Object tab (the empty-tab fallback), after
       which the arrow keys nudged nothing (2026-09-15 review, driven).
       The selected items are remembered by oid and picked up again
       where they survive on the slide we land on. */
    var was=pres.slides||[],keepOids=[],sWas=was[cur];
    if(sWas&&sWas.annots) selIdxs().forEach(function(i){
      var a=sWas.annots[i]; if(a&&a.oid) keepOids.push(a.oid);});
    var keepTitle=(selAnnot==='t'||selAnnot==='s')?selAnnot:null;
    pres.slides=d.slides||[];
    var jump=-1,nSl=Math.max(was.length,pres.slides.length);
    for(var si=0;si<nSl&&jump<0;si++)
      if(histSlideSig(was[si])!==histSlideSig(pres.slides[si])) jump=si;
    if(jump>=0) cur=jump;
    if(d.showNums) pres.showNums=1; else delete pres.showNums;
    if(d.tapzoom) pres.tapzoom=1; else delete pres.tapzoom;
    if(d.hideTrace) pres.hideTrace=1; else delete pres.hideTrace;
    var pageWas=pres.page||null,bgWas=deckPageBg();
    /* T263: 'layouts' belongs in this list. histState has always
       snapshotted it, and nothing read it back -- so making or deleting
       a custom slide layout could not be undone, while every other
       design-level key could. d.layouts is always emitted and [] is
       truthy, so this assigns rather than deletes. */
    ['wmark','head','foot','styles','tokens','components','cuts',
     'guides','masters','layouts','page','cropMarks','live',
     'scale']
      .forEach(function(k){
        if(d[k]) pres[k]=d[k]; else delete pres[k];});
    if(d.talkMins) pres.talkMins=d.talkMins; else delete pres.talkMins;
    /* types are restored with their own statement rather than by joining
       the list above, because the registry has to be re-grafted the
       moment the list changes - every menu, every specimen row and
       applyStyleTo read STYLE_DEFAULTS, not pres.types, so an undo that
       restored the list without syncing would leave the deck offering a
       type that no longer resolves. */
    if(d.types) pres.types=d.types; else delete pres.types;
    syncCustomTypes();
    /* T494: read back what histState now saves (see the note there) */
    ['cite','bib','slot'].forEach(function(k){
      if(d[k]) pres[k]=d[k]; else delete pres[k];});
    /* sections get their own merge rather than joining the list above:
       that loop deletes what the snapshot lacks, and the snapshot
       deliberately lacks the fold flags — so it would collapse-or-expand
       every section on every undo. Names come from the snapshot; whether
       a section is open stays exactly as you left it. */
    if(d.sections){
      var was=pres.sections||{};
      pres.sections={};
      Object.keys(d.sections).forEach(function(k){
        var v=d.sections[k];
        pres.sections[k]=(v&&typeof v==='object')
          ?{name:v.name||'Untitled section',trans:v.trans,color:v.color,
            link:v.link}
          :{name:v};
        if(!pres.sections[k].trans) delete pres.sections[k].trans;
        if(!pres.sections[k].color) delete pres.sections[k].color;
        if(!pres.sections[k].link) delete pres.sections[k].link;   /* T601 */
        if(was[k]&&was[k].fold) pres.sections[k].fold=1;
      });
    } else delete pres.sections;
    if(cur>=pres.slides.length) cur=Math.max(0,pres.slides.length-1);
    activePane=-1;selAnnot=null;selSet=[];
    /* T494: the selection, by oid, on the slide we land on. Set BEFORE
       refresh() so renderAnnots' own paintSel draws it and showFmt at
       the end sees the same signature it had -- a selection that
       survives must not read as a fresh one and yank the tab. */
    var sNow=pres.slides[cur],back=[];
    if(sNow&&sNow.annots&&keepOids.length)
      sNow.annots.forEach(function(a,i){
        if(a&&a.oid&&keepOids.indexOf(a.oid)>=0) back.push(i);});
    if(back.length){selSet=back;selAnnot=back[back.length-1];}
    else if(keepTitle&&sNow&&sNow.layout==='title'){
      selAnnot=keepTitle;selSet=[keepTitle];}
    /* the styles come back as DEFINITIONS only. Every text box already
       carries the sizes it had in this snapshot (applyStyleTo writes them
       in), so restyling here would overwrite the restored boxes with the
       restored definitions — the same round trip we are undoing. */
    /* a page size or background is not repainted by refresh(): they are
       applied to the stage, so an undo across one has to re-run the same
       two calls the picker does, and re-fit a ribbon whose column may
       have just changed shape */
    var pageChanged=(pres.page||null)!==pageWas;
    if(pageChanged||deckPageBg()!==bgWas) deckZoom=0;
    /* persist WITHOUT recording a new history entry */
    source='draft';
    deckChanged();    /* a change all the same: see deckGen */
    draftSet(pres.name||'untitled',JSON.stringify(pres));   /* T429 */
    status();scheduleAutosave();
    if(pageChanged) applyPage();
    if(typeof applyPageBg==='function') applyPageBg();
    refresh();
    if(pageChanged){
      if(typeof syncTopBar==='function') syncTopBar();
      if(typeof applySideRibbon==='function') applySideRibbon();
    }
    /* the guide layer is not the annot layer: it hangs off the slide and
       caches the signature it last drew, so an undo across a guide edit
       has to ask it again or the restored model is invisible */
    if(typeof syncGuides==='function') syncGuides();
    /* the format bar follows the selection -- cleared, or the one that
       survived (T494); the Objects pane reads the same fact */
    if(typeof showFmt==='function') showFmt();
    if(typeof renderSelPane==='function') renderSelPane();
  }
  function undo(){
    if(typeof nudgeSettle==='function') nudgeSettle();   /* T499 */
    if(!undoStack.length) return;
    redoStack.push(histSnap);histSnap=undoStack.pop();
    /* T499: stepping back over a whole-deck restore moves the head back */
    histHeadMarks.forEach(function(m){
      if(m.depth===undoStack.length+1) histHeadTo(m.from);});
    updateUndoBtns();histRestore(histSnap);
  }
  function redo(){
    if(typeof nudgeSettle==='function') nudgeSettle();   /* T499 */
    if(!redoStack.length) return;
    undoStack.push(histSnap);histSnap=redoStack.pop();
    histHeadMarks.forEach(function(m){
      if(m.depth===undoStack.length) histHeadTo(m.to);});
    updateUndoBtns();histRestore(histSnap);
  }
  function updateUndoBtns(){
    var u=$('#dc-undo'),r=$('#dc-redo');
    if(u) u.disabled=!undoStack.length;
    if(r) r.disabled=!redoStack.length;
  }

  /* ---------- DOM cloning from the cards already on the page ---------- */
  /* ONE LOOKUP PER CARD, NOT PER ASK (2026-10-09). Every thumbnail of a
     figure asks for its card twice (paneImgSrc, miniCell), and each ask
     was a selector match over the whole notebook -- about 5,900
     elements, 13 ms at 4x for one strip of 45 figures. The answer is
     remembered per card, and trusted only while it is still true: the
     same shell element, still in the document, still wearing that
     anchor, and nothing remounted, closed or re-copied since
     (dropFrameCache empties the memo; it is declared up beside
     frameNodeCache). A miss is never remembered -- a card that is not
     there yet may be inserted without a remount. */
  function cardEl(ref){
    var it=resolveRef(ref); if(!it) return null;
    var sh=APP.shells[it.nb]; if(!sh) return null;
    var anchor=String(it.anchor),k=it.nb+'::'+anchor,m=cardElMemo.get(k);
    if(m&&m.sh===sh.el&&m.el.isConnected
       &&m.el.getAttribute('data-anchor')===anchor) return m.el;
    var el=sh.el.querySelector(
      '.card[data-anchor="'+anchor.replace(/"/g,'\\"')+'"]');
    if(el) cardElMemo.set(k,{sh:sh.el,el:el}); else cardElMemo.delete(k);
    return el;
  }
  function stripIds(node){
    if(node.removeAttribute) node.removeAttribute('id');
    $$('[id]',node).forEach(function(n){n.removeAttribute('id');});
    return node;
  }
  /* per-frame figure history: every successful live clone is remembered;
     on a notebook reload those become the "previous figure" a frame can
     revert to (session-only — snapshots never enter the saved deck) */
  var frameSnaps={},frameSnapsPrev={};
  var frozenFrames=new WeakMap();   /* annot -> snapshot html it shows */
  /* ---- FRAME RENDER CACHES (2026-08-23 perf) --------------------------
     renderAnnots used to re-run cloneBody per cell frame per layer
     rebuild: a full cloneNode(true) of a card body carrying multi-MB
     base64 figures, four querySelectorAll stripping passes, and an
     outerHTML serialisation into frameSnaps — per frame, per call. The
     prepared node is now cached and re-cloned on use (the embBody
     e._node precedent).
     frameNodeCache: normRef+'::'+requestedPart -> ready-to-insert node.
     INVALIDATION — a stale frame is a wrong frame, so every event that
     can change a card's rendered body drops the affected entries via
     dropFrameCache():
       1. the 'sem:shell' handler (a notebook opened OR reloaded — the
          refresh-pictures path), per stem;
       2. the 'sem:shellclosed' handler, per stem — frames fall back to
          the deck's embedded copy;
       3. embStore(), per ref — a new/updated embedded copy must show
          (it matters when the notebook is not open).
     NOT invalidation points, deliberately:
       - document filter changes (the Plots/Code/Outputs menus): they
         only toggle classes/stubs on the live cards, and cloneBody
         normalises all of that away (strips the pt-, ot-, part- and
         code-off classes, removes .ot-stub, restores .figpager-nav),
         so the clone is filter-invariant;
       - the notebook-side figpager's CURRENT page: view state, not
         content — the placed frame's own pager stays interactive;
       - freeze/unfreeze ("Previous figure"): it switches BUILDERS
         (framePartFromSnap vs framePart), no shared entries;
       - version locks: verNodeCache is keyed by the immutable
         per-commit card object (fetchVerCards never refetches a defined
         key), and locking/unlocking picks a different code path.
     snapNodeCache is content-addressed (keyed by the snapshot HTML
     string itself), so it cannot go stale by construction. */
  /* the three cache stores are DECLARED far above, beside EMBED
     (T133): embStore -> dropFrameCache reads frameNodeCache, and
     normPres runs embStore AT EVAL TIME through the projectPres
     initialiser -- so a declaration here was six hundred lines too
     late the first time a saved deck arrived carrying inline emb. */
  /* drop cached frame nodes for one notebook stem, one full ref, or all
     (both key shapes are prefixes of 'stem::anchor::part') */
  function dropFrameCache(stemOrRef){
    /* a frame may draw differently from now on: the frames of this
       notebook, or of this card, or (null) of every one */
    deckViewChanged(stemOrRef);
    cardElMemo.clear();  /* and a card may stand elsewhere: see its
                            declaration beside frameNodeCache */
    if(stemOrRef==null){frameNodeCache={};return;}
    var pfx=stemOrRef+'::';
    Object.keys(frameNodeCache).forEach(function(k){
      if(k.indexOf(pfx)===0) delete frameNodeCache[k];});
  }
  /* T298: A FIGURE IS A KEPT COPY UNLESS YOU ASK FOR A LIVE LINK.
     cloneBody read the OPEN CARD first and the deck's own copy only as
     a fallback, so a notebook re-run silently rewrote slides that were
     finished -- the second half of "I have lost too many things"
     (2026-09-05). The kept copy now wins, and the notebook is what you
     go BACK to, deliberately, through Refresh.

     Liveness is per-REF rather than per-box on purpose: two frames
     showing the same cell cannot sensibly disagree about whether that
     cell is live, and the refresh, the provenance and the git pin are
     all keyed by ref already. */
  function refIsLive(ref){
    if(!ref||!pres||!pres.live) return false;
    if(pres.live[ref]) return true;
    var n=normRef(ref);
    return !!(n&&pres.live[n]);
  }
  function setRefLive(ref,on){
    if(!ref||!pres) return;
    if(!pres.live) pres.live={};
    var k=normRef(ref)||ref;
    if(on) pres.live[k]=1; else {delete pres.live[k];delete pres.live[ref];}
    /* invalidation point 4: the frame is cached by ref, and which SOURCE
       it was built from is exactly what just changed */
    dropFrameCache(k);
    if(k!==ref) dropFrameCache(ref);
  }
  /* T302: `fromLive` asks the NOTEBOOK, not the frame. Three callers
     need that and only that -- the staleness comparison, the capture it
     feeds, and a chart re-reading its table -- and after T298 they were
     all silently answered with the kept copy instead, so nothing was
     ever stale, "Update figures" reported "every figure already
     matches" against a notebook that had visibly moved on, and the
     refresh it would have run had nothing new to store. Found by
     driving it, not by reading it. */
  function cloneBody(ref,fromLive){
    /* the deck's own copy, already filter-stripped at capture time */
    if(!fromLive&&!refIsLive(ref)){
      var kept=embBody(ref);
      if(kept) return stripIds(kept.cloneNode(true));
    }
    var c=cardEl(ref);
    if(!c){
      /* no live card either: the copy embedded in the deck is all there
         is, and for a live link that is still better than a blank */
      var eb=embBody(ref);
      return eb?stripIds(eb.cloneNode(true)):null;
    }
    /* the notebook typesets its maths as it is read, so a card nobody
       has scrolled to may still hold raw TeX: set it now, before it is
       cloned onto a slide, kept, compared or measured -- the same card
       every one of those always saw once the page had loaded */
    if(window.jvMath) window.jvMath.settle(c);
    var b=$('.cardbody',c); if(!b) return null;
    b=stripIds(b.cloneNode(true));
    /* the DOCUMENT's filter state (hidden plot types, folded/hidden parts)
       must not ride into slides — a placed frame shows its part in full */
    $$('.pt-off,.pt-fold,.ot-off,.ot-fold,.part-off,.part-fold,.code-off',b)
      .forEach(function(n){
        ['pt-off','pt-fold','pt-open','ot-off','ot-fold','ot-open',
         'part-off','part-fold','part-open','code-off']
          .forEach(function(cl){n.classList.remove(cl);});
      });
    /* per-output fold stubs are filter chrome, not content */
    $$('.ot-stub',b).forEach(function(n){n.remove();});
    $$('.figpager-nav',b).forEach(function(n){n.style.display='';});
    /* MathJax's menu numbers each equation in the order this page set
       it -- the reading order, now -- so a kept copy taken from the same
       card read differently came out different bytes on every save. The
       number is the page menu's bookkeeping, not the figure (sameCardHtml) */
    $$('mjx-container[ctxtmenu_counter]',b).forEach(function(n){
      n.removeAttribute('ctxtmenu_counter');});
    /* T303: only a LIVE clone is a "previous figure". This line sits
       in the live-card branch, which a kept ref now returns before
       reaching -- so the snapshot stopped being taken, which is right.
       But liveCardHtml passes fromLive=1 to answer the staleness
       question, and that re-armed it behind the user's back: pressing
       Previous figure on a kept frame then put a picture on the slide
       that the slide had never shown. The staleness probe is not a
       render and must not leave a trail. */
    var it=resolveRef(ref);
    if(it&&!fromLive) frameSnaps[it.ns]=b.outerHTML;
    return b;
  }
  /* T303: THE CODE FACET WAS STILL A SYM LINK. T298 taught cloneBody
     to prefer the deck's kept copy and left cloneCode alone, so a
     placed CODE frame still read the open notebook: re-run it and the
     code on a finished slide rewrote itself -- the very loss T298
     shipped to stop -- and splitFrame exists precisely to put a code
     frame BESIDE a figure frame, so kept and live sat on one slide.
     Closing the notebook changed a finished slide too, since the kept
     copy was only the fallback.

     The preference lives HERE and not inside cloneCode because
     cloneCode has five callers and two of them -- openVFull and the
     review step box -- show a NOTEBOOK cell's code, not a deck frame.
     Making cloneCode kept-first would have quietly switched those to
     the deck's snapshot while the notebook was open. */
  function frameCode(ref){
    if(!refIsLive(ref)){
      var e=embFor(ref);
      if(e&&e.code){
        var t=document.createElement('template');t.innerHTML=e.code;
        var n=t.content.firstElementChild;
        if(n) return stripIds(n.cloneNode(true));
      }
    }
    return cloneCode(ref);
  }
  function cloneCode(ref){
    var c=cardEl(ref);
    if(!c){
      var e=embFor(ref);
      if(!e||!e.code) return null;
      var t=document.createElement('template');t.innerHTML=e.code;
      var n=t.content.firstElementChild;
      return n?stripIds(n.cloneNode(true)):null;
    }
    var inner=$('.codeinner',c); if(!inner) return null;
    return stripIds(inner.cloneNode(true));
  }
  /* a cell can contribute several things to a slide: its CODE, its
     FIGURE(s) and its printed OUTPUT. A frame shows one 'part'. */
  function cellFacets(ref){
    /* T298: ASK THE BODY THE FRAME WILL ACTUALLY RENDER. Reading the
       live card here while cloneBody rendered the kept copy would let a
       re-run notebook that gained a plot make the frame choose part
       'figure' from a snapshot that has no figure in it -- an empty
       frame with no way to see why. */
    var kept=refIsLive(ref)?null:embBody(ref);
    var card=kept?null:cardEl(ref);
    var it=resolveRef(ref);
    var f={code:!!(it&&it.hasCode),figure:false,output:false};
    var body=null;
    if(card){
      if(!f.code&&card.querySelector('.codeinner')) f.code=true;
      body=$('.cardbody',card);
    } else {
      body=kept||embBody(ref);   /* the deck's own copy is a cardbody too */
    }
    if(body){
      /* live embeds (plotly/bokeh/vega/folium) are figures too */
      f.figure=!!body.querySelector('.figframe,.figpager,.plotframe');
      f.output=!!body.querySelector(
        'pre.result,pre.stream,.rich:not(.plotframe),.jv-xr,.note')
        ||(!f.figure&&!!(body.textContent||'').trim());
    }
    return f;
  }
  function autoPart(f){
    return f.figure?'figure':(f.output?'output':(f.code?'code':'body'));
  }
  function hasFacet(f,part){
    return (part==='code'&&f.code)||(part==='figure'&&f.figure)
      ||(part==='output'&&f.output);
  }
  function partOf(a){
    var f=cellFacets(a.ref);
    /* honor the chosen part only if the cell STILL has it (a refresh may
       have removed the figure/output) — else fall back to auto */
    if(a.part&&a.part!=='auto'&&hasFacet(f,a.part)) return a.part;
    return autoPart(f);
  }
  function applyPartFilter(b,part){
    if(part==='figure'){
      /* the figure part is JUST the figure — drop outputs AND any markdown
         note / caption that rides along in the card body (a .plotframe is
         a live figure, e.g. bokeh/vega/folium — keep it) */
      $$('.cb-out,.jv-xr,pre.result,pre.stream,.rich:not(.plotframe),'
        +'.note,.note-src,.htmltoggle,.caption',b)
        .forEach(function(n){if(n.parentNode) n.parentNode.removeChild(n);});
    } else if(part==='output'){
      $$('.cb-fig,.figframe,.figpager,.plotframe',b).forEach(function(n){
        if(n.parentNode) n.parentNode.removeChild(n);});
    }
    return b;
  }
  function framePart(ref,part){
    /* cached per (ref, requested part): cloneBody — and its frameSnaps
       outerHTML snapshot — now runs only when the cache was dropped,
       i.e. on first sight or after the source card actually changed.
       See the invalidation list on frameNodeCache above. */
    var key=(normRef(ref)||String(ref||''))+'::'+(part||'auto');
    var hit=frameNodeCache[key];
    if(hit) return hit.cloneNode(true);
    var f=cellFacets(ref);
    if(!part||part==='auto'||!hasFacet(f,part)) part=autoPart(f);
    var b;
    if(part==='code') b=frameCode(ref)||cloneBody(ref);
    else {
      b=cloneBody(ref);
      /* a figure/output frame whose kept body is null falls through to
         the code, and that fallback must obey the same preference */
      b=b?applyPartFilter(b,part):frameCode(ref);
    }
    if(b) frameNodeCache[key]=b.cloneNode(true);
    return b;
  }
  /* ---- figure LOCKS: a frame pinned to a git commit renders that
     commit's card (fetched once, cached) — refresh never touches it, and
     the source notebook doesn't even have to be open ---- */
  var verCards={},verMeta={},verPending={};
  function lockParts(a){
    var r=normRef(a.ref)||String(a.ref||'');
    var pr=splitRef(r);
    if(!pr[0]) return null;
    var path=nbPathFor(pr[0]);
    if(!path||/^https?:/i.test(path)) return null;
    return {stem:pr[0],anchor:pr[1],path:path,
      key:path+'@'+a.lockver.commit+'::'+pr[1],
      pkey:path+'@'+a.lockver.commit};
  }
  function fetchVerCards(path,commit,anchors){
    var pkey=path+'@'+commit;
    var pend=verPending[pkey]=verPending[pkey]||{};
    anchors=anchors.filter(function(an){
      return verCards[pkey+'::'+an]===undefined&&!pend[an];});
    if(!anchors.length) return Promise.resolve();
    anchors.forEach(function(an){pend[an]=1;});
    return APP.api('/api/versioncards',
      {path:path,commit:commit,anchors:anchors})
    .then(function(j){
      verMeta[pkey]={msg:j.msg||'',date:j.date||''};
      anchors.forEach(function(an){
        verCards[pkey+'::'+an]=(j.cards||{})[an]||null;
        delete pend[an];
      });
      deckViewChanged();   /* a locked frame can be drawn now */
      var l=stage.querySelector('.annot-layer');
      var s=pres.slides[cur];
      if(l&&s&&!deckEl.hidden){renderAnnots(l,s);paintSel(l);}
    }).catch(function(){
      anchors.forEach(function(an){
        verCards[pkey+'::'+an]=null;delete pend[an];});
    });
  }
  /* undefined = loading, null = unavailable, object = the card.
     Asked once per locked frame while a slide renders, so the misses of
     one render are COLLECTED and fetched together after it: one request
     per notebook version, not one per frame -- each request is a git
     read on the server, several git processes apiece (2026-10-08). */
  var verAsk={};
  function verCardFor(a){
    if(!(a.lockver&&a.lockver.commit)||APP.mode!=='app') return null;
    var lp=lockParts(a); if(!lp) return null;
    var hit=verCards[lp.key];
    if(hit!==undefined) return hit;
    var q=verAsk[lp.pkey];
    if(!q){
      q=verAsk[lp.pkey]={path:lp.path,commit:a.lockver.commit,anchors:[]};
      Promise.resolve().then(function(){
        delete verAsk[lp.pkey];
        fetchVerCards(q.path,q.commit,q.anchors);
      });
    }
    if(q.anchors.indexOf(lp.anchor)<0) q.anchors.push(lp.anchor);
    return undefined;
  }
  /* resolve the part and filter a snapshot BODY node (snapshots hold no
     code part) — shared by the string and version-card paths */
  function snapPart(b,part){
    var hasFig=!!b.querySelector('.figframe,.figpager,.plotframe');
    if(!part||part==='auto'||part==='code')
      part=hasFig?'figure':'output';
    return applyPartFilter(b,part);
  }
  function frameFromVerCard(card,part){
    /* was: template-parse card.html, clone, re-serialise to outerHTML,
       then framePartFromSnap parsed the string AGAIN — per frame, per
       render. Now parsed once per card object (verCards entries are
       immutable) and cached per part (2026-08-23 perf). */
    var byPart=verNodeCache.get(card);
    if(!byPart){byPart={};verNodeCache.set(card,byPart);}
    var pk=part||'auto';
    if(pk in byPart)
      return byPart[pk]?byPart[pk].cloneNode(true):null;
    var t=document.createElement('template');t.innerHTML=card.html||'';
    var b=t.content.querySelector('.cardbody');
    var out=b?snapPart(stripIds(b.cloneNode(true)),part):null;
    byPart[pk]=out?out.cloneNode(true):null;
    return out;
  }
  function lockChip(c,a,ok){
    c.classList.add('an-locked-ver');
    var lp=lockParts(a);
    var meta=(lp&&verMeta[lp.pkey])||{};
    var msg=a.lockver.msg||meta.msg||'';
    var date=a.lockver.date||meta.date||'';
    var fz=document.createElement('span');
    fz.className='an-lockchip'+(ok?'':' warn');
    fz.innerHTML=bic('lock')+' '+esc(a.lockver.commit);
    fz.title=(ok?'Locked to commit ':'Locked to commit (content '
      +'unavailable — showing live) ')+a.lockver.commit
      +(msg?' — “'+msg+'”':'')+(date?' · '+date:'')
      +'\nRefresh never changes this frame. Unlock via the ribbon.';
    c.appendChild(fz);
  }
  /* render a frame from a REMEMBERED body (the pre-refresh figure).
     The string used to be re-parsed through template.innerHTML on every
     call — multi-MB of HTML, per frame, per rebuild. Now parsed once per
     (html, part) and re-cloned; keyed by the string itself, so the cache
     is content-addressed and cannot go stale (2026-08-23 perf). */
  function framePartFromSnap(html,part){
    var byPart=snapNodeCache.get(html);
    if(!byPart){byPart={};snapNodeCache.set(html,byPart);}
    var pk=part||'auto';
    if(pk in byPart)
      return byPart[pk]?byPart[pk].cloneNode(true):null;
    var t=document.createElement('template');
    t.innerHTML=html;
    var b=t.content.firstElementChild;
    b=b?snapPart(b.cloneNode(true),part):null;
    byPart[pk]=b?b.cloneNode(true):null;
    return b;
  }
  function facetList(ref){
    var f=cellFacets(ref),out=[];
    if(f.figure) out.push('figure');
    if(f.output) out.push('output');
    if(f.code) out.push('code');
    return out;
  }
  /* split a frame into two adjacent frames — one per part (e.g. the
     figure beside its code), each labelled */
  function splitFrame(ai){
    var s=pres.slides[cur]; if(!s) return;
    var a=(s.annots||[])[ai]; if(!a||a.k!=='cell'||!a.ref) return;
    var facs=facetList(a.ref); if(facs.length<2) return;
    var cur0=partOf(a);
    var other=facs.filter(function(x){return x!==cur0;})[0];
    a.part=cur0;
    var w=a.w||46,h=a.h||56,x=a.x||6,y=a.y||6;
    /* split WITHIN the frame's own bounds so the two never overflow or
       overlap: side by side if wide enough, otherwise stacked */
    var half=(w-2)/2;
    if(half>=16){
      a.w=half;
      s.annots.push({k:'cell',ref:a.ref,part:other,
        x:x+half+2,y:y,w:w-half-2,h:h});
    } else {
      var hh=Math.max(16,(h-2)/2);
      a.h=hh;
      s.annots.push({k:'cell',ref:a.ref,part:other,
        x:x,y:y+hh+2,w:w,h:h-hh-2>=16?h-hh-2:hh});
    }
    markDirty();refresh();
  }
  /* the code/figure/output picker shown on a filled frame (+ split) */
  function buildPartChooser(s,ai){
    var a=(s.annots||[])[ai]; if(!a||!a.ref) return null;
    var facs=facetList(a.ref); if(facs.length<2) return null;
    var curp=partOf(a);
    var box=document.createElement('div');box.className='cellparts';
    /* let draw tools (edit mode) still start a shape over the button;
       in the builder (create) or select tool the button always acts */
    function guardDown(e){if(mode!=='edit'||tool==='select') e.stopPropagation();}
    function armed(){return mode!=='edit'||tool==='select';}
    /* T530: words and icons like every other button -- the pills read
       "figure / code / split" in lower-case mono beside sans buttons */
    var PART_IC={figure:'plots',code:'code',output:'output'};
    facs.forEach(function(fp){
      var b=document.createElement('button');
      b.className='cellpartbtn'+(fp===curp?' on':'');
      b.innerHTML=(PART_IC[fp]?bic(PART_IC[fp])+' ':'')
        +esc(fp.charAt(0).toUpperCase()+fp.slice(1));
      b.title='Show the '+fp+' in this frame';
      b.addEventListener('mousedown',guardDown);
      b.addEventListener('click',function(e){
        if(!armed()) return;
        e.stopPropagation();
        if(partOf(a)===fp&&a.part) return;
        a.part=fp;markDirty();refresh();});
      box.appendChild(b);
    });
    var sp=document.createElement('button');
    sp.className='cellpartbtn split';sp.innerHTML=bic('outline')+' Split in two';
    sp.title='Split into two frames — one for each part';
    sp.addEventListener('mousedown',guardDown);
    sp.addEventListener('click',function(e){
      if(!armed()) return;
      e.stopPropagation();splitFrame(ai);});
    box.appendChild(sp);
    return box;
  }
  /* through the page's one typesetter (app.js jvMath): synchronous
     whenever MathJax is there -- callers re-fit and measure right after
     -- loaded on first need, a no-op when nothing reads as TeX, and
     serialised with every other MathJax call on the page */
  function typeset(el){
    if(window.jvMath) return window.jvMath.typeset(el);
    if(window.MathJax&&MathJax.typesetPromise)
      return MathJax.typesetPromise([el]).catch(function(){});
  }
  /* MathJax there -- loading it if this page has not needed it yet --
     then ok(); no() when it cannot be had (offline, a blocked CDN) */
  function mathsThen(ok,no){
    var M=window.jvMath;
    (M?M.ensure():Promise.resolve()).then(function(){
      if(window.MathJax&&MathJax.typesetPromise) ok(); else no();
    },no);
  }
  /* A <style>'s rules, as text. MathJax writes its stylesheet as text on
     its FIRST typeset pass and adds every glyph after that through the
     CSSOM (insertRule), which textContent never shows -- and since the
     page typesets as it is read (2026-10-09), that first pass is only
     the first screen's. So a copy of the page's CSS (the standalone HTML
     export, the presenter window) reads MathJax's sheet rule by rule. */
  function styleText(st){
    if(st&&st.id==='MJX-CHTML-styles'&&st.sheet){
      try{
        return [].map.call(st.sheet.cssRules,function(r){
          return r.cssText;}).join('\n');
      }catch(e){}
    }
    return st.textContent;
  }
  /* the same figure, whatever MathJax did to it: its markup records the
     ORDER this page typeset equations in (ctxtmenu_counter) and the font
     scale it measured at that moment, neither of which is the figure.
     The page typesets as it is read now, so that order follows your
     scrolling -- and a kept copy must not read as "out of date" for it */
  function sameCardHtml(a,b){
    if(a===b) return true;
    a=String(a||'');b=String(b||'');
    if(a.indexOf('<mjx-container')<0||b.indexOf('<mjx-container')<0)
      return false;
    return mjxNeutral(a)===mjxNeutral(b);
  }
  function mjxNeutral(h){
    return h.replace(/<mjx-container\b[^>]*>/g,function(t){
      return t.replace(/\sctxtmenu_counter="\d+"/,'')
        .replace(/font-size:\s*[\d.]+%;?\s*/,'');
    });
  }
  /* fn calls MathJax itself: run once it is there, never overlapping the
     page's own typesetting. Rejects when there is no MathJax to be had. */
  function mathsRun(fn){
    var M=window.jvMath;
    if(M) return M.run(fn);
    if(window.MathJax&&MathJax.typesetPromise)
      return Promise.resolve().then(fn);
    return Promise.reject(new Error('No maths renderer'));
  }
  function multiNb(){return APP.order.length>1;}
  function nbChip(cls,stem){
    var c=document.createElement('span');c.className=cls;
    c.textContent=stem;return c;
  }
  /* ---------- view mode: slide rendering + vertical code trail ------
     Horizontal = the story; vertical = how each slide was made. Every
     framed card contributes its full upstream chain (open data ->
     transforms -> plot), deduped, in execution order — one cell per
     screen below the slide. */
  var vGroups=[];
  var traceSel=0;          /* which plot's trace shows (thumbnail pick) */
  var traceView='cells';   /* 'cells' list or 'tree' (docs tree, reused) */
  var TRACE_COLORS=['#39a9c0','#ff6b57','#f0a848','#46a892',
    '#c98fd0','#5b8dd6'];
  function hiddenSet(s){
    var h={};(s&&s.hidden||[]).forEach(function(r){h[r]=1;});return h;
  }
  function toggleHidden(s,ns){
    if(!s) return;
    s.hidden=s.hidden||[];
    var i=s.hidden.indexOf(ns);
    if(i>=0) s.hidden.splice(i,1); else s.hidden.push(ns);
    markDirty();
  }
  /* ---- reusable code trace used by the presentation's slide code-trail
     (the docs "Plot trace" instead opens a tab of cloned docs cards) ----
     spec = { groups:[{it,steps,color}], list:()=>[ns hidden],
              toggle:(ns)=>void (persist), showHiddenRef:{v:bool} } */
  function renderTrace(spec){
    spec.showHiddenRef=spec.showHiddenRef||{v:false};
    function rebuild(oldNode){
      var fresh=traceNode(spec,rebuild);
      if(oldNode&&oldNode.parentNode)
        oldNode.parentNode.replaceChild(fresh,oldNode);
      return fresh;
    }
    return rebuild(null);
  }
  /* the presentation wrapper: groups come from the slide's framed plots */
  function buildTrace(s){
    return renderTrace({
      groups:vGroups,
      list:function(){return (s&&s.hidden)||[];},
      toggle:function(ns){toggleHidden(s,ns);}
    });
  }
  /* one lineage group for a SINGLE plot/item (the docs popup) */
  function lineageForItem(ns){
    var it=ITEMS[ns]; if(!it) return null;
    var steps=[],seen={};
    (it.chain||[]).forEach(function(anchor){
      var up=ITEMS[nsKey(it.nb,anchor)];
      /* markdown notes that name a lineage variable ride along in the trace */
      if(up&&(up.hasCode||up.kind==='note')&&!seen[up.ns]){
        seen[up.ns]=1;steps.push(up);}
    });
    if(it.hasCode&&!seen[it.ns]) steps.push(it);
    return {it:it,steps:steps,color:TRACE_COLORS[0]};
  }
  /* ---- per-plot dependency graph (the docs popup) ---- */
  /* the code-kind palette: app.js owns the table (window.SemView.kindFill
     — app.js is spliced before this file in page.html). The literal here
     is only the fallback for a page carrying the deck without app.js. */
  var NODE_FILL=(window.SemView&&window.SemView.kindFill)
    ||{figure:'#39a9c0',diagnostic:'#39a9c0',dataset:'#4d90c0',
    transform:'#5b7589',metric:'#46a892',note:'#cf9a4e',text:'#8ba0b2',
    imports:'#a3855c','function':'#46a892',data:'#4d90c0',constant:'#9a7cc0',
    settings:'#5b7589',plotting:'#39a9c0',print:'#cf9a4e',code:'#8ba0b2'};
  function nodeColor(st){
    if(st.kind==='figure'||st.kind==='diagnostic') return NODE_FILL.figure;
    if(st.kind==='note') return NODE_FILL.note;
    var cks=st.codeKinds||[st.codeKind||'code'];
    return NODE_FILL[cks[0]]||NODE_FILL[st.kind]||'#8ba0b2';
  }
  var SVGNS='http://www.w3.org/2000/svg';
  /* ---- shapes for the "+ Shapes" tool. Geometric ones are SVG <path>s in a
     0..100 box (stretched to the frame, non-scaling stroke); !/? are glyphs.
     'rect' + 'ellipse' stay CSS-drawn (see the an-rect renderer). ---- */
  var SHAPE_PATHS={
    triangle:'M50 6 L95 92 L5 92 Z',
    diamond:'M50 4 L96 50 L50 96 L4 50 Z',
    pentagon:'M50 5 L95 39 L77 93 L23 93 L5 39 Z',
    hexagon:'M27 6 H73 L97 50 L73 94 H27 L3 50 Z',
    star:'M50 3 L61 37 H97 L68 59 L79 95 L50 73 L21 95 L32 59 L3 37 H39 Z',
    cross:'M37 5 H63 V37 H95 V63 H63 V95 H37 V63 H5 V37 H37 Z',
    arrow:'M5 36 H60 V18 L96 50 L60 82 V64 H5 Z',
    heart:'M50 90 C6 56 12 16 50 40 C88 16 94 56 50 90 Z',
    cloud:'M30 82 C12 82 6 58 24 52 C20 30 52 22 58 38 '
      +'C72 26 92 40 84 56 C98 58 96 82 78 82 Z',
    bubble:'M8 8 H92 V66 H44 L24 90 V66 H8 Z',
    lightning:'M58 4 L20 56 H46 L38 96 L82 40 H54 Z',
    /* T419: BRACKETS AND BRACES (2026-09-14, user: "Having things like
       large angle brackets and stuff is always really useful but they
       are currently missing"). Open strokes, not outlines: no Z, and
       SHAPE_OPEN keeps the fill off them. Drawn tall and thin, and the
       box stretches them like every other path. */
    langle:'M88 4 L12 50 L88 96',
    rangle:'M12 4 L88 50 L12 96',
    lbracket:'M82 4 H24 V96 H82',
    rbracket:'M18 4 H76 V96 H18',
    lbrace:'M80 4 C56 4 62 22 62 32 C62 44 60 48 30 50 '
      +'C60 52 62 56 62 68 C62 78 56 96 80 96',
    rbrace:'M20 4 C44 4 38 22 38 32 C38 44 40 48 70 50 '
      +'C40 52 38 56 38 68 C38 78 44 96 20 96'
  };
  /* a shape that is a line, not a region: nothing to fill, ends round */
  var SHAPE_OPEN={langle:1,rangle:1,lbracket:1,rbracket:1,lbrace:1,rbrace:1};
  var SHAPE_GLYPH={exclaim:'!',question:'?'};

  /* ---- line styles, arrow heads, gradients ---------------------------
     One table per thing, each carrying BOTH how it draws on the canvas
     (SVG) and what it becomes in PowerPoint (OOXML) — the two cannot
     drift, which is the only way "the poster and the .pptx look the
     same" stays true as this list grows. */
  var LINE_STYLES=[
    {id:'solid',label:'Solid',dash:'',ppt:'solid'},
    {id:'dash',label:'Dashed',dash:'9 7',ppt:'dash'},
    {id:'dot',label:'Dotted',dash:'1 6',ppt:'sysDot'},
    {id:'dashdot',label:'Dash-dot',dash:'12 5 2 5',ppt:'dashDot'},
    {id:'lgdash',label:'Long dash',dash:'20 8',ppt:'lgDash'}];
  var LINE_DASH={},LINE_PPT={};
  LINE_STYLES.forEach(function(s){
    LINE_DASH[s.id]=s.dash;LINE_PPT[s.id]=s.ppt;});
  /* an older poster stored a boolean `dash`; read it as the dashed style */
  function lineStyle(a){
    return a.style||(a.dash?'dash':'solid');
  }
  function dashFor(a){return LINE_DASH[lineStyle(a)]||'';}

  /* ---- line weight, in the same currency as everything else ----------
     Every dimension on a page is page-relative: x/y/w/h are percentages,
     text is a percentage of page height resolved at render time (fontPx).
     Line weight was the one exception — `a.sw` went straight out as CSS
     px — so it was the only thing that did not move when the page did.
     Measured: zooming 3.74x grew the text 3.75x and the stroke 1.00x, so
     a line fell from 12.7% of the text height to 3.4% (2026-08-10, user:
     "as you zoom in and out the line stays the same thick on the screen
     whilst the presentation gets smaller").

     `a.sw` now means "pixels on a page 720px tall". 720 is not arbitrary:
     it is the height the 16:9 print page has always been built at, and it
     is within 0.3% of a true 191mm at 96dpi. So every number already on
     disk keeps exactly the weight it has today on a slide, and the same
     number finally means something on a poster, where 3px of ink on a
     1189mm sheet was a 0.8mm hairline beside 31mm text. */
  var SW_REF_H=720;
  var SW_DEFAULT=3;
  function swOf(a){return (a&&a.sw!=null)?a.sw:SW_DEFAULT;}
  /* the layer's height -- measured ONCE per render while renderAnnots
     is drawing it (see ONE MEASURE OF THE PAGE there), and live at any
     other time */
  function layerH(layer){
    var p=layer._hPass;
    if(p&&p.h) return p.h;
    /* EVERY PAGE OF AN EXPORT IS THE SAME PAGE (2026-10-09, speed, critic
       #6). buildPrintRoot lays out one .print-page per slide, all of the
       one size the deck's page has, and each render measured its own --
       a forced layout of the growing export per slide, 184 ms of a
       60-slide PDF at 4x. The first page measured answers for the rest
       of that build (printPageH, set and cleared by buildPrintRoot). */
    var h;
    if(printPageH&&printPageH.root.contains(layer)){
      if(!printPageH.h) printPageH.h=layer.getBoundingClientRect().height||0;
      h=printPageH.h;
    } else h=layer.getBoundingClientRect().height||0;
    if(p) p.h=h;
    return h;
  }
  var printPageH=null;
  function pageScale(layer){
    var h=layer?layerH(layer):0;
    return (h||SW_REF_H)/SW_REF_H;
  }
  function strokePx(a,layer){
    /* the same 0.5px guard fontPx uses: it only stops a collapse to zero,
       it is not a legibility floor */
    return Math.max(0.5,swOf(a)*pageScale(layer));
  }
  /* a dash pattern is measured in the same units as the stroke it dashes,
     so it has to scale with it. Left unscaled, a 9px gap on a stroke that
     had shrunk to 0.5px read as a row of dots, and a different pattern at
     every zoom level. */
  function dashPx(a,layer){
    var d=dashFor(a); if(!d) return '';
    var k=pageScale(layer);
    return d.split(' ').map(function(n){
      return (parseFloat(n)*k).toFixed(2);}).join(' ');
  }
  /* what this weight will actually print, for the controls and preflight */
  function swMm(a,pg){
    return swOf(a)/SW_REF_H*((pg||pageOf()).mm[1]||191);
  }

  /* Head shapes are drawn in a 10x10 marker box. `ppt` is the OOXML
     head type; PowerPoint has no "bar", so it degrades to none there and
     the shape says so in its tooltip. */
  var HEADS=[
    {id:'none',label:'None',ppt:'none'},
    {id:'triangle',label:'Triangle',ppt:'triangle',
     path:'M0 0 L10 5 L0 10 z'},
    {id:'stealth',label:'Stealth',ppt:'stealth',
     path:'M0 0 L10 5 L0 10 L3 5 z'},
    {id:'open',label:'Open',ppt:'arrow',
     path:'M0 0 L10 5 L0 10',open:1},
    {id:'diamond',label:'Diamond',ppt:'diamond',
     path:'M0 5 L5 0 L10 5 L5 10 z'},
    {id:'oval',label:'Round',ppt:'oval',
     path:'M5 0 A5 5 0 1 1 4.99 0 z'},
    {id:'bar',label:'Bar',ppt:'none',
     path:'M9 0 L9 10',open:1}];
  var HEAD_BY={};HEADS.forEach(function(h){HEAD_BY[h.id]=h;});
  var HEAD_SIZES=[
    {id:'sm',label:'Small',mul:4.5,ppt:'sm'},
    {id:'md',label:'Medium',mul:6.5,ppt:'med'},
    {id:'lg',label:'Large',mul:9.5,ppt:'lg'},
    {id:'xl',label:'Huge',mul:13,ppt:'lg'}];
  var HEADSZ_BY={};HEAD_SIZES.forEach(function(s){HEADSZ_BY[s.id]=s;});
  /* the end head: older posters used `nohead` to mean "this is a line" */
  function headEnd(a){
    if(a.head!=null) return a.head;
    return a.nohead?'none':'triangle';
  }
  function headStart(a){return a.tail||'none';}
  function headSize(a){return HEADSZ_BY[a.hsz]||HEADSZ_BY.md;}

  /* ---- attached endpoints --------------------------------------------
     An endpoint can be pinned to an item (`a.c1`/`a.c2` = {i:index}).
     Its coordinates are then DERIVED at render time from where that item
     currently is, which is what makes the arrow follow it around. The
     stored x/y stay as a fallback for when the target goes away. */
  function edgePoint(r,tox,toy){
    /* where a line from the rect's centre towards (tox,toy) leaves it —
       so the arrow stops at the border instead of burying its head in
       the middle of the figure */
    var cx=(r.l+r.r)/2,cy=(r.t+r.b)/2;
    var dx=tox-cx,dy=toy-cy;
    if(!dx&&!dy) return {x:cx,y:cy};
    var hw=(r.r-r.l)/2,hh=(r.b-r.t)/2;
    var sx=dx?hw/Math.abs(dx):Infinity,sy=dy?hh/Math.abs(dy):Infinity;
    var t=Math.min(sx,sy);
    return {x:cx+dx*t,y:cy+dy*t};
  }
  function tiedRect(layer,s,c){
    if(!c||typeof c.i!=='number') return null;
    var t=(s.annots||[])[c.i];
    if(!t||t.hide||t.k==='arrow') return null;
    return annotRectPct(layer,s,c.i);
  }
  /* an ELBOW leaves and enters a box at the middle of the side facing
     the other end -- the way an org chart is drawn, and the way the
     diagram dialog's preview draws it. Where the centre line crosses the
     border, a hierarchy's six drops left their parent at six scattered
     points and the outer two ran down its sides (2026-10-08 review).
     Null when the other end is not clear of the box on that axis. */
  function elbowPoint(r,bend,far){
    var cx=(r.l+r.r)/2,cy=(r.t+r.b)/2;
    if(bend==='v'){
      if(far.y>=r.b) return {x:cx,y:r.b};
      if(far.y<=r.t) return {x:cx,y:r.t};
    } else {
      if(far.x>=r.r) return {x:r.r,y:cy};
      if(far.x<=r.l) return {x:r.l,y:cy};
    }
    return null;
  }
  function arrowEnds(layer,s,a,idx){
    var e={x1:a.x1,y1:a.y1,x2:a.x2,y2:a.y2};
    var r1=tiedRect(layer,s,a.c1),r2=tiedRect(layer,s,a.c2);
    /* aim each attached end at the OTHER end, so both slide around their
       item's border as either one moves */
    var far1=r2?{x:(r2.l+r2.r)/2,y:(r2.t+r2.b)/2}:{x:a.x2,y:a.y2};
    var far2=r1?{x:(r1.l+r1.r)/2,y:(r1.t+r1.b)/2}:{x:a.x1,y:a.y1};
    /* corners dragged in by hand win over the canned route (arrowPath) */
    var bd=((a.bend==='v'||a.bend==='h')&&!arrowMids(a).length)?a.bend:'';
    if(r1){var p1=(bd&&elbowPoint(r1,bd,far1))||edgePoint(r1,far1.x,far1.y);
      e.x1=p1.x;e.y1=p1.y;}
    if(r2){var p2=(bd&&elbowPoint(r2,bd,far2))||edgePoint(r2,far2.x,far2.y);
      e.x2=p2.x;e.y2=p2.y;}
    return e;
  }
  /* straight, curved (quadratic through an offset midpoint) or elbowed.
     Coordinates are PERCENTAGES of the page, and must be converted to
     pixels here: <line> accepted x1="20%", but path data has no units —
     "M20 50" means 20px,50px, so every line and arrow was drawn in a
     60-pixel stub in the top-left corner (2026-08-07, user: "arrow just
     appears in the top left"). Scaling here rather than with a viewBox
     keeps stroke width and arrowheads circular instead of stretched. */
  /* the corners a line is dragged through, if any. Percentages of the
     page like everything else, in the order they are walked. An arrow
     without them is exactly what it always was - two endpoints - so
     nothing that never touches a corner notices they exist (2026-08-20,
     user: "when adding arrows you can really edit all the points and make
     it the exact shape you want"). */
  function arrowMids(a){
    return (a&&Array.isArray(a.mid))?a.mid:[];
  }
  function arrowPath(e,a,W,H){
    W=W||100;H=H||100;
    var x1=e.x1/100*W,y1=e.y1/100*H,x2=e.x2/100*W,y2=e.y2/100*H;
    /* CORNERS win over every canned route: once you have dragged one in by
       hand, "curved" and "elbowed" are no longer describing the line you
       drew. Smoothed with the same Catmull-Rom the freehand tool uses, so
       a dragged corner reads as a bend rather than a kink - unless
       a.sharp says the kink was the point. */
    var mids=arrowMids(a);
    if(mids.length){
      var pts=[[x1,y1]].concat(mids.map(function(m){
        return [m[0]/100*W,m[1]/100*H];}),[[x2,y2]]);
      if(a.sharp)
        return 'M'+pts.map(function(q){return q[0]+' '+q[1];}).join(' L');
      var f=function(n){return Math.round(n*100)/100;};
      var d2='M'+f(pts[0][0])+' '+f(pts[0][1]);
      for(var k=0;k<pts.length-1;k++){
        var q0=pts[k-1]||pts[k],q1=pts[k],q2=pts[k+1],q3=pts[k+2]||pts[k+1];
        d2+='C'+f(q1[0]+(q2[0]-q0[0])/6)+' '+f(q1[1]+(q2[1]-q0[1])/6)
          +','+f(q2[0]-(q3[0]-q1[0])/6)+' '+f(q2[1]-(q3[1]-q1[1])/6)
          +','+f(q2[0])+' '+f(q2[1]);
      }
      return d2;
    }
    var bend=a.bend||'none';
    if(bend==='h')      /* out sideways first, then down/up */
      return 'M'+x1+' '+y1+' L'+((x1+x2)/2)+' '+y1
        +' L'+((x1+x2)/2)+' '+y2+' L'+x2+' '+y2;
    if(bend==='v')
      return 'M'+x1+' '+y1+' L'+x1+' '+((y1+y2)/2)
        +' L'+x2+' '+((y1+y2)/2)+' L'+x2+' '+y2;
    var cv=+a.curve||0;
    if(!cv) return 'M'+x1+' '+y1+' L'+x2+' '+y2;
    /* bow the line out perpendicular to itself; `curve` is a percentage of
       the page, so it scales to pixels like the endpoints do */
    var mx=(x1+x2)/2,my=(y1+y2)/2;
    var dx=x2-x1,dy=y2-y1,len=Math.sqrt(dx*dx+dy*dy)||1;
    var nx=-dy/len,ny=dx/len;
    var bow=cv/100*Math.min(W,H);
    return 'M'+x1+' '+y1+' Q'+(mx+nx*bow)+' '+(my+ny*bow)+' '+x2+' '+y2;
  }
  /* menu order + short labels */
  var SHAPE_LIST=[
    ['rect','Rectangle'],['ellipse','Ellipse'],['triangle','Triangle'],
    ['diamond','Diamond'],['pentagon','Pentagon'],['hexagon','Hexagon'],
    ['star','Star'],['cross','Plus'],['arrow','Arrow'],['heart','Heart'],
    ['cloud','Cloud'],['bubble','Speech'],['lightning','Bolt'],
    ['exclaim','Exclaim'],['question','Question'],
    /* T419 */
    ['langle','Angle \u2039'],['rangle','Angle \u203a'],
    ['lbrace','Brace {'],['rbrace','Brace }'],
    ['lbracket','Bracket ['],['rbracket','Bracket ]']];
  /* the fill a shape actually paints: none, a tint of its own line
     colour (the original behaviour, kept for existing posters), a solid
     colour, or a gradient — linear at an angle, or radiating from the
     centre */
  /* ---- GRADIENTS -------------------------------------------------------
     A gradient is a list of STOPS: [{o:0..1, c:'#rrggbb'}, ...]. It used to
     be exactly two colours in `a` and `b`, which made a three-colour
     gradient impossible to express at all (2026-08-20, user asked for
     "gradients from different directions, multiple colours").
     `a`/`b` are still read on the way IN so every deck saved before this
     keeps its gradient, and every paint boundary projects the resolved
     first/last stops back onto them so the two-colour PowerPoint writer
     need not understand the multi-stop model. */
  function gradStops(g){
    if(!g) return [];
    if(Array.isArray(g.stops)&&g.stops.length>=2) return g.stops;
    return [{o:0,c:g.a||'#39a9c0'},{o:1,c:g.b||'transparent'}];
  }
  /* Resolve a gradient at a PAINT boundary without baking its token
     references back into the deck. Keeping the legacy a/b projection in
     step with the resolved stop list matters to PowerPoint, whose writer
     deliberately supports two stops while the canvas supports any number. */
  function tokenGradient(g,col){
    if(!g) return g;
    var out=deep(g),fallback=tokVal(col)||'#39a9c0';
    out.stops=gradStops(g).map(function(st){
      var cp=deep(st);
      cp.c=tokVal(st.c)||fallback;
      return cp;
    });
    out.a=out.stops[0].c;
    out.b=out.stops[out.stops.length-1].c;
    return out;
  }
  function gradCss(g,col){
    var st=tokenGradient(g,col).stops.map(function(s2){
      return s2.c+' '+Math.round((s2.o||0)*100)+'%';
    }).join(', ');
    if(g.type==='radial')
      return 'radial-gradient(circle at '
        +(g.cx==null?50:g.cx)+'% '+(g.cy==null?50:g.cy)+'%, '+st+')';
    /* CSS measures its angle from "up" and clockwise; the model keeps the
       maths convention the SVG paint server uses, so the two differ by 90 */
    return 'linear-gradient('+((+g.ang||0)+90)+'deg, '+st+')';
  }
  function cssFill(a,col){
    if(!a.fill&&!a.grad) return 'transparent';
    if(a.grad) return gradCss(a.grad,col);
    if(a.fillc) return tokVal(a.fillc);
    return shapeFill(col,0x26/255);
  }
  /* `sw` arrives already resolved to screen pixels by strokePx, and the
     dash has to be resolved against the same page so the two agree */
  /* ---- FREEHAND ------------------------------------------------------
     A drawn stroke is stored the way a shape is — a box in page
     percentages — with its points normalised to 0..1 INSIDE that box. So
     moving, resizing, rotating, opacity, lock, hide, the Objects pane and
     the selection handles all work on it without knowing it exists: they
     only ever touch x/y/w/h. Keeping raw page coordinates instead would
     have meant a special case in every one of those.
     Catmull-Rom through the points, converted to cubics: a hand-drawn
     line has to read as a curve, not as the polygon the mouse reported. */
  function drawPathD(pts){
    if(!pts||!pts.length) return '';
    var P=pts.map(function(q){return [q[0]*100,q[1]*100];});
    var f=function(n){return (Math.round(n*100)/100);};
    if(P.length===1) return 'M'+f(P[0][0])+' '+f(P[0][1])+'l0 0';
    var d='M'+f(P[0][0])+' '+f(P[0][1]);
    for(var i=0;i<P.length-1;i++){
      var p0=P[i-1]||P[i],p1=P[i],p2=P[i+1],p3=P[i+2]||P[i+1];
      d+='C'+f(p1[0]+(p2[0]-p0[0])/6)+' '+f(p1[1]+(p2[1]-p0[1])/6)
        +','+f(p2[0]-(p3[0]-p1[0])/6)+' '+f(p2[1]-(p3[1]-p1[1])/6)
        +','+f(p2[0])+' '+f(p2[1]);
    }
    return d;
  }
  function drawFreeSvg(a,layer){
    var svg=document.createElementNS(SVGNS,'svg');
    svg.setAttribute('class','an-shape-svg');
    svg.setAttribute('viewBox','0 0 100 100');
    /* stretched to the box like a shape, so the stroke needs the same
       non-scaling-stroke or it would thicken as you widen the drawing */
    svg.setAttribute('preserveAspectRatio','none');
    var p=document.createElementNS(SVGNS,'path');
    p.setAttribute('d',drawPathD(a.pts));
    p.setAttribute('fill','none');
    p.setAttribute('stroke',tokVal(a.color)||'#ff6b57');
    p.setAttribute('stroke-width',strokePx(a,layer));
    p.setAttribute('vector-effect','non-scaling-stroke');
    p.setAttribute('stroke-linecap','round');
    p.setAttribute('stroke-linejoin','round');
    var dsh=dashPx(a,layer);
    if(dsh) p.setAttribute('stroke-dasharray',dsh);
    svg.appendChild(p);
    return svg;
  }
  function drawShapeSvg(shp,col,sw,a,idx,layer){
    col=tokVal(col)||'#ff6b57';
    var dash=dashPx(a,layer);
    var svg=document.createElementNS(SVGNS,'svg');
    svg.setAttribute('class','an-shape-svg');
    svg.setAttribute('viewBox','0 0 100 100');
    var licon=(typeof lineIcon==='function')?lineIcon(shp):null;
    if(licon){
      /* T560: an icon, on its 24-unit grid, kept in proportion, its
         lines the shape's own colour and weight */
      svg.setAttribute('viewBox','0 0 24 24');
      svg.setAttribute('preserveAspectRatio','xMidYMid meet');
      var ip=document.createElementNS(SVGNS,'path');
      ip.setAttribute('d',lineIconD(licon[3]));
      ip.setAttribute('fill',a.fill?(tokVal(a.fillc)||shapeFill(col,0x2b/255))
        :'none');
      ip.setAttribute('stroke',col);
      ip.setAttribute('stroke-width',sw);
      ip.setAttribute('vector-effect','non-scaling-stroke');
      ip.setAttribute('stroke-linecap','round');
      ip.setAttribute('stroke-linejoin','round');
      if(dash) ip.setAttribute('stroke-dasharray',dash);
      svg.appendChild(ip);
      return svg;
    }
    if(SHAPE_GLYPH[shp]){
      svg.setAttribute('preserveAspectRatio','xMidYMid meet');
      var tx=document.createElementNS(SVGNS,'text');
      tx.setAttribute('x','50');tx.setAttribute('y','54');
      tx.setAttribute('text-anchor','middle');
      tx.setAttribute('dominant-baseline','central');
      tx.setAttribute('font-size','104');tx.setAttribute('font-weight','800');
      tx.setAttribute('fill',col);   /* font comes from CSS (.an-shape-svg text) */
      tx.textContent=SHAPE_GLYPH[shp];
      svg.appendChild(tx);
    } else {
      svg.setAttribute('preserveAspectRatio','none');
      var p=document.createElementNS(SVGNS,'path');
      /* The canvas draws a rectangle and an ellipse as a CSS box, so
         neither is in SHAPE_PATHS -- and the thumbnails, which draw every
         shape through here, wrote them as d="": the two commonest shapes
         were missing from every slide in the strip (2026-10-01, found
         driving T572). Their outlines, for the callers that need a path. */
      p.setAttribute('d',SHAPE_PATHS[shp]||(shp==='ellipse'
        ?'M1 50 A49 49 0 1 0 99 50 A49 49 0 1 0 1 50 Z'
        :shp==='rect'?'M1 1 H99 V99 H1 Z':''));
      var fillVal='none';
      if(SHAPE_OPEN[shp]){
        /* T419: a bracket is a stroke; a fill would paint the page
           between its arms */
        p.setAttribute('stroke-linecap','round');
      } else if(a.grad){
        /* SVG cannot take a CSS gradient string, so the same gradient is
           declared as a paint server and referenced */
        var gid='an-grad-'+(idx==null?'x':idx);
        var gd=document.createElementNS(SVGNS,'defs');
        var g=tokenGradient(a.grad,col);
        var gel=document.createElementNS(SVGNS,
          g.type==='radial'?'radialGradient':'linearGradient');
        gel.setAttribute('id',gid);
        if(g.type!=='radial'){
          var rad=((+g.ang||0))*Math.PI/180;
          gel.setAttribute('x1',(50-50*Math.cos(rad))+'%');
          gel.setAttribute('y1',(50-50*Math.sin(rad))+'%');
          gel.setAttribute('x2',(50+50*Math.cos(rad))+'%');
          gel.setAttribute('y2',(50+50*Math.sin(rad))+'%');
        } else {
          gel.setAttribute('cx',(g.cx==null?50:g.cx)+'%');
          gel.setAttribute('cy',(g.cy==null?50:g.cy)+'%');
          gel.setAttribute('r','62%');
        }
        g.stops.forEach(function(st){
          var s2=document.createElementNS(SVGNS,'stop');
          s2.setAttribute('offset',st.o==null?0:st.o);
          s2.setAttribute('stop-color',st.c);
          gel.appendChild(s2);
        });
        gd.appendChild(gel);svg.appendChild(gd);
        fillVal='url(#'+gid+')';
      } else if(a.fill){
        fillVal=tokVal(a.fillc)||shapeFill(col,0x2b/255);
      }
      p.setAttribute('fill',fillVal);
      p.setAttribute('stroke',col);
      p.setAttribute('stroke-width',sw);
      /* the shape SVG is preserveAspectRatio="none", so without this the
         outline would stretch with the box instead of staying round */
      p.setAttribute('vector-effect','non-scaling-stroke');
      p.setAttribute('stroke-linejoin','round');
      if(dash) p.setAttribute('stroke-dasharray',dash);
      svg.appendChild(p);
    }
    return svg;
  }
  /* ---- text on a curved baseline -------------------------------------
     `a.arc` bows the baseline: positive arches up, negative sags down,
     and the magnitude is how far in percent of the box's width. The flat
     span stays in the DOM (hidden) because it is what carries selection,
     editing and the stored text — the SVG is a rendering of it. */
  function applyTextArc(box,span,a,idx){
    var r=box.getBoundingClientRect();
    var w=r.width,h=r.height;
    if(!w||!h) return;
    var txt=String(a.text||'');
    if(!txt.trim()) return;
    var cs=window.getComputedStyle(span);
    var fs=parseFloat(cs.fontSize)||16;
    var arc=Math.max(-95,Math.min(95,+a.arc||0));
    /* The bow is bounded by the box's OWN height, not its width: scaled
       off the width, an arch on a wide title peaked hundreds of px above
       a one-line box and drew itself off the page. The box is given room
       to hold the arch (see the min-height set before measuring), so a
       deeper curve makes the box taller rather than escaping it. */
    var pad=fs*0.3;
    var avail=Math.max(0,h-fs-2*pad);
    var bow=avail*Math.min(1,Math.abs(arc)/55)*(arc>=0?1:-1);
    var baseY=(arc>=0)?(h-pad):(pad+fs*0.85);
    var svg=document.createElementNS(SVGNS,'svg');
    svg.setAttribute('class','an-arcsvg');
    svg.setAttribute('viewBox','0 0 '+w+' '+h);
    svg.setAttribute('width',w);svg.setAttribute('height',h);
    var defs=document.createElementNS(SVGNS,'defs');
    var pid='an-arcp-'+idx;
    var p=document.createElementNS(SVGNS,'path');
    p.setAttribute('id',pid);
    p.setAttribute('fill','none');
    p.setAttribute('d','M '+pad+' '+baseY+' Q '+(w/2)+' '+(baseY-2*bow)
      +' '+(w-pad)+' '+baseY);
    defs.appendChild(p);svg.appendChild(defs);
    var t=document.createElementNS(SVGNS,'text');
    t.setAttribute('font-size',fs);
    t.setAttribute('font-family',cs.fontFamily);
    t.setAttribute('font-weight',cs.fontWeight);
    t.setAttribute('font-style',cs.fontStyle);
    t.setAttribute('fill',cs.color);
    var tp=document.createElementNS(SVGNS,'textPath');
    tp.setAttribute('href','#'+pid);
    tp.setAttributeNS('http://www.w3.org/1999/xlink','xlink:href','#'+pid);
    tp.setAttribute('startOffset','50%');
    tp.setAttribute('text-anchor','middle');
    tp.textContent=txt.replace(/\n+/g,' ');
    t.appendChild(tp);svg.appendChild(t);
    box.classList.add('an-arced');
    box.appendChild(svg);
  }
  function plotGraph(group,onNode){
    if(!group) return null;
    /* the dependency graph is CODE lineage — linked markdown notes ride along
       in the trace's card list but are not graph nodes (they aren't
       computational deps, and mixing them in creates note<->definer cycles
       that the transitive reduction can't lay out) */
    var steps=group.steps.filter(function(s){return s.kind!=='note';});
    if(steps.length<2) return null;                 /* nothing to draw */
    var n=steps.length,idx={},i;
    for(i=0;i<n;i++) idx[steps[i].ns]=i;
    /* each step's ancestors that are also in this plot's set (from chain) */
    var anc=steps.map(function(s){
      var set={};
      (s.chain||[]).forEach(function(a){
        var ns=nsKey(s.nb,a); if(idx[ns]!==undefined) set[ns]=1;});
      return set;
    });
    /* direct parents = transitive reduction (drop ancestors reachable
       through another ancestor) */
    var parents=steps.map(function(s,i2){
      var a=Object.keys(anc[i2]);
      return a.filter(function(p){
        return !a.some(function(q){
          return q!==p&&anc[idx[q]]&&anc[idx[q]][p];});
      });
    });
    var depth=[]; for(i=0;i<n;i++) depth.push(-1);
    function dep(i2){
      if(depth[i2]>=0) return depth[i2];
      depth[i2]=0;   /* cycle guard */
      var m=0; parents[i2].forEach(function(p){
        m=Math.max(m,dep(idx[p])+1);});
      depth[i2]=m; return m;
    }
    for(i=0;i<n;i++) dep(i);
    var maxD=0; depth.forEach(function(v){if(v>maxD)maxD=v;});
    var layers=[],L; for(L=0;L<=maxD;L++) layers.push([]);
    for(i=0;i<n;i++) layers[depth[i]].push(i);
    var NW=152,NH=30,GX=20,GY=52,PADX=14,PADY=14,maxCols=0;
    layers.forEach(function(l){if(l.length>maxCols)maxCols=l.length;});
    var W=PADX*2+maxCols*NW+(maxCols-1)*GX;
    var H=PADY*2+(maxD+1)*NH+maxD*GY,pos={};
    layers.forEach(function(l,Ld){
      var rowW=l.length*NW+(l.length-1)*GX,x0=(W-rowW)/2;
      l.forEach(function(i2,k){
        pos[i2]={x:x0+k*(NW+GX),y:PADY+Ld*(NH+GY)};});
    });
    var svg=document.createElementNS(SVGNS,'svg');
    svg.setAttribute('class','plotgraph');
    svg.setAttribute('viewBox','0 0 '+W+' '+H);
    svg.setAttribute('preserveAspectRatio','xMidYMin meet');
    svg.style.maxHeight=Math.min(H,300)+'px';
    steps.forEach(function(s,i2){
      parents[i2].forEach(function(p){
        var a=pos[idx[p]],b=pos[i2];
        var x1=a.x+NW/2,y1=a.y+NH,x2=b.x+NW/2,y2=b.y,mid=(y1+y2)/2;
        var path=document.createElementNS(SVGNS,'path');
        path.setAttribute('class','pg-edge');
        path.setAttribute('d','M'+x1+' '+y1+' C'+x1+' '+mid+' '
          +x2+' '+mid+' '+x2+' '+y2);
        svg.appendChild(path);
      });
    });
    steps.forEach(function(s,i2){
      var p=pos[i2];
      var g=document.createElementNS(SVGNS,'g');
      g.setAttribute('class','pg-node');
      g.setAttribute('transform','translate('+p.x+','+p.y+')');
      g.setAttribute('tabindex','0');g.setAttribute('role','button');
      var r=document.createElementNS(SVGNS,'rect');
      r.setAttribute('width',NW);r.setAttribute('height',NH);
      r.setAttribute('rx',7);r.setAttribute('fill',nodeColor(s));
      g.appendChild(r);
      var t=document.createElementNS(SVGNS,'text');
      t.setAttribute('x',NW/2);t.setAttribute('y',NH/2+4);
      t.setAttribute('text-anchor','middle');
      var label=s.title||splitRef(s.ns)[1];
      if(label.length>22) label=label.slice(0,21)+'…';
      t.textContent=label;g.appendChild(t);
      var open=function(){onNode?onNode(s):openVFull(s);};
      g.addEventListener('click',open);
      g.addEventListener('keydown',function(e){
        if(e.key==='Enter'||e.key===' '){e.preventDefault();open();}});
      svg.appendChild(g);
    });
    var wrap=document.createElement('div');wrap.className='plotgraph-wrap';
    var lbl=document.createElement('div');lbl.className='pg-eyebrow';
    lbl.textContent='dependency graph';
    wrap.appendChild(lbl);wrap.appendChild(svg);
    return wrap;
  }
  function traceItemFor(stem,anchor){
    return resolveRef(stem?nsKey(stem,anchor):anchor)||resolveRef(anchor);
  }
  function lineageFor(s){
    /* one group per framed card, ordered like the frames sit on the
       slide (row by row, left to right); each group = that card's full
       chain + its own code */
    var frames=[],seen={};
    (s.annots||[]).forEach(function(a){
      if(a.k!=='cell'||!a.ref) return;
      var it=resolveRef(a.ref);
      if(it&&!seen[it.ns]){seen[it.ns]=1;frames.push({a:a,it:it});}
    });
    frames.sort(function(p,q){
      var ry=Math.round((p.a.y||0)/12)-Math.round((q.a.y||0)/12);
      return ry!==0?ry:((p.a.x||0)-(q.a.x||0));
    });
    var groups=[];
    frames.forEach(function(f){
      /* a framed markdown note carries no code trail of its own — its chain
         now names its variables' cards (docs feature), but the presentation
         must stay note-free */
      if(f.it.kind==='note') return;
      var steps=[],seen2={};
      (f.it.chain||[]).forEach(function(anchor){
        var ns=nsKey(f.it.nb,anchor);
        var up=ITEMS[ns];
        if(up&&up.hasCode&&!seen2[ns]){seen2[ns]=1;steps.push(up);}
      });
      if(f.it.hasCode&&!seen2[f.it.ns]) steps.push(f.it);
      if(steps.length)
        groups.push({it:f.it,steps:steps,
          color:TRACE_COLORS[groups.length%TRACE_COLORS.length]});
    });
    var flat=[];
    groups.forEach(function(g){
      g.steps.forEach(function(st,k){
        flat.push({it:st,g:g,num:k+1});
      });
    });
    return {groups:groups,flat:flat};
  }
  /* the SELECTED plot's lineage as the docs dependency tree: a pseudo-
     shell (hidden card clones + a .treeview) fed to the docs builder, so
     zoom / width / expand / resize all behave exactly like the Tree view */
  function traceTreeNode(g){
    var wrap=document.createElement('div');
    wrap.className='deck-tracetree';
    var store=document.createElement('div');store.hidden=true;
    var items=[];
    (g.steps||[]).forEach(function(st){
      items.push(st);
      var c=cardEl(st.ns);
      if(c&&window.jvMath) window.jvMath.settle(c);
      if(c) store.appendChild(c.cloneNode(true));  /* ids kept: the tree
        builder looks nodes up by card id WITHIN this wrapper */
    });
    var tv=document.createElement('div');tv.className='treeview';
    wrap.appendChild(store);wrap.appendChild(tv);
    if(window.SemView&&window.SemView.buildTree)
      window.SemView.buildTree({el:wrap,
        data:{stem:g.it.nb,items:items}});
    return wrap;
  }
  function plotThumb(g,glow){
    var w=document.createElement('div');w.className='vo-plot';
    if(glow){
      w.style.borderColor=g.color;
      w.style.boxShadow='0 0 16px '+g.color+'66';
    }
    var src=paneImgSrc(g.it.ns);
    if(src){
      var im=document.createElement('img');
      /* a thumbnail is a picture OF something already named beside it,
         so it really is decorative -- aria-hidden says so instead of
         leaving a screen reader to guess from an empty alt (T105) */
      im.src=src;im.alt='';im.setAttribute('aria-hidden','true');
      w.appendChild(im);
    }
    var tl=document.createElement('span');tl.className='vo-plot-t';
    tl.textContent=g.it.title;w.appendChild(tl);
    return w;
  }
  function openVFull(st){
    var vf=$('#vfull'); if(!vf) return;
    var b=$('#vfull-badge'); if(b) b.textContent=st.kind;
    var t=$('#vfull-t'); if(t) t.textContent=st.title;
    var body=$('#vfull-body');
    if(body){
      body.innerHTML='';
      var c=cloneCode(st.ns);
      if(c) body.appendChild(c);
    }
    vf.hidden=false;
  }
  function closeVFull(){
    var vf=$('#vfull'); if(vf) vf.hidden=true;
    closeSpot();
  }
