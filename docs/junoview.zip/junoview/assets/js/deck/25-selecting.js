/* 25-selecting.js — what belongs to what, locks, snapping, the marquee and the canvas menu.
   ONE FRAGMENT of deck.js's single IIFE, concatenated with its
   siblings in filename order by assets.deck_js(). It does not
   parse alone and is not meant to: see 00-page.js. */
  /* ---- WHICH CONTROL BELONGS TO WHICH KIND OF ITEM ------------------
     One table, checked for completeness at the bottom of showFmt.

     The alternative — a hand-written show() line per control — is exactly
     how "Ends" and "Route" (both arrow properties) came to be offered on a
     triangle: four new dropdowns were added to the markup and none of them
     got a line, so they showed for everything selected, forever, and
     nothing complained (2026-08-07, user). A control that is not in this
     table and not handled explicitly now throws in the console instead of
     quietly appearing on every item.

     '*' means every kind; the value is a space-separated list otherwise. */
  var FMT_KINDS={
    '#fmt-stylewrap':'arrow rect draw', /* dashes apply to any stroke */
    /* a table's rules are a stroke like any other, so the same weight
       menu sets how heavy they are (2026-08-20) */
    '#fmt-swwrap':'arrow rect draw table',
    '#fmt-headwrap':'arrow',          /* arrowheads: a shape has no ends */
    '#fmt-bendwrap':'arrow',          /* straight/curved/elbow: ditto */
    '#fmt-fillwrap':'rect',           /* fill + gradients: shapes only */
    '#fmt-shapewrap':'rect',
    '#fmt-cropwrap':'image cell',
    '#fmt-picwrap':'image cell flip', /* T550: picture corrections */
    '#fmt-zoomcall':'image',          /* T387: a window onto the picture */
    '#fmt-linkzoom':'image cell',     /* T387: pictures that zoom together */
    '#fmt-weburl':'web',              /* T388: the page's address */
    '#fmt-mediawrap':'video',         /* trim, poster, switches (T321) */
    '#fmt-chartwrap':'chart',         /* the Chart pane's door (T322) */
    '#fmt-tablewrap':'table',         /* the Table pane's door (T324) */
    '#fmt-figures':'flip',
    /* T439: the book's other three doors, on the row beside the tile */
    '#fmt-flip-imgs':'flip','#fmt-flip-pages':'flip','#fmt-flip-own':'flip'
  };
  /* controls whose visibility depends on more than the kind (how many are
     selected, what a placed cell contains, whether the page is a poster).
     Listed so the completeness check knows they are deliberate. */
  var FMT_MANUAL=('#fmt-geom-xy #fmt-geom-wh #fmt-lhwrap '
    +'#fmt-sup #fmt-sub '   /* T541: shown for text by hand, beside Bold */
    /* T544: Change case (a door and its menu) and Clear formatting */
    +'#fmt-casewrap #fmt-case-btn #fmt-case-menu #fmt-clear '
    /* the four windows of options (T177): a wrapper, its door, the
       rows the Paragraph one builds, and the Weight heading that
       carries the printed thickness. The wrappers are the atoms a
       ribbon layout moves; the doors are what showFmt shows. */
    +'#fmt-fontwrap #fmt-font-btn #fmt-para-ind '
    +'#fmt-al-left #fmt-al-center #fmt-al-right '
    +'#fmt-para-curve #fmt-linewrap #fmt-line #fmt-sw-lab '
    +'#fmt-srcwrap #fmt-src '
    /* the Object group's provenance row (T198): where it came from,
       re-read it, keep it in place. The by-bullet trio and the effect
       buttons left this tab in T220. */
    +'#fmt-path #fmt-lock #fmt-match #fmt-cmp-make #fmt-cmp-add #fmt-cmp-find '
    /* THE HISTORY TILE, AND WHY THE OBJECT TAB WOULD NOT GO AWAY.
       #fmt-hist (T220's "what this object has been through", given a
       group of its own by T233) is shown by showFmt but appeared in
       neither table, so the deselect sweep -- which only reaches ids in
       fmtGovernedSet() -- could never hide it again. From the first
       selection onward its group stayed occupied, so tabHasContent
       ('object') stayed true, the Object tab never left the strip, and
       the T192 fall-back that returns you to the tab you were on never
       fired even once. Deselecting left you standing on Object with
       #et-fmt hidden: an empty ribbon row (2026-09-05, user: "the object
       tab should only appear when clicking on an object, then when
       unclicking back to previous tab"). It was the ONLY control on the
       whole tab with no governed self-or-ancestor. */
    +'#fmt-hist '
    /* hidden BY the governed #fmt-cropwrap, listed only so the
       completeness audit below stops flagging it -- exactly as the
       bullets and numbers carets above are */
    +'#fmt-crop-caret '

    /* the two children of the governed #fmt-stylewrap-tx wrapper: their
       visibility IS the wrapper's, listed so the completeness audit
       below stops flagging them on every first selection (2026-08-24) */
    +'#fmt-eqedit #fmt-mdedit '
    +'#fmt-stylewrap-tx #fmt-style-tx #fmt-style-menu-tx '
    +'#fmt-tbl-rowplus #fmt-tbl-rowminus #fmt-tbl-colplus '
    +'#fmt-tbl-colminus #fmt-tbl-head #fmt-tbl-grid '
    +'#fmt-forward #fmt-backward '
    +'#fmt-bullets #fmt-numbers #fmt-indent #fmt-outdent '
    /* the split wrappers and their carets: the wrapper has to be
     governed or the deselect sweep hides the caret, and a hidden
     caret collapses the whole control through the :has() rule */
    +'#fmt-bulletswrap #fmt-bullets-caret #fmt-bullets-menu '
    +'#fmt-numberswrap #fmt-numbers-caret #fmt-numbers-menu '
    +'#fmt-dup #fmt-group #fmt-ungroup #fmt-front #fmt-back '
    +'#fmt-shdwrap #fmt-rotl #fmt-rotr #fmt-rotwrap #fmt-arline #fmt-argrid #fmt-samewrap '
    +'#fmt-alignwrap #fmt-opwrap #fmt-txcol-btn '
    /* the wrappers around the two colour dropdowns. They got ids so a
       ribbon layout could move a button and its swatch menu as ONE
       thing; that made them controls, and a control on this bar has to
       be governed or it shows for everything, forever (2026-08-25). */
    +'#fmt-txcolwrap #fmt-fillcolwrap '
    +'#fmt-fillcol-btn #fmt-txlab #fmt-bglab #fmt-szwrap #fmt-smaller '
    +'#fmt-sizecell #fmt-txquick #fmt-bgquick #fmt-lh-btn #fmt-opcell '
    +'#fmt-bigger #fmt-bold #fmt-ital #fmt-under #fmt-strike #fmt-font '
    +'#fmt-parawrap '
    +'#fmt-replace #fmt-locate #fmt-revert #fmt-lockver #fmt-parts '
    +'#fmt-caption #fmt-alt #fmt-prov #fmt-lockar #fmt-sizepos '
    +'#fmt-crop #fmt-same #fmt-style #fmt-sw #fmt-head #fmt-bend '
    +'#fmt-fillstyle #fmt-shape '
    +'#fmt-align-btn #fmt-para #fmt-size #fmt-op '
    +'#fmt-opval #fmt-imgrefresh #fmt-imglink').split(' ');

  /* EVERY CONTEXTUAL CONTROL, in one list: the two tables that already
     govern them. */
  function fmtAllIds(){
    return Object.keys(FMT_KINDS).concat(FMT_MANUAL);
  }
  function fmtGovernedSet(){
    var g={};
    fmtAllIds().forEach(function(id){g[id]=1;});
    return g;
  }
  /* Inspectors are about the CURRENT primary selection, not the object
     that happened to be selected when their door was opened. Keep this
     beside showFmt because every canvas selection path already converges
     here, including deselection and title/subtitle pseudo-items. */
  var inspectorSig='';
  /* the tab a selection carried you away from, for the way back (T192) */
  var tabBeforeSel='';
  /* T465: the selection showFmt last carried the ribbon for. showFmt
     runs again on every re-render of the same selection -- a colour
     hover's live preview, every fmtApply -- and each run used to decide
     the tab afresh, so a shape you had walked over to Style was yanked
     back to Object by the first swatch you hovered (the T410 complaint,
     for shapes). The tab follows a NEW selection only. */
  var fmtSelSig='';
  function syncInspectorPanes(force){
    /* the numbers pane is an inspector too, and a cheap one -- four
       value writes, and an immediate return when it is closed. It sits
       ABOVE the signature gate on purpose: the gate exists to stop
       24-snapshot history walks during a slider preview, and this does
       no walking (T65). */
    if(typeof sizePaneSync==='function') sizePaneSync();
    if(typeof mediaPaneSync==='function') mediaPaneSync();
    if(typeof chartPaneSync==='function') chartPaneSync();
    if(typeof tablePaneSync==='function') tablePaneSync();
    var hp=$('#objhist');
    var pp=$('#provpane');
    var histOpen=!!hp&&!hp.hidden,provOpen=!!pp&&!pp.hidden;
    if(!histOpen&&!provOpen){inspectorSig='';return;}
    var s=pres.slides[cur];
    /* Both panes describe the primary item, just like the ribbon. Group
       expansion belongs to bulk verbs, not to an inspector's subject. */
    var a=s&&typeof selAnnot==='number'&&(s.annots||[])[selAnnot];
    if(histOpen&&a) ensureOids(s);
    var sig=(histOpen?'h':'')+(provOpen?'p':'')+'|'+cur+'|'
      +(a?(histOpen?a.oid:(a.ref||a.k)):'none');
    /* showFmt also runs during continuous previews. Walking 24 whole-deck
       history snapshots for every slider input would make an open pane
       turn a smooth gesture into a crawl; markDirty owns edit refreshes. */
    if(!force&&sig===inspectorSig) return;
    inspectorSig=sig;
    if(histOpen){
      ohOid=a?a.oid:null;
      renderObjHist();
    }
    if(provOpen) renderProvPane();
  }
  function showFmt(){
    var bar=$('#et-fmt'); if(!bar) return;
    var et=$('#edit-tools');
    var s=pres.slides[cur];
    var a=(s&&selAnnot!==null)?annotByIdx(s,selAnnot):null;
    syncInspectorPanes();
    if(window.SemDeckFindSync) window.SemDeckFindSync();
    if(!a){
      bar.hidden=true;
      fmtSelSig='';
      /* ...AND EVERY CONTEXTUAL CONTROL, one at a time. Hiding the bar
         used to be enough because every one of them lived inside it. A
         ribbon layout may put any of them in a group of its own, and a
         control that relied on an ancestor for its hiding would then sit
         there visible with nothing selected — and keep its whole group
         on screen with it, which is how a tab that should have been
         empty stayed in the strip (2026-08-25, found in a browser).
         Hiding them individually makes the rule a fact about the
         CONTROL rather than about where it happens to sit.
         ONLY THE OUTERMOST governed element, though (T177). A button
         inside a governed wrapper is hidden BY the wrapper, and the
         wrapper is what the selection branch shows again; hiding the
         button as well left it hidden for good, because nothing ever
         showed it. Driven on 2026-09-02 against the build before this
         one: after the first deselection -- which is to say at boot --
         the Colour group, Arrange, Styles, Spacing, Layout, the size
         field and the opacity slider had all gone, and the substring
         tests could not see it. The outermost governed elements are
         exactly the atoms a ribbon layout moves, so the 2026-08-25
         promise still holds. */
      var gov=fmtGovernedSet();
      fmtAllIds().forEach(function(id){
        var el=$(id); if(!el) return;
        var p=el.parentNode,inner=false;
        while(p&&p!==document){
          if(p.id&&gov['#'+p.id]){inner=true;break;}
          p=p.parentNode;
        }
        if(!inner) el.hidden=true;
      });
      /* a window that was open was about the selection that has just
         gone; an empty window standing open would be a lie (T177) */
      if(typeof optPanelsClose==='function') optPanelsClose();
      if(et) et.classList.remove('fmt-open');
      /* the pane outlives the selection — it is the SLIDE's build order —
         so it has to be told the selection went away, or its effect
         chooser keeps offering the last item's effect to nothing */
      animPaneSync();animRibbonSync();
      syncRibbonGroups();
      return;
    }
    /* THE TAB FOLLOWS THE SELECTION. Default opens Style for words and
       tables, Object for every other selected thing; other ribbon layouts
       name their own target.
       Clicking a figure while you happened to be elsewhere still has to
       reveal its tools instead of leaving them on a tab you cannot see
       — which is how "the ability to lock cells" appeared to vanish when
       it had simply moved one tab away (2026-08-20, user).
       Not while a drawing tool is armed: placing five shapes in a row
       must not yank you off Insert after each one. */
    /* ...and WHICH tab that is belongs to the layout: `home` is the
       markup's answer, and a layout that calls its format tab "Object"
       would otherwise send you to a tab that does not exist
       (2026-08-25, ribbon layouts). */
    var kind=(selAnnot==='t'||selAnnot==='s')?'text':a.k;
    var selT=(typeof ribbonSelTab==='function')?ribbonSelTab():'home';
    /* Default's Style tab is about the selected thing's appearance. A
       figure or shape still belongs on Object, even though it may expose a
       Line control on Style too. Custom layouts own their declared target. */
    /* T410: A LINE IS ITS STROKE (2026-09-13, user: "When clicking on a
       line, it always tries to take me away from line and to the object
       tab"). Object has nothing for a line but arrange and size; its
       dash, weight, ends and route are the Line window on Style. So a
       line or a pen stroke lands on Style, and stays there when you
       are already on it. A shape keeps going to Object: its fill and
       edge are there. */
    /* T465: ...and so does a SHAPE. "its fill and edge are there" had
       stopped being true: Object holds arrange, size, opacity and
       reuse, while Fill, Border, Line and Shape are the Style tab's
       Line & shape group (2026-09-15 review, measured). */
    var strokeSel=(kind==='arrow'||kind==='draw'||kind==='rect');
    if(selT==='style'&&kind!=='text'&&kind!=='table'&&!strokeSel)
      selT='object';
    var selSig=cur+'|'+String(selAnnot)+'|'
      +(selSet||[]).map(String).join(',');
    var freshSel=(selSig!==fmtSelSig);
    fmtSelSig=selSig;
    /* DECIDED HERE, DONE AT THE END. The switch used to happen on this
       line, before a single control had been revealed — and once a
       layout may give the format groups a tab of their own, that tab is
       still EMPTY at this point, so the empty-tab fallback in
       syncRibbonGroups bounced straight back off it and the selection
       appeared to do nothing (2026-08-25, found in a browser). Deciding
       now and switching after the controls exist keeps both rules. */
    /* AN OPEN PANE IS AN OPEN WORKFLOW (T141 / JVUX-06). The Timeline
       pane's own empty state says "Select an item first" — and doing
       exactly that used to yank the ribbon from Insert to Object,
       moving you away from the controls you had just opened. With any
       inspector pane open, selection still reveals the contextual
       groups (showFmt below) but no longer STEALS the tab; with none
       open, the switch behaves as it always has. */
    var hold=PANE_IDS.some(function(pid){
      var el=$('#'+pid); return el&&!el.hidden;})
      ||(typeof animGalleryOpen==='function'&&animGalleryOpen())
      /* the Animation tab carries the selection's own effect tiles
         (T182): clicking a thing while standing there is how you pick
         what to animate, and being carried off to Object would take
         the tiles away in the same click */
      ||activeTab()==='animation';
    var wantTab=(freshSel&&activeTab()!==selT&&tool==='select'&&!justDrew
      &&!hold)?selT:'';
    /* T481: STANDING ON A CONTEXTUAL TAB, STAY. Clicking a text box
       from Object yanked the ribbon to Style; clicking a figure from
       Style yanked it to Object -- and each yank overwrote the way
       back with the tab you were yanked from, so Esc landed on Home
       (2026-09-15 review). A contextual tab that still has content
       for the new selection keeps you; the tab you CHOSE is the one
       remembered. */
    var ctxNow=(activeTab()==='style'||activeTab()==='object');
    var ctxTab=activeTab();
    /* REMEMBER WHERE YOU WERE (T192). The selection carries you to
       Object; when it goes, syncRibbonGroups brings you back to the
       tab you left rather than to Home (2026-09-02, user: "if you are
       on Insert tab, and you click on an object then unclick, it
       should go back to Insert"). */
    if(wantTab&&!ctxNow) tabBeforeSel=activeTab();
    justDrew=false;
    /* a table is not a text box, but its WORDS take the same size, font
       and alignment controls a text box does (2026-08-20) */
    var isTbl=(kind==='table');
    bar.hidden=false;
    /* the contextual groups REPLACE the Insert group instead of adding
       a third toolbar row — the canvas must not shrink when you select
       something (2026-08-05, user: "you can't really see the poster
       you are working on") */
    if(et) et.classList.add('fmt-open');
    function show(id,on,pressed){
      var el=$(id); if(!el) return;
      el.hidden=!on;
      if(on&&pressed!==undefined)
        el.setAttribute('aria-pressed',pressed.toString());
    }
    /* cellText = a resizable text-ish cell (A-/A+ content zoom applies to any
       non-figure cell). noteCell = a MARKDOWN note specifically — only its
       rendered .note carries a colour, so ONLY it gets the colour swatches. */
    var cellText=false,noteCell=false;
    if(kind==='cell'&&a.ref){
      var ci=resolveRef(a.ref);
      cellText=!!ci&&ci.kind!=='figure'&&ci.kind!=='diagnostic';
      noteCell=!!ci&&ci.kind==='note';
    }
    var isText=(kind==='text');
    var isNum=(typeof selAnnot==='number');
    /* the colour swatches drive a.color for text / arrows / shapes, and a.txcol
       for a markdown note — but NOT images or figure/code cells */
    /* T465: the same set the door (hasInk, below) shows for -- a table
       and a pen stroke got a Colour door that opened on headings over
       nothing, every swatch hidden (2026-09-15 review) */
    var colourable=isText||kind==='arrow'||kind==='rect'||noteCell
      ||isTbl||kind==='draw';
    $$('.sw:not(.swbg)',bar).forEach(function(sw){
      sw.hidden=!colourable;
      var cur_=(kind==='cell')?(a.txcol||''):(a.color||defaultColor(kind));
      sw.setAttribute('aria-pressed',(cur_===sw.dataset.c).toString());
    });
    show('#fmt-smaller',isText||cellText||isTbl);
    show('#fmt-bigger',isText||cellText||isTbl);
    var fontSel=$('#fmt-font');
    if(fontSel){
      fontSel.hidden=!isText;
      if(isText){
        var fv=a.font||'sans';
        /* a typed family is not one of the listed options — show it as
           its own entry rather than silently reading back as "Sans" */
        var ex=fontSel.querySelector('option[data-typed]');
        if(ex) ex.remove();
        /* (T570: unless it is already there, among the recent faces) */
        var listed=[].some.call(fontSel.options,function(o){
          return o.value===fv;});
        if(!FONTMAP[fv]&&!listed){
          fontSel.insertAdjacentHTML('afterbegin',
            '<option data-typed="1" value="'
            +esc(fv).replace(/"/g,'&quot;')+'">'+esc(fv)
            +'</option>');
        }
        fontSel.value=fv;
        /* T570: the closed list wears the face it names, too */
        fontSel.style.fontFamily=fontCss(fv)||'';
      }
    }
    show('#fmt-bold',isText,!!a.b);
    show('#fmt-ital',isText,!!a.i);
    show('#fmt-under',isText,!!a.u);
    show('#fmt-strike',isText,!!a.strike);
    /* T541: characters, so words only -- a text box's own */
    show('#fmt-sup',isText);
    show('#fmt-sub',isText);
    /* T544: words too -- a text box, a title, a subtitle */
    show('#fmt-casewrap',isText);
    show('#fmt-case-btn',isText);
    show('#fmt-clear',isText);
    show('#fmt-szwrap',isText||isTbl);
    /* T220: the size cell is on the row now that the Font window
       is gone */
    show('#fmt-sizecell',isText||cellText||isTbl);
    /* named styles are for TEXT BOXES: a title/subtitle pseudo-item is
       already the deck's title style by definition */
    show('#fmt-stylewrap-tx',isText&&isNum);
    /* T489: the Styles door names the style this box wears -- after
       picking Heading 2 it still read "Styles" and the choice was only
       visible by reopening the menu (2026-09-15 review) */
    if(isText&&isNum&&typeof doorVal==='function'){
      var sd=a.style?styleDef(a.style):null;
      doorVal('#fmt-style-tx',sd?sd.label:'Plain',function(word){
        return 'Named text styles \u2014 Title, Headings, Body, Caption '
          +'\u2014 and pushing this box\u2019s look to all of them. '
          +(word==='Plain'?'This box wears none':'This box is '+word);
      });
    }
    /* spacing applies to any run of words, including a table's */
    show('#fmt-lhwrap',(isText||isTbl)&&isNum);
    show('#fmt-eqedit',isMaths(a)&&isNum);
    /* a markdown box's face is the RENDERING, so the way in is the
       editor rather than the caret (T74) */
    show('#fmt-mdedit',!!(a&&a.k==='text'&&a.md)&&isNum);
    var szIn=$('#fmt-size');
    if(szIn&&(isText||isTbl)&&document.activeElement!==szIn)
      szIn.value=Math.round((a.size||(isTbl?2.2:2.6))*5.4);
    /* THE DOORS OF THE WINDOWS (T177). Each shows when anything inside
       it would; syncOptDoors below is the safety net that hides one
       whose contents all stood down. The Paragraph window opens for a
       table too, because a table's words take spacing. */
    show('#fmt-lh-btn',(isText||isTbl)&&isNum);
    show('#fmt-font-btn',isText||cellText||isTbl);
    /* T220: the box indent and curve are a text box's own; a table's
       words take spacing, which is its own door. T514 put list levels
       directly on the row. */
    show('#fmt-parawrap',isText&&isNum);
    show('#fmt-para',(isText||isTbl)&&isNum);
    var lineKinds=['arrow','rect','draw','table'];
    show('#fmt-linewrap',isNum&&lineKinds.indexOf(kind)>=0);
    show('#fmt-line',isNum&&lineKinds.indexOf(kind)>=0);
    /* bullets / numbering / indent. The two list buttons show WHICH list
       is on, which the old menu line could not; indent and outdent only
       appear once there is a list to move a bullet inside. */
    var lst=isText?listOf(a):0;
    /* T227: pressed when ANY kind of that family is on, and the
       gallery marks which one */
    /* the split wrappers are controls too, so they need a rule of
       their own or the deselect sweep hides them for good */
    show('#fmt-bulletswrap',isText&&isNum);
    show('#fmt-numberswrap',isText&&isNum);
    show('#fmt-bullets',isText&&isNum,!!lst&&!listIsOrdered(lst));
    show('#fmt-numbers',isText&&isNum,!!lst&&listIsOrdered(lst));
    if(typeof listGallerySync==='function') listGallerySync(lst);
    /* Keep these visible for every text box: caretList decides whether
       the live paragraph is a list, including a list inside mixed text. */
    show('#fmt-indent',isText&&isNum);
    show('#fmt-outdent',isText&&isNum);
    /* the three alignments, in the row and showing which is on
       (T189); they were rows of a menu called Layout, then chips in
       a window called Paragraph */
    var alg=isText?(a.align||'left'):'';
    show('#fmt-al-left',isText&&isNum,alg==='left');
    show('#fmt-al-center',isText&&isNum,alg==='center');
    show('#fmt-al-right',isText&&isNum,alg==='right');
    /* the kind-driven controls, all from one table */
    Object.keys(FMT_KINDS).forEach(function(id){
      var spec=FMT_KINDS[id];
      show(id,isNum&&(spec==='*'||spec.split(' ').indexOf(kind)>=0));
    });
    /* what this weight will actually PRINT. It goes in the tooltip, never
       the label: a label whose width changed with the selected item would
       make the ribbon's required width depend on what you clicked, and
       the fit ladder has no rung left to absorb that. */
    var lnBtn=$('#fmt-sw'),swW=$('#fmt-swwrap'),swL=$('#fmt-sw-lab');
    if(lnBtn&&isNum&&swW&&!swW.hidden){
      var mmw=swMm(a);
      var swSay=(mmw<1?mmw.toFixed(2):mmw.toFixed(1))
        +'mm on this page ('+swPt(a).toFixed(2).replace(/\.?0+$/,'')+'pt)';
      lnBtn.title='Line thickness — '+swSay;
      /* ...and on the Weight section's heading inside the Line window,
         which is where the reader is looking now (T177) */
      if(swL) swL.textContent='weight — '+swSay;
    }
    if(swW&&swL) swL.hidden=swW.hidden;
    /* every drawn menu shows which option the selection is ON */
    if(isNum) syncLineMenus(a);
    if(typeof arrangeMenuSync==='function') arrangeMenuSync();
    animPaneSync();animRibbonSync();
    show('#fmt-opwrap',true);
    var opR=$('#fmt-op'),opV=$('#fmt-opval');
    var opPct=Math.round((a.op==null?1:a.op)*100);
    if(opR) opR.value=opPct;
    if(opV) opV.textContent=opPct+'%';
    show('#fmt-dup',isNum);
    var nSel=selSet.filter(function(i){return typeof i==='number';}).length;
    /* T487: a selection that already IS one group is offered Ungroup
       alone, not Group and Ungroup side by side */
    show('#fmt-group',nSel>=2&&!selIsOneGroup());
    show('#fmt-ungroup',isNum&&a.grp!=null);
    /* Bring to front and Send to back are BUTTONS again. They were
       menu-only, which is why they read as missing (2026-08-20, user
       asked for "the bring to forewards send to back" - both pairs were
       in the code, three clicks deep inside Arrange). The one-STEP pair
       stays in the menu: it is the rarer of the two and the row has to
       stay honest about its width. */
    show('#fmt-front',isNum);
    show('#fmt-back',isNum);
    show('#fmt-forward',false);
    show('#fmt-backward',false);
    show('#fmt-arline',false);
    show('#fmt-argrid',false);
    show('#fmt-rotl',false);
    show('#fmt-rotr',false);
    show('#fmt-rotwrap',isNum);   /* T549 */
    /* count what can actually be RESIZED, not what is selected. selRects
       drops arrows (no box), locked and hidden items, so two selected
       arrows offered "Same size" and then did nothing at all when you
       picked from it (2026-08-07 audit). */
    /* selRects(TRUE), the same size-only reading sameSize itself uses.
       Gated on the plain selRects it counted `pinned` items out, so
       selecting two POSITION-LOCKED boxes hid the control -- and the
       four modes behind it were unreachable in exactly the case the
       verb had just been fixed to handle. A gate stricter than its own
       verb is a feature you cannot get at (2026-08-30). */
    show('#fmt-samewrap',selRects(true).length>=2);
    /* the menu now covers single-item actions (order, rotate) too */
    show('#fmt-alignwrap',isNum);
    var plainText=isText&&typeof selAnnot==='number';
    /* A SHAPE gets the fill swatches too. It did not, so a triangle's
       body could not be given a colour by any control in the app: the
       outline worked (Colour → a.color → stroke) but the fill popup was
       gated to text, its handler had no shape branch, and "Solid colour…"
       just copied the outline. A green triangle with a red outline was
       not constructible (2026-08-07, user: "yet I can't change the
       fucking colour"). */
    var showBg=plainText||noteCell||kind==='rect';
    show('#fmt-txlab',(isText&&kind!=='cell')||noteCell);
    show('#fmt-bglab',showBg);
    /* the popup buttons mirror what their menus can act on, and the label
       names the PART it recolours: "Colour" next to "Fill" left people
       guessing which one was the outline (2026-08-19, user: "'colour' vs
       'fill colour' is confusing — is that border?") */
    /* T234: not a flip book either. Nothing renders a.color for one
       -- applyCommon writes opacity and rotation and stops -- so the
       door was a control that did nothing at all (2026-09-04, user:
       "why do flip books even have a colour? What does that do?"). */
    var hasInk=isText||isTbl||noteCell||kind==='arrow'||kind==='rect'
      ||kind==='draw';
    show('#fmt-txcol-btn',hasInk);
    show('#fmt-txquick',hasInk);
    if(typeof quickSwatchSync==='function') quickSwatchSync();
    var tcb=$('#fmt-txcol-btn');
    /* innerHTML, not textContent: this button is RENAMED for whatever is
       selected, and textContent would delete the icon with the old word
       every time -- which is why it was the one ribbon button that could
       never keep one (2026-08-25). */
    /* T467: named for what it COLOURS. An arrow had two doors reading
       "Line ▾" 200px apart -- this one (its colour) and Line & shape's
       (dash, weight, ends) -- and a shape's sat in a group captioned
       "Font" (2026-09-15 review). */
    if(tcb) tcb.innerHTML=bic('palette')+' '
      +((isText||kind==='cell')?'Text colour ▾'
      :kind==='rect'?'Border colour ▾'
      :(kind==='arrow'||kind==='draw')?'Line colour ▾':'Colour ▾');
    var fgl=$('.rbn-fontgrp>.rbn-lab');
    if(fgl) fgl.textContent=(isText||isTbl||noteCell)?'Font':'Colour';
    if(tcb) tcb.title=(isText||kind==='cell')
      ?'Every colour for the words \u2014 and this deck\u2019s own colours, '
        +'which every box wearing one follows'
      :kind==='rect'?'Every colour for this shape\u2019s outline'
      :(kind==='arrow'||kind==='draw')?'Every colour for this line'
      :'Every colour for the table\u2019s words and rules';
    /* a SHAPE has one Fill control and it is the panel in Line & shape;
       this button stays for text boxes and cell frames, which have a
       background colour but no fill STYLE (2026-08-20, user: "confusing
       there is a fill and fill colour") */
    show('#fmt-fillcol-btn',showBg&&kind!=='rect');
    show('#fmt-bgquick',showBg&&kind!=='rect');
    /* T221: the opacity slider wears its name now, so the caption
       goes with the slider rather than standing on its own */
    var opw=$('#fmt-opwrap');
    show('#fmt-opcell',!!opw&&!opw.hidden);
    /* T548: a shadow, for anything that can cast one; the row that is
       on is marked */
    var shdIx=selIdxs().filter(function(i){
      var x=(pres.slides[cur].annots||[])[i];
      return typeof i==='number'&&x&&SHADOWABLE[x.k];});
    show('#fmt-shdwrap',shdIx.length>0);
    if(shdIx.length){
      var shNow=(pres.slides[cur].annots||[])[shdIx[0]].shadow||'none';
      $$('#fmt-shd-menu [data-shd]').forEach(function(o){
        o.setAttribute('aria-pressed',
          o.getAttribute('data-shd')===shNow?'true':'false');});
    }
    /* a shape now has two Fill buttons — this one picks the COLOUR, the
       one in Line & shape picks none/solid/gradient. Say which is which. */
    var fcb=$('#fmt-fillcol-btn');
    if(fcb) fcb.innerHTML=bic('fill')+' '
      +((kind==='rect')?'Fill colour ▾':'Box colour ▾');
    /* the wrapper around each colour dropdown shows exactly when its
       button does. Read from the button rather than restated, so the
       rule for when Colour appears stays in one place (2026-08-25).
       AFTER the two show() calls above, not before them: read first,
       it copied the button's state from the previous selection, and
       from the markup's `hidden` on the very first one -- so the
       Colour group was one selection behind, and absent at the start
       (found driving T177, 2026-09-02). */
    ['txcol','fillcol'].forEach(function(k){
      var cb=$('#fmt-'+k+'-btn'),cw=$('#fmt-'+k+'wrap');
      if(cb&&cw) cw.hidden=cb.hidden;
    });
    $$('.swbg',bar).forEach(function(sw){
      sw.hidden=!showBg;
      /* read back from the field the item's renderer actually uses, or
         the wrong swatch lights up */
      var cur_;
      if(kind==='cell') cur_=(a.bgcol||'');
      else if(kind==='rect')
        cur_=a.grad?'':(!a.fill?'none':(a.fillc||''));
      else cur_=((a.bg===0)?'none':(a.bgc||'#0e1926'));
      sw.setAttribute('aria-pressed',(cur_===sw.dataset.c).toString());
    });
    /* the Table group, the only place row and column counts live */
    ['#fmt-tbl-rowplus','#fmt-tbl-rowminus','#fmt-tbl-colplus',
     '#fmt-tbl-colminus'].forEach(function(id){show(id,isTbl);});
    show('#fmt-tbl-head',isTbl,isTbl&&!!a.thead);
    show('#fmt-tbl-grid',isTbl,isTbl&&a.grid!==0);
    show('#fmt-replace',kind==='cell');
    show('#fmt-locate',kind==='cell'&&!!a.ref);
    /* for anything that came OUT of a notebook, which since T58 means a
       flip book as well as a placed cell */
    show('#fmt-prov',isNum&&!!provRef(a));
    /* SIZE, SHAPE AND POSITION -- for anything that is a box. An arrow
       is two endpoints and has neither (T65). */
    var hasBox=isNum&&kind!=='arrow';
    /* the door to the pane that types the same four numbers as the
       ribbon's own fields is retired from the ribbon (T212); the pane
       stays for the pane owner */
    show('#fmt-sizepos',false);
    show('#fmt-geom-xy',hasBox);show('#fmt-geom-wh',hasBox);
    show('#fmt-lockar',hasBox,hasBox&&!!a.lockar);
    var lab=$('#fmt-lockar');
    if(lab&&hasBox) lab.innerHTML=(a.lockar?bic('unlock'):bic('lock'))
      +' Lock aspect ratio';
    /* ONE BUTTON, TWO STATES — the pattern #fmt-revert above already
       uses. A figure without a caption gets "Caption"; one with a
       caption gets "Untie caption", which until now had no door but a
       right-click row (2026-08-26 audit, T58). */
    var figSel=isNum&&isFigure(a);
    show('#fmt-caption',figSel);
    /* T552: alt text, for every picture in the selection; the tooltip
       says whether it has been written */
    var altIx=altSelIdxs();
    show('#fmt-alt',altIx.length>0);
    if(altIx.length){
      var ab=$('#fmt-alt'),a0=(pres.slides[cur].annots||[])[altIx[0]];
      if(ab) ab.title=(a0&&a0.dec?'Marked decorative — a screen reader '
          +'skips it. '
        :(a0&&a0.alt)?'Alt text: “'+String(a0.alt).slice(0,80)
          +(String(a0.alt).length>80?'…':'')+'”. '
        :'No alt text yet. ')
        +'Say what this shows, for somebody who cannot see it; empty '
        +'marks it decorative';
    }
    if(figSel){
      var cb=$('#fmt-caption'),hasCap=capHasOne(a);
      if(cb){
        cb.innerHTML=hasCap?(bic('unlink')+' Untie caption')
          :(bic('caption')+' Caption');
        cb.title=hasCap
          ?'Let them be two ordinary objects again. The words stay '
            +'exactly where they are; they simply stop following the '
            +'figure.'
          :'Put a caption under this figure — at its width, already '
            +'tied to it and already numbered, so it follows the '
            +'figure and renumbers itself when slides move.';
      }
    }
    var lockedV=(kind==='cell')&&!!(a.lockver&&a.lockver.commit);
    var frozen=(kind==='cell')&&frozenFrames.has(a);
    var hasPrev=(kind==='cell')&&!!a.ref
      &&!!frameSnapsPrev[normRef(a.ref)];
    show('#fmt-revert',(frozen||hasPrev)&&!lockedV);
    if((frozen||hasPrev)&&!lockedV){
      var rvb=$('#fmt-revert');
      if(rvb) rvb.innerHTML=frozen
        ?(bic('reload')+' Live figure')
        :(bic('reset')+' Previous figure');
    }
    /* Locking pins a figure to its notebook's git commit, which needs the
       local server to talk to git - so it only WORKS in the app build.
       It used to disappear entirely everywhere else, which reads as a
       feature that was removed rather than one that is unavailable here
       (2026-08-20, user: "what happened to locking all the images to a
       git commit"). It is shown and disabled instead, and the tooltip
       says what would make it work. */
    var isCellRef=(kind==='cell')&&!!a.ref;
    var canLock=isCellRef&&APP.mode==='app';
    show('#fmt-lockver',isCellRef);
    var lvb=$('#fmt-lockver');
    if(lvb&&isCellRef){
      lvb.disabled=!canLock;
      lvb.innerHTML=lockedV
        ?(bic('unlock')+' Unlock figure')
        :(bic('lock')+' Lock figure');
      lvb.title=canLock
        ?('Pin this figure to its notebook\u2019s current git commit '
          +'\u2014 refreshes stop changing it, and it renders even with '
          +'the notebook closed')
        :('Not available in a standalone export \u2014 locking needs the '
          +'Junoview app and a git repository');
    }
    /* #fmt-cropwrap: visibility from FMT_KINDS.
       Animation is a BUILD — an item appearing on click as you step
       through a deck. A poster is one printed page: there is no click and
       nothing to step through, so it is not offered (2026-08-07, user:
       "why is there animate options in a poster"). */
    /* the code/figure/output part-picker (+ split) — moved off the frame
       into the ribbon's Object group */
    /* only for a picture that actually knows where it came from —
       otherwise it is a button that can only ever fail */
    var ir=$('#fmt-imgrefresh');
    if(ir){
      var anyLinked=false,anyAddr=false;
      selIdxs().forEach(function(i){
        var xa=(s&&s.annots||[])[i];
        if(xa&&xa.k==='image'&&xa.fkey) anyLinked=true;
        /* T437: a path or an address re-reads too */
        if(xa&&xa.k==='image'&&typeof picAddr==='function'&&picAddr(xa))
          anyAddr=true;});
      ir.hidden=!(anyLinked||anyAddr);
      ir.innerHTML=bic('reload')+(anyLinked&&!anyAddr
        ?' Refresh from file':' Refresh from path');
    }
    /* T437: Link only -- the size saving, as a switch you can see */
    var lk=$('#fmt-imglink');
    if(lk){
      var lkOn=kind==='image'&&isNum&&typeof picAddr==='function'
        &&!!picAddr(a);
      lk.hidden=!lkOn;
      if(lkOn) lk.setAttribute('aria-pressed',
        (picState(a)==='link').toString());
    }
    /* WHERE IT CAME FROM, on the row (T198): a picture's file, a
       figure's notebook; and the lock that keeps a thing in place */
    var pth=$('#fmt-path');
    if(pth){
      var from='';
      if(kind==='image'){
        from=(typeof picAddr==='function'&&picAddr(a))
          ||a.fname||a.psrc||'';
        /* T438: SAID EVEN WHEN THERE IS NONE. A pasted picture has no
           path, and the row used to vanish -- which reads as "the tab
           does not show paths" rather than "this one has none". */
        if(!from) from='pasted or dropped \u2014 no file behind it';
      }
      else if(isNum&&provRef(a)){
        var pref=provRef(a),ci2=resolveRef(pref),po=provOf(a);
        var ff=(kind==='flip')?(flipFrames(a)[a.at||0]||{}):{};
        from=a.nbpath||ff.nbpath
          ||(ci2&&(ci2.nbpath||ci2.stem||ci2.nb))
          ||(po&&po.saved&&po.saved.nbpath)||String(pref);
      }
      pth.hidden=!from;
      if(from){
        /* T530: THE FILE'S NAME FIRST, then its folder. The path was
           elided in the middle and then cut by the 170px cell, so the
           row read "C:\Users\rvgp59...\example_cli..." -- the one
           part worth reading was the part that went. The whole path is
           still on hover, and still the first thing on the tab (T438). */
        var fs=String(from),cut=Math.max(fs.lastIndexOf('/'),
          fs.lastIndexOf('\\'));
        var fbase=(cut>=0&&cut<fs.length-1)?fs.slice(cut+1):fs;
        var fdir=(cut>=0&&cut<fs.length-1)?fs.slice(0,cut):'';
        pth.innerHTML='<span>From</span><span><b></b><i></i></span>';
        pth.querySelector('b').textContent=fbase;
        pth.querySelector('i').textContent=fdir?((typeof midElide==='function')
          ?midElide(fdir,40):fdir):'';
        pth.title='From '+from;
      }
    }
    /* T439: the flip book's own-object door names the page showing
       and which way it goes; a book with no pages has none to offer */
    var fo=$('#fmt-flip-own');
    if(fo&&kind==='flip'){
      var pgAt=a.at||0,pgF=flipFrames(a)[pgAt];
      fo.hidden=!pgF;
      if(pgF){
        fo.innerHTML=bic(pgF.own?'link':'unlink')+' '
          +(pgF.own?'Back in book':'Own object');
        fo.title=pgF.own
          ?('Page '+(pgAt+1)+' goes back into the book\u2019s box as an '
            +'ordinary page')
          :('Takes page '+(pgAt+1)+' out of the book\u2019s box as an '
            +'object you can move, resize, fade or crop on its own. It '
            +'still shows with this page');
      }
    }
    /* T487: pressed for the POSITION lock only; a fully locked item
       (reached through Alt-marquee or Layers) showed "[on]" with the
       position-lock words and a click that did nothing (2026-09-15
       review). The button is disabled and says where the full lock
       comes off. */
    show('#fmt-lock',isNum,isNum&&lockMode(a)==='pos');
    var lkB=$('#fmt-lock');
    if(lkB&&isNum){
      var full=lockedAll(a);
      lkB.disabled=full;
      if(!lkB.dataset.title0) lkB.dataset.title0=lkB.title;
      lkB.title=full?('Fully locked \u2014 "Not locked" in the '
        +'right-click menu or the Layers pane takes it off'):lkB.dataset.title0;
    }
    /* T220: what this object has been through, one click away */
    show('#fmt-hist',isNum);
    /* T229: making a set of clones, and finding the ones that exist */
    var selCount=selIdxs().length;
    var cmpOn=!!(a&&a.cmp&&a.cinst);
    show('#fmt-match',isNum&&selCount>=1);   /* T413 */
    show('#fmt-cmp-make',isNum&&selCount>=1&&!cmpOn);
    show('#fmt-cmp-add',cmpOn);   /* T409: the door that was missing */
    show('#fmt-cmp-find',cmpOn);
    var cf=$('#fmt-cmp-find');
    if(cf&&cmpOn&&typeof cmpInstances==='function'){
      var cn=cmpInstances(a.cmp).length;
      cf.innerHTML=bic('locate')+' Its clones ('+cn+')';
    }
    /* the Source window's door (T177): anything that came from
       somewhere -- a placed cell, a picture that knows its file, or
       anything with a provenance to show */
    var srcOn=(kind==='cell')||(isNum&&!!provRef(a))||!!(ir&&!ir.hidden);
    show('#fmt-srcwrap',srcOn);
    show('#fmt-src',srcOn);
    var partsSlot=$('#fmt-parts');
    if(partsSlot){
      partsSlot.innerHTML='';
      var pcr=(kind==='cell'&&typeof selAnnot==='number')
        ?buildPartChooser(s,selAnnot):null;
      if(pcr) partsSlot.appendChild(pcr);
      partsSlot.hidden=!pcr;
    }
    /* the frames pane FOLLOWS the selection: select a flip book and it
       shows that one's figures; select a caption instead and its "tie to"
       row wakes up for whatever is selected. Only when the pane is
       actually open — this runs on every click on the canvas. */
    if(typeof renderFlipPane==='function'){
      var fpEl=$('#flippane');
      if(fpEl&&!fpEl.hidden){
        selIdxs().forEach(function(i){
          var xf=(s&&s.annots||[])[i];
          if(xf&&xf.k==='flip') flipPaneIdx=i;});
        renderFlipPane();
      }
    }
    /* COMPLETENESS. Every #fmt-* control in the contextual bar must be
       governed by FMT_KINDS or listed in FMT_MANUAL. Without this, a
       control added to the markup and forgotten here shows for every kind
       of item, silently and forever — precisely what happened with Ends
       and Route on a shape. Console-only: it is a wiring mistake for
       whoever adds the control, not a user-facing failure. */
    if(!showFmt._checked){
      showFmt._checked=true;
      var governed={};
      Object.keys(FMT_KINDS).forEach(function(k){governed[k]=1;});
      FMT_MANUAL.forEach(function(k){governed[k]=1;});
      var stray=[];
      $$('[id^="fmt-"]',bar).forEach(function(el){
        if(/-menu$/.test(el.id)) return;          /* menu bodies */
        if(governed['#'+el.id]) return;
        /* T497: A CONTROL INSIDE A GOVERNED WRAPPER IS GOVERNED. The
           deselect sweep above already reasons this way ("a button
           inside a governed wrapper is hidden BY the wrapper"), but
           this check did not, so it cried wolf on every first
           selection of every session -- #fmt-chart, #fmt-media and
           #fmt-table, each inside a wrapper FMT_KINDS maps -- and a
           warning that fires every time is one nobody reads; the
           real stray it exists for (Ends and Route on a shape) would
           pass under it (2026-09-15 review). The same rule the sweep
           uses, so the two cannot disagree about what is governed. */
        for(var p=el.parentNode;p&&p!==bar;p=p.parentNode)
          if(p.id&&governed['#'+p.id]) return;
        stray.push('#'+el.id);
      });
      if(stray.length&&window.console&&console.warn)
        console.warn('deck: ribbon controls governed by nothing in '
          +'showFmt, so they will show for every selection: '
          +stray.join(', '));
    }
    /* the windows: doors over empty rooms go, headings over empty rows
       go, and an open window is redrawn for what is selected now */
    syncOptDoors();
    if(typeof optPanelsSync==='function') optPanelsSync();
    /* ...and NOW the tab, with the controls that justify it in place.
       setTab re-runs syncRibbonGroups itself, so this is one call or the
       other, never both. */
    if(wantTab&&ctxNow){
      /* T481: the contextual tab keeps you if it still has content for
         what is selected now; the groups are judged first (with the
         way back kept safe from the empty-tab fallback), and only an
         emptied tab hands over to the other contextual one */
      var keep=tabBeforeSel;
      syncRibbonGroups();
      tabBeforeSel=keep;
      if(activeTab()===ctxTab&&tabHasContent(ctxTab)) wantTab='';
    }
    if(wantTab) setTab(wantTab,true); else syncRibbonGroups();
  }
  /* ---- THE DOORS OF THE WINDOWS (T177) ---------------------------------
     A window's door shows when anything inside it would. showFmt says so
     explicitly for each, and this sweep is the safety net: a heading
     over a row with nothing showing goes with the row, and a door over a
     window with nothing showing goes too -- closing the window if it was
     open, because the selection it was about has changed. A section
     (.opt-sec) counts as content while it is shown: showFmt governs
     those by kind, and their rows are built on open. */
  function optAlive(c,stop){
    var n=c;
    while(n&&n!==stop){if(n.hidden) return false;n=n.parentNode;}
    return true;
  }
  function syncOptDoors(){
    $$('#edit-tools .opt-drop').forEach(function(w){
      if(w.dataset.flat) return;
      var door=null,panel=null;
      [].slice.call(w.children).forEach(function(c){
        if(!door&&c.classList.contains('dbtn')) door=c;
        if(!panel&&c.classList.contains('opt-panel')) panel=c;
      });
      if(!door||!panel) return;
      $$('.opt-row',panel).forEach(function(r){
        var any=$$('button,input,select',r).some(function(c){
          return optAlive(c,r);});
        r.hidden=!any;
        var lab=r.previousElementSibling;
        if(lab&&lab.classList.contains('hd-lab')) lab.hidden=!any;
      });
      /* T220: a window whose rows are BUILT when it opens is not
         empty just because it is closed. Before spacing moved out of
         the Paragraph window, its .opt-sec kept the sweep happy; with
         that gone the door vanished for every text box. showFmt alone
         decides these two. */
      if(panel.dataset.built) return;
      var any=$$('button,input,select',panel).some(function(c){
        return !c.classList.contains('opt-sec-btn')&&optAlive(c,panel);})
        ||$$('.opt-sec',panel).some(function(sc){return optAlive(sc,panel);});
      if(any) return;
      door.hidden=true;w.hidden=true;
      if(!panel.hidden&&typeof overlayHide==='function') overlayHide(panel);
    });
  }
  /* hide a ribbon group whose controls are all hidden, and drop the divider
     before the first visible group — so the format ribbon stays tidy */
  function syncRibbonGroups(){
    if(typeof clipSync==='function') clipSync();   /* T537 */
    /* the WHOLE ribbon, not just the contextual half: a static group can
       empty out too (Notebooks has nothing to offer a poster with no
       placed cells yet) and an empty group that still drew its label and
       divider read as a missing feature */
    var bar=$('#edit-tools'); if(!bar) return;
    /* WHAT IS VISIBLE FIRST, and the tab filter after it. A group's
       emptiness is a fact about its controls, not about which tab is
       showing, so this pass does not care — and the answer is what the
       tab decisions below need. `data-off` still goes on before anything
       MEASURES the row, which is what the old ordering was protecting
       (2026-08-25, ribbon layouts). */
    $$('.rbn-grp',bar).forEach(function(g){
      /* T438: the provenance readout is content too -- a pasted
         picture has no refresh button and no Source door, and its
         group was hidden with the one line the tab exists to show */
      var SEL='button,input,select,.sh-drop,.fmt-path';
      var vis=false,kids=[].slice.call(g.querySelectorAll(SEL));
      /* T453: A SHELVED GROUP'S ROW IS NOT INSIDE IT. rbnShelfOpen
         moves the whole .rbn-row into the ribbon's shelf, so a group
         whose options are open would have had nothing left but its door
         -- which this pass skips -- and would have been hidden out from
         under the very row it is showing. Its controls are still its
         own wherever they are sitting. */
      var shelved=(typeof rbnFoldRow==='function')?rbnFoldRow(g):null;
      if(shelved&&!g.contains(shelved))
        kids=kids.concat([].slice.call(shelved.querySelectorAll(SEL)));
      else shelved=null;
      for(var i=0;i<kids.length;i++){
        var n=kids[i],blocked=false;
        /* ...and the walk up stops at whichever host it came from */
        var stop=g.contains(n)?g:shelved;
        /* A FOLD DOOR IS NOT CONTENT, AND THE DRAWER IT OPENS IS NOT A
           REASON TO HIDE. rbnFoldGroup (T187) moves the group's whole
           .rbn-row into a `hidden` .rbn-foldmenu and leaves a tile
           behind. Both halves fooled this pass, in opposite directions:
           the door is a visible <button> nothing governs, so a folded
           group ALWAYS read as occupied -- and that is the other half of
           why the Object tab would not leave the strip. Once the window
           was narrow enough for the ladder to fold that group, its
           controls could all be hidden and the tab still had one visible
           child forever. Found in a browser on 2026-09-05: after
           deselecting, the group's five children were the wrap, the
           "Object ▾" door, and three properly-hidden controls.
           Skipping the drawer's `hidden` is the matching half: without
           it a folded group with real content on it would read as empty
           and be taken off the row entirely. A control one click away is
           still on the ribbon -- that is what folding MEANS. */
        if(n.classList.contains('rbn-foldwrap')
           ||n.classList.contains('rbn-foldbtn')) continue;
        /* T497: NOR ARE A STRIP'S ARROWS. Back / Next / Show all are
           the chrome round a row of tiles, not choices of their own
           (rbnFoldReadout already skips them); with the tiles hidden
           they kept the Effect group -- and its door over an empty
           shelf -- on a poster's ribbon (2026-09-15 review) */
        if(n.closest&&n.closest('.strip-nav')) continue;
        while(n&&n!==stop){
          if(n.hidden&&!n.classList.contains('rbn-foldmenu')){
            blocked=true;break;}
          n=n.parentNode;
        }
        if(!blocked){vis=true;break;}
      }
      g.hidden=!vis;
    });
    /* A CONTEXTUAL TAB, and what happens when its reason goes away. A
       ribbon layout may put every object control on a tab of its own —
       PowerPoint's "Picture Format" is the same idea — and such a tab is
       empty until something is selected. An empty tab you can still
       click reads as broken, so the strip drops it; and being left
       STANDING on one when you deselect would show you a blank row, so
       the ribbon falls back to the first tab that has anything, which is
       what every application with contextual tabs does. */
    if(!tabHasContent(activeTab())){
      var to='';
      /* back to the tab the selection took you from, if it still has
         anything on it; the first tab with content otherwise (T192) */
      if(tabBeforeSel&&tabHasContent(tabBeforeSel)) to=tabBeforeSel;
      TABS.forEach(function(t){if(!to&&tabHasContent(t)) to=t;});
      tabBeforeSel='';
      if(to&&to!==activeTab()){curTab=to;lsSet(tabKey(),to);}
    }
    applyTab();
    /* T453: a row on the shelf belongs to one group on one tab; if that
       group has just gone away, give the row back before anything
       measures the row it is no longer part of */
    if(typeof rbnShelfSync==='function') rbnShelfSync();
    /* `rbn-first` used to be stamped on the leading visible group so a
       ::before divider could be suppressed on it. The dividers became a
       border-right on the group itself and `:last-child` handles the end
       of the row, so nothing has styled that class since — it was three
       lines of bookkeeping maintained for no reader (2026-08-17 audit). */
    sizeRibbonGroups();
    /* groups appearing or leaving changes the width the row needs, so the
       density has to be re-judged every time the selection does. (The
       strip's ceiling no longer is: the ribbon spans the window above
       the strip (T514), so a selection cannot move it -- T582.) */
    fitEditRibbon();
  }
  /* How many columns each group needs to fill two rows ACROSS: half its
     visible controls, rounded up.
     This is a COUNT OF WHAT IS SHOWING RIGHT NOW, so it goes stale the
     moment anything reveals a control without re-running it — and something
     did. applyPage() un-hides #vw-versions ("Slides" / "Versions") after
     the count, so View was sized for the two controls it had at count time,
     the third landed in an implicit third grid row, and the row overran its
     own VIEW label and printed on top of it (2026-08-16). Owning the count
     in one function that fitEditRibbon also calls makes it self-healing:
     any path that re-fits the ribbon re-counts it first. */
  /* T365: can this cell be widened to its column without reading as a
     mistake? A plain button or a dropdown wrapper can -- both are one
     label in one box. A joined run, a strip, a fixed tile cannot. */
  function rbnCanFit(c){
    if(c.classList.contains('sh-drop')
       ||c.classList.contains('dc-menuwrap')) return true;
    return c.classList.contains('dbtn')
      &&!c.classList.contains('big-tile');
  }
  function sizeRibbonGroups(){
    var bar=$('#edit-tools'); if(!bar) return;
    $$('.rbn-grp',bar).forEach(function(g){
      var row=g.querySelector('.rbn-row'); if(!row) return;
      var n=0,last=null,buf=[],pairs=[];
      /* T365: the cells fill DOWN then across, so consecutive single
         cells pair off into columns and a spanning control resets the
         pairing (it takes the next whole column for itself) */
      function flushPairs(){
        while(buf.length>=2) pairs.push([buf.shift(),buf.shift()]);
        buf.length=0;
      }
      [].slice.call(row.children).forEach(function(c){
        c.classList.remove('rbn-odd');
        c.classList.remove('rbn-fit');
        /* T365: `.rbn-hid` is how a customised ribbon layout hides a
           control (applyRibbonPrefs; deck.css makes it
           display:none!important). It is not the `hidden` attribute,
           so this count -- and the parity built on it -- was wrong for
           anyone who had switched a button off. */
        if(c.hidden||c.classList.contains('rbn-hid')) return;
        /* a control that spans BOTH rows is worth two cells, or a group
           made of nothing but stacks asks for half the columns it needs
           and pushes the overflow into an implicit third row */
        /* ...but a CELL is one track high by rule (.rbn-cell is
           --rbn-track, .rbn-seg is --rbn-btn-h), so `rbn-tall` on one is
           a claim it cannot honour: it reserved a column for a 26px
           control and left the row under it empty (T370). Counted as
           the one cell it is, and the grid below is told the same. */
        if(!c.classList.contains('rbn-cell')
           &&(c.classList.contains('rbn-stack')
              ||c.classList.contains('rbn-big')
              ||c.classList.contains('rbn-tall'))){
          n+=2;last=null;flushPairs();return;
        }
        /* a wrapper counts as the one cell it contributes */
        if(c.classList.contains('sh-drop')||c.classList.contains('dc-menuwrap')){
          var b=c.querySelector('.dbtn');
          if(b&&!b.hidden){n++;last=c;buf.push(c);}
          return;
        }
        n+=1;last=c;buf.push(c);
      });
      flushPairs();
      /* T365: --rbn-cols is gone. Nothing read it -- no rule in any of
         the five stylesheets -- which is what the T207 comment above
         .rbn-row already says: "The column count is no longer a
         variable anything sets." Placement is grid-auto-flow:column
         against two 30px tracks, and `n` is now used for the parity
         below rather than for a property nobody consumed. */
      /* T365: both halves of a column share its width -- but only where
         widening is not absurd. A joined run is as wide as all of its
         segments; stretching a plain button to that is the "why is tidy
         page huge?" of 2026-09-03, so a pair holding one is left alone
         and the markup gives such runs a column of their own instead. */
      pairs.forEach(function(p){
        if(rbnCanFit(p[0])&&rbnCanFit(p[1])){
          p[0].classList.add('rbn-fit');p[1].classList.add('rbn-fit');}
      });
      /* ...and the odd one out fills the band rather than hanging at
         the top of it with a hole underneath */
      if(n%2===1&&last) last.classList.add('rbn-odd');
    });
  }
  /* T585: a drawn menu option that is only POINTED AT applies as a
     preview (30-format-bar.js, drawnOpt): no history, no dirty mark --
     the same quiet a held Trim stepper gets */
  var fmtPreview=false;
  function fmtApply(fn,quiet){
    quiet=quiet||fmtPreview;
    var s=pres.slides[cur]; if(!s) return;
    /* T494: the words being typed get their own entry BEFORE the format
       mutates the box, or the first Ctrl+Z after Bold takes the
       sentence and leaves the bold (see histSettle) */
    if(!quiet) histSettle();
    /* apply to EVERY selected item (a group or shift-multi-select), not just
       the primary — otherwise formatting a multi-selection silently changes
       only one item and collapses the selection */
    var targets=selSet.filter(function(i){return typeof i==='number';});
    if(targets.length){
      targets.forEach(function(i){if(s.annots[i]) fn(s.annots[i]);});
    } else {
      var a=annotByIdx(s,selAnnot); if(!a) return;
      fn(a);
    }
    /* quiet = live preview inside a continuous gesture (a Trim stepper
       being held, a value being typed): redraw but push NO history —
       the gesture's end commits ONE undo entry instead of one per
       keystroke evicting real edits from the 50-slot stack
       (2026-08-05 review) */
    if(!quiet) markDirty();
    var l=stage.querySelector('.annot-layer');
    if(!l) return;
    renderAnnots(l,s);
    if(targets.length>1){        /* keep the multi-selection alive */
      selSet=targets.slice();paintSel(l);
      showFmt();
    } else selectAnnot(l,selAnnot);
  }
  function pctPoint(layer,ev){
    var r=layer.getBoundingClientRect();
    return {x:Math.max(0,Math.min(100,(ev.clientX-r.left)/r.width*100)),
            y:Math.max(0,Math.min(100,(ev.clientY-r.top)/r.height*100))};
  }
  /* T405: THE SAME POINT, UNCLAMPED, for a MOVE. pctPoint pins the
     pointer to the page, which is right for drawing a new box and wrong
     for dragging one: the drag's delta could never carry an object past
     the page edge, so nothing could be parked beside the slide, though
     the layer already spills while editing and the stage grows
     scrollbars for it (2026-09-13, user: "it is useful sometimes to be
     able to drag objects outside of the slide and leave them there, but
     that isn't really an option here"). Playback and every export clip
     to the page, so a parked object is out of the show until it is
     dragged back. */
  function pctPointFree(layer,ev){
    var r=layer.getBoundingClientRect();
    return {x:(ev.clientX-r.left)/(r.width||1)*100,
            y:(ev.clientY-r.top)/(r.height||1)*100};
  }
  /* ---- LOCKS -----------------------------------------------------------
     TWO locks, because there are two different things people mean by the
     word (TASKS T3):

       'all'  fully locked. The item cannot be clicked, dragged, resized,
              typed into or nudged on the canvas at all -- the Objects
              pane, and an Alt-marquee, are its remaining doors. This is
              the lock that already existed, and every saved deck carries
              it as `lock:1`.
       'pos'  position locked. Pinned where it is, and otherwise entirely
              yours: select it, resize it, restyle it, type in it. This
              is what a figure frame usually wants -- the plot must not
              wander, and you still need to make it bigger.

     `lockMode` is the ONLY reader of the raw flag; everything else asks
     one of the two questions below, so a third mode would be a change in
     one place. `pinned` is the movement question and `lockedAll` the
     reachability one -- getting those two the wrong way round is exactly
     the bug this section exists to make hard. */
  function lockMode(a){
    if(!a||!a.lock) return '';
    return a.lock==='pos'?'pos':'all';
  }
  function lockedAll(a){return lockMode(a)==='all';}
  function pinned(a){return !!lockMode(a);}
  var LOCK_LABEL={'':'Not locked','pos':'Position locked',
    all:'Fully locked'};
  /* ---- snap-to-align: while dragging or resizing, edges and centers
     snap to the canvas (edges + middle) and to every other object's
     edges + centers, with dashed guide lines. Hold Alt to disable --
     EXCEPT in an Alt-drag clone, where Alt already means "copy" and you
     have to keep holding it (see startMove's `cloning`). ---- */
  /* 6px was too tight to feel: on a poster zoomed to fit, a 6px window is
     a couple of real millimetres and the snap kept slipping past you */
  var SNAP_PX=9;
  function annotRectPct(layer,s,i){
    var a=(s.annots||[])[i]; if(!a) return null;
    if(a.k==='arrow')
      return {l:Math.min(a.x1,a.x2),r:Math.max(a.x1,a.x2),
              t:Math.min(a.y1,a.y2),b:Math.max(a.y1,a.y2)};
    /* NO LAYER is a legitimate caller: the .pptx export walks every slide,
       and only the one on screen has a rendered layer to measure. Without
       one we fall through to the stored box, which is the same fallback
       an attached endpoint already uses when its target goes away. */
    var el=layer?layer.querySelector('.an-item[data-idx="'+i+'"]'):null;
    /* auto-sized items (text) AND aspect-fitted figure frames answer with
       their RENDERED rect — snapping must align to the visible plot, not
       a letterboxed stored box */
    if(el&&(a.w==null||a.h==null
            ||el.classList.contains('an-figonly'))){
      var lr=layer.getBoundingClientRect();
      if(lr.width&&lr.height){
        var er=el.getBoundingClientRect();
        return {l:(er.left-lr.left)/lr.width*100,
                r:(er.right-lr.left)/lr.width*100,
                t:(er.top-lr.top)/lr.height*100,
                b:(er.bottom-lr.top)/lr.height*100};
      }
    }
    if(a.w==null||a.h==null) return null;
    var ap=anchorPos(a,a.w,a.h);
    return {l:ap.x,r:ap.x+a.w,t:ap.y,b:ap.y+a.h};
  }
  function snapTargets(layer,s,skip){
    var xs=[0,50,100],ys=[0,50,100];
    (s.annots||[]).forEach(function(a,i){
      if(skip.indexOf(i)>=0||a.hide) return;
      var r=annotRectPct(layer,s,i);
      if(!r) return;
      xs.push(r.l,(r.l+r.r)/2,r.r);
      ys.push(r.t,(r.t+r.b)/2,r.b);
    });
    /* the margin box and grid columns are snap lines too — a visible
       guide you cannot snap to would be worse than none */
    var g=guideTargets();
    xs=xs.concat(g.xs);ys=ys.concat(g.ys);
    /* guides you dragged off the rulers yourself — and only while
       they are shown: an invisible line that still pulls items onto
       itself is worse than either state (2026-08-29) */
    var cg=guidesShown()?customGuides():{x:[],y:[],b:[]};
    xs=xs.concat(cg.x);ys=ys.concat(cg.y);
    /* a guide box contributes its edges AND its middles: lining things up
       with one is the entire reason for drawing it */
    cg.b.forEach(function(v){
      xs.push(v[0],v[0]+v[2]/2,v[0]+v[2]);
      ys.push(v[1],v[1]+v[3]/2,v[1]+v[3]);
    });
    return {xs:xs,ys:ys};
  }
  /* ---- equal-gap detection -------------------------------------------
     Alignment gets you edges that agree; what still reads as sloppy is
     uneven whitespace. While dragging, look for a position where the gap
     to a neighbour matches a gap that already exists between two other
     items on the same band, and mark both. */
  function gapCands(layer,s,skip,bb,horiz){
    var boxes=[];
    (s.annots||[]).forEach(function(a,i){
      if(skip.indexOf(i)>=0||!a||a.hide||a.k==='arrow') return;
      var r=annotRectPct(layer,s,i); if(!r) return;
      /* only items on the same band count: a figure three columns over
         is not "next to" anything */
      var overlap=horiz?(r.b>bb.t&&r.t<bb.b):(r.r>bb.l&&r.l<bb.r);
      if(overlap) boxes.push(r);
    });
    boxes.sort(function(p,q){return horiz?(p.l-q.l):(p.t-q.t);});
    /* a gap is not just a NUMBER. It was measured between two particular
       neighbours, and to show you what a match matched — which is the
       whole point of the badge — the pair has to travel with the value
       (2026-08-25, T7). The old code kept only the number, which is why
       the comment above promised to "mark both" and only one was ever
       drawn. */
    var gaps=[];
    for(var i=1;i<boxes.length;i++){
      var p=boxes[i-1],q=boxes[i];
      var g=horiz?(q.l-p.r):(q.t-p.b);
      if(g>0.2) gaps.push({g:g,
        a:horiz?p.r:p.b, b:horiz?q.l:q.t,
        at:horiz?(Math.max(p.t,q.t)+Math.min(p.b,q.b))/2
                :(Math.max(p.l,q.l)+Math.min(p.r,q.r))/2});
    }
    return {boxes:boxes,gaps:gaps};
  }
  /* returns a delta that makes one of the dragged item's gaps equal to an
     existing gap, plus the pair of gaps to draw */
  function bestGap(layer,s,skip,bb,horiz,thr){
    var c=gapCands(layer,s,skip,bb,horiz);
    if(!c.gaps.length||!c.boxes.length) return null;
    var lo=horiz?bb.l:bb.t,hi=horiz?bb.r:bb.b;
    var best=null;
    c.boxes.forEach(function(r){
      var before=horiz?r.r:r.b,after=horiz?r.l:r.t;
      c.gaps.forEach(function(gp){
        var g=gp.g;
        /* place the dragged box a distance g AFTER this one... */
        var d1=(before+g)-lo;
        if(Math.abs(d1)<=thr&&(!best||Math.abs(d1)<Math.abs(best.d)))
          best={d:d1,gap:g,from:r,side:'after',src:gp};
        /* ...or a distance g BEFORE it */
        var d2=(after-g)-hi;
        if(Math.abs(d2)<=thr&&(!best||Math.abs(d2)<Math.abs(best.d)))
          best={d:d2,gap:g,from:r,side:'before',src:gp};
      });
    });
    return best;
  }
  /* PAGE PERCENT <-> MILLIMETRES, both directions, in one place. The
     model is percent because a deck has to survive a page-shape change;
     every number a human reads or types is millimetres, because that is
     what the rulers, the gap badges and the print shop speak (T7, T65).
     `horiz` picks which side of the page the percentage is OF -- x and w
     are percentages of the width, y and h of the height. */
  function pctMm(v,horiz){
    var pg=pageOf();
    return v/100*((horiz?pg.mm[0]:pg.mm[1])||0);
  }
  function mmPct(v,horiz){
    var pg=pageOf(),m=(horiz?pg.mm[0]:pg.mm[1])||0;
    return m?(v/m*100):0;
  }
  /* a distance across the page, in the millimetres the rulers speak.
     A percentage means nothing to anyone laying out an A0 poster, and
     the badge exists precisely so the number can be read (T7). */
  function gapMm(v,horiz){
    var mm=Math.abs(pctMm(v,horiz));
    return (mm<10?Math.round(mm*10)/10:Math.round(mm))+' mm';
  }
  function drawGapMarks(layer,marks){
    $$('.snapgap,.snapgap-lab',layer).forEach(function(n){n.remove();});
    marks.forEach(function(m){
      var lo=Math.min(m.a,m.b),hi=Math.max(m.a,m.b);
      var el=document.createElement('div');
      /* the gap you are MAKING is solid; the one it matched is drawn
         faint, because it is evidence rather than an instruction */
      el.className='snapgap'+(m.ref?' snapgap-ref':'');
      if(m.horiz){
        el.style.left=lo+'%';el.style.width=(hi-lo)+'%';
        el.style.top=(m.at-0.35)+'%';el.style.height='0.7%';
      } else {
        el.style.top=lo+'%';el.style.height=(hi-lo)+'%';
        el.style.left=(m.at-0.35)+'%';el.style.width='0.7%';
      }
      layer.appendChild(el);
      /* THE BADGE. A bar says "these two distances agree"; the number
         says what the distance IS, which is the question you were
         actually asking when you started dragging (T7). It reuses
         .dragtag, which was styled for exactly this kind of readout and
         then never wired to anything. */
      var lab=document.createElement('div');
      lab.className='dragtag snapgap-lab'+(m.ref?' snapgap-lab-ref':'');
      lab.textContent=gapMm(hi-lo,m.horiz);
      if(m.horiz){
        lab.style.left=((lo+hi)/2)+'%';
        lab.style.top=m.at+'%';
      } else {
        lab.style.left=m.at+'%';
        lab.style.top=((lo+hi)/2)+'%';
      }
      layer.appendChild(lab);
    });
  }
  function bestSnap(cands,vals,thr){
    var best=null;
    for(var i=0;i<vals.length;i++) for(var j=0;j<cands.length;j++){
      var d=cands[j]-vals[i];
      if(Math.abs(d)<=thr&&(!best||Math.abs(d)<Math.abs(best.d)))
        best={d:d,at:cands[j]};
    }
    return best;
  }
  function snapThr(layer){
    var r=layer.getBoundingClientRect();
    return {x:r.width?SNAP_PX/r.width*100:1,
            y:r.height?SNAP_PX/r.height*100:1};
  }
  /* a snap onto the PAGE's own edge or centre says something different
     from a snap onto another item, so the two are coloured apart */
  function isPageLine(v){
    return v===0||v===50||v===100;
  }
  function drawSnapGuides(layer,sx,sy){
    $$('.snapline',layer).forEach(function(n){n.remove();});
    if(sx!=null){
      var v=document.createElement('div');
      v.className='snapline snap-v'+(isPageLine(sx)?' snap-page':'');
      v.style.left=sx+'%';
      layer.appendChild(v);
    }
    if(sy!=null){
      var h=document.createElement('div');
      h.className='snapline snap-h'+(isPageLine(sy)?' snap-page':'');
      h.style.top=sy+'%';
      layer.appendChild(h);
    }
  }
  function clearSnapGuides(layer){
    /* .snapgap-lab is named here explicitly: the badge carries `dragtag`
       and `snapgap-lab`, neither of which is `.snapgap`, so it was only
       ever cleaned up incidentally — by the renderAnnots at the end of a
       drag, which is itself guarded by `if(movedAny)` (2026-08-25). */
    $$('.snapline,.snapgap,.snapgap-lab',layer)
      .forEach(function(n){n.remove();});
  }
  function startMove(layer,s,idx,ev0){
    ev0.preventDefault();
    /* ALT-DRAG CLONES. The copies are made in place and it is THEY that
       travel, so the originals are left exactly where they were and the
       rest of this function needs to know nothing about it.
       Alt also turns snapping off mid-drag (see `mm`) -- but not during
       a clone drag, where Alt was pressed to say "copy", not "ignore the
       guides", and where you have to keep holding it the whole way. */
    var cloning=false,cloneIdx=null,selWas=selIdxs().slice();
    if(ev0.altKey&&typeof idx==='number'){
      var pick=selIdxs();
      if(pick.indexOf(idx)<0) pick=[idx];
      pick=pick.filter(function(i){
        var m=(s.annots||[])[i];return m&&!lockedAll(m);});
      var clones=cloneAnnots(pick,0,0);
      if(clones.length){
        cloning=true;cloneIdx=clones.slice();
        /* quiet: the mouseup at the end of this gesture takes the one
           undo entry, and it should undo the clone and its move together
           -- they are one gesture */
        markDirty(true);
        renderAnnots(layer,s);
        var k=pick.indexOf(idx);
        idx=clones[k>=0?k:0];
        selectMany(layer,clones);
      }
    }
    var a=annotByIdx(s,idx); if(!a) return;
    var start=pctPointFree(layer,ev0);   /* T405: a move may leave the page */
    /* drag the whole current selection (group / multi-select) together —
       pinned members stay put, under EITHER lock */
    var movers=selSet.filter(function(i){return typeof i==='number';});
    if(typeof idx==='number'&&movers.indexOf(idx)<0) movers=[idx];
    movers=movers.filter(function(i){
      var m=(s.annots||[])[i];return m&&!pinned(m);});
    var origs={};
    movers.forEach(function(i){
      origs[i]=deep((s.annots||[])[i]);});
    /* a snapshot of each mover's tied caption, for the same reason the
       movers themselves are snapshotted: the drag is computed from the
       ORIGINAL position every mousemove, never incrementally */
    var capOrig={};
    movers.forEach(function(i){
      var m=(s.annots||[])[i];
      if(!m||!m.cap) return;
      var ci=capOfFig(s,m);
      /* a POSITION LOCK is about position, and every direct mover
         already honours it — this was the one path that dragged a
         pinned item anyway (2026-08-26 audit, T58) */
      if(ci>=0&&movers.indexOf(ci)<0&&!pinned(s.annots[ci]))
        capOrig[i]={a:s.annots[ci],o:deep(s.annots[ci])};
    });
    var single=(typeof idx!=='number')?deep(a):null;
    var thr=snapThr(layer);
    var targets=snapTargets(layer,s,movers);
    /* snap by the union bounding box of everything being dragged
       (hidden members travel along but contribute no snap geometry) */
    var origBB=null;
    movers.forEach(function(i){
      var m=(s.annots||[])[i];
      if(!m||m.hide) return;
      var r=annotRectPct(layer,s,i); if(!r) return;
      origBB=origBB?{l:Math.min(origBB.l,r.l),r:Math.max(origBB.r,r.r),
        t:Math.min(origBB.t,r.t),b:Math.max(origBB.b,r.b)}:r;
    });
    var gapMarks=[];
    /* THE GESTURE PATH (2026-08-23 perf). A drag no longer rebuilds the
       whole annotation layer per mousemove: renderAnnots re-clones every
       placed card (multi-MB figure bodies) on each rebuild. Instead the
       EXISTING nodes' inline left/top move — children (text, captions,
       handles, the selection outline, a frame's aspect-fitted geometry)
       ride along for free — and only the arrows are redrawn, because an
       attached endpoint is DERIVED from where its target item sits. The
       one real renderAnnots runs on mouseup. */
    var movedEls={};
    movers.forEach(function(i){
      var m=(s.annots||[])[i];
      if(!m||m.k==='arrow') return;   /* arrows redraw as strokes below */
      var el=layer.querySelector('div.an-item[data-idx="'+i+'"]');
      if(el) movedEls[i]={el:el,l:parseFloat(el.style.left)||0,
                          t:parseFloat(el.style.top)||0};
    });
    var singleEl=null;
    if(single){
      var tEl=layer.querySelector('div.an-item[data-idx="'+idx+'"]');
      if(tEl) singleEl={el:tEl,l:parseFloat(tEl.style.left)||0,
                        t:parseFloat(tEl.style.top)||0};
    }
    var anyArrow=(s.annots||[]).some(function(m){
      return m&&m.k==='arrow';});
    var movedAny=false;
    function mm(ev){
      movedAny=true;
      var p=pctPointFree(layer,ev);   /* T405 */
      var dx=p.x-start.x,dy=p.y-start.y;
      var sx=null,sy=null;
      /* CLEARED EVERY MOVE, like sx/sy beside it. It used to be reset
         inside the branch that fills it, which is skipped entirely when
         Alt suppresses snapping — so pressing Alt part-way through a drag
         froze the last marks on the page and drawGapMarks below happily
         redrew them, at their stale coordinates, for the rest of the
         gesture. help.html promises Alt "ignores snapping"; it has to
         ignore the evidence of it too (2026-08-25). */
      gapMarks=[];
      if(cloning||!ev.altKey){
        if(single){       /* a title item positions by its CENTER */
          var bx0=bestSnap(targets.xs,[single.x+dx],thr.x);
          var by0=bestSnap(targets.ys,[single.y+dy],thr.y);
          if(bx0){dx+=bx0.d;sx=bx0.at;}
          if(by0){dy+=by0.d;sy=by0.at;}
        } else if(origBB){
          var bb={l:origBB.l+dx,r:origBB.r+dx,
                  t:origBB.t+dy,b:origBB.b+dy};
          var bx=bestSnap(targets.xs,[bb.l,(bb.l+bb.r)/2,bb.r],thr.x);
          var by=bestSnap(targets.ys,[bb.t,(bb.t+bb.b)/2,bb.b],thr.y);
          if(bx){dx+=bx.d;sx=bx.at;}
          if(by){dy+=by.d;sy=by.at;}
          /* an edge snap wins over an equal-gap snap on the same axis:
             agreeing with a line is a stronger intention than matching a
             distance */
          if(!bx){
            var gx=bestGap(layer,s,movers,bb,true,thr.x);
            if(gx){
              dx+=gx.d;
              var nb={l:bb.l+gx.d,r:bb.r+gx.d};
              var mid=(bb.t+bb.b)/2;
              gapMarks.push({horiz:true,at:mid,
                a:gx.side==='after'?gx.from.r:nb.r,
                b:gx.side==='after'?nb.l:gx.from.l});
              /* ...and the gap it MATCHED. Two bars carrying the same
                 number is the whole message; one bar on its own only
                 ever said "something snapped" (T7) */
              if(gx.src) gapMarks.push({horiz:true,at:gx.src.at,
                a:gx.src.a,b:gx.src.b,ref:1});
            }
          }
          if(!by){
            var gy=bestGap(layer,s,movers,bb,false,thr.y);
            if(gy){
              dy+=gy.d;
              var nby={t:bb.t+gy.d,b:bb.b+gy.d};
              var midx=(bb.l+bb.r)/2;
              if(gy.src) gapMarks.push({horiz:false,at:gy.src.at,
                a:gy.src.a,b:gy.src.b,ref:1});
              gapMarks.push({horiz:false,at:midx,
                a:gy.side==='after'?gy.from.b:nby.b,
                b:gy.side==='after'?nby.t:gy.from.t});
            }
          }
        }
      }
      if(single){
        a.x=single.x+dx;a.y=single.y+dy;
        if(singleEl){
          singleEl.el.style.left=(singleEl.l+dx)+'%';
          singleEl.el.style.top=(singleEl.t+dy)+'%';
        }
      }
      else movers.forEach(function(i){
        var m=(s.annots||[])[i],o=origs[i];
        if(!m||!o) return;
        if(m.k==='arrow'){
          m.x1=o.x1+dx;m.y1=o.y1+dy;m.x2=o.x2+dx;m.y2=o.y2+dy;
        } else if(m.anch){
          var op=anchorPos(o,o.w,o.h);
          anchorSet(m,op.x+dx,op.y+dy,o.w,o.h);
        } else {m.x=o.x+dx;m.y=o.y+dy;}
        /* the drag writes absolute positions from a snapshot rather
           than going through shiftAnnot, so the caption hook has to be
           repeated here — and it moves by the same delta from ITS own
           snapshot, or a caption would creep on every mousemove */
        if(m.cap&&capOrig[i]){
          var cc=capOrig[i];
          if(cc.a.anch){
            var cp=anchorPos(cc.o,cc.o.w,cc.o.h);
            anchorSet(cc.a,cp.x+dx,cp.y+dy,cc.o.w,cc.o.h);
          } else {cc.a.x=cc.o.x+dx;cc.a.y=cc.o.y+dy;}
        }
        var me=movedEls[i];
        if(me){me.el.style.left=(me.l+dx)+'%';
               me.el.style.top=(me.t+dy)+'%';}
      });
      if(anyArrow) redrawArrows(layer,s);
      drawSnapGuides(layer,sx,sy);
      drawGapMarks(layer,gapMarks);
    }
    function mu(){
      document.removeEventListener('mousemove',mm);
      document.removeEventListener('mouseup',mu);
      clearSnapGuides(layer);
      /* AN ALT-CLICK THAT NEVER MOVED IS NOT A COPY. The clone is made on
         mousedown precisely so that it is the copy that travels — but
         when the gesture turns out to be a click, that left an
         exact-overlap duplicate sitting on top of its original, with
         nothing to see and no toast, where Ctrl+D offsets by CLONE_OFF
         so that a copy is never invisible (2026-08-26 audit, T57).
         Taken back off here, with the selection you had put back. The
         clone was made quietly, so nothing has to come off the undo
         stack either. */
      if(cloning&&!movedAny&&cloneIdx&&cloneIdx.length){
        var ann=s.annots||[];
        cloneIdx.slice().sort(function(p,q){return q-p;})
          .forEach(function(ci){ann.splice(ci,1);});
        renderAnnots(layer,s);
        if(selWas.length) selectMany(layer,selWas);
        else {selAnnot=null;selSet=[];paintSel(layer);showFmt();}
        markDirty(true);
        return;
      }
      /* the ONE rebuild per gesture (a moveless click keeps the old
         no-render path, so double-click-to-type is undisturbed) */
      if(movedAny){renderAnnots(layer,s);paintSel(layer);}
      markDirty();
    }
    document.addEventListener('mousemove',mm);
    document.addEventListener('mouseup',mu);
  }
  function startResize(layer,s,idx,ev0,corner){
    ev0.preventDefault();ev0.stopPropagation();
    var a=annotByIdx(s,idx);
    if(!a||typeof idx!=='number') return;
    /* A TIED CAPTION KEEPS THE FIGURE'S WIDTH. It is the one dimension a
       caption shares with its figure — a caption wider or narrower than
       the thing it describes is the single most common way a figure
       block stops looking deliberate — and it is the only one, because
       a caption's HEIGHT is its words (T17). */
    var capA=null,capO=null,figO=null;
    if(a.cap){
      var ci0=capOfFig(s,a);
      if(ci0>=0){capA=s.annots[ci0];capO=deep(capA);figO=deep(a);}
    }
    corner=corner||'se';
    var east=corner.indexOf('e')>=0,west=corner.indexOf('w')>=0;
    var south=corner.indexOf('s')>=0,north=corner.indexOf('n')>=0;
    var start=pctPoint(layer,ev0);
    var el=layer.querySelector('.an-item[data-idx="'+idx+'"]');
    var lr=layer.getBoundingClientRect();
    /* a figure frame: first snap the stored rect to the plot it visually
       hugs, then keep the plot's aspect locked while dragging */
    var figRatio=0;
    function takeFit(f){
      if(!f) return false;
      a.w=f.w;a.h=f.h;
      anchorSet(a,f.x,f.y,f.w,f.h);
      return true;
    }
    if(a.k==='cell'&&el&&el.classList.contains('an-figonly')){
      var ff=figFit(layer,a,figImg(el));
      if(takeFit(ff)) figRatio=ff.ratio;
    }
    /* A PLACED IMAGE gets the same treatment, for the same reason. It did
       not, and the result was the bug you could not put your finger on:
       .an-imgel is object-fit:contain, so a free-form box that no longer
       matches the picture's shape just grows LETTERBOX. Drag a wide photo
       downwards and the selection outline gets taller while the photo
       stays exactly the size it was — "images don't get bigger when you
       drag them, just get's a bigger border" (2026-08-20, user).
       So: snap the stored box onto the picture (killing any letterbox
       already banked), then hold the picture's aspect for the drag, which
       is what every other tool does with a photo. Hold SHIFT to stretch
       it out of shape on purpose.
       T588: A CROPPED PICTURE KEEPS ITS SHAPE TOO. It used to resize
       free-form, "because the box IS the crop window and reshaping it is
       the whole point" -- but a cropped picture is object-fit:cover, so
       every drag that changed the box's shape cut more of the picture
       away, and a picture shrunk until one side hit the size floor was
       cropped by the other (2026-09-30, user: "when trying to re-size and
       image a lot of the time it just ends up cropping it if it gets too
       small, which is definently not what i want"). Resizing resizes;
       reshaping the crop is the Crop button's job. So a picture with a
       crop or a window (T587) holds the shape it has now, read off the
       box -- not the source picture's, which is not what it shows -- and
       Shift still frees it. Not while trimming: those are the trim
       handles' drags, not this one. */
    var imgFree=false,cropHold=false;
    if(a.k==='image'&&el&&(a.crop||a.win)&&!cropMode){
      cropHold=true;imgFree=true;
    } else if(a.k==='image'&&!a.crop&&el){
      var ie=el.querySelector('.an-imgel');
      var fi=ie?figFit(layer,a,ie):null;
      if(takeFit(fi)){figRatio=fi.ratio;imgFree=true;}
      /* ...unless Shift says otherwise, live, below */
    }
    var er=el?el.getBoundingClientRect():null;
    var ow=a.w||(er?er.width/lr.width*100:10);
    var oh=a.h||(er?er.height/lr.height*100:10);
    var origin=anchorPos(a,ow,oh),ox=origin.x,oy=origin.y;
    /* THE ASPECT LOCK (T65). Two sources, one number. A figure frame and
       an uncropped picture bring their own ratio (figRatio, above); any
       other item the user has locked with "Keep shape" is held to the
       shape it has RIGHT NOW, read off the box at mousedown -- the lock
       says "stay this shape", never "become square", which is why
       nothing is stored on the item but the flag.
       SHIFT IS THE MOMENTARY OPPOSITE of whatever is in force: it frees
       a locked item and constrains an unlocked one, which is what every
       drawing tool has taught people to expect. It used only to free,
       and only a picture. The one exception is a figure frame, whose box
       IS its plot -- freeing it just banks letterbox again, so Shift
       cannot reach it (that is what imgFree marks). */
    var boxRatio=(oh>0&&lr.height&&lr.width)
      ?((ow*lr.width)/(oh*lr.height)):0;
    var baseRatio=figRatio||((a.lockar||cropHold)?boxRatio:0);
    var canFree=imgFree||!!a.lockar;
    /* A ONE-AXIS HANDLE. The untouched axis is not this drag's business:
       nothing below writes to it, and only an aspect lock may move it --
       centred, so the item grows evenly either side rather than lurching
       towards whichever edge happened to be first in the source. */
    var axisX=(east||west)&&!(north||south);
    var axisY=(north||south)&&!(east||west);
    var thr=snapThr(layer);
    var targets=snapTargets(layer,s,[idx]);
    /* the same gesture path startMove uses (2026-08-23 perf): sync the
       existing element's inline box from the model instead of rebuilding
       the layer per mousemove; shapes/freehand scale via their viewBox,
       a fitted figure via its 100%-sized <img>, and attached arrows are
       redrawn because their endpoints derive from this box. The one real
       renderAnnots runs on mouseup. */
    var anyArrow=(s.annots||[]).some(function(m){
      return m&&m.k==='arrow';});
    var movedAny=false;
    /* T584: THE FLOOR IS A FEW PIXELS, NOT 4% OF THE SLIDE. 4% was about
       60px on a laptop, so a dot marking a town on a map could not be
       made smaller than a coin (2026-09-30, user: "I tried drawing an
       oval just then, but it seems like there is a minimum size").
       Six screen pixels still leaves something to take hold of. */
    var mnX=lr.width?600/lr.width:0.5,mnY=lr.height?600/lr.height:0.5;
    /* T542: a text box that KEEPS a height (the fit line a.fh -- words
       at its middle or foot, or shrinking to fit) has that height moved
       by the vertical handles. A box that grows with its words still has
       none to move. */
    var fh0=(a.k==='text'&&a.fh)?+a.fh:0;
    function mm(ev){
      movedAny=true;
      var p=pctPoint(layer,ev);
      var dx=p.x-start.x,dy=p.y-start.y;
      /* Shift is the momentary opposite of the lock that is in force, so
         you can decide mid-gesture rather than before it (T65) */
      var ratio=baseRatio
        ?((canFree&&ev.shiftKey)?0:baseRatio)
        :(ev.shiftKey?boxRatio:0);
      /* the dragged corner moves; the opposite corner stays anchored */
      var nx=ox,ny=oy,nw=ow,nh=oh;
      if(east) nw=Math.max(mnX,ow+dx);
      if(west){nw=Math.max(mnX,ow-dx);nx=ox+(ow-nw);}
      if(a.k!=='text'){
        if(south) nh=Math.max(mnY,oh+dy);
        if(north){nh=Math.max(mnY,oh-dy);ny=oy+(oh-nh);}
      }
      var sx=null,sy=null;
      if(!ev.altKey){
        /* the moving edges snap; an aspect-locked figure snaps its width
           and lets the height follow the plot's ratio. A guide only shows
           when the snap actually landed (the size floor can cancel it). */
        /* ONLY THE AXIS BEING DRAGGED SNAPS. With four corners every
           handle moved both axes, so the `else` arms below were only
           ever reached by a real west/north drag. A side handle makes
           east AND west false, and the else arm would then slide the
           left edge sideways during a purely vertical drag (T65). */
        if(east||west){
          var bx=bestSnap(targets.xs,[east?nx+nw:nx],thr.x);
          if(bx){
            if(east){if(nw+bx.d>=mnX){nw+=bx.d;sx=bx.at;}}
            else if(nw-bx.d>=mnX){nx+=bx.d;nw-=bx.d;sx=bx.at;}
          }
        }
        /* an aspect-locked drag snaps the axis that LEADS and lets the
           other follow: width for a corner or a side handle, height when
           the gesture is vertical-only */
        if(a.k!=='text'&&(north||south)&&(!ratio||axisY)){
          var by=bestSnap(targets.ys,[south?ny+nh:ny],thr.y);
          if(by){
            if(south){if(nh+by.d>=mnY){nh+=by.d;sy=by.at;}}
            else if(nh-by.d>=mnY){ny+=by.d;nh-=by.d;sy=by.at;}
          }
        }
      }
      if(ratio&&lr.height&&lr.width){
        if(axisY&&a.k!=='text'){
          /* dragged by a top or bottom edge: the HEIGHT leads and the
             width follows. The other way round is what the four-corner
             version did, and on a side handle it computed nh from an
             unchanged nw -- an aspect-locked figure would not have moved
             at all (T65). The width grows either side, because a side
             handle names no horizontal edge to anchor. */
          nw=nh*(lr.height*ratio/lr.width);
          nx=ox+(ow-nw)/2;
        } else {
          nh=nw*(lr.width/(lr.height*ratio));
          if(axisX) ny=oy+(oh-nh)/2;   /* ditto, vertically */
          else if(north) ny=oy+oh-nh;  /* keep the bottom edge anchored */
        }
      }
      if(fh0&&(south||north)){
        var nf=Math.max(3,fh0+(south?dy:-dy));
        a.fh=Math.round(nf*100)/100;
        if(north) ny=oy+(fh0-nf);
        if(el) el.style.minHeight='calc('+a.fh+'% - 0.7em - 2px)';
      }
      a.w=nw;
      if(a.k!=='text') a.h=nh;
      anchorSet(a,nx,ny,nw,nh);
      if(el){
        var live=anchorPos(a,nw,nh);
        el.style.left=live.x+'%';el.style.top=live.y+'%';
        if(a.w!=null){el.style.width=a.w+'%';
          if(a.k==='text') el.style.maxWidth='none';}
        if(a.h!=null&&a.k!=='text') el.style.height=a.h+'%';
      }
      if(anyArrow) redrawArrows(layer,s);
      drawSnapGuides(layer,sx,sy);
      /* the numbers move with the drag: a readout that only caught up on
         mouseup would be the wrong number for the whole gesture (T65) */
      if(typeof sizePaneSync==='function') sizePaneSync();
    }
    function mu(){
      document.removeEventListener('mousemove',mm);
      document.removeEventListener('mouseup',mu);
      clearSnapGuides(layer);
      /* the caption takes the figure's new width at the END of the
         gesture, not per mousemove: one commit, and a caption that does
         not reflow its words sixty times a second (T17) */
      if(movedAny) capFollowResize(capA,capO,figO,a);
      /* the ONE rebuild per gesture; a moveless mousedown keeps the old
         no-render path */
      if(movedAny){renderAnnots(layer,s);selectAnnot(layer,idx);}
      markDirty();
    }
    document.addEventListener('mousemove',mm);
    document.addEventListener('mouseup',mu);
  }
  /* called from the resize gesture's own commit */
  function capFollowResize(capA,capO,figO,fig){
    if(!capA||!capO||!figO||!fig) return;
    var w0=figO.w,w1=fig.w;
    if(!(w0>0)||!(w1>0)) return;
    /* the caption's LEFT tracks the figure's left, and its width the
       figure's width. Its own y is left alone: a caption sits under its
       figure, and where "under" is depends on how tall the caption is,
       which is its words' business. */
    var f0=anchorPos(figO,w0,figO.h),f1=anchorPos(fig,w1,fig.h);
    var c0=anchorPos(capO,capO.w,capO.h);
    var cw=capO.w?capO.w*(w1/w0):capO.w;
    if(capO.w) capA.w=cw;
    /* A POSITION LOCK IS ABOUT POSITION — the rule T57 settled for the
       Arrange verbs, and the same one here: a pinned caption still takes
       its figure's width, and stays exactly where it was put. */
    if(pinned(capA)) return;
    anchorSet(capA,c0.x+(f1.x-f0.x),c0.y,cw,capO.h);
  }
  function startRotate(layer,s,idx,ev0){
    ev0.preventDefault();ev0.stopPropagation();
    var a=annotByIdx(s,idx);
    if(!a) return;
    function mm(ev){
      var el=layer.querySelector('.an-item[data-idx="'+idx+'"]');
      if(!el) return;
      /* the visual centre is rotation-invariant, so measuring the live
         bounding box keeps the pivot stable while the item spins */
      var r=el.getBoundingClientRect();
      var ang=Math.atan2(ev.clientY-(r.top+r.height/2),
                         ev.clientX-(r.left+r.width/2))*180/Math.PI+90;
      if(ev.shiftKey) ang=Math.round(ang/15)*15;
      ang=((ang%360)+360)%360;
      if(ang>180) ang-=360;
      /* a small magnetic dead-zone so items land EXACTLY straight */
      [0,90,-90,180,-180].forEach(function(v){
        if(Math.abs(ang-v)<=1) ang=(v===-180)?180:v;});
      a.rot=Math.round(ang*10)/10||0;
      renderAnnots(layer,s);paintSel(layer);
    }
    function mu(){
      document.removeEventListener('mousemove',mm);
      document.removeEventListener('mouseup',mu);
      if(!a.rot) delete a.rot;
      markDirty();
    }
    document.addEventListener('mousemove',mm);
    document.addEventListener('mouseup',mu);
  }
  function startDraw(layer,s,kind,p0){
    /* A LINE IS AN ARROW WITH NO HEAD, so it keeps k:'arrow' and inherits
       endpoint dragging, attachment, routing, dashes, the Objects pane
       and the PowerPoint connector export for nothing. `nohead` rather
       than head:'none' because headEnd and both label functions read that
       field to say "Line" instead of "Arrow". It is drawn rather than
       dropped in ready-made (2026-08-10, user: "I hate it how when you
       click line, it just creates a line — can it please be drawn like it
       does with the shapes"), and it stays a theme-aware divider colour
       instead of alarm-orange. */
    if(kind==='rect'&&typeof shapeUsed==='function')
      shapeUsed(pendingShape);   /* T573: yours lead the gallery */
    var a=(kind==='rect')
      ?{k:'rect',x:p0.x,y:p0.y,w:0,h:0,color:'#ff6b57',sw:SW_DEFAULT,
        shape:(pendingShape!=='rect'?pendingShape:undefined)}
      :(kind==='draw')
      ?{k:'draw',x:p0.x,y:p0.y,w:0,h:0,pts:[[0,0]],sw:SW_DEFAULT,
        color:pageIsLight(deckPageBg())?'#44525c':'#8aa0b0'}
      :(kind==='cell')
      ?{k:'cell',x:p0.x,y:p0.y,w:0,h:0,ref:null}
      /* born EMPTY and already carrying its own id: the id is what every
         binding on the slide points at, so it has to exist from the
         first moment the box does */
      :(kind==='flip')
      ?{k:'flip',x:p0.x,y:p0.y,w:0,h:0,fid:flipId(),frames:[],at:0}
      :(kind==='text')
      /* colour comes from the page theme. Born EMPTY and UNBOXED: the
         "Text" placeholder and the default panel both had to be removed
         by hand on every single box (2026-08-19, user: "no placeholder
         text and no background by default"). A box left empty deletes
         itself on blur, so nothing invisible is ever left behind. */
      ?textBorn(p0)
      /* A TABLE is rows of plain strings plus a handful of switches. Not
         HTML: a table you can only fill by typing HTML is a table nobody
         will use, and rows-of-strings is the shape every export already
         knows how to walk (2026-08-20, user asked for "Tables"). The
         header row is a FLAG rather than a separate field, so turning it
         on or off never moves a single cell of data. */
      :(kind==='table')
      ?{k:'table',x:p0.x,y:p0.y,w:0,h:0,size:2.2,thead:1,grid:1,
        sw:1,rows:[['','',''],['','',''],['','','']]}
      :(kind==='line')
      ?{k:'arrow',x1:p0.x,y1:p0.y,x2:p0.x,y2:p0.y,nohead:1,sw:SW_DEFAULT,
        color:pageIsLight(deckPageBg())?'#44525c':'#8aa0b0'}
      :{k:'arrow',x1:p0.x,y1:p0.y,x2:p0.x,y2:p0.y,
        color:'#ff6b57',sw:SW_DEFAULT};
    var boxed=(a.k==='rect'||a.k==='cell'||a.k==='text'
      ||a.k==='table'||a.k==='flip');
    s.annots=s.annots||[];
    s.annots.push(a);
    var idx=s.annots.length-1;
    /* the raw trail, in page percentages, for a freehand stroke */
    var raw=(kind==='draw')?[[p0.x,p0.y]]:null;
    /* Fold the trail into a box plus 0..1 points. A stroke drawn dead
       straight has no extent on one axis, which would divide by zero and
       leave a box too thin to grab, so each axis gets a floor and the
       points centre themselves in it. */
    function foldTrail(){
      var xs=raw.map(function(q){return q[0];});
      var ys=raw.map(function(q){return q[1];});
      var x0=Math.min.apply(null,xs),x1=Math.max.apply(null,xs);
      var y0=Math.min.apply(null,ys),y1=Math.max.apply(null,ys);
      var w=x1-x0,h=y1-y0,MIN=1.5;
      if(w<MIN){x0-=(MIN-w)/2;w=MIN;}
      if(h<MIN){y0-=(MIN-h)/2;h=MIN;}
      a.x=x0;a.y=y0;a.w=w;a.h=h;
      a.pts=raw.map(function(q){
        return [(q[0]-x0)/w,(q[1]-y0)/h];});
    }
    function mm(ev){
      var p=pctPoint(layer,ev);
      if(raw){
        /* thin the trail: a mousemove every pixel would store thousands
           of points into the document and the undo stack */
        var last=raw[raw.length-1];
        if(Math.abs(p.x-last[0])+Math.abs(p.y-last[1])>=0.35) raw.push([p.x,p.y]);
        foldTrail();
      } else if(boxed){
        a.x=Math.min(p0.x,p.x);a.y=Math.min(p0.y,p.y);
        a.w=Math.abs(p.x-p0.x);a.h=Math.abs(p.y-p0.y);
      } else {a.x2=p.x;a.y2=p.y;}
      renderAnnots(layer,s);
    }
    function mu(){
      document.removeEventListener('mousemove',mm);
      document.removeEventListener('mouseup',mu);
      /* the item about to be selected is one you JUST DREW, so the tab
         must not follow the selection this time — otherwise placing five
         shapes in a row throws you off Insert after every one */
      justDrew=true;
      /* T584: a CLICK is under 4 screen pixels of travel, the usual
         click-or-drag line. It was 1.5% of the slide (~22px on a laptop),
         so a small dot drawn on purpose was thrown away as a stray click */
      var lr=layer.getBoundingClientRect();
      var cx=lr.width?400/lr.width:1.5,cy=lr.height?400/lr.height:1.5;
      var tiny=raw?(raw.length<3)
        :boxed?(a.w<cx&&a.h<cy)
        :(Math.abs(a.x2-a.x1)<cx&&Math.abs(a.y2-a.y1)<cy);
      /* A CLICK IS STILL A CLICK. Dragging says how big; clicking asks
         for the usual one, which is the fast way when the size does not
         matter yet — and it is what these two tools have always done, so
         nobody's habit breaks. A shape, line or arrow with no drag is
         still discarded: there is no sensible default size for those, and
         dropping a canned one is what the line tool was told off for
         (2026-08-10). */
      if(tiny&&a.k==='draw'){
        s.annots.splice(idx,1);      /* a stray click is not a drawing */
      } else if(tiny&&a.k==='table'){
        a.x=Math.min(p0.x,54);a.y=Math.min(p0.y,72);a.w=44;a.h=24;
      } else if(tiny&&a.k==='cell'){
        a.x=Math.min(p0.x,64);a.y=Math.min(p0.y,64);a.w=34;a.h=30;
      } else if(tiny&&a.k==='text'){
        delete a.w;delete a.h;          /* auto-size to its own words */
      } else if(tiny) s.annots.splice(idx,1);
      markDirty();setTool('select');
      renderAnnots(layer,s);
      if(!tiny||(boxed&&a.k!=='draw')){
        selectAnnot(layer,idx);
        if(a.k==='text') focusText(layer,idx);
        /* T468: THE TILE SAYS "FROM NOTEBOOK", SO THE FRAME GOES THERE.
           Drawing one used to show a tiny "Click to add an object"
           caption and then a pop-up asking what to put in it -- with
           the notebook one answer among four (2026-09-15 review). With
           a notebook open the picker opens at once; Escape or Cancel
           brings you back to the frame, whose caption still offers the
           other sources (a picture, the clipboard, a link). */
        if(a.k==='cell'&&!a.ref&&APP.order&&APP.order.length
           &&typeof startPick==='function')
          setTimeout(function(){startPick(idx);},0);
      }
    }
    document.addEventListener('mousemove',mm);
    document.addEventListener('mouseup',mu);
  }
  /* put the caret in a fresh text box with its placeholder selected, so
     the first thing you type replaces "Text" */
  function focusText(layer,idx){
    var tx=layer.querySelector('.an-item[data-idx="'+idx+'"] .an-tx');
    if(!tx) return;
    if(tx._beginEdit) tx._beginEdit();   /* make it editable FIRST */
    tx.focus();
    try{
      var rng=document.createRange();
      rng.selectNodeContents(tx);
      var sl=window.getSelection();
      sl.removeAllRanges();sl.addRange(rng);
    }catch(e){}
  }
  function distToSeg(px,py,x1,y1,x2,y2){
    var dx=x2-x1,dy=y2-y1;
    var L2=dx*dx+dy*dy;
    var u=L2?((px-x1)*dx+(py-y1)*dy)/L2:0;
    u=Math.max(0,Math.min(1,u));
    return Math.hypot(px-(x1+u*dx),py-(y1+u*dy));
  }
  function startEndpoint(layer,s,idx,ep,ev0){
    ev0.preventDefault();
    var a=(s.annots||[])[idx];
    if(!a||a.k!=='arrow'||pinned(a)) return;
    function mm(ev){
      var p=pctPoint(layer,ev);
      a['x'+ep]=p.x;a['y'+ep]=p.y;
      renderAnnots(layer,s);selectAnnot(layer,idx);
    }
    function mu(){
      document.removeEventListener('mousemove',mm);
      document.removeEventListener('mouseup',mu);
      markDirty();
    }
    document.addEventListener('mousemove',mm);
    document.addEventListener('mouseup',mu);
  }
  /* drag one corner. Deliberately the SAME snapping every other drag
     gets, so a corner lines up with the things around it. */
  function startMidPoint(layer,s,idx,mi,ev0){
    ev0.preventDefault();ev0.stopPropagation();
    var a=annotByIdx(s,idx);
    if(!a||!Array.isArray(a.mid)||!a.mid[mi]) return;
    var thr=snapThr(layer);
    var targets=snapTargets(layer,s,[idx]);
    function mm(ev){
      var p=pctPoint(layer,ev);
      var x=p.x,y=p.y,sx=null,sy=null;
      if(!ev.altKey){
        var bx=bestSnap(targets.xs,[x],thr.x);
        if(bx){x+=bx.d;sx=bx.at;}
        var by=bestSnap(targets.ys,[y],thr.y);
        if(by){y+=by.d;sy=by.at;}
      }
      a.mid[mi]=[x,y];
      renderAnnots(layer,s);selectAnnot(layer,idx);
      drawSnapGuides(layer,sx,sy);
    }
    function mu(){
      document.removeEventListener('mousemove',mm);
      document.removeEventListener('mouseup',mu);
      clearSnapGuides(layer);markDirty();
    }
    document.addEventListener('mousemove',mm);
    document.addEventListener('mouseup',mu);
  }
  function arrowAt(layer,s,ev){
    if(!s.annots) return -1;
    var r=layer.getBoundingClientRect();
    var px=ev.clientX-r.left,py=ev.clientY-r.top;
    var best=-1,bestD=12;
    s.annots.forEach(function(a,i){
      if(a.k!=='arrow'||lockedAll(a)||a.hide) return;
      /* T585: THE LINE YOU CAN SEE, not the chord between its ends. The
         straight x1,y1 -> x2,y2 found a curved or bent arrow where it is
         not drawn and missed it where it is. Its rendered grab path has
         the real shape and a width that is its tolerance, so ask that;
         a later arrow (drawn on top) wins a tie. */
      var hp=layer.querySelector('.an-arrow-hit[data-idx="'+i+'"]');
      if(hp&&typeof hp.isPointInStroke==='function'&&window.DOMPoint){
        var inS=null;
        try{inS=hp.isPointInStroke(new DOMPoint(px,py));}catch(e){}
        if(inS!==null){if(inS){best=i;bestD=0;}return;}
      }
      var d=distToSeg(px,py,
        a.x1/100*r.width,a.y1/100*r.height,
        a.x2/100*r.width,a.y2/100*r.height);
      if(d<bestD){bestD=d;best=i;}
    });
    return best;
  }
  /* ---- T576: CLICK AGAIN TO REACH WHAT IS UNDERNEATH -------------------
     A picture over a shape, a box over a background panel: the one on top
     took every click, and the only ways to the one below were Tab and the
     Layers pane. Now a click on what is already selected -- a separate
     click, not the start of a drag and not the second half of a
     double-click (which types) -- selects the next object down at that
     point, the next click the one below that, and round to the top again.
     A group you have not stepped into counts as one object. It waits out
     a double-click's second press before it acts, and any press on an
     object in the meantime cancels it. */
  var ctTimer=0,ctHinted=false,ctLast=null;
  function clickThroughArm(layer,idx,ev0){
    if(ev0.button!==0||ev0.detail>1) return;
    var x0=ev0.clientX,y0=ev0.clientY;
    function up(ev){
      document.removeEventListener('mouseup',up,true);
      if(Math.abs(ev.clientX-x0)>3||Math.abs(ev.clientY-y0)>3) return;
      ctTimer=setTimeout(function(){
        ctTimer=0;clickThroughNext(layer,idx,x0,y0);},300);
    }
    document.addEventListener('mouseup',up,true);
  }
  function clickThroughNext(layer,idx,x,y){
    var s=pres.slides[cur];
    if(!s||mode!=='edit'||!layer||!document.body.contains(layer)) return;
    if(selSet.indexOf(idx)<0) return;       /* the selection moved on */
    function unit(i){
      var a=(typeof i==='number')?(s.annots||[])[i]:null;
      return (a&&a.grp!=null&&inGroup!==a.grp)?'g:'+a.grp:'i:'+i;
    }
    var units=[],seen={};
    (document.elementsFromPoint?document.elementsFromPoint(x,y):[])
      .forEach(function(e){
        var it=e.closest&&e.closest('.an-item');
        if(!it||!layer.contains(it)) return;
        var raw=it.getAttribute('data-idx'); if(raw==null) return;
        var i=(raw==='t'||raw==='s')?raw:+raw;
        var k=unit(i); if(seen[k]) return;
        seen[k]=1;units.push(i);
      });
    if(units.length<2) return;
    var at=-1,mine=unit(idx);
    units.forEach(function(u,k){if(unit(u)===mine) at=k;});
    var next=units[(at+1)%units.length];
    if(unit(next)===mine) return;
    selectAnnot(layer,next,false);
    ctLast={x:x,y:y,idx:next};
    if(!ctHinted){
      ctHinted=true;
      toast('The object underneath — click again to go deeper. Tab '
        +'walks every object on the slide',5000);
    }
  }
  /* ---- TOUCH AND PEN (T575) -------------------------------------------
     Every gesture on the canvas -- select, move, resize, rotate, draw,
     an arrow's ends, the drag box -- is written against mouse events: a
     mousedown on the layer, then mousemove and mouseup on the document.
     A pen sends those only sometimes and a finger drag never does (the
     browser scrolls instead), so on a touchscreen the canvas could be
     tapped but nothing could be moved. Rather than teach forty handlers
     a second language, a finger or a pen on the editing canvas is spoken
     to them in the one they know: pointerdown becomes their mousedown on
     what was touched, each pointermove a mousemove on what is under it,
     pointerup the mouseup -- and preventDefault on the pointerdown stops
     the browser adding its own copies, so nothing happens twice. A
     second finger is ignored while the first is down. Two taps in the
     same place are a double-click (which starts typing in a box), and a
     touch held still is the right-click menu. Presenting, a finger swipe
     left or right is the next or the last step. The mouse is untouched:
     pointerType 'mouse' is never bridged. */
  var touchId=null;
  function touchFire(target,type,src,buttons){
    if(!target||!target.dispatchEvent) return;
    target.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,
      view:window,clientX:src.clientX,clientY:src.clientY,
      screenX:src.screenX,screenY:src.screenY,button:0,
      buttons:buttons,shiftKey:!!src.shiftKey,ctrlKey:!!src.ctrlKey,
      altKey:!!src.altKey,metaKey:!!src.metaKey,
      detail:type==='dblclick'?2:1}));
  }
  function touchBoot(){
    if(!stage||typeof PointerEvent!=='function') return;
    var lastTap=null,holdT=0;
    stage.addEventListener('pointerdown',function(e){
      if(e.pointerType==='mouse'||!e.isPrimary) return;
      if(mode==='view'){touchSwipe(e);return;}
      if(mode!=='edit') return;
      var t=e.target;
      if(!t||!t.closest||!t.closest('.annot-layer')) return;
      /* typing in a box: the caret is the browser's to place */
      if(t.closest('[contenteditable="true"]')) return;
      if(touchId!==null) return;
      touchId=e.pointerId;
      e.preventDefault();
      var x0=e.clientX,y0=e.clientY,moved=false;
      touchFire(t,'mousedown',e,1);
      /* held still for 600 ms: the right-click menu */
      clearTimeout(holdT);
      holdT=setTimeout(function(){
        if(moved||touchId===null) return;
        var tg=document.elementFromPoint(x0,y0)||t;
        touchFire(document,'mouseup',{clientX:x0,clientY:y0,
          screenX:e.screenX,screenY:e.screenY},0);
        tg.dispatchEvent(new MouseEvent('contextmenu',{bubbles:true,
          cancelable:true,view:window,clientX:x0,clientY:y0,button:2}));
        end();
      },600);
      function mv(ev){
        if(ev.pointerId!==touchId) return;
        ev.preventDefault();
        if(Math.abs(ev.clientX-x0)>4||Math.abs(ev.clientY-y0)>4){
          moved=true;clearTimeout(holdT);}
        var tg=document.elementFromPoint(ev.clientX,ev.clientY)||document;
        touchFire(tg,'mousemove',ev,1);
      }
      function up(ev){
        if(ev.pointerId!==touchId) return;
        clearTimeout(holdT);
        touchFire(document,'mouseup',ev,0);
        end();
        if(ev.type==='pointercancel') return;
        /* two taps in one place are a double-click */
        var now=Date.now();
        if(!moved&&lastTap&&now-lastTap.t<400
           &&Math.abs(ev.clientX-lastTap.x)<24
           &&Math.abs(ev.clientY-lastTap.y)<24){
          var tg=document.elementFromPoint(ev.clientX,ev.clientY)||t;
          touchFire(tg,'dblclick',ev,0);
          lastTap=null;
        } else lastTap=moved?null:{t:now,x:ev.clientX,y:ev.clientY};
      }
      function end(){
        touchId=null;
        document.removeEventListener('pointermove',mv,true);
        document.removeEventListener('pointerup',up,true);
        document.removeEventListener('pointercancel',up,true);
      }
      document.addEventListener('pointermove',mv,true);
      document.addEventListener('pointerup',up,true);
      document.addEventListener('pointercancel',up,true);
    });
  }
  /* presenting: a quick sideways swipe is the next or the last step */
  function touchSwipe(e){
    if(e.pointerType!=='touch') return;
    var x0=e.clientX,y0=e.clientY,t0=Date.now();
    function up(ev){
      document.removeEventListener('pointerup',up,true);
      if(ev.pointerId!==e.pointerId||mode!=='view') return;
      var dx=ev.clientX-x0,dy=ev.clientY-y0;
      if(Date.now()-t0>700||Math.abs(dx)<60||Math.abs(dx)<Math.abs(dy)*1.5)
        return;
      if(dx<0) advance(); else backStep();
    }
    document.addEventListener('pointerup',up,true);
  }
  /* ---- MARQUEE: drag a box on empty canvas to select what it touches --
     Mousedown on nothing used to deselect and stop there, so the only way
     to select several items was to shift-click each one - and shift-click
     on a text box was itself broken until 2026-08-20 (2026-08-20, user:
     "You can't drag and select multiple items. The shift and select
     multiple is realyl hard to do").
     TOUCH, not enclose: a band that has to swallow an item whole is
     unusable on a poster where the figures are bigger than the gap you
     have to drag in. Hold Shift or Ctrl to add to what is already
     selected. A drag under the threshold is still just a click, so
     "click empty space to deselect" is unchanged. */
  var MARQUEE_PX=4;
  function startMarquee(layer,s,ev0){
    /* THE ONE DRAG-STARTER IN THIS FILE THAT USED NOT TO. Every other
       one preventDefaults (startMove, startResize, startRotate,
       startEndpoint, startMidPoint) and the handler's own
       ev.preventDefault sits AFTER the select-tool block, so a marquee
       press was the single press the browser still got to act on: it
       began a NATIVE TEXT SELECTION and dragged it across every text
       box, table and notebook card the band crossed. That is the whole
       page going blue while you are trying to pick three items -- "it
       just results in everything being selected" (T63).
       preventDefault also stops the browser moving focus, and an
       on-canvas edit commits on BLUR (see editableText), so the caret
       is taken out deliberately first -- otherwise clicking empty
       space would leave you still typing into the box you clicked
       away from, with the words uncommitted. */
    var ae=document.activeElement;
    if(ae&&ae.isContentEditable&&layer.contains(ae)) ae.blur();
    ev0.preventDefault();
    var add=ev0.shiftKey||ev0.ctrlKey||ev0.metaKey;
    /* HOLD ALT TO SWEEP UP FULLY LOCKED ITEMS TOO. A lock means "not by
       accident", not "never again", and the Objects pane being the only
       way back to a background frame you locked months ago is a long way
       round (TASKS T3). Shift and Ctrl are taken — they add to the
       selection — so Alt it is, and on empty canvas it means nothing
       else. Position-locked items were never excluded here: they select
       and restyle like anything else, they just do not move. */
    var takeLocked=ev0.altKey;
    if(!add) leaveGroup(null);
    var base=add?selSet.filter(function(i){return typeof i==='number';}):[];
    var p0=pctPoint(layer,ev0);
    var band=null,moved=false;
    function mm(ev){
      /* A MOUSEUP OUTSIDE THE WINDOW NEVER ARRIVES. Release the button
         over the browser chrome or off-screen -- easy, the band is
         being dragged at a page edge -- and `mu` never ran: the band
         stayed on the layer and this handler carried on with the
         button UP, growing over the whole page and rewriting selSet on
         every move, until the next click's mouseup fired the stale `mu`
         and committed "everything selected" (T63). ev.buttons is 0
         once nothing is held, which is the one question that tells a
         live drag from a dead one; `mu` is a hoisted declaration, so
         calling it from here is fine. */
      if(!ev.buttons){mu();return;}
      var p=pctPoint(layer,ev);
      if(!moved){
        var dx=Math.abs(p.x-p0.x)*layer.clientWidth/100;
        var dy=Math.abs(p.y-p0.y)*layer.clientHeight/100;
        if(dx<MARQUEE_PX&&dy<MARQUEE_PX) return;
        moved=true;
        band=document.createElement('div');
        band.className='an-marquee';
        layer.appendChild(band);
      }
      var l=Math.min(p0.x,p.x),t=Math.min(p0.y,p.y);
      var r=Math.max(p0.x,p.x),b=Math.max(p0.y,p.y);
      band.style.left=l+'%';band.style.top=t+'%';
      band.style.width=(r-l)+'%';band.style.height=(b-t)+'%';
      var hit=base.slice();
      (s.annots||[]).forEach(function(a,i){
        /* hidden items are never on the table; fully locked ones are on
           it only when Alt asked for them */
        if(!a||a.hide) return;
        if(lockedAll(a)&&!takeLocked) return;
        var q=annotRectPct(layer,s,i); if(!q) return;
        if(q.r<l||q.l>r||q.b<t||q.t>b) return;
        groupMembers(s,i).forEach(function(j){
          if(hit.indexOf(j)<0) hit.push(j);});
      });
      selSet=hit;
      selAnnot=hit.length?hit[hit.length-1]:null;
      paintSel(layer);
    }
    function mu(){
      document.removeEventListener('mousemove',mm);
      document.removeEventListener('mouseup',mu);
      if(band) band.remove();
      if(!moved){
        /* a plain click on empty canvas: clear, unless you were adding */
        if(!add) selectAnnot(layer,null);
        return;
      }
      /* commit through the normal path so the ribbon and the Layers
         pane follow */
      lastSelSig='';
      showFmt();renderSelPane();
    }
    document.addEventListener('mousemove',mm);
    document.addEventListener('mouseup',mu);
  }
  /* Empty means DECORATIVE, and the prompt says so rather than
     leaving "I skipped this box" and "this picture carries nothing"
     looking the same. Cancel changes nothing, which is what Escape has
     to mean here (T105). */
  /* Typed, not scripted. The prompt takes a URL or a slide number,
     and a slide number is resolved to that slide's `sid` HERE -- once,
     while the number still means what the author meant -- so the stored
     link survives every later reorder (T118). */
  /* WHERE A TYPED LINK GOES (T546: one reading for an object and for
     words). A slide's number is a jump held by sid; anything else must
     be an address mdHref allows -- and a bare www.example.org or
     example.org/page is taken to mean https, as PowerPoint takes it.
     null for empty (remove the link), {err} for something unusable. */
  function linkTarget(got){
    got=String(got||'').trim();
    if(!got) return null;
    var n=got.match(/^(?:slide\s*)?(\d+)$/i);
    if(n){
      var idx=parseInt(n[1],10)-1;
      if(idx<0||idx>=(pres.slides||[]).length)
        return {err:'There is no slide '+n[1]};
      ensureSids();
      return {to:'slide',sid:pres.slides[idx].sid};
    }
    if(/^(?:www\.)?[a-z0-9-]+(?:\.[a-z0-9-]+)+(?:[\/?#]\S*)?$/i.test(got))
      got='https://'+got;
    var h=mdHref(got);
    if(!h||h.charAt(0)==='#')
      return {err:'That is not a link this can follow \u2014 http, https '
        +'and mailto only'};
    return {to:'url',href:h};
  }
  var LINK_LABEL='A link (https://\u2026 or mailto:\u2026), or a slide\u2019s '
    +'number, like 7';
  /* `i` is an item's index, or 't' / 's' for a title slide's two lines,
     which carry a link the same way (applyCommon marks them) */
  function setObjLink(i){
    var a=annotByIdx(pres.slides[cur],i); if(!a) return;
    var was=a.link?(a.link.to==='url'?a.link.href
      :('slide '+(linkSlideIdx(a.link.sid)+1))):'';
    askText({title:'Where clicking this goes, while you present',
      label:LINK_LABEL,value:was,placeholder:'https://\u2026 or 7',
      note:'Empty removes the link',ok:'Link'},function(got){
    if(got===null) return;
    var t=linkTarget(got);
    if(!t){delete a.link;markDirty();renderSlide();
      toast('Link removed');return;}
    if(t.err){toast(t.err);return;}
    a.link=t;
    markDirty();renderSlide();
    toast('Linked to '+linkLabel(a.link));
    });
  }
  /* ---- T546: LINKED WORDS ------------------------------------------------
     Highlighted words become an <a> in the box's rich text: href for a
     web address, data-sid for a slide -- the two the sanitizer keeps.
     The question takes the focus, and a box that loses the focus stops
     being edited, so the highlight is kept as character offsets and put
     back in the box's editor (whichever element holds it by then) when
     the answer comes; the browser's own createLink / unlink does the
     cutting, and richSelectionEdit the committing. */
  function wordLinkAt(el){
    var sel=window.getSelection();
    if(!sel||!sel.rangeCount) return null;
    var n=sel.getRangeAt(0).commonAncestorContainer;
    if(n&&n.nodeType===3) n=n.parentNode;
    var a=(n&&n.closest)?n.closest('a'):null;
    return (a&&el.contains(a))?a:null;
  }
  function linkWords(el){
    var sel=window.getSelection();
    var inA=wordLinkAt(el);
    /* a bare caret inside a link means that link's words */
    if(sel.isCollapsed&&inA){
      var r0=document.createRange();r0.selectNodeContents(inA);
      sel.removeAllRanges();sel.addRange(r0);
    }
    if(sel.isCollapsed) return false;
    var item=el.closest?el.closest('.an-item[data-idx]'):null;
    var idx=item?item.getAttribute('data-idx'):null;
    var at=caretAt(el),words=sel.toString();
    var was='';
    if(inA) was=inA.getAttribute('data-sid')
      ?('slide '+(linkSlideIdx(inA.getAttribute('data-sid'))+1))
      :(inA.getAttribute('href')||'');
    function again(){
      var layer=stage.querySelector('.annot-layer');
      var nt=(layer&&idx!=null)?layer.querySelector('.an-item[data-idx="'
        +idx+'"] .an-tx'):null;
      if(!nt) return null;
      if(nt._beginEdit) nt._beginEdit();
      nt.focus();caretPut(nt,at);
      return nt;
    }
    askText({title:'Link these words',
      what:'\u201c'+words.slice(0,60)+(words.length>60?'\u2026':'')
        +'\u201d \u2014 while you present, a click on them opens the page '
        +'or goes to the slide.',
      label:LINK_LABEL,value:was,placeholder:'https://\u2026 or 7',
      note:'Empty removes the link',ok:'Link'},function(got){
      if(got===null){again();return;}
      var t=linkTarget(got);
      if(t&&t.err){toast(t.err);again();return;}
      if(!again()) return;
      var mark='https://jv-link.invalid/'+Date.now().toString(36);
      richSelectionEdit(function(){
        var ed=activeTextEditable();
        if(!t){try{document.execCommand('unlink',false,null);}catch(e){}
          return;}
        try{document.execCommand('createLink',false,t.href||mark);}
        catch(e){}
        if(t.sid&&ed) $$('a',ed).forEach(function(x){
          if(x.getAttribute('href')!==mark) return;
          x.removeAttribute('href');x.setAttribute('data-sid',t.sid);});
      });
      toast(t?('Linked to '+linkLabel(t)):'Link removed');
    });
    return true;
  }
  /* THE ONE DOOR: the Text tile, Ctrl+K and the mini toolbar. Words if
     any are highlighted (or the caret is in a link), otherwise the one
     selected object. False when there is nothing to link. */
  function linkNow(){
    var el=activeTextEditable(),sel=window.getSelection();
    if(el&&sel&&sel.rangeCount&&el.contains(sel.anchorNode)
       &&(!sel.isCollapsed||wordLinkAt(el))) return linkWords(el);
    if(selAnnot==='t'||selAnnot==='s'){setObjLink(selAnnot);return true;}
    var ids=selIdxs();
    if(ids.length===1){setObjLink(ids[0]);return true;}
    if(ids.length>1){
      toast('Select one object to link \u2014 or highlight words in a '
        +'text box');
      return true;
    }
    return false;
  }
  function linkBoot(){
    var b=$('#tx-link');
    if(b){
      b.addEventListener('mousedown',function(e){
        if(activeTextEditable()) e.preventDefault();});
      b.addEventListener('click',function(){
        if(!linkNow()) toast('Select an object, or highlight words in a '
          +'text box, to link it');
      });
    }
    /* in the editor a click on linked words selects and types, never
       follows: the anchor would otherwise take this window with it */
    stage.addEventListener('click',function(e){
      if(mode!=='edit') return;
      var a=e.target.closest&&e.target.closest('.an-tx a');
      if(a) e.preventDefault();
    },true);
    /* the rail's Find owns Ctrl+K until there is something to link */
    window.SemDeckLinkable=function(){
      return !deckEl.hidden&&mode==='edit'
        &&(selAnnot!==null||selIdxs().length>0);
    };
  }
  /* T552: what alt text is for -- a picture, a figure from a notebook, a
     flip book, a clip or a chart: whatever a screen reader would otherwise
     announce as an unlabelled image */
  function altable(a){
    return !!a&&(isFigure(a)||a.k==='chart');
  }
  function altSelIdxs(){
    var an=(pres.slides[cur]&&pres.slides[cur].annots)||[];
    return selIdxs().filter(function(i){
      return typeof i==='number'&&altable(an[i]);});
  }
  var altBtn=$('#fmt-alt');
  if(altBtn) altBtn.addEventListener('click',function(e){
    e.stopPropagation();
    var ix=altSelIdxs();
    if(ix.length) setAltText(ix);
  });
  function setAltText(idxs){
    var ans=(pres.slides[cur].annots||[]);
    var first=ans[idxs[0]]||{};
    var was=first.dec?'':(first.alt||'');
    askText({title:first.k==='chart'?'What this chart shows'
        :'What this picture shows',
      what:'Somebody who cannot see it reads this instead of it.',
      label:'Alt text',value:was,multi:true,ok:'Set',
      note:'Empty marks the picture decorative \u2014 a rule, a texture, '
        +'a logo already named in the words. Ctrl+Enter to set.'},
    function(got){
    if(got===null) return;
    got=got.trim();
    idxs.forEach(function(i){
      var a=ans[i]; if(!a) return;
      if(got){delete a.dec;a.alt=got;}
      else {delete a.alt;a.dec=1;}
    });
    markDirty();renderSlide();
    toast(got?'Alt text set':'Marked decorative \u2014 a screen reader '
      +'will skip '+(idxs.length===1?'it':'them'));
    });
  }
  /* REPEAT ON OTHER SLIDES. This is deliberately a copy, not a linked
     component: the object can be edited independently after it lands. The
     three scopes cover the useful readings of "all", while the range prompt
     keeps a long deck from needing a second slide-picker surface. */
  function repeatSelection(scope){
    var source=pres.slides[cur],srcs=(source&&source.annots||[]);
    var picked=selIdxs().filter(function(i){return srcs[i]&&!lockedAll(srcs[i]);})
      .map(function(i){return srcs[i];});
    if(!picked.length){toast('Select an unlocked object first');return;}
    var targets=[],i;
    if(scope==='all'){
      for(i=0;i<(pres.slides||[]).length;i++) if(i!==cur) targets.push(i);
    } else if(scope==='section'){
      var sec=source&&source.sec||'';
      for(i=0;i<(pres.slides||[]).length;i++)
        if(i!==cur&&(pres.slides[i].sec||'')===sec) targets.push(i);
    } else {
      /* T475: the editor's own question; the copy happens in its answer */
      askText({title:'Repeat on which slides?',label:'A range of slides',
        value:'1-'+pres.slides.length,placeholder:'2-6',ok:'Repeat'},
      function(raw){
        if(raw===null) return;
        var m=String(raw).trim().match(/^(\d+)\s*(?:-|–|\.\.)\s*(\d+)$/);
        if(!m){toast('Use a range such as 2-6');return;}
        var lo=Math.max(1,Math.min(+m[1],+m[2]))-1;
        var hi=Math.min(pres.slides.length,Math.max(+m[1],+m[2]));
        for(var i2=lo;i2<hi;i2++) if(i2!==cur) targets.push(i2);
        repeatOnto(targets);
      });
      return;
    }
    repeatOnto(targets);
    function repeatOnto(targets){
    if(!targets.length){toast('There are no other slides in that scope');return;}
    var n=0;
    targets.forEach(function(ti){
      var target=pres.slides[ti];
      var copies=independentCopies(picked,target,source.grpmeta);
      copies.forEach(function(cp){
        if(cp.anim) cp.anim={type:cp.anim.type||'fade',
          order:nextAnimOrder(target)};
        target.annots=target.annots||[];target.annots.push(cp);n++;
      });
    });
    if(!n) return;
    markDirty();refresh();renderFilm();
    toast(n+' object'+(n===1?'':'s')+' added to '+targets.length
      +' slide'+(targets.length===1?'':'s')+' — edit each copy freely');
    }
  }
  /* ---- THE CANVAS RIGHT-CLICK MENU -------------------------------------
     Paste has three answers now (the plain one, in place, here) and a
     ribbon cannot grow three buttons for one verb without becoming the
     thing fitEditRibbon spends its life fighting. A right-click is also
     the only door that knows WHERE you clicked, which is precisely the
     question "Paste here" asks -- so the click point is captured when
     the menu opens and handed to pasteBuf, rather than read back from
     the live pointer, which by then is over the menu.
     Built from the film strip's helpers (menuHead / floatAt) so this
     file has one context-menu idiom, not two. */
  /* T31. One flag, set on every selected item, the way setLockSel
     does -- a selection is a selection. */
  function setPrivSel(on){
    var s2=pres.slides[cur]; if(!s2) return;
    var n=0;
    selIdxs().forEach(function(i){
      var a=(s2.annots||[])[i]; if(!a) return;
      if(on) a.priv=1; else delete a.priv;
      n++;
    });
    if(!n) return;
    markDirty();renderSlide();presenterSync&&presenterSync();
    toast(on?(n===1?'Yours \u2014 the audience will not see it'
        :(n+' items are yours \u2014 the audience will not see them'))
      :(n===1?'Back on the slide for everyone'
        :(n+' items are back on the slide for everyone')));
  }
  function openCanvasMenu(layer,s,ev){
    var old=$('#canvas-menu'); if(old) old.remove();
    var m=document.createElement('div');
    m.className='sh-menu canvas-menu';m.id='canvas-menu';
    /* the click, in page percentages, frozen at open time */
    var at=pctPoint(layer,ev);
    function row(label,keys,fn,title,icon,host){
      var b=document.createElement('button');
      b.className='dbtn vw-opt';
      /* the icon is trusted bic() markup; the LABEL stays a text node */
      if(icon) b.innerHTML=bic(icon)+' ';
      b.appendChild(document.createTextNode(label));
      if(keys){
        var k=document.createElement('kbd');
        k.textContent=keys;b.appendChild(k);
      }
      if(title) b.title=title;
      b.addEventListener('click',function(e){
        e.stopPropagation();m.remove();fn();});
      (host||m).appendChild(b);
      return b;
    }
    var n=selIdxs().length;
    if(n){
      menuHead(m,n===1?'this object':n+' objects');
      row('Duplicate','Ctrl+D',duplicateSel,
        'An independent copy, just clear of this one — or Alt-drag '
        +'on the page to place it as you go','copy');
      /* T93. Offered only when something in the selection actually HAS
         a source to drop -- on three text boxes this would be a second
         Duplicate with a longer name, and a menu row that does nothing
         is worse than no row. Same rule the figure/caption rows below
         follow: appear exactly when they apply and ask nothing.
         hasContext and stripContext are one list, in the CLONES section
         of 30-format-bar.js. */
      if(selIdxs().some(function(i){
        return hasContext((pres.slides[cur].annots||[])[i]);}))
        row('Duplicate without its source','Ctrl+Shift+D',function(){
          duplicateSel(1);},
          'The same box, size, styling and crop — pointing at '
          +'nothing, so you can aim it at a different figure','unlink');
      row('Cut','Ctrl+X',function(){
        var c=cutSel();
        if(c) toast(c+' item'+(c===1?'':'s')+' cut');});
      row('Copy','Ctrl+C',function(){
        var c=copySel();
        if(c) toast(c+' item'+(c===1?'':'s')+' copied');});
      /* T535: the look on its own, PowerPoint's Ctrl+Shift+C / V */
      row('Copy look','Ctrl+Shift+C',function(){
        if(copyLook()) toast('Look copied \u2014 select what should wear '
          +'it and press Ctrl+Shift+V');},
        'Its typeface, size, colours, fill and line \u2014 not its words '
        +'or its place','palette');
      if(lookBuf)
        row('Paste look','Ctrl+Shift+V',function(){
          var nl=pasteLook();
          if(nl) toast('Look pasted onto '+nl+' object'+(nl===1?'':'s')
            +' \u2014 Ctrl+Z undoes it');},
          'The look you copied, on everything selected','palette');
      row('Delete','Del',deleteSel,null,'exit');
      menuHead(m,'repeat on slides');
      row('All other slides','',function(){repeatSelection('all');},
        'Copy this selection to every other slide; each copy is independent',
        'copy');
      row('Every slide in this section','',function(){repeatSelection('section');},
        'Copy this selection to the other slides in the current section',
        'copy');
      row('A slide range…','',function(){repeatSelection('range');},
        'Copy this selection to a numbered range of slides','copy');
      /* ALT TEXT (T105). On the right-click menu and nowhere else, for
         the same reason T5's select-by-type is: the ribbon never wraps,
         so a control that applies to one kind of object earns its place
         on the menu that already knows what you clicked. Offered only
         when the selection actually contains a picture -- a row that
         does nothing is worse than no row. */
      var altSel=altSelIdxs();   /* T552: every kind a picture can be */
      /* LINK (T118). Any object can be one, so unlike Alt text this
         needs no kind test -- but like it, it lives on the menu that
         already knows what you clicked rather than on a ribbon that
         must not wrap. */
      if(selIdxs().length===1){
        var lk0=(pres.slides[cur].annots||[])[selIdxs()[0]];
        menuHead(m,'where it goes');
        row(lk0&&lk0.link?'Change where this goes':'Make this a link\u2026',
          '',function(){setObjLink(selIdxs()[0]);},
          'While presenting, a click opens a web page or jumps to '
          +'another slide in this deck','link');
        if(lk0&&lk0.link)
          row('Remove the link','',function(){
            delete lk0.link;markDirty();renderSlide();
            toast('Link removed');},null,'unlink');
      }
      /* T442: the equation editor, from the menu that knows what you
         clicked -- the same door the double-click takes */
      if(selIdxs().length===1){
        var eq0=(pres.slides[cur].annots||[])[selIdxs()[0]];
        if(eq0&&typeof isMaths==='function'&&isMaths(eq0)){
          menuHead(m,'equation');
          row('Edit the equation\u2026','',function(){
            if(window.SemDeckEquation) window.SemDeckEquation(selIdxs()[0]);},
            'Open it in the equation editor \u2014 the palette, the live '
            +'preview, display or inline. Double-clicking the box does '
            +'the same','maths');
        }
      }
      if(altSel.length){
        var one0=(pres.slides[cur].annots||[])[altSel[0]];
        menuHead(m,'what it shows');
        row(one0&&one0.dec?'Alt text \u2014 marked decorative'
          :((one0&&one0.alt)?'Alt text \u2014 written':'Alt text\u2026'),
          '',function(){setAltText(altSel);},
          'Describe what the picture shows, for someone who cannot see '
          +'it. Leave it empty to mark it decorative',
          'caption');
      }
      /* A FIGURE AND ITS CAPTION (T17). Two objects selected, one of
         them a figure and one a text box, is an unambiguous "tie
         these" — so the row appears exactly then and asks nothing. */
      var capSel=selIdxs();
      var capAn=(pres.slides[cur].annots||[]);
      if(capSel.length===2){
        var f0=capAn[capSel[0]],f1=capAn[capSel[1]];
        var figI=isFigure(f0)?capSel[0]:(isFigure(f1)?capSel[1]:-1);
        var txI=(f0&&f0.k==='text')?capSel[0]
          :((f1&&f1.k==='text')?capSel[1]:-1);
        if(figI>=0&&txI>=0&&figI!==txI){
          menuHead(m,'figure');
          row('Make this the figure’s caption','',function(){
            if(tieCaption(figI,txI))
              toast('Tied — the caption follows its figure now. '
                +'Type {fig} in it for its number');},
            'It moves with the figure and takes its width when the '
            +'figure is resized. It is still an ordinary text box you '
            +'can select and restyle on its own.','link');
        }
      } else if(capSel.length===1){
        var one=capAn[capSel[0]];
        /* ADD ONE, rather than tie two things that already exist. T17
           shipped only the tie, and only when exactly two objects were
           selected — so there was no answer at all to "caption this",
           which is one command on the picture in every other tool and
           is how anyone actually writes a caption (2026-08-26 audit,
           T58). */
        if(one&&isFigure(one)&&!capHasOne(one)){
          menuHead(m,'figure');
          row('Add a caption','',function(){addCaption(capSel[0]);},
            'A text box under it, at its width, already tied and '
            +'already numbered — type the words','caption');
        }
        if(one&&(one.cap||one.capOf)){
          menuHead(m,'figure');
          if(one.capOf) row('Number it — put “Figure N” in front','',
            function(){numberCaption(capSel[0]);},
            'Writes {fig} into the caption, which renders as the '
            +'figure’s number and renumbers itself when slides move',
            'numbers');
          row(one.capOf?'Untie this caption'
            :'Untie this figure’s caption','',
            function(){
              if(untieCaption(capSel[0]))
                toast('Untied — they are two ordinary objects');},
            null,'unlink');
        }
        /* a reference from ANY text box to a figure */
        if(one&&one.k==='text'&&!one.capOf){
          /* NUMBER FIRST, THEN LIST. The list was built from figures
             that already had a `cap` — and `cap` is minted by
             figNumbers(), which was called two lines further down,
             INSIDE `if(figs.length)`. On any deck where nothing had ever
             been tied or numbered no figure had a cap, so the list came
             back empty, the guard failed, figNumbers never ran, and the
             section could not appear: not on this deck, not on any deck,
             ever (2026-08-26 audit, T58). */
          var fmap=figNumbers();
          var figs=[];
          (pres.slides||[]).forEach(function(sl){
            (sl.annots||[]).forEach(function(x){
              if(isFigure(x)&&!x.hide&&x.cap) figs.push(x);});});
          if(figs.length){
            menuHead(m,'refer to a figure');
            /* EVERY figure -- `.slice(0,8)` once threw the rest away
               (T58) -- but in ONE row. A row per figure made the menu as
               long as the deck had figures: seven on the example, thirty
               on a thesis poster, each "Insert a reference to Figure n"
               (2026-09-29 audit, T533). One figure is still one click;
               more open a picker that names each by its title. */
            var figNo=function(x){return fmap[x.cap]?fmap[x.cap].n:'?';};
            if(figs.length===1){
              row('Insert a reference to Figure '+figNo(figs[0]),'',function(){
                refCaption(capSel[0],figs[0].cap);},
                'Writes {fig:'+figs[0].cap+'}, which follows that figure\u2019s '
                +'number wherever it ends up','locate');
            } else {
              row('Insert a reference to a figure\u2026','',function(){
                askText({title:'Refer to a figure',
                  what:'The number follows the figure wherever it ends up.',
                  rows:[{k:'cap',label:'Figure',type:'select',value:figs[0].cap,
                    options:figs.map(function(x){
                      var it=(x.k==='cell'&&x.ref)?resolveRef(x.ref):null;
                      var nm=(it&&it.title)||x.alt||x.fname||'';
                      return [x.cap,'Figure '+figNo(x)+(nm?' \u2014 '+nm:'')];
                    })}],
                  ok:'Insert reference'},function(v){
                  if(v&&v.cap) refCaption(capSel[0],v.cap);});
              },'One of the '+figs.length+' figures in this deck, by its '
                +'number and name','locate');
            }
          }
        }
      }
      /* PAGES, on the box that would carry them (T165). Offered for one
         text box at a time: a page is a fact about THIS box, and adding
         one to nine selected boxes at once is a gesture nobody could
         undo in their head. Named "page" and "flip book" because those
         are words the product already uses -- a review this morning
         found the vocabulary too big to add to. */
      if(selIdxs().length===1){
        var pgI=selIdxs()[0];
        var pgA=(pres.slides[cur].annots||[])[pgI];
        if(pgA&&pgA.k==='text'&&typeof textAddPage==='function'){
          var np=textPages(pgA).length;
          menuHead(m,'flip book');
          row(np>1?('Add a page \u2014 '+np+' so far'):'Add a page','',
            function(){
              var at=textAddPage(pgI);
              renderSlide();renderFilm();
              if(at!=null) toast('Page '+(at+1)
                +' \u2014 click through them like a flip book\u2019s '
                +'figures');
            },
            'Another page of words in the same box. The box turns its '
            +'pages on a click, the way a flip book turns its figures',
            'flipbook');
          /* ...and, once the box walks with a flip book, WHICH FIGURE
             this page belongs to. Two rows rather than a list of every
             figure: the model stores a CHANGE, so the only two things
             worth saying about a page are "the next figure starts here"
             and "no it does not". (T166) */
          if(np>1&&pgA.fb){
            var pgBk=flipById(pres.slides[cur],pgA.fb);
            var pgN=pgBk?flipFrames(pgBk).length:0;
            if(pgN>1){
              var pgAt=Math.max(0,Math.min(np-1,pgA.at||0));
              var figs=pageFigs(pres.slides[cur],pgBk,pgA);
              var here=figs[pgAt]||0;
              var own=textPageFig(pgA,pgAt);
              if(here<pgN-1) row('Figure '+(here+2)+' starts on this page','',
                function(){
                  textPageFigSet(pgA,pgAt,here+1);
                  renderSlide();renderFilm();
                  toast('Page '+(pgAt+1)+' onwards goes with figure '
                    +(here+2));
                },
                'Everything from this page on belongs to the next '
                +'figure, until another page says otherwise','flipbook');
              if(own!=null&&pgAt>0) row('Keep this page with the one '
                +'before','',
                function(){
                  textPageFigSet(pgA,pgAt,null);
                  renderSlide();renderFilm();
                  toast('Page '+(pgAt+1)+' follows the page before it');
                },
                'Stops this page starting a new figure — it goes back '
                +'to whichever figure the page before it is on','undo');
            }
          }
          if(np>1) row('Remove this page','',
            function(){
              textDropPage(pgI,pgA.at||0);
              renderSlide();renderFilm();
              toast('Page removed');
            },
            'Takes away the page you are on. Page one is the box '
            +'itself and stays','trash');
        }
      }
      /* SHOWS WITH WHICH FIGURE (T161) -- the tie, offered from the
         thing being TIED.
         Tying text to a flip book's page has worked since T86 and reads
         well once you are there: "Just this figure" / "This figure and
         every one after" / "...and every one before". But its only door
         was a `Figures...` button that appears only while the FLIP BOOK
         is selected, so the flow ran backwards from the way anyone
         thinks about it -- select the book, open its pane, THEN select
         your text. Asked for again on 2026-09-01 as though it did not
         exist ("it is hard to tie text to a page on the flipbook"),
         which is the second time this feature has been re-requested
         while shipping; T86 added a hint inside the pane, and the pane
         was still the wrong place to be standing.
         So: start from the text. `showFlipPane` sets which book the
         pane is about and never touches the selection, so one click
         lands on the tie control with your item already named in it. */
      /* THE SAME SENTENCE, FOR A CHART'S SERIES (T162). A flip book's
         pages were the only thing on a slide that stepped when T161 was
         written; T160 made a chart's series the second, and "this
         sentence appears when the treatment line does" is the identical
         request. So it is the identical section -- one head, one row per
         stepper -- rather than a second place to look. */
      if(selIdxs().length){
        var tieS=pres.slides[cur];
        var tieBooks=[],tieCharts=[];
        ((tieS&&tieS.annots)||[]).forEach(function(x,xi){
          if(!x) return;
          if(x.k==='flip'&&flipFrames(x).length){tieBooks.push(xi);return;}
          /* only a chart that actually STEPS. On one that arrives whole
             there is no moment to tie to, and a row that cannot mean
             anything is worse than no row -- the rule the figure rows
             above already follow. */
          if(x.k==='chart'&&x.anim&&x.anim.by==='series'
            &&window.SemDeckChart.seriesCount(x)) tieCharts.push(xi);
        });
        var tieMine=selIdxs().filter(function(i){
          var x=(tieS.annots||[])[i];return x&&x.k!=='flip';});
        if((tieBooks.length||tieCharts.length)&&tieMine.length)
          menuHead(m,'shows with');
        if(tieBooks.length&&tieMine.length
          &&typeof showFlipPane==='function'){
          tieBooks.forEach(function(bi){
            var bk=(tieS.annots||[])[bi];
            var one=tieMine.length===1?(tieS.annots||[])[tieMine[0]]:null;
            var tied=one&&one.fb===bk.fid&&one.fbf!=null;
            var lab=tied
              ?('\u2713 Shows with figure '+((one.fbf|0)+1)
                +' of '+(annotLabel(bk)||'the flip book'))
              :('Show with a figure of '
                +(annotLabel(bk)||'the flip book')+'\u2026');
            row(lab,'',function(){showFlipPane(true,bi);},
              'Pick which figure this belongs to, and whether it shows '
              +'with that figure only, from it onwards, or up to it',
              'flipbook');
          });
        }
        /* PAIR THEM ALL UP AT ONCE (T175). Offered above the one-at-a-
           time rows, because with several things selected it is almost
           always the thing you meant: the rows below still do one
           object, and this does the walk.
           Both readings of "tied" are offered rather than picked for
           you -- "just this one at a time" is a walk-through, "and
           everything before it" builds a list up as you go -- because
           which one you want is a fact about the talk, not about the
           slide. */
        (function(){
          if(tieMine.length<2) return;
          var books=tieBooks.concat(tieCharts);
          books.forEach(function(bi){
            var bk2=(tieS.annots||[])[bi];
            var w=walkPairs(tieS,bi,tieMine);
            if(!w||!w.n) return;
            var what=(w.kind==='flip')?'figure':'series';
            /* "series" is already its own plural; "2 seriess" is the
               kind of thing that makes a good feature look unfinished */
            var whats=(w.kind==='flip')
              ?('figure'+(w.slots.length===1?'':'s')):'series';
            [['only','one at a time',
              'Each one shows only beside its own '+what+' \u2014 a '
              +'walk-through'],
             ['from','building up',
              'Each one arrives with its '+what+' and stays, so the '
              +'list builds up as you go']].forEach(function(md){
              row('Pair '+w.n+' up with the '+w.slots.length+' '
                +whats+' of '
                +(annotLabel(bk2)||'it')+' \u2014 '+md[1],'',
                function(){walkApply(bi,tieMine,md[0]);},
                md[2]+'. In reading order, top to bottom'
                +(w.words.length>w.n
                  ?(' \u2014 '+(w.words.length-w.n)+' would be left over')
                  :''),
                w.kind==='flip'?'flipbook':'plots');
            });
          });
        })();
        tieCharts.forEach(function(ci){
          /* a chart cannot be tied to its own series */
          var mine2=tieMine.filter(function(i){return i!==ci;});
          if(!mine2.length) return;
          var ca=(tieS.annots||[])[ci];
          var one2=mine2.length===1?(tieS.annots||[])[mine2[0]]:null;
          var t2=(one2&&one2.tie&&one2.tie.to==='series'
            &&one2.tie.id===ca.oid)?one2.tie:null;
          var lab2=t2
            ?('✓ Shows with “'+t2.at+'” in '
              +(annotLabel(ca)||'the chart'))
            :('Show with a series of '
              +(annotLabel(ca)||'the chart')+'…');
          row(lab2,'',function(){
            window.SemDeckChart.tieDlg(ci,mine2,ev);},
            'Pick which series this belongs to, and whether it arrives '
            +'with that series and stays, shows only while it is the '
            +'newest, or goes when it arrives','plots');
        });
      }
      /* REPLACING ONE THING WITH ANOTHER (T174), which is the thing
         people actually fight PowerPoint over: "it's really annoying
         when you want an image replacing another image". Two objects
         selected is exactly the shape of that question, so it is asked
         here and answered in one click -- the first goes on the same
         click the second arrives on. Not restricted to images: a table
         replaced by its chart, or one paragraph by another, is the same
         move and the same fix.
         The ORDER is the selection order, and the label says which is
         which rather than making you guess. */
      var swapN=selIdxs();
      if(swapN.length===2){
        var sA=(pres.slides[cur].annots||[])[swapN[0]];
        var sB=(pres.slides[cur].annots||[])[swapN[1]];
        if(sA&&sB){
          menuHead(m,'one replaces the other');
          [[0,1],[1,0]].forEach(function(pair){
            var gone=(pres.slides[cur].annots||[])[swapN[pair[0]]];
            var comes=(pres.slides[cur].annots||[])[swapN[pair[1]]];
            row('Replace \u201c'+String(annotLabel(gone)).slice(0,18)
              +'\u201d with \u201c'+String(annotLabel(comes)).slice(0,18)
              +'\u201d','',function(){
              var s5=pres.slides[cur];
              /* the incoming object needs a click of its own; the
                 outgoing one leaves on that same click. If it already
                 has one, that IS the click -- re-running this must not
                 push the swap one further along every time.
                 The outgoing object is left exactly as it was. On a
                 slide with nothing else built that means "simply there,
                 until it goes", which is what a swap looks like when you
                 describe it out loud, and it costs no extra click. */
              if(!comes.anim)
                comes.anim={type:'fade',order:nextAnimOrder(s5)};
              if(comes.anim&&gone.anim
                &&(gone.anim.order||0)>=(comes.anim.order||0)){
                comes.anim.order=nextAnimOrder(s5);
                delete comes.anim.parts;   /* T577: a block again */
              }
              gone.out=comes.anim.order||0;
              markDirty();renderSlide();renderFilm();
              if(typeof animPaneSync==='function') animPaneSync();
              if(typeof renderSelPane==='function') renderSelPane();
              toast('One click: \u201c'
                +String(annotLabel(gone)).slice(0,18)+'\u201d goes, '
                +'\u201c'+String(annotLabel(comes)).slice(0,18)
                +'\u201d arrives');
            },'One click swaps them over \u2014 no stacking two things '
              +'up and hoping','exit');
          });
        }
      }
      /* T579: DISAPPEAR, WHERE YOU ARE ALREADY POINTING AT THE THING
         (2026-09-30, user: "I cannot figure out how to make an image
         disappear"). The Animation tab's own verb, one click from the
         object: a click of its own at the end, or back to staying. The
         caret on the tab still says WHEN, beside another arrival. */
      if(swapN.length===1&&!(pageOf&&pageOf().poster)){
        var dA=(pres.slides[cur].annots||[])[swapN[0]];
        if(dA&&!dA.hide){
          var dGone=animOut(dA)!=null;
          menuHead(m,'animation');
          row(dGone?'Stay on the slide':'Disappear on a click','',function(){
            var s6=pres.slides[cur];
            if(animOut(dA)!=null) delete dA.out;
            else dA.out=nextAnimOrder(s6);
            markDirty();repaintAnimation();
            if(typeof animRibbonSync==='function') animRibbonSync();
            if(typeof animPaneSync==='function') animPaneSync();
            toast(animOut(dA)!=null
              ?('\u201c'+String(annotLabel(dA)).slice(0,18)+'\u201d '
                +'disappears on its own click \u2014 Animation \u2192 '
                +'Disappear says when')
              :('\u201c'+String(annotLabel(dA)).slice(0,18)+'\u201d '
                +'stays on the slide'));
          },dGone?'Keep it on the slide to the end'
            :'It goes away on a click of its own, after everything else '
            +'on this slide so far','exit');
        }
      }
      /* PINNED TO WHICH CORNER (T14). Offered for one object at a
         time: an anchor is a fact about that item, and a menu that
         set nine of them at once would be a menu nobody could undo in
         their head. */
      if(selIdxs().length===1){
        var anI=selIdxs()[0];
        var anA=(pres.slides[cur].annots||[])[anI];
        if(anA&&anA.k!=='arrow'){
          menuHead(m,'pinned to');
          var nowAn=anA.anch||'';
          row('Nothing — measured from the top left','',
            function(){setAnchor(anI,'');},
            'The default, and what every object in every deck did '
            +'before this existed').classList.toggle('on',!nowAn);
          ['tl','tc','tr','cl','c','cr','bl','bc','br']
            .forEach(function(k){
              if(k==='tl') return;   /* same as no anchor */
              row(ANCHORS[k][0],'',function(){setAnchor(anI,k);},
                'Stays this far from there when the page changes shape')
                .classList.toggle('on',nowAn===k);
            });
        }
      }
      /* CHARTS (T117). A selected chart edits here; a selected
         table (or a frame showing a table card) can become one. */
      (function(){
        var ci=selIdxs();
        if(ci.length!==1) return;
        var ca=(pres.slides[cur].annots||[])[ci[0]];
        if(!ca) return;
        if(ca.k==='table'){
          /* T324: what each column holds, and everything that follows */
          menuHead(m,'table');
          row('Columns\u2026','',function(){
            window.SemDeckTable.pane(true);},
            'What each column holds \u2014 numbers or text \u2014 and so '
            +'how it lines up, its decimals, its units, its footer and '
            +'its colours','table');
        }
        if(ca.k==='chart'){
          menuHead(m,'chart');
          CHART_TYPES.forEach(function(t){
            row(((ca.ct||'bar')===t[0]?'\u2713 ':'')+t[1],'',
              function(){ca.ct=t[0];markDirty();renderSlide();
                toast(t[1]+' chart');},
              null,'plots');
          });
          row('Edit data\u2026','',function(){
            window.SemDeckChart.dataDlg(ci[0]);},
            'The numbers behind this chart, one row per category. '
            +'Editing them unlinks the chart from its table.','pen');
          /* T322: everything else a chart can be asked */
          row('Chart options\u2026','',function(){
            window.SemDeckChart.pane(true);},
            'Stacking, log and second axes, data labels, axis titles, '
            +'trend lines, and each series\u2019 colour, name and axis',
            'plots');
          row(ca.leg===0?'Show the legend':'Hide the legend','',
            function(){
              if(ca.leg===0) delete ca.leg; else ca.leg=0;
              markDirty();renderSlide();},null,'eye');
          /* ONE CLICK FOR THE SLOW REVEAL (T160). Assigning a build
             number to each series by hand is exactly the drag-a-list-of-
             opaque-blocks misery people complain about in PowerPoint --
             where, documented and unfixed, chart series animations
             cannot be reordered AT ALL. The default order is the one the
             data is already in, which is nearly always the one you want;
             the order painter is the escape hatch when it is not. */
          (function(){
            var ns=window.SemDeckChart.seriesCount(ca);
            if(!ns) return;
            var on=!!(ca.anim&&ca.anim.by==='series');
            row(on?'\u2713 Reveal series one at a time'
                  :'Reveal series one at a time','',
              function(){
                if(on){
                  if(ca.anim) delete ca.anim.by;
                } else {
                  if(!ca.anim) ca.anim={type:'fade',
                    order:nextAnimOrder(pres.slides[cur])};
                  ca.anim.by='series';
                }
                markDirty();renderSlide();renderFilm();
                if(typeof animRibbonSync==='function') animRibbonSync();
                toast(on?'The whole chart arrives on one click'
                  :('Axes first, then '+ns+' series \u2014 '
                    +(ns+1)+' clicks'));
              },
              'The axes and gridlines arrive first, then one series per '
              +'click. The scale is fixed from the start, so nothing '
              +'moves as the lines come in.','stagger');
          })();
          if(ca.ref) row('Linked to its table','',function(){},
            'Update figures from their sources re-reads the numbers; '
            +'position, type and colours stay yours.','link');
        } else if(window.SemDeckChart.dataOf(ca)){
          menuHead(m,'chart');
          row('Turn into a chart','',function(){
            var data=window.SemDeckChart.dataOf(ca);
            if(!data){toast('Could not read numbers out of this '
              +'table');return;}
            var na=window.SemDeckChart.place(data,{
              x:Math.min(64,(ca.x||10)+6),y:Math.min(60,(ca.y||10)+6),
              ref:ca.k==='cell'?ca.ref:null});
            if(na) toast('Chart added beside the table \u2014 '
              +'right-click it to change its type');},
            'A bar chart of these numbers: first row names the '
            +'series, first column is the category. Born linked, so '
            +'updating figures re-reads the table.','plots');
        }
      })();
      /* COMPONENTS. The rows differ by what you are pointing at: a
         plain selection can BECOME one; an instance can push its look
         to the definition or leave it. */
      var cSel=selIdxs();
      var cA=(pres.slides[cur].annots||[])[cSel[cSel.length-1]];
      var cInst=(cA&&cA.cmp&&cA.cinst)?cA:null;
      menuHead(m,'component');
      if(cInst){
        var cDef=cmpStore()[cInst.cmp];
        var cN=cmpInstances(cInst.cmp).length;
        /* T409: the door the ribbon has, here too */
        row('Add a clone\u2026','',function(){cmpAddMenu(null,cInst);},
          'Another one here, on every slide, or on every slide after '
          +'this one \u2014 and what the clones share','plus');
        row('Push this look to \u201c'
          +((cDef&&cDef.name)||'the component')+'\u201d','',
          function(){
            var k=cmpPush(cInst.cmp,cur,cInst.cinst);
            toast(k?(k+' other instance'+(k===1?'':'s')+' updated')
              :'Saved \u2014 no other instances yet');},
          'The other '+(cN-1)+' instance'+(cN===2?'':'s')
          +' take this arrangement and look now. They follow every '
          +'edit anyway (T409); this is for a deck made before they '
          +'did. Their own words and figures are untouched.');
        /* WHERE ELSE IS THIS? The section could push a look to every
           other instance and could cut this one loose from them, but it
           could not tell you they existed — the count only ever
           appeared inside a tooltip on a different row (T89). */
        row('Its clones\u2026',String(cN),   /* T420: one name everywhere */
          function(){cmpInstMenu(cInst.cmp);},
          'Every place in the deck it has been put, as a list — '
          +'pick one to go to that slide with the instance already '
          +'selected','locate');
        row('Detach this one','',function(){
          var k=cmpDetach(cur,cInst.cinst);
          if(k) toast(k+' object'+(k===1?'':'s')
            +' \u2014 no longer linked');},
          'Turns this instance into ordinary objects. The component and '
          +'its other instances are unaffected.');
      } else if(cSel.length){
        row('Make clones of '
          +(cSel.length===1?'this':('these '+cSel.length))+'\u2026','',
          function(){cmpMakeMenu(null,cSel);},   /* T409 */
          'Same look, same place, or both \u2014 every copy keeps its '
          +'own words and figures, and changing one changes them all.',
          'group');
      }
      if(selIdxs().length===1){
        var fa=(pres.slides[cur].annots||[])[selIdxs()[0]];
        if(fa&&fa.k==='text'){
          /* T572: the Paragraph window's three AutoFit answers, in the
             same words -- one vocabulary on the row and on this menu */
          menuHead(m,'autofit');
          var fNow=!fa.fh?'g':(fa.fit==='shrink'?'s':'x');
          [['g','Grow the box','The box grows with its words'],
           ['s','Shrink the words','The box keeps its height and the '
             +'words shrink to fit it. The size you chose is kept, and it '
             +'never shrinks past readable'],
           ['x','Fixed box','The box keeps its height; words that do not '
             +'fit run over it, marked while you edit']]
            .forEach(function(p){
              row(p[1],'',function(){paraApply('f:'+p[0]);},p[2])
                .classList.toggle('on',fNow===p[0]);
            });
          if(fa.style&&styleDef(fa.style)){
            menuHead(m,'make default / style for '
              +styleDef(fa.style).label);
            row('Use this look for new boxes','',function(){
              if(promoteStyleFromBox(fa,false))
                toast('New '+styleDef(fa.style).label
                  +' boxes will use this look');
            },'Save this box’s typography and colours as the default for '
              +styleDef(fa.style).label+'; existing boxes stay as they are',
              'styles');
            row('Apply this look to slides…','',function(){
              if(typeof window.SemDeckApplyDlg==='function')
                window.SemDeckApplyDlg();
            },'Choose every slide, one section, or any individual slides. '
              +'Cancelling changes nothing and does not alter the default',
              'inherit');
            row('Save as a named variation…','',function(){
              var base=fa.style,p=styleDef(base);
              askText({title:'A variation of '+p.label,
                label:'Call this variation',value:'',ok:'Save',
                note:'It follows '+p.label+' for every property you '
                  +'did not change'},function(nm){
              if(nm===null) return;
              nm=String(nm).trim();
              if(!nm){toast('A variation needs a name');return;}
              var v=addVariant(nm,base);
              if(!v){toast('Could not make that variation');return;}
              var delta=variantDeltaFrom(fa,base,null);
              if(Object.keys(delta).length) deckStyles()[v.id]=delta;
              applyStyleTo(fa,v.id);
              markDirty();refresh();
              toast('Saved “'+nm+'” as a variation of '+p.label);
              });
            },'Keep this as a reusable named look. It follows the current '
              +'type for every property you did not change','plus');
          }
        }
      }
      if(selIdxs().length===1){
        var pvA=(pres.slides[cur].annots||[])[selIdxs()[0]];
        if(pvA&&pvA.k==='cell'&&pvA.ref){
          row('Where this came from…','',showProvPane,
            'The notebook and cell that made it, every cell in its '
            +'lineage, and whether the notebook has moved on since',
            'tree');
        }
      }
      row('History of this object…','',showObjHist,
        'Every state it has been through that the undo stack still '
        +'remembers, and a button to put any of them back','history');
      /* MATCH OBJECTS (T129). Every other T89 feature got a row on this
         menu; the one actually NAMED "match objects" never did — its
         doors were thirty rows down the Arrange dropdown and a button
         inside the Layers pane, both needing a second surface. Same
         three verbs as matchMenuAt, armed directly: armMatch validates
         the selection itself and says what it needs. */
      menuHead(m,'match');
      row('Copy this look to objects I click\u2026','',
        function(){armMatch('to');},
        'Then click each object that should take it','swap');
      row('Take the look of an object I click\u2026','',
        function(){armMatch('from');},
        'Then click the one object whose look you want here','swap');
      if(n>=2)
        row('Lay these out like a group I click\u2026','',
          function(){armMatch('layout');},
          'Then click a group whose arrangement these should copy. The '
          +'look does not travel \u2014 only positions and sizes','group');
      /* THE APPLY DIALOG, for everything that is not text (T129). Its
         own code has handled shapes, frames, arrows and tables since it
         was written — but its only door was the TEXT Styles menu, so a
         selected rectangle could not reach a dialog built for it. Text
         keeps its existing door; this one appears for the rest. */
      if(n===1){
        var apA=(pres.slides[cur].annots||[])[selIdxs()[0]];
        if(apA&&apA.k!=='text')
          row('Apply this look to\u2026','',function(){
            if(typeof window.SemDeckApplyDlg==='function')
              window.SemDeckApplyDlg();},
            'Choose which of its properties travel and which slides '
            +'they travel to','inherit');
      }
      /* SELECT BY WHAT THINGS ARE. Inline rather than behind a
         submenu: this is already a menu, and the counts are the point —
         a row that says how many it will take is a row you can trust
         before you click it. */
      var sby=selectByRows();
      if(sby.length){
        menuHead(m,'select on this slide');
        sby.forEach(function(r){
          row(r.label,String(r.n),function(){selectBy(r.key,r.val);});
        });
      }
      /* the lock, in words. The pane's button cycles the same three
         states in a quarter of the space; here they are named, which is
         how anyone finds out the position-only one exists at all. */
      var lms=selIdxs().map(function(i){
        return lockMode((pres.slides[cur].annots||[])[i]);});
      var lmNow=lms.every(function(x){return x===lms[0];})?lms[0]:null;
      menuHead(m,'lock');
      [['','Not locked',null,null],
       ['pos','Lock position',
        'Pinned where it is — still yours to select, resize and '
        +'restyle','pin'],
       ['all','Lock fully',
        'No clicking or dragging on the canvas. The Objects pane, and '
        +'an Alt-marquee, are the way back','lock']]
        .forEach(function(o){
          var b=row(o[1],'',function(){setLockSel(o[0]);},o[2],o[3]);
          if(lmNow===o[0]) b.classList.add('on');
        });
    }
    /* PLACING A COMPONENT never needed a selection — the definitions
       are deck-wide and the click point is the menu's own — but the
       rows sat inside the selection branch, so an EMPTY canvas had no
       component door at all (T129). Moved here, where both halves of
       the menu can reach them. */
    /* T474: the deck's one word for these is clones (T420); and the
       ribbon has the same door now (Images > Place > Clone…) */
    var cAll=cmpList();
    if(cAll.length){
      menuHead(m,'add a clone of');
      cAll.forEach(function(c){
        row('\u201c'+c.name+'\u201d',String(c.n),function(){
          var k=cmpPlace(c.id,at);
          if(k) toast('A clone of \u201c'+c.name+'\u201d is on this slide');},
          'A clone of this set, here');
      });
    }
    /* WHO SEES THIS. Beside `lock`, because both answer "what can be
       done to this object" rather than "what does it look like" (T31). */
    if(selIdxs().length){
      var pvs=selIdxs().map(function(i){
        return !!((pres.slides[cur].annots||[])[i]||{}).priv;});
      var allPriv=pvs.every(function(x){return x;});
      menuHead(m,'who sees it');
      var pb=row(allPriv?'\u2713 Only me':'Only me','',function(){
        setPrivSel(!allPriv);},
        'Show this only on your screen and in presenter view \u2014 never '
        +'to the audience, or in a PDF or .pptx','eye');
      if(allPriv) pb.classList.add('on');
    }
    /* the slide's SEQUENCE (T106): always offered, because reading
       order is a property of the slide, not of a selection */
    menuHead(m,'slide');
    row('Order on this slide\u2026','',function(){
      if(window.SemDeckReadingOrder) window.SemDeckReadingOrder();},
      'The order things are numbered and revealed in. Quick animate '
      +'sets it by clicking; here you nudge one step','stagger');
    row((function(){
      var mm=(typeof mastOf==='function')
        &&mastOf(pres.slides[cur]);
      return 'Master \u2014 '+((mm&&mm.name)||'none')+'\u2026';
    })(),'',function(){
      if(window.SemDeckMasters) window.SemDeckMasters();},
      'A look this slide inherits live \u2014 a background and the '
      +'objects drawn behind it (a logo, a footer band). Set it here for '
      +'one slide, a section or the deck.',
      'inherit');
    row('Insert a chart','',function(){
      var na=window.SemDeckChart.place(
        {cats:['A','B','C'],series:[
          {name:'Series 1',ys:[3,5,2]},{name:'Series 2',ys:[2,3,4]}]},
        {x:Math.max(2,Math.min(64,(at.x||40)-16)),
         y:Math.max(2,Math.min(58,(at.y||35)-17))});
      if(na) toast('Chart placed \u2014 right-click it to edit the '
        +'numbers or change its type');},
      'A bar chart with sample numbers to replace \u2014 or select a '
      +'placed table and \u201cTurn into a chart\u201d. Exports to '
      +'a .pptx as an editable chart.','plots');
    var cgm=customGuides();
    menuHead(m,'guides');
    row('Draw a guide box','B',armGuideBox,
        'An editing aid to lay out inside \u2014 drag its edges to '
        +'resize and its grip to move it. It snaps, and it is never '
        +'printed, exported or shown while presenting','frame');
    /* SHOWN OR HIDDEN, which is not drawn or deleted. Offered only once
       there is something to hide, so an empty page does not carry a
       toggle for nothing. */
    if(cgm.b.length||cgm.x.length||cgm.y.length){
      var gShown=guidesShown();
      var gvb=row(gShown?'\u2713 Show your guides':'Show your guides','H',
        function(){showCustomGuides(!gShown);},
        'Hidden, they neither draw nor snap. They stay in the deck, so '
        +'this gets them out of the way \u2014 it is not a delete',
        'guides');
      if(gShown) gvb.classList.add('on');
    }
    if(cgm.b.length)
      row('Clear the '+cgm.b.length+' guide box'
        +(cgm.b.length===1?'':'es'),'',function(){clearGuides(true);});
    if(cgm.x.length||cgm.y.length)
      row('Clear every guide','',function(){clearGuides(false);},
        'The boxes and the lines dragged off the rulers');
    menuHead(m,'paste');
    if(!clipBuf.length){
      /* greyed, the way every editor shows a Paste with nothing to paste,
         rather than a sentence standing in for the command (T533) */
      var pz=row('Paste','Ctrl+V',function(){});
      pz.disabled=true;pz.title='Nothing copied yet';
    } else {
      row('Paste','Ctrl+V',function(){pasteBuf('auto');},
        'Nudged clear of the original on this slide; in the same place '
        +'on any other');
      row('Paste in place','Ctrl+Shift+V',function(){pasteBuf('place');},
        'Exactly where it was copied from — the way you put one '
        +'caption in the identical spot on twenty slides');
      row('Paste here','Ctrl+Alt+V',function(){pasteBuf('here',at);},
        'Centred on the point you right-clicked');
    }
    cmPasteUp(m);
    cmFold(m);
    floatAt(m,ev);
  }
  /* T533: PASTE BESIDE CUT AND COPY. Paste was the last section of the
     menu, eight headings below the Cut and Copy it belongs with. When
     the menu opens on a selection, its rows move up to follow the first
     section's; on the empty canvas they are near the top already. */
  function cmPasteUp(m){
    var heads=$$('.hd-lab',m),ph=null;
    heads.forEach(function(h){
      if((h.textContent||'').trim().toLowerCase()==='paste') ph=h;});
    if(!ph||heads.length<3||heads[0]===ph) return;
    var first=(heads[0].textContent||'').trim().toLowerCase();
    if(!/^this object$|objects$/.test(first)) return;
    var block=[ph],n=ph.nextSibling;
    while(n&&!(n.classList&&n.classList.contains('hd-lab'))){
      block.push(n);n=n.nextSibling;}
    block.forEach(function(k){m.insertBefore(k,heads[1]);});
  }
  /* THE FOLD (T137). A right-click on one text box reached 31 buttons
     under 13 headings -- an inspector forced into a popup. The
     immediate actions stay in sight; every section past the everyday
     ones folds behind one worded "More" row that says how many rows it
     holds. Nothing moves surface: the rows keep their handlers, they
     just wait until asked for. Menus small enough to read whole (the
     empty-canvas one) never fold. */
  /* 'shows with' EARNS ITS PLACE HERE (T162). T161 added it and left it
     foldable "like every other optional section" -- which put the door
     built to fix a discoverability problem behind another door. This
     section exists precisely because the feature had been re-requested
     twice as though it did not exist; folding it repeats the mistake it
     was written to correct. */
  /* T579: 'animation' for the same reason -- its one row, Disappear,
     is there because the verb could not be found on the tab */
  var CM_KEEP={'this object':1,'2 objects':1,'where it goes':1,
    'what it shows':1,'figure':1,'refer to a figure':1,'paste':1,
    'chart':1,'shows with':1,'flip book':1,'repeat on slides':1,
    'this slide':1,'this section':1,'animation':1};
  function cmFold(m){
    m.setAttribute('role','menu');
    $$('button',m).forEach(function(b){
      b.setAttribute('role','menuitem');});
    if(m.querySelectorAll('button').length<=12) return;
    var more=document.createElement('div');
    more.className='cm-more';more.hidden=true;
    var folding=false,kids=[].slice.call(m.children);
    kids.forEach(function(k){
      if(k.classList&&k.classList.contains('hd-lab')){
        var t=(k.textContent||'').trim().toLowerCase();
        /* Repeating and making a default were both explicitly requested
           as right-click workflows. Leaving either behind More made a
           working command look absent in the live editor (2026-09-11). */
        folding=!CM_KEEP[t]&&!/^make default \/ style for /.test(t)
          &&!/objects?$/.test(t)
          &&!/^slide \d+$/.test(t)&&!/^a version of slide \d+$/.test(t)
          &&t!=='this page';
      }
      if(folding) more.appendChild(k);
    });
    var n=more.querySelectorAll('button').length;
    if(!n) return;
    var t2=document.createElement('button');
    t2.className='dbtn vw-opt cm-moret';t2.type='button';
    t2.setAttribute('aria-expanded','false');
    t2.setAttribute('role','menuitem');
    t2.innerHTML=(bic('menu')||'')+' More \u2014 '+n+' option'
      +(n===1?'':'s')+' \u25be';
    t2.title='Anchoring, components, matching, visibility, reading '
      +'order, master, chart and guide rows \u2014 everything less '
      +'everyday, one click away';
    t2.addEventListener('click',function(e){
      e.stopPropagation();
      more.hidden=!more.hidden;
      t2.setAttribute('aria-expanded',(!more.hidden).toString());
      cmRefit(m,more.hidden?null:t2);
    });
    m.appendChild(t2);m.appendChild(more);
  }
  /* T421: THE FOLD OPENS DOWNWARDS, AND THE SCREEN DOES NOT GROW. floatAt
     clamps the menu to the window when it opens, measured FOLDED; the
     24 rows behind More then extended it past the bottom edge, where
     nothing could be clicked or scrolled to -- on a 900px screen every
     Match row was unreachable from the right-click menu (2026-09-14).
     Re-clamp after the fold changes, and bring the fold's first rows
     into view inside the menu's own scroll. */
  function cmRefit(m,at){
    var r=m.getBoundingClientRect();
    if(r.bottom>window.innerHeight-8)
      m.style.top=Math.max(8,window.innerHeight-8-r.height)+'px';
    if(at) m.scrollTop=Math.max(0,at.offsetTop-6);
  }
  function setLockSel(mode){
    var s=pres.slides[cur]; if(!s||!s.annots) return;
    var idxs=selIdxs();
    if(!idxs.length) return;
    idxs.forEach(function(i){
      var a=s.annots[i]; if(!a) return;
      if(mode==='pos') a.lock='pos';
      else if(mode==='all') a.lock=1;
      else delete a.lock;
    });
    markDirty();
    var l=stage.querySelector('.annot-layer');
    if(l){renderAnnots(l,s);paintSel(l);}
    showFmt();   /* T481: the ribbon's Lock in place reads the new state */
    toast(LOCK_LABEL[mode]+(idxs.length===1?''
      :' — '+idxs.length+' items'));
  }
  function wireEditor(layer,s){
    /* Editable words keep the browser's native menu: it owns spelling
       suggestions and corrections. A right-click on a corner takes it
       out; anywhere else on the canvas opens OUR object menu. */
    layer.addEventListener('contextmenu',function(ev){
      if(ev.target&&ev.target.closest&&ev.target.closest(
        '[contenteditable="true"],[contenteditable="plaintext-only"]')) return;
      if(ev.target&&ev.target.classList
         &&ev.target.classList.contains('an-mid')){ev.preventDefault();return;}
      if(mode!=='edit'||tool!=='select') return;
      ev.preventDefault();
      openCanvasMenu(layer,s,ev);
    });
    layer.addEventListener('mousedown',function(ev){
      if(mode!=='edit') return;
      var t=ev.target;
      /* T534: THE KEYBOARD FOLLOWS THE CLICK. Every canvas gesture
         preventDefaults its mousedown, and that also stops the browser
         moving focus -- so after pressing a ribbon button and then
         clicking an object, Enter pressed that button AGAIN and Tab
         walked the ribbon instead of the slide (2026-09-29 audit). A
         click on the page hands the keys to the page; a box being typed
         in is on the page, and keeps them. */
      var fa=document.activeElement;
      if(fa&&fa!==document.body&&fa.blur&&!layer.contains(fa)) fa.blur();
      /* WHILE A MATCH IS ARMED the canvas is a picker, not an editor: the
         next thing you press is the object you meant, and selecting or
         dragging it instead would be the wrong answer to a gesture you
         have already committed to. Handled at the top of the one handler
         that owns canvas mousedown, so there is no second code path
         deciding what a click means (2026-08-22). */
      /* SEQUENCING uses the same door as matching, for the same
         reason: while a mode is armed the canvas is a picker, and one
         handler decides what a click means (T168). Shift is read HERE,
         off the event, because a modifier is a property of the click
         and not a state to keep in step. */
      if(typeof seqOn==='function'&&seqOn()){
        var st=(t.closest&&t.closest('.an-item[data-idx]'));
        if(st){
          ev.preventDefault();ev.stopPropagation();
          seqHit(+st.getAttribute('data-idx'),!!ev.shiftKey);
        }
        return;
      }
      if(matchArm){
        var mt=(t.closest&&t.closest('.an-item[data-idx]'));
        if(mt){
          ev.preventDefault();ev.stopPropagation();
          matchHit(+mt.getAttribute('data-idx'));
        }
        return;
      }
      var item=(t.closest&&t.closest('.an-item'))
        ||(t.getAttribute&&t.classList
           &&t.classList.contains('an-item')?t:null);
      if(tool==='select'){
        /* A RIGHT-CLICK PICKS, AND NEVER DRAGS. The menu that follows
           acts on the selection, so the click has to be able to change
           it -- but this handler used to run its full select/move/
           marquee ladder on button 2 as well, which meant the menu
           opened on top of a drag already in progress. The one
           exception is a bend corner, where right-click REMOVES it and
           the endpoint branch below owns the gesture. */
        if(ev.button===2
           &&!(t.classList&&t.classList.contains('an-endpt'))){
          var rraw=item&&item.getAttribute('data-idx');
          if(rraw!=null){
            var ridx=(rraw==='t'||rraw==='s')?rraw:+rraw;
            if(selIdxs().indexOf(ridx)<0) selectAnnot(layer,ridx,false);
          }
          return;
        }
        /* endpoint handles first, then resize handles, then arrows
           (they render on top, so they win the click even over a
           frame), then the item */
        if(t.classList&&t.classList.contains('an-endpt')){
          var idxE=+t.getAttribute('data-idx');
          selectAnnot(layer,idxE);
          /* the faint handle halfway along a segment CREATES a corner and
             then drags it, so adding and placing are one gesture */
          if(t.hasAttribute('data-addat')){
            var at=+t.getAttribute('data-addat');
            var aA=annotByIdx(s,idxE);
            if(aA){
              var mids=arrowMids(aA).slice();
              var pA=pctPoint(layer,ev);
              mids.splice(at,0,[pA.x,pA.y]);
              aA.mid=mids;
              markDirty();renderAnnots(layer,s);selectAnnot(layer,idxE);
              startMidPoint(layer,s,idxE,at,ev);
            }
            return;
          }
          if(t.hasAttribute('data-mid')){
            var mi2=+t.getAttribute('data-mid');
            /* Alt+click takes a corner out; so does a right-click, which
               is what a vector editor has trained everyone to try */
            if(ev.altKey||ev.button===2){
              var aR=annotByIdx(s,idxE);
              if(aR&&Array.isArray(aR.mid)){
                aR.mid.splice(mi2,1);
                if(!aR.mid.length) delete aR.mid;
                markDirty();renderAnnots(layer,s);selectAnnot(layer,idxE);
              }
              return;
            }
            startMidPoint(layer,s,idxE,mi2,ev);
            return;
          }
          startEndpoint(layer,s,idxE,
            t.getAttribute('data-ep'),ev);
          return;
        }
        if(item&&t.classList&&t.classList.contains('an-resize')){
          var rawR=item.getAttribute('data-idx');
          var idxR=(rawR==='t'||rawR==='s')?rawR:+rawR;
          selectAnnot(layer,idxR);
          startResize(layer,s,idxR,ev,t.dataset.corner);
          return;
        }
        if(item&&t.classList&&t.classList.contains('an-rotate')){
          var rawRo=item.getAttribute('data-idx');
          var idxRo=(rawRo==='t'||rawRo==='s')?rawRo:+rawRo;
          selectAnnot(layer,idxRo);
          startRotate(layer,s,idxRo,ev);
          return;
        }
        var ai=arrowAt(layer,s,ev);
        if(ai>=0){
          /* honour shift/multi-select the same way the item branch does */
          if(ev.shiftKey){selectAnnot(layer,ai,true);return;}
          if(selSet.indexOf(ai)<0) selectAnnot(layer,ai,false);
          else {selAnnot=ai;paintSel(layer);showFmt();}
          startMove(layer,s,ai,ev);
          return;
        }
        if(item){
          var raw=item.getAttribute('data-idx');
          var idx=(raw==='t'||raw==='s')?raw:+raw;
          /* Shift OR Ctrl/Cmd adds and removes; it never starts a drag.
             Ctrl is here because half the world reaches for it first and
             it did nothing at all before (2026-08-20). */
          if((ev.shiftKey||ev.ctrlKey||ev.metaKey)&&typeof idx==='number'){
            selectAnnot(layer,idx,true);return;
          }
          /* clicking outside the group you are inside leaves it */
          if(inGroup!=null&&typeof idx==='number'){
            var ga=(s.annots||[])[idx];
            if(!ga||ga.grp!==inGroup) leaveGroup(null);
          }
          /* T576: a second, separate click on what is already selected
             (and only that) reaches the object underneath it -- see
             clickThroughArm */
          if(ctTimer){clearTimeout(ctTimer);ctTimer=0;}
          /* ...and a click at the same spot as the last one that reached
             underneath carries on from THAT object: the top one would
             otherwise take the click back and the third never came */
          if(ctLast&&selSet.indexOf(idx)<0&&selSet.indexOf(ctLast.idx)>=0
             &&Math.abs(ev.clientX-ctLast.x)<=4
             &&Math.abs(ev.clientY-ctLast.y)<=4){
            var ctIt=layer.querySelector('.an-item[data-idx="'
              +ctLast.idx+'"]');
            if(ctIt){idx=ctLast.idx;item=ctIt;}
          }
          if(selSet.indexOf(idx)>=0
             &&selSet.length===groupMembers(s,idx).length
             &&!item.classList.contains('an-editing'))
            clickThroughArm(layer,idx,ev);
          /* clicking an item already in a multi-selection keeps the set and
             drags the whole group */
          if(selSet.indexOf(idx)<0) selectAnnot(layer,idx,false);
          else {selAnnot=idx;paintSel(layer);showFmt();}
          /* every item drags from its body, text included. The only thing
             that does not is a box you are actually typing in. */
          if(!item.classList.contains('an-editing'))
            startMove(layer,s,idx,ev);
        } else startMarquee(layer,s,ev);
        return;
      }
      ev.preventDefault();
      /* A GUIDE IS NOT AN ANNOTATION, so it forks off here rather than
         inside startDraw: startDraw's whole job is building s.annots
         entries, and a guide that never becomes one cannot leak into a
         render or an export later (see the guide-boxes section). */
      if(tool==='guide'){
        startGuideBox(layer,pctPoint(layer,ev));
        return;
      }
      /* EVERY insert tool draws the same way. Text and cell used to be
         the two that did not: they dropped a canned box wherever you
         clicked and left you to resize it by hand, every single time
         (2026-08-17, user: "when you add them it would be good to draw
         them out to the shape you like, they just kind of snap to the one
         shape"). */
      if(tool!=='select') startDraw(layer,s,tool,pctPoint(layer,ev));
    });
    /* double-click a GROUP to step inside it; the second double-click on
       a text box inside then edits its words, as it always did */
    layer.addEventListener('dblclick',function(ev){
      if(mode!=='edit'||tool!=='select') return;
      var it=ev.target.closest&&ev.target.closest('.an-item');
      if(!it){leaveGroup(layer);return;}
      var raw=it.getAttribute('data-idx');
      if(raw==='t'||raw==='s') return;
      var i2=+raw,a2=(s.annots||[])[i2];
      if(!a2||a2.grp==null||inGroup===a2.grp) return;
      ev.stopPropagation();
      inGroup=a2.grp;
      selectAnnot(layer,i2);
      toast('Inside the group \u2014 clicks pick one item. Esc to step out');
    });
  }
  /* every tool that exists. Anything else is NO tool. */
  var TOOLS={select:1,text:1,arrow:1,rect:1,line:1,cell:1,draw:1,
    table:1,flip:1,guide:1};
  function setTool(t){
    /* An unknown tool used to be armed happily: the QR button (since
       removed, T220) carried the generic
       `et` class with no data-tool, so the shared wiring ran
       setTool(undefined) and left the editor in a state no code handles —
       the button pressed, Cancel showing, the layer classed
       `tool-undefined`, the hint empty, and clicks on the page doing
       nothing. Worse, that wiring ran AFTER that handler's own
       setTool('select'), so it clobbered the cleanup and the state
       survived a successful insert (2026-08-17).
       The stray class is gone; this makes the whole family of that bug
       impossible rather than fixing the one instance of it. */
    if(!TOOLS[t]) t='select';
    tool=t;
    /* arming the guide-box tool with your own guides hidden would draw a
       box you could not see. Here rather than in each of the three doors
       onto it, so the generic `.et` wiring is covered too. */
    if(t==='guide') showCustomGuides(true);
    $$('#edit-tools .et').forEach(function(b){
      b.setAttribute('aria-pressed',(b.dataset.tool===t).toString());});
    /* the armed shape's tile lights (T197) */
    if(typeof shapeStripSync==='function') shapeStripSync();
    var l=stage.querySelector('.annot-layer');
    if(l) l.className='annot-layer tool-'+t;
    /* The way OUT, shown exactly when there is something to get out of.
       Escape has always de-armed a tool, but nothing said so, and an
       armed tool otherwise looks identical to no tool at all except for
       the cursor (2026-08-10, user). It sits beside the tools rather than
       in the hint, because the hint is the first thing the fit ladder
       drops and the exit must never be droppable. */
    var cx=$('#et-cancel');
    if(cx) cx.hidden=(t==='select');
    if(t!=='select'&&cropMode){
      cropModeOff();                     /* T587: the frame takes the trim */
      if(l&&pres.slides[cur]) renderAnnots(l,pres.slides[cur]);
    }
    var hint=$('#et-hint');
    /* "the slide" is wrong on a poster, which is one printed page and has
       no slides — the word leaked into every one of these (2026-08-07
       audit; cf. the Page/Slide label and the Versions button) */
    var pw=pageOf().poster?'the page':'the slide';
    if(hint) hint.textContent=
      t==='text'?('Drag on '+pw+' to draw a'
        +(pendingStyle&&styleDef(pendingStyle)
          ?' '+styleDef(pendingStyle).label:' text')
        +' box, or click for one that sizes itself')
      :t==='arrow'?'Drag on '+pw+' to draw an arrow'
      :t==='rect'?(function(){
        /* T469: the shape's own label, with its article -- it said
           "draw a lbrace" and "draw a exclaim" (2026-09-15 review) */
        var nm='shape';
        (typeof SHAPE_LIST!=='undefined'?SHAPE_LIST:[]).forEach(function(p){
          if(p[0]===pendingShape) nm=String(p[1]).toLowerCase();});
        if(pendingShape==='rect') nm='rectangle';
        return 'Drag on '+pw+' to draw '+(/^[aeiou]/.test(nm)?'an ':'a ')+nm;
      })()
      :t==='draw'?'Hold the mouse down and draw on '+pw+' freehand'
      :t==='line'?'Drag on '+pw+' to draw a line'
      :t==='cell'?'Drag on '+pw+' to draw a box for a figure (or click for '
        +'the usual size), then click the figure in your notebook'
      :t==='flip'?('Drag on '+pw+' to draw a flip book, then add the '
        +'figures you want to step through')
      :t==='table'?'Drag on '+pw+' to draw a table (or click for a 3\u00d73). '
        +'Double-click a cell to type; Tab moves along, Enter goes down'
      :t==='guide'?'Drag on '+pw+' to draw a guide box \u2014 an editing '
        +'aid to lay out inside. It snaps, and it is never printed, '
        +'exported or shown while presenting'
      /* NOTHING in the resting state. A hint earns its place by telling
         you about a mode you have just entered and cannot see; describing
         the default state — click to select, drag to move — is a caption
         on the obvious, sitting in the middle of the toolbar forever
         (2026-08-10, user: "what is that even there?"). */
      :'';
    /* THE DRAWING GROUP (T188): the mode's name over a short hint,
       and Cancel under them, in a group that exists only while a
       tool is armed. The long hint above is the ladder's first
       casualty; this one is two lines the group can afford. */
    var stc=$('#et-status');
    if(stc){
      stc.hidden=(t==='select');
      var word={text:'Text box',arrow:'Arrow',rect:'Shape',line:'Line',
        cell:'From notebook',flip:'Flip book',table:'Table',
        guide:'Guide box',draw:'Freehand'}[t]||t;
      if(t==='text'&&pendingStyle&&styleDef(pendingStyle))
        word=styleDef(pendingStyle).label+' box';
      if(t==='rect'&&pendingShape!=='rect'){
        var shp=SHAPE_LIST.filter(function(p){return p[0]===pendingShape;})[0];
        word=shp?shp[1]:pendingShape;
      }
      var how=(t==='text'||t==='cell'||t==='table')
        ?'Drag to draw, or click for the usual size'
        :'Drag on '+pw+' to draw it';
      stc.innerHTML='<span><b>Drawing: '+esc(word)+'</b></span>'
        +'<span>'+esc(how)+'</span>';
    }
    if(typeof txStripSync==='function') txStripSync();
    /* THE DRAWING GROUP FOLLOWS THE TAB THAT ARMED THE TOOL (T220).
       It used to live on Insert, which was the only tab a tool could
       be armed from; Images and Text can both arm one, and a group
       whose Cancel is on the other tab is a trap. */
    var cg=$('.rbn-grp.rbn-cancel');
    if(cg&&t!=='select'&&typeof activeTab==='function'){
      var at=activeTab();
      if(at==='images'||at==='text') cg.setAttribute('data-tab',at);
    }
    /* the group appeared or went, so the row is re-judged */
    if(typeof syncRibbonGroups==='function') syncRibbonGroups();
  }
  function deleteSel(){
    var s=pres.slides[cur];
    if(!s||!s.annots) return;
    var idxs=selIdxs();
    if(!idxs.length) return;
    /* A FULLY LOCKED ITEM IS NOT DELETABLE. "Lock fully takes it off the
       canvas altogether: no clicking, no dragging, no typing" (help),
       and every other bulk verb already asks lockedAll — duplicate,
       arrange, align, the PowerPoint export. Delete was the one that did
       not, and it is the one you cannot take back by looking at it.
       Both documented ways to hold a locked item in a selection end at
       this function: Alt+marquee "sweeps up fully locked items too", and
       the Objects pane is "the way back" for something you cannot click.
       Select one there to unlock it, press Delete meaning the other
       three, and it was gone (2026-08-25). */
    var kept=idxs.filter(function(i){
      return !lockedAll((s.annots||[])[i]);});
    var held=idxs.length-kept.length;
    if(!kept.length){
      toast(held===1?'That item is fully locked — unlock it first'
        :'Those '+held+' items are fully locked — unlock them first');
      return;
    }
    /* A CAPTION WHOSE FIGURE HAS GONE is rubbish somebody else has to
       find: the review lint exists partly to report exactly this. Untie
       it here instead. The caption STAYS — it is an ordinary text box
       and the words in it are yours — it simply stops claiming to
       belong to something that is not there (2026-08-26 audit, T58). */
    var untied=0,fmapDel=null;
    kept.forEach(function(i){
      var f=(s.annots||[])[i];
      if(!f||!f.cap) return;
      var ci=capOfFig(s,f);
      if(ci<0||kept.indexOf(ci)>=0) return;
      var c=s.annots[ci];
      /* FREEZE THE NUMBER IT WAS SHOWING. `{fig}` means "the number of
         the figure I am tied to", so the moment that figure goes the
         token has nothing left to say — and an untied box still
         holding one renders '[not a caption]' where a second ago it
         read 'Figure 3'. The words it was showing are the words it
         keeps. */
      fmapDel=fmapDel||figNumbers();
      var hitDel=fmapDel[f.cap];
      if(hitDel){
        var nDel=String(hitDel.n);
        c.text=String(c.text||'').replace(/\{fig\}/g,nDel);
        if(c.html) c.html=String(c.html).replace(/\{fig\}/g,nDel);
      }
      delete c.capOf;
      untied++;
    });
    kept.sort(function(x,y){return y-x;}).forEach(function(i){
      if(i>=0&&i<s.annots.length) s.annots.splice(i,1);});
    if(!s.annots.length) delete s.annots;
    selAnnot=null;selSet=[];markDirty();
    var l=stage.querySelector('.annot-layer');
    if(l) renderAnnots(l,s);
    showFmt();
    /* say what was NOT deleted, or a mixed selection looks like Delete
       half-worked for no reason */
    if(held) toast(held+' fully locked item'+(held===1?'':'s')+' kept');
    else if(untied) toast(untied+' caption'+(untied===1?'':'s')
      +' untied — the text is still there');
  }
  /* does this figure already have a caption on this slide */
  function capHasOne(a){
    var s=pres.slides[cur];
    return !!(a&&a.cap&&s&&capOfFig(s,a)>=0);
  }
  /* T17 shipped the TIE. This is the command: make the box, put it
     under the figure at the figure's width, tie it, number it, and
     leave the caret in it. */
  function addCaption(i){
    var s2=pres.slides[cur];
    var f=s2&&(s2.annots||[])[i];
    if(!f||!isFigure(f)) return 0;
    var l=stage.querySelector('.annot-layer');
    var r=l?annotRectPct(l,s2,i):null;
    var x=r?r.l:(f.x||10);
    var y=(r?r.b:((f.y||10)+(f.h||20)))+1;
    var w=r?(r.r-r.l):(f.w||40);
    s2.annots=s2.annots||[];
    s2.annots.push({k:'text',x:Math.max(0,x),y:Math.min(96,y),
      w:Math.max(6,w),size:1.8,bg:0,style:'caption',
      text:'Figure {fig}. '});
    var ci=s2.annots.length-1;
    tieCaption(i,ci);
    var l2=stage.querySelector('.annot-layer');
    if(l2){selectAnnot(l2,ci);focusText(l2,ci);}
    toast('Caption added — it follows the figure and numbers itself');
    return 1;
  }
  function groupSel(){
    var s=pres.slides[cur]; if(!s||!s.annots) return;
    var idxs=selSet.filter(function(i){return typeof i==='number';});
    if(idxs.length<2) return;
    var gid=nextGrp(s);
    idxs.forEach(function(i){if(s.annots[i]) s.annots[i].grp=gid;});
    markDirty();
    var l=stage.querySelector('.annot-layer');
    if(l){renderAnnots(l,s);selectAnnot(l,idxs[0]);}
    /* T487: Ctrl+G was invisible -- a group looked pixel-identical to a
       plain multi-selection and nothing said it had happened
       (2026-09-15 review) */
    toast('Grouped \u2014 '+idxs.length+' items move as one. '
      +'Ctrl+Shift+G ungroups; double-click to edit one inside');
  }
  function ungroupSel(){
    var s=pres.slides[cur];
    if(!s||typeof selAnnot!=='number'||!s.annots) return;
    var a=s.annots[selAnnot]; if(!a||a.grp==null) return;
    var g=a.grp;
    var ng=0;
    s.annots.forEach(function(x){if(x.grp===g){delete x.grp;ng++;}});
    markDirty();
    var l=stage.querySelector('.annot-layer');
    if(l){renderAnnots(l,s);selectAnnot(l,selAnnot);}
    toast('Ungrouped \u2014 '+ng+' separate items again');
  }
