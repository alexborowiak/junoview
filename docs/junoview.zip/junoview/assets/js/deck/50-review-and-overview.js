/* 50-review-and-overview.js — the deck as words, the overview map, cuts, and the builder's sidebar.
   ONE FRAGMENT of deck.js's single IIFE, concatenated with its
   siblings in filename order by assets.deck_js(). It does not
   parse alone and is not meant to: see 00-page.js. */
  /* ---- WHAT THE DECK SAYS, IN WORDS -----------------------------------
     (TASKS T35.) Two halves of one idea: write the deck out as text a
     person or a language model can read, and say what looks wrong with
     it while you are in there.

     WHY THIS IS NOT PREFLIGHT. `preflight` asks "will this print" — per
     slide, physical, millimetres and dpi and contrast. This asks "does
     this hold together" — deck-wide, editorial, about words and figures
     and whether the same thing is called two things. They share no
     question and no unit, and folding one into the other would give you
     a list where "0.2mm line" sits next to "slide 12 has 90 words on
     it" as if those were the same kind of problem.

     THE EXPORT IS TEXT, AND MARKDOWN. junoview is offline and stays
     offline; what travels is the words. Markdown because it pastes into
     anything, because a model reads structure out of it without being
     told the format, and because a colleague can read it as it stands —
     which is the difference between an export and a dump.

     IT SAYS WHERE A FIGURE CAME FROM, and that is the part no other
     export can do: a deck knows its figures by notebook anchor, so the
     review can say "the toe map, from demo::toe_map" rather than
     "[image]". Reviewing a talk without knowing which figure is which
     is reviewing a talk with the pictures cut out.

     THE FOUR LINTS ARE THE FOUR TASKS.md NAMES, and each one reports
     what it counted rather than a verdict, because a heuristic that
     will not show its working is one you cannot argue with:
       - a figure nobody mentions: on the slide, no caption, and no text
         or note on that slide that names it.
       - a caption with no figure: `capOf` pointing at nothing, or text
         that reads like a caption and is tied to nothing. T17 made the
         tie explicit, which is what makes this answerable at all.
       - two spellings of one thing: terms that are the same once
         hyphens, spaces and case are taken out. Grouped that way,
         "sea-level"/"sea level" and "Toe Map"/"toe map" fall out
         together, and "The"/"the" — which differ only in the first
         letter, i.e. a sentence beginning — deliberately do not.
       - a slide with a lot on it: words and items, both counted. */
  var DENSE_WORDS=55, DENSE_ITEMS=12;
  function revText(a){
    if(!a) return '';
    if(a.k==='text') return String(a.text||'');
    if(a.k==='table'&&Array.isArray(a.rows))
      return a.rows.map(function(r){
        return (r||[]).map(function(c){
          return typeof c==='string'?c:((c&&c.t)||'');}).join(' | ');
      }).join('\n');
    return '';
  }
  function slideWordCount(sl){
    var n=0;
    (sl.annots||[]).forEach(function(a){
      if(!a||a.hide||a.priv) return;
      var t=revText(a).trim();
      if(t) n+=t.split(/\s+/).length;
    });
    if(sl.layout==='title')
      n+=String((sl.title||'')+' '+(sl.sub||'')).trim()
        .split(/\s+/).filter(Boolean).length;
    return n;
  }
  /* capOfFig answers the editor's MODEL question and must see every tied
     caption. A review asks the narrower audience question instead. */
  function reviewCaption(sl,a){
    var ci=capOfFig(sl,a);
    var ca=ci>=0?(sl.annots||[])[ci]:null;
    return ca&&!ca.hide&&!ca.priv?ca:null;
  }
  /* WHERE A FIGURE CAME FROM, in one line. The deck knows this and no
     other export of it does. */
  function revFigLine(sl,a,map){
    var bits=[];
    var nm=a.ref?String(a.ref).split('::').pop():'';
    bits.push(nm||(a.k==='image'?'a placed picture'
      :a.k==='flip'?'a flip book':'a frame'));
    var num=(a.cap&&map[a.cap])?map[a.cap].n:0;
    if(num) bits[0]='Figure '+num+' — '+bits[0];
    var ca=reviewCaption(sl,a);
    /* A caption normally travels WITH its figure, which used to bypass
       deckReview's private/hidden guard entirely. Apply the same audience
       boundary before borrowing its words (T49). */
    var cap=ca?revText(ca).trim():'';
    if(cap) bits.push('“'+figSubst(cap,ca,map)+'”');
    if(a.ref) bits.push('from '+a.ref);
    else if(a.k==='image') bits.push('pasted in, not from a notebook');
    if(a.k==='flip'&&Array.isArray(a.frames))
      bits.push(a.frames.length+' frames');
    return bits.join(' · ');
  }
  /* WHAT TO CALL A SLIDE IN AN EXPORT THAT TRAVELS. `filmText` names a
     slide by the first thing written on it, which is right in the strip
     — you are looking at the slide, private items and all. Here it is
     wrong: a slide whose only text is an "only me" note would be
     HEADED with that note, and the whole promise of T31 is that those
     words do not leave. So the heading is taken from the same reading
     order with the private items already dropped. */
  function revHeading(sl){
    if(!sl) return '';
    if(sl.label) return String(sl.label);
    if(sl.layout==='title'&&sl.title) return String(sl.title);
    var out='';
    orderedIdx(sl).forEach(function(j){
      if(out) return;
      var a=(sl.annots||[])[j];
      if(!a||a.hide||a.priv||a.capOf) return;
      var t=revText(a).trim();
      if(t) out=t.split(/[\r\n]/)[0];
    });
    return out;
  }
  function deckReview(){
    var L=[],map=figNumbers();
    var runs=sectionRuns();
    var n=(pres.slides||[]).length;
    var mins=goalTotal();
    L.push('# '+(pres.name||'Untitled deck'));
    L.push('');
    L.push(n+' slide'+(n===1?'':'s')
      +(runs.filter(function(r){return r.id;}).length
        ?(' in '+runs.filter(function(r){return r.id;}).length
          +' sections'):'')
      +(mins?(' · '+fmtMins(mins)+' planned'):'')
      +(pres.talkMins?(' · '+pres.talkMins+' minute slot'):''));
    if(pres.notes){
      L.push('');
      L.push('## About the whole talk');
      L.push('');
      L.push(String(pres.notes).trim());
    }
    runs.forEach(function(run){
      L.push('');
      L.push('## '+(run.id?(run.name||'Section')
        :(runs.length>1?'(no section)':'The slides')));
      for(var k=0;k<run.n;k++){
        (function(i){
          var sl=pres.slides[i];
          if(!sl) return;
          L.push('');
          L.push('### '+(i+1)+'. '+(revHeading(sl)||'(untitled)'));
          var tags=[];
          if(sl.opt) tags.push('optional');
          if(sl.cuts&&sl.cuts.length)
            tags.push('only in: '+sl.cuts.map(function(c){
              return (cutMap()[c]||{}).name||c;}).join(', '));
          if(slideGoal(sl)) tags.push(fmtMins(slideGoal(sl))+' planned');
          if(tags.length) L.push('*'+tags.join(' · ')+'*');
          if(sl.layout==='title'){
            if(sl.title) L.push('');
            if(sl.title) L.push('**'+sl.title+'**');
            if(sl.sub) L.push(sl.sub);
          }
          /* IN READING ORDER, not storage order: the review has to say
             the slide in the order somebody looking at it would */
          var words=[],figs=[];
          orderedIdx(sl).forEach(function(j){
            var a=(sl.annots||[])[j];
            /* a private note is not part of the talk, and this export
               travels (T31) */
            if(!a||a.hide||a.priv) return;
            if(isFigure(a)){figs.push(revFigLine(sl,a,map));return;}
            if(a.capOf) return;         /* said with its figure */
            var t=figSubst(revText(a),a,map).trim();
            if(t) words.push(t);
          });
          if(words.length){
            L.push('');
            words.forEach(function(t){
              L.push(t.split('\n').map(function(ln,li){
                return (li?'  ':'- ')+ln;}).join('\n'));
            });
          }
          if(figs.length){
            L.push('');
            L.push('Figures:');
            figs.forEach(function(f){L.push('- '+f);});
          }
          if(sl.notes){
            L.push('');
            L.push('Speaker notes:');
            String(sl.notes).trim().split('\n').forEach(function(ln){
              L.push('> '+ln);});
          }
        })(run.at+k);
      }
    });
    L.push('');
    return L.join('\n');
  }
  /* the terms, normalised: hyphens, spaces and case out, so the
     variants of one thing land in one bucket */
  function termKey(w){
    return String(w||'').toLowerCase().replace(/[^a-z0-9]+/g,'');
  }
  function reviewLints(){
    var out=[],map=figNumbers();
    var surfaces={};
    (pres.slides||[]).forEach(function(sl,si){
      var texts=[];
      (sl.annots||[]).forEach(function(a){
        if(!a||a.hide||a.priv) return;
        var t=revText(a); if(t) texts.push(t);
      });
      if(sl.notes) texts.push(String(sl.notes));
      if(sl.layout==='title') texts.push((sl.title||'')+' '+(sl.sub||''));
      var all=texts.join(' ');
      /* --- 1. a figure nobody mentions --- */
      (sl.annots||[]).forEach(function(a,i){
        if(!isFigure(a)||a.hide||a.priv) return;
        if(reviewCaption(sl,a)) return;       /* a PUBLIC caption */
        var num=(a.cap&&map[a.cap])?map[a.cap].n:0;
        var nm=a.ref?String(a.ref).split('::').pop():'';
        var named=(num&&new RegExp('\\bfig(?:ure)?\\.?\\s*'+num+'\\b','i')
          .test(all))
          ||(nm&&all.toLowerCase().indexOf(nm.toLowerCase().replace(
            /[_-]+/g,' '))>=0)
          ||(nm&&all.toLowerCase().indexOf(nm.toLowerCase())>=0);
        if(named) return;
        out.push({sev:'warn',si:si,i:i,
          head:'Slide '+(si+1)+': a figure nothing mentions',
          why:(num?('Figure '+num):'This figure')+' has no caption, and '
            +'no text or note on the slide names it. An audience does '
            +'not know what they are looking at.'});
      });
      /* --- 2. a caption with no figure --- */
      (sl.annots||[]).forEach(function(a,i){
        if(!a||a.hide||a.priv||a.k!=='text') return;
        var t=revText(a).trim();
        var looks=/^\s*(fig(ure)?\.?\s*\d|table\s*\d)/i.test(t);
        if(a.capOf){
          if(figOfCap(sl,a)>=0) return;
          out.push({sev:'err',si:si,i:i,
            head:'Slide '+(si+1)+': a caption whose figure is gone',
            why:'“'+t.slice(0,60)+'” is tied to a figure that is no '
              +'longer on this slide. It will number as [missing '
              +'figure] and read as a caption for nothing.'});
        } else if(looks){
          out.push({sev:'warn',si:si,i:i,
            head:'Slide '+(si+1)+': a caption that is not tied to '
              +'anything',
            why:'“'+t.slice(0,60)+'” reads like a caption but belongs '
              +'to no figure, so it will not follow one, and its '
              +'number will not update when the slides move.'});
        }
      });
      /* --- 4. a slide with a lot on it --- */
      var wc=slideWordCount(sl);
      var ic=(sl.annots||[]).filter(function(a){
        return a&&!a.hide&&!a.priv&&!a.capOf;}).length;
      if(wc>DENSE_WORDS||ic>DENSE_ITEMS)
        out.push({sev:'warn',si:si,i:null,
          head:'Slide '+(si+1)+': a lot on one slide',
          why:wc+' words and '+ic+' things on it. Above about '
            +DENSE_WORDS+' words an audience reads instead of '
            +'listening.'});
      /* COLLECT THE SURFACES for lint 3. Single words AND adjacent
         pairs, because the whole point is that "sea-level" and "sea
         level" are the same term written two ways -- and one of those
         is one token while the other is two. A first pass that only
         looked at single tokens found the hyphenated form and never
         the spaced one, so the two could never meet in a bucket. */
      var toks=all.match(/[A-Za-z][A-Za-z0-9'-]*/g)||[];
      function surf(w){
        var k=termKey(w);
        if(k.length<4) return;
        (surfaces[k]=surfaces[k]||{})[w]=(surfaces[k][w]||0)+1;
      }
      toks.forEach(function(w,i){
        if(w.length>=4) surf(w);
        if(i+1<toks.length){
          var pair=w+' '+toks[i+1];
          if(termKey(pair).length>=6) surf(pair);
        }
      });
    });
    /* --- 3. two spellings of one thing --- */
    Object.keys(surfaces).forEach(function(k){
      var forms=Object.keys(surfaces[k]);
      if(forms.length<2) return;
      /* forms differing ONLY in the first letter's case are a sentence
         beginning, not an inconsistency */
      var real=forms.some(function(a){
        return forms.some(function(b){
          return a!==b&&a.slice(1)!==b.slice(1);});});
      if(!real) return;
      /* NO MINIMUM COUNT. A first pass wanted three occurrences before
         reporting, which silently hid the commonest real case -- the
         term said once each way, which is exactly the inconsistency
         worth catching. Two surfaces that normalise to the same string
         and differ by more than a capital is already a strong enough
         signal; the count is shown so you can judge it yourself. */
      var total=forms.reduce(function(t,f){return t+surfaces[k][f];},0);
      out.push({sev:'warn',si:null,i:null,
        head:'Two spellings of one thing',
        why:forms.map(function(f){
          return '“'+f+'” ×'+surfaces[k][f];}).join(', ')
          +'. Pick one — an audience reads the difference as a '
          +'distinction.'});
    });
    /* --- 4. a picture nobody has described (T105) ---
       Deliberately NOT "has no alt text": a picture is allowed to carry
       nothing, and saying so is a real answer. What this reports is the
       picture nobody has decided about, which is the only state that is
       an omission rather than a choice. It reads the same field the
       renderer does, so a deck this is quiet about is a deck whose alt
       text is really there. */
    (pres.slides||[]).forEach(function(sl,si){
      (sl.annots||[]).forEach(function(a,i){
        if(!a||a.priv) return;
        /* T552: a chart is a picture of numbers, and asked the same */
        if(a.k!=='image'&&a.k!=='flip'&&a.k!=='chart') return;
        if(a.dec||(a.alt&&String(a.alt).trim())) return;
        var what=a.k==='chart'?'chart':'picture';
        out.push({sev:'warn',si:si,i:i,
          head:'This '+what+' does not say what it shows',
          why:'Somebody who cannot see it gets “'
            +(annotLabel(a)||what)+'” — the name of the box, not '
            +'what is in it. Select it and use Object › Alt text '
            +'(or right-click it), or leave that empty to mark it '
            +'decorative if it really carries nothing.'});
      });
    });
    /* --- 5. the talk does not fit the time it has (T121) ---
       Every part of this already existed and none of it was a LINT:
       slideGoal and goalTotal add the goals up, rehStats holds what
       each slide actually took, and the notes pane shows the verdict
       while you are presenting. That is the wrong moment -- the review
       is where you still have time to cut a slide. So this restates
       what those already know rather than measuring anything new. */
    var goal=goalTotal();
    var st=rehStats(),runs=(st.runs||[]).length;
    if(goal&&runs){
      var real=0,timed=0;
      (pres.slides||[]).forEach(function(sl){
        var a=sl&&sl.sid?st.by[sl.sid]:null;
        if(a&&a.n){real+=a.mean/60;timed++;}
      });
      /* only worth saying when most of the deck has actually been
         rehearsed -- half a run extrapolated to a whole talk is a
         number that looks like evidence and is not */
      if(timed>=Math.ceil((pres.slides||[]).length/2)&&real){
        var over=real-goal;
        if(Math.abs(over)>=Math.max(1,goal*0.1))
          out.push({sev:over>0?'err':'warn',si:null,i:null,
            head:over>0?'This runs long':'This runs short',
            why:'The goals add up to '+fmtMins(goal)+' and '+timed
              +' rehearsed slide'+(timed===1?'':'s')+' averaged '
              +fmtMins(real)+' \u2014 '+fmtMins(Math.abs(over))
              +(over>0?' over. Cut a slide, or move the goal.'
                :' under. There is room for the thing you left out.')});
      }
    }
    /* --- 6. a link that goes nowhere (T118) ---
       An internal jump is stored by `sid` precisely so reordering
       cannot repoint it -- but DELETING the target still can, and
       silently. This is the one lint that reports a broken thing
       rather than a debatable one. */
    (pres.slides||[]).forEach(function(sl,si){
      (sl.annots||[]).forEach(function(a,i){
        var l=a&&a.link;
        if(!l||l.to!=='slide') return;
        if(linkSlideIdx(l.sid)>=0) return;
        out.push({sev:'err',si:si,i:i,
          head:'This link goes nowhere',
          why:'It points at a slide that is no longer in the deck. '
            +'Clicking it while presenting says so and stays put, '
            +'which is not what you want an audience to see.'});
      });
    });
    /* --- 7. two slides that are the same slide --- */
    var seen={};
    (pres.slides||[]).forEach(function(sl,si){
      var key=(sl.annots||[]).filter(function(a){
        return a&&!a.hide&&!a.priv;
      }).map(function(a){
        return a.k+':'+(revText(a)||a.src||'').slice(0,80);
      }).sort().join('|');
      if(!key||key.length<20) return;    /* an empty slide is not a copy */
      if(seen[key]!=null){
        out.push({sev:'warn',si:si,i:null,
          head:'This slide is a copy of an earlier one',
          why:'Slide '+(seen[key]+1)+' has the same objects and the '
            +'same words. A duplicate left in by accident reads as a '
            +'stutter; one left in on purpose usually wants a build '
            +'instead.'});
      } else seen[key]=si;
    });
    return out;
  }
  /* THE WHOLE REVIEW AS ONE THING (T121).
     The panel showed the lints and the readable text side by side and
     then exported only the text, so the half you would send to a
     co-author was the half without the findings in it. The .md now
     carries both, and there is a JSON door beside it for anything that
     is not a person -- a pre-submission check in CI, most obviously.
     Neither recomputes: both read reviewLints(), so an export can never
     disagree with what the panel just showed you. */
  function reviewMarkdown(text,lints){
    if(!lints.length) return text;
    var head='## What this review found\n\n';
    var body=lints.map(function(l){
      var where=(l.si!=null)?('Slide '+(l.si+1)+' \u2014 '):'';
      return '- **'+(l.sev==='err'?'':'')+where+l.head+'.** '+l.why;
    }).join('\n');
    return head+body+'\n\n---\n\n'+text;
  }
  function reviewJson(lints){
    return JSON.stringify({
      deck:pres.name||'',
      slides:(pres.slides||[]).length,
      findings:lints.map(function(l){
        return {severity:l.sev,slide:(l.si==null?null:l.si+1),
          object:(l.i==null?null:l.i),title:l.head,detail:l.why};
      })
    },null,2);
  }
  /* THE PANEL. The lints first, because they are the reason to open it
     twice; the text below them, because it is the reason to open it at
     all. Both at once rather than two doors: what a lint says and what
     the reviewer will read are the same deck, and having to switch
     between them to check one against the other is the whole problem
     with a separate report. */
  function reviewClose(){
    var ov=$('#deck-review');
    if(ov) ov.remove();
    document.removeEventListener('keydown',reviewKey,true);
  }
  function reviewKey(e){
    if(!$('#deck-review')) return;
    if(e.key==='Escape'){
      e.preventDefault();e.stopPropagation();reviewClose();}
  }
  function openReview(){
    reviewClose();
    var text=deckReview(),lints=reviewLints();
    var ov=document.createElement('div');
    ov.className='deck-review';ov.id='deck-review';
    ov.innerHTML='<div class="rv-head">'
      +'<span class="rv-t">Send this deck out to be read</span>'
      +'<span class="deck-spring"></span>'
      +'<button class="dbtn" id="rv-copy">'+bic('copy')+' Copy</button>'
      +'<button class="dbtn" id="rv-dl">'+bic('markdown')
      +' Save as .md</button>'
      +'<button class="dbtn" id="rv-json" title="The same findings as '
      +'JSON, for something that is not a person to read \u2014 a '
      +'pre-submission check, say">'+bic('code')
      +' Save as .json</button>'
      +'<button class="dbtn" id="rv-close">'+bic('exit')
      +' Close</button></div>'
      +'<div class="rv-main">'
      +'<div class="rv-lints" id="rv-lints"></div>'
      +'<div class="rv-textwrap"><span class="rv-lab">'
      +'what a reader gets — markdown, so it pastes anywhere</span>'
      +'<textarea class="rv-text" id="rv-text" readonly '
      +'spellcheck="false"></textarea></div></div>';
    document.body.appendChild(ov);
    ov.querySelector('#rv-text').value=text;
    var host=ov.querySelector('#rv-lints');
    var hd=document.createElement('div');
    hd.className='rv-lhead';
    var errs=lints.filter(function(l){return l.sev==='err';}).length;
    hd.textContent=lints.length
      ?(lints.length+' thing'+(lints.length===1?'':'s')+' to look at'
        +(errs?(' · '+errs+' serious'):''))
      :'Nothing looks wrong with the content';
    host.appendChild(hd);
    var note=document.createElement('div');
    note.className='rv-note';
    note.textContent='About what the deck says. “Before you print” '
      +'is the other list — that one is about ink and millimetres.';
    host.appendChild(note);
    lints.forEach(function(l){
      var b=document.createElement('button');
      b.className='rv-lint sev-'+l.sev;
      var h=document.createElement('span');
      h.className='rv-lh';h.textContent=l.head;
      var w=document.createElement('span');
      w.className='rv-lw';w.textContent=l.why;
      b.appendChild(h);b.appendChild(w);
      if(l.si!=null){
        b.title='Go to slide '+(l.si+1);
        b.addEventListener('click',function(){
          reviewClose();
          cur=l.si;selAnnot=(l.i==null?null:l.i);
          selSet=(l.i==null?[]:[l.i]);
          refresh();
        });
      } else b.classList.add('nogo');
      host.appendChild(b);
    });
    ov.querySelector('#rv-close').addEventListener('click',reviewClose);
    ov.querySelector('#rv-copy').addEventListener('click',function(){
      var ta=ov.querySelector('#rv-text');
      ta.select();
      var done=false;
      try{done=document.execCommand('copy');}catch(e){}
      if(!done&&navigator.clipboard)
        navigator.clipboard.writeText(text).then(function(){
          toast('Copied — paste it wherever it is being read');});
      else toast(done?'Copied — paste it wherever it is being read'
        :'Select the text and copy it');
    });
    ov.querySelector('#rv-dl').addEventListener('click',function(){
      /* the findings AND the readable text: the half you send to a
         co-author used to be the half without the findings (T121) */
      var blob=new Blob([reviewMarkdown(text,lints)],
        {type:'text/markdown'});
      var a=document.createElement('a');
      a.href=URL.createObjectURL(blob);
      a.download=(pres.name||'deck')+'.review.md';
      a.click();
      setTimeout(function(){URL.revokeObjectURL(a.href);},2000);
      toast('Saved — it travels; junoview stays here');
    });
    ov.querySelector('#rv-json').addEventListener('click',function(){
      var blob=new Blob([reviewJson(lints)],{type:'application/json'});
      var a=document.createElement('a');
      a.href=URL.createObjectURL(blob);
      a.download=(pres.name||'deck')+'.review.json';
      a.click();
      setTimeout(function(){URL.revokeObjectURL(a.href);},2000);
      toast(lints.length+' finding'+(lints.length===1?'':'s')
        +' saved as JSON');
    });
    document.addEventListener('keydown',reviewKey,true);
  }
  /* ---- THE OVERVIEW: THE WHOLE TALK AT ONCE ---------------------------
     (TASKS T26.) TASKS.md is careful about what this is: "the realistic
     scope of the infinite-canvas wish — an overview/navigation layer,
     not canvas-based authoring". So it navigates and it does not author,
     and that boundary is the reason it can be an overlay over the
     existing model rather than a second editor.

     WHY AN OVERLAY AND NOT A PANE. Every pane in this app docks beside
     the stage and takes width from the page; this needs the opposite —
     all the room there is, for as long as you are looking, and none
     afterwards. It is the same shape as the spotlight and the presenter
     view, which are the other two things here that take the screen and
     give it straight back.

     WHAT IT DRAWS is what already exists: sectionRuns() for the
     clusters, miniDiagram() for the tiles, and the same reading of
     optional/cut membership the playback filter uses. Nothing here
     computes a fact of its own, which is why it cannot disagree with
     the strip it is a zoom-out of. */
  function overviewClose(){
    var ov=$('#deck-overview');
    if(ov) ov.remove();
    if(ovwIO){ovwIO.disconnect();ovwIO=null;}
    document.removeEventListener('keydown',overviewKey,true);
    ovwKeys=null;
  }
  /* T557: while the map is a sorter, its keys are the sorter's; set by
     openOverview, cleared on close */
  var ovwKeys=null;
  /* ---- THE SORTER'S TILES (2026-10-09, editor #11) ----------------------
     Opening the sorter drew sixty miniDiagrams (110 ms at 4x on a
     60-slide deck), and every pick-up, duplicate and delete drew them
     all again. A tile now takes a copy of the strip's thumbnail of its
     slide whenever the strip holds one drawn from exactly what the
     slide is now (filmThumbSource), and is drawn itself only when it
     has to be: at once within OVW_NEAR of the current slide, and as it
     comes into view (ovwIO) beyond that, in a box of the same size and
     the slide's own colour. */
  var ovwIO=null,OVW_NEAR=32;
  function ovwThumb(sl,i,copyOf,body){
    var c=copyOf(sl);
    if(c) return c;
    if(Math.abs(i-cur)<=OVW_NEAR||!window.IntersectionObserver)
      return miniDiagram(sl);
    if(!ovwIO) ovwIO=new IntersectionObserver(function(es){
      es.forEach(function(e){
        if(!e.isIntersecting) return;
        ovwIO.unobserve(e.target);
        var t=e.target.closest('.ovw-tile'),s2=t&&pres.slides[+t.dataset.i];
        if(!s2||!e.target.parentNode) return;
        var paintWas=paintSlide;
        try{e.target.parentNode.replaceChild(miniDiagram(s2),e.target);}
        finally{paintSlide=paintWas;}
      });
    },{root:body,rootMargin:'300px'});
    var ph=document.createElement('span');
    ph.className='mini-diagram free mini-lazy';
    if(typeof pageBgOf==='function') ph.style.background=pageBgOf(sl);
    /* the defaults a drawing fills in, filled in now (filmLazyBox) */
    if(sl&&sl.layout==='title'){titleProps(sl,'t');titleProps(sl,'s');}
    filmPrime(sl);   /* ...and the trail a drawing leaves (filmPrime) */
    ovwIO.observe(ph);
    return ph;
  }
  function overviewKey(e){
    if(!$('#deck-overview')) return;
    if(e.key==='Escape'){
      e.preventDefault();e.stopPropagation();
      /* T482: a search still typed is cleared first, like the ribbon
         gallery's; the map closes on the next Escape */
      var fi=$('#ovw-find');
      if(fi&&document.activeElement===fi&&fi.value){
        fi.value='';fi.dispatchEvent(new Event('input',{bubbles:true}));
        fi.focus();return;
      }
      overviewClose();
      return;
    }
    if(ovwKeys) ovwKeys(e);
  }
  /* ---- T557: THE SLIDE SORTER ------------------------------------------
     The map was a way to look and to go. While editing it is PowerPoint's
     Slide Sorter as well: a click picks a slide (Ctrl adds or takes one
     out, Shift takes a run), a double-click or Enter opens it, and the
     picked slides drag as one block to anywhere in the deck -- landing in
     the section of the slide they are dropped beside, as the strip's
     drop does. Duplicate, New section and Delete act on what is picked,
     on the buttons and on Ctrl+D and Delete; Ctrl+A picks everything and
     Ctrl+Z undoes, redrawing the sorter. The picked set is held as the
     slide OBJECTS, not their numbers, so it survives every reorder. While
     presenting it stays the map: a click goes there. */
  function openOverview(){
    overviewClose();
    var sorting=(mode!=='view');
    var picked=[],anchor=null;
    if(sorting&&pres.slides[cur]){picked=[pres.slides[cur]];anchor=picked[0];}
    var ov=document.createElement('div');
    ov.className='deck-overview'+(sorting?' sorting':'');
    ov.id='deck-overview';
    ov.setAttribute('role','dialog');
    ov.setAttribute('aria-label',sorting?'Slide sorter':'Overview map');
    var head=document.createElement('div');
    head.className='ovw-head';
    var t=document.createElement('span');
    t.className='ovw-t';
    head.appendChild(t);
    var tools=null,tb={};
    if(sorting){
      tools=document.createElement('span');tools.className='ovw-tools';
      [['open','play','Open','Go to this slide (Enter, or a double-click)'],
       ['dup','copy','Duplicate','A copy of each picked slide, after it '
         +'(Ctrl+D)'],
       ['sec','plus','New section','Start a section at the first picked '
         +'slide'],
       ['del','exit','Delete','Delete the picked slides (Delete). Ctrl+Z '
         +'brings them back']].forEach(function(b){
        var x=document.createElement('button');
        x.type='button';x.className='dbtn'+(b[0]==='del'?' dbtn-warn':'');
        x.innerHTML=bic(b[1])+' '+b[2];x.title=b[3];
        x.addEventListener('click',function(e){
          e.stopPropagation();act(b[0]);});
        tools.appendChild(x);tb[b[0]]=x;
      });
      head.appendChild(tools);
    }
    var sp=document.createElement('span');
    sp.className='deck-spring';head.appendChild(sp);
    /* THE SEARCH BOX IS THE MAP'S (T30). Filtering a map you can already
       see beats a separate results list you cannot. */
    var find=document.createElement('input');
    find.className='ovw-find';find.id='ovw-find';find.type='search';
    find.placeholder='Find a slide\u2026';
    find.setAttribute('aria-label','Find a slide by its words or notes');
    head.appendChild(find);
    var cnt=document.createElement('span');
    cnt.className='ovw-fn';head.appendChild(cnt);
    var cl=document.createElement('button');
    cl.className='dbtn';cl.innerHTML=bic('exit')+' Close';
    cl.title='Esc';
    cl.addEventListener('click',overviewClose);
    head.appendChild(cl);
    ov.appendChild(head);
    var body=document.createElement('div');
    body.className='ovw-body';
    ov.appendChild(body);
    var dragging=false;
    function pickedIdx(){
      return picked.map(function(s){return pres.slides.indexOf(s);})
        .filter(function(i){return i>=0;}).sort(function(a,b){return a-b;});
    }
    function openAt(i){
      overviewClose();
      /* PRESENTING, go() -- so the transition plays, the rehearsal
         clock attributes the time and the presenter view follows.
         Setting cur by hand would skip all three (T30). */
      if(mode==='view'){go(i);return;}
      cur=i;activePane=-1;selAnnot=null;selSet=[];
      refresh();
    }
    function draw(){
      body.innerHTML='';
      if(ovwIO){ovwIO.disconnect();ovwIO=null;}
      var copyOf=filmThumbSource();
      var runs=sectionRuns();
      var n=(pres.slides||[]).length;
      t.textContent=(sorting?'Slide sorter \u2014 ':'')
        +(pres.name||'This deck')+' \u2014 '+n+' slide'+(n===1?'':'s')
        +(function(){
          var ns=runs.filter(function(r){return r.id;}).length;
          return ns?(' in '+ns+' section'+(ns===1?'':'s')):'';
        })();
      runs.forEach(function(r){
        var grp=document.createElement('div');
        grp.className='ovw-grp';
        grp.dataset.at=String(r.at);grp.dataset.n=String(r.n);
        grp.dataset.sec=r.id||'';
        var gh=document.createElement('div');
        gh.className='ovw-gh';
        gh.textContent=r.id?(r.name||'Section')
          :(runs.length>1?'(no section)':'');
        if(gh.textContent) grp.appendChild(gh);
        var tiles=document.createElement('div');
        tiles.className='ovw-tiles';
        for(var k=0;k<r.n;k++){
          (function(i){
            var sl=pres.slides[i];
            var tile=document.createElement('button');
            tile.className='ovw-tile'+(i===cur?' cur':'')
              +(sl&&sl.opt?' opt':'')
              +(sl&&sl.hide?' hid':'')
              +(slideSkipped(i)?' cut':'');
            var num=document.createElement('span');
            num.className='ovw-n';num.textContent=String(i+1);
            tile.appendChild(num);
            tile.dataset.i=String(i);
            tile.appendChild(ovwThumb(sl,i,copyOf,body));
            var lab=document.createElement('span');
            lab.className='ovw-lab';
            lab.textContent=filmText(sl)||'';
            tile.appendChild(lab);
            tile.dataset.i=String(i);
            tile.title=sorting?('Slide '+(i+1)+' \u2014 click to pick, '
                +'double-click to open, drag to move')
              :((sl&&sl.opt?'Optional \u2014 ':'')+'Go to slide '+(i+1));
            tile.addEventListener('click',function(e){
              if(!sorting){openAt(i);return;}
              if(e.shiftKey&&anchor&&pres.slides.indexOf(anchor)>=0){
                var a0=pres.slides.indexOf(anchor);
                var lo=Math.min(a0,i),hi=Math.max(a0,i);
                picked=pres.slides.slice(lo,hi+1);
              } else if(e.ctrlKey||e.metaKey){
                var at=picked.indexOf(sl);
                if(at>=0) picked.splice(at,1); else picked.push(sl);
                anchor=sl;
              } else {picked=[sl];anchor=sl;}
              paint();
            });
            if(sorting){
              tile.addEventListener('dblclick',function(){openAt(i);});
              tile.draggable=true;
              tile.addEventListener('dragstart',function(e){
                if(picked.indexOf(sl)<0){picked=[sl];anchor=sl;paint();}
                dragging=true;
                try{e.dataTransfer.setData('text/plain','slides');
                  e.dataTransfer.effectAllowed='move';}catch(err){}
              });
              tile.addEventListener('dragend',function(){
                dragging=false;clearMarks();});
            }
            tiles.appendChild(tile);
          })(r.at+k);
        }
        grp.appendChild(tiles);
        body.appendChild(grp);
      });
      paint();
      if(find.value) applyFind();
    }
    function paint(){
      $$('.ovw-tile',body).forEach(function(tl){
        var on=picked.indexOf(pres.slides[+tl.dataset.i])>=0;
        tl.classList.toggle('pick',on);
        if(sorting) tl.setAttribute('aria-pressed',on?'true':'false');
      });
      if(!sorting) return;
      var k=pickedIdx().length,many=k>1?(' '+k):'';
      tb.open.disabled=k!==1;
      tb.dup.disabled=!k;tb.sec.disabled=!k;tb.del.disabled=!k;
      tb.dup.innerHTML=bic('copy')+' Duplicate'+many;
      tb.del.innerHTML=bic('exit')+' Delete'+many;
    }
    function clearMarks(){
      $$('.ovw-tile.drop-before,.ovw-tile.drop-after',body)
        .forEach(function(x){
          x.classList.remove('drop-before');x.classList.remove('drop-after');});
    }
    /* where a drop lands: before or after the tile under the pointer, and
       in that tile's section */
    function dropAt(e){
      var tl=e.target.closest&&e.target.closest('.ovw-tile');
      if(tl&&body.contains(tl)){
        var r=tl.getBoundingClientRect(),i=+tl.dataset.i;
        var after=e.clientX>r.left+r.width/2;
        var s0=pres.slides[i];
        return {tile:tl,after:after,to:after?i+1:i,sec:(s0&&s0.sec)||''};
      }
      var g=e.target.closest&&e.target.closest('.ovw-grp');
      if(g&&body.contains(g))
        return {tile:null,to:+g.dataset.at+(+g.dataset.n),
          sec:g.dataset.sec||''};
      return null;
    }
    if(sorting){
      body.addEventListener('dragover',function(e){
        if(!dragging) return;
        e.preventDefault();
        clearMarks();
        var d=dropAt(e);
        if(d&&d.tile) d.tile.classList.add(d.after?'drop-after':'drop-before');
      });
      body.addEventListener('drop',function(e){
        if(!dragging) return;
        e.preventDefault();dragging=false;clearMarks();
        var d=dropAt(e); if(!d) return;
        moveBlock(d.to,d.sec);
      });
    }
    function moveBlock(to,sec){
      var idxs=pickedIdx(); if(!idxs.length) return;
      /* T601: a part keeps its own order and takes in no slide */
      if(typeof partGuardMove==='function'){
        for(var q=0;q<idxs.length;q++)
          if(partGuardMove(idxs[q],sec)) return;
      }
      var block=idxs.map(function(i){return pres.slides[i];});
      var curSl=pres.slides[cur];
      var before=idxs.filter(function(i){return i<to;}).length;
      idxs.slice().reverse().forEach(function(i){pres.slides.splice(i,1);});
      var at=Math.max(0,Math.min(pres.slides.length,to-before));
      Array.prototype.splice.apply(pres.slides,[at,0].concat(block));
      /* the slides join the section they landed in, as a strip drop does
         -- a section is one contiguous run, and normSections would drag
         a stray straight back */
      block.forEach(function(s2){if(sec) s2.sec=sec; else delete s2.sec;});
      var ci=pres.slides.indexOf(curSl); if(ci>=0) cur=ci;
      normSections();markDirty();refresh();draw();
      toast(block.length===1?'Slide moved':block.length+' slides moved');
    }
    function act(what){
      var idxs=pickedIdx(); if(!idxs.length&&what!=='all') return;
      if(what==='open'){openAt(idxs[0]);return;}
      if(what==='dup'){
        var copies=[];
        /* last first, so each copy lands after its own slide and the
           numbers of the ones still to copy do not move -- and ONE undo
           step for the lot */
        idxs.slice().reverse().forEach(function(i){
          var at=slideCopyAt(pres.slides[i],i);
          if(at>=0) copies.unshift(pres.slides[at]);});
        if(copies.length) cur=pres.slides.indexOf(copies[0]);
        activePane=-1;selAnnot=null;selSet=[];
        normSections();markDirty();refresh();
        picked=copies;anchor=copies[0]||null;draw();
        toast(copies.length===1?'Slide duplicated'
          :copies.length+' slides duplicated');
        return;
      }
      if(what==='sec'){
        var first=pres.slides[idxs[0]];
        newSection(idxs[0],'New section');
        var id=first&&first.sec;
        draw();
        if(id&&typeof renameSection==='function')
          renameSection(id,function(){draw();});
        return;
      }
      if(what==='del'){
        var n=idxs.length;
        /* T601: a part's slides are deleted in the part */
        if(typeof partOfSlide==='function'&&idxs.some(function(i){
            return partOfSlide(pres.slides[i]);})){
          toast(partSays(partOfSlide(pres.slides[idxs.filter(function(i){
            return partOfSlide(pres.slides[i]);})[0]])),7000);
          return;
        }
        /* one undo step for the lot */
        idxs.slice().reverse().forEach(function(i){pres.slides.splice(i,1);});
        cur=Math.max(0,Math.min(idxs[0],pres.slides.length-1));
        activePane=-1;selAnnot=null;selSet=[];
        normSections();markDirty();refresh();
        picked=pres.slides[cur]?[pres.slides[cur]]:[];
        anchor=picked[0]||null;draw();
        toast(n===1?'Slide deleted \u2014 Ctrl+Z brings it back'
          :n+' slides deleted \u2014 Ctrl+Z brings them back');
      }
    }
    ovwKeys=!sorting?null:function(e){
      if(e.target===find) return;
      var ctrl=e.ctrlKey||e.metaKey,k=e.key;
      var stop=function(){e.preventDefault();e.stopPropagation();};
      if(k==='Delete'||k==='Backspace'){stop();act('del');return;}
      if(k==='Enter'){stop();act('open');return;}
      if(ctrl&&(k==='a'||k==='A')){
        stop();picked=pres.slides.slice();anchor=picked[0]||null;paint();
        return;}
      if(ctrl&&(k==='d'||k==='D')){stop();act('dup');return;}
      if(ctrl&&(k==='z'||k==='Z'||k==='y'||k==='Y')){
        stop();
        if(k==='y'||k==='Y'||e.shiftKey) redo(); else undo();
        /* undo hands back new slide objects: the current one stays
           picked, so the keys go on working */
        picked=picked.filter(function(s2){
          return pres.slides.indexOf(s2)>=0;});
        if(!picked.length&&pres.slides[cur]){
          picked=[pres.slides[cur]];anchor=picked[0];}
        draw();return;
      }
      if(k==='ArrowRight'||k==='ArrowLeft'){
        var at=pickedIdx(),i=at.length?at[at.length-1]:cur;
        var j=Math.max(0,Math.min(pres.slides.length-1,
          i+(k==='ArrowRight'?1:-1)));
        stop();picked=[pres.slides[j]];anchor=picked[0];paint();
        var tl=body.querySelector('.ovw-tile[data-i="'+j+'"]');
        if(tl) tl.focus();
      }
    };
    /* TYPE TO NARROW. The tiles are already drawn; a hit hides the ones
       that do not match rather than rebuilding the map, so the slides
       do not jump about under the pointer as you type. */
    function applyFind(){
      var q=find.value.trim();
      if(!q){
        $$('.ovw-tile',ov).forEach(function(t){t.hidden=false;
          t.classList.remove('hit');
          var w=t.querySelector('.ovw-why'); if(w) w.remove();});
        $$('.ovw-grp',ov).forEach(function(g){g.hidden=false;});
        cnt.textContent='';
        return;
      }
      var hits={},n=0;
      slideHits(q).forEach(function(h){hits[h.i]=h;n++;});
      $$('.ovw-tile',ov).forEach(function(t){
        var i=+t.dataset.i;
        var h=hits[i];
        t.hidden=!h;
        t.classList.toggle('hit',!!h);
        var w=t.querySelector('.ovw-why');
        if(w) w.remove();
        if(h){
          var e=document.createElement('span');
          e.className='ovw-why';
          e.textContent=(h.where?(h.where+': '):'')+h.snip;
          t.appendChild(e);
        }
      });
      /* a section with nothing left in it stops taking up a heading */
      $$('.ovw-grp',ov).forEach(function(g){
        g.hidden=!$$('.ovw-tile',g).some(function(t){return !t.hidden;});
      });
      cnt.textContent=n?(n+' slide'+(n===1?'':'s')):'nothing';
    }
    find.addEventListener('input',applyFind);
    find.addEventListener('keydown',function(e){
      e.stopPropagation();
      if(e.key==='Escape'){
        if(find.value){find.value='';applyFind();e.preventDefault();}
        return;
      }
      /* Enter goes to the first one, which is what you meant */
      if(e.key==='Enter'){
        var first=$$('.ovw-tile',ov).filter(function(t){
          return !t.hidden;})[0];
        if(first){e.preventDefault();openAt(+first.dataset.i);}
      }
    });
    draw();
    document.body.appendChild(ov);
    /* the picked tile in view, so a long deck opens where you are */
    var curT=body.querySelector('.ovw-tile.cur');
    if(curT&&curT.scrollIntoView) curT.scrollIntoView({block:'center'});
    if(sorting&&curT) curT.focus();
    /* CAPTURE, so Esc closes the map before the editor's own Esc ladder
       reads it as "drop the tool" — the innermost state wins, which is
       the rule that ladder already follows */
    document.addEventListener('keydown',overviewKey,true);
  }
  /* ---- OPTIONAL SLIDES, NAMED CUTS, AND RUNNING LATE ------------------
     (TASKS T24 and T25 — one model, and T25 is three lines once T24
     exists, so they are built together.)

     THE PROBLEM: three files called talk-45.deck, talk-20.deck and
     talk-5.deck, diverging from the day they were copied.

     THE MODEL. A slide carries `opt:1` when it is optional, and a set of
     cut names in `cuts` — a slide IS IN a cut when it names it. Both
     live ON THE SLIDE, for the reason sections chose the same shape and
     recorded it: membership stored on the slide travels through every
     splice, every drag, every duplicate and every undo for free, while a
     stored list of indexes has to be repaired after each of them and
     will eventually not be.

     `pres.cuts` holds only the NAMES, exactly as `pres.sections` holds
     only section names, and for the same reason: the order and the
     membership are read back off the slide list.

     WHAT A CUT MEANS. A slide with no `cuts` is in EVERY cut — that is
     what makes the feature adoptable, because an existing deck is
     already a complete "everything" cut and turning one on excludes
     nothing until you say so. Naming cuts on a slide narrows it.

     RUNNING LATE (T25) is then not a fourth concept: it is a live
     filter that also drops anything marked optional, from wherever you
     have got to. It is deliberately NOT a cut — you do not choose it
     before the talk, you reach for it at minute 34 — and it applies
     from the CURRENT slide onward, because the ones you have already
     shown are not the problem. */
  function cutMap(){
    /* Reads must not recreate an empty map after the last version is
       deleted. newCut is the one lifecycle verb allowed to create it. */
    return (pres&&pres.cuts)||{};
  }
  function hasCut(id){
    return Object.prototype.hasOwnProperty.call(cutMap(),id);
  }
  function cutList(){
    var m=cutMap();
    return Object.keys(m).map(function(id){
      return {id:id,name:String((m[id]&&m[id].name)||id)};
    }).sort(function(a,b){return a.name.localeCompare(b.name);});
  }
  function cutId(){
    var m=cutMap(),n=1;
    while(Object.prototype.hasOwnProperty.call(m,'k'+n)) n++;
    return 'k'+n;
  }
  function cutNameTaken(name,except){
    var want=String(name||'').toLowerCase();
    return cutList().some(function(c){
      return c.id!==except&&c.name.toLowerCase()===want;});
  }
  function newCut(name){
    name=String(name||'').trim()||'Short talk';
    if(cutNameTaken(name,'')){
      toast('There is already a custom show called “'+name+'”');return '';
    }
    var id=cutId();
    if(!pres.cuts) pres.cuts={};
    pres.cuts[id]={name:name};
    markDirty();
    return id;
  }
  /* the cut currently being SHOWN, or '' for the whole deck. Session
     state, not deck state: which version you are rehearsing today is
     not a property of the document, and sending someone a deck must not
     send them your rehearsal. Same argument matchPick makes. */
  var showCut='',lateFrom=-1;
  var runFilterPres=null;
  /* A cut and Running late belong to one open deck, not to the next deck
     that happens to reuse k1. Also repair a deleted/stale active id at the
     one read boundary rather than asking every caller to remember (T50). */
  function activeCut(){
    if(runFilterPres!==pres){
      runFilterPres=pres;showCut='';lateFrom=-1;
    }
    if(showCut&&!hasCut(showCut)) showCut='';
    return showCut;
  }
  function renameCut(id){
    if(!hasCut(id)) return false;
    var d=cutMap()[id]; if(!d) return false;
    var old=d.name||id;
    /* T475: the editor's own question; the menu re-syncs itself once
       the answer lands, so this returns false to its caller */
    askText({title:'Name this custom show',value:old,ok:'Rename'},function(v){
    if(v==null) return;
    v=v.trim(); if(!v||v===old) return;
    if(cutNameTaken(v,id)){
      toast('There is already a custom show called “'+v+'”');return;
    }
    d.name=v;
    markDirty();renderFilm();presenterSync&&presenterSync();
    toast('Custom show renamed to “'+v+'”');
    cutsSync();   /* T477: the menu and the tab's strip */
    });
    return false;
  }
  function delCut(id){
    if(!hasCut(id)) return false;
    var d=cutMap()[id]; if(!d) return false;
    var name=d.name||id;
    var universal=(pres.slides||[]).filter(function(sl){
      return sl&&Array.isArray(sl.cuts)&&sl.cuts.length
        &&sl.cuts.every(function(c){return c===id;});}).length;
    /* T527: the editor's own question; like renameCut, the menu
       re-syncs itself when the answer lands, so this returns false */
    askYes({title:'Delete the custom show \u201c'+name+'\u201d?',
      what:'Slides stay in the deck. '
        +(universal?(universal+' slide'+(universal===1?'':'s')
          +' in no other custom show will be in every one again.')
          :'No slide will become universal.'),
      ok:'Delete custom show',cancel:'Keep it',danger:true},function(y){
      if(y===true) delCutNow(id);});
    return false;
  }
  function delCutNow(id){
    var d=cutMap()[id]; if(!d) return;
    var name=d.name||id;
    var wasActive=activeCut()===id;
    delete pres.cuts[id];
    (pres.slides||[]).forEach(function(sl){
      if(!sl||!Array.isArray(sl.cuts)) return;
      var keep=sl.cuts.filter(function(c){return c!==id;});
      if(keep.length) sl.cuts=keep; else delete sl.cuts;
    });
    if(!Object.keys(pres.cuts).length) delete pres.cuts;
    if(wasActive) showCut='';
    markDirty();renderFilm();presenterSync&&presenterSync();
    toast('Deleted “'+name+'” — every slide stayed'
      +(wasActive?' · showing every slide':''));
    cutsSync();   /* the menu and the tab's strip, as renameCut does */
  }
  /* a slide is in a cut when it names it — and a slide that names no
     cuts is in all of them, which is what makes an existing deck a
     complete "everything" version on the day this ships. */
  function inCut(sl,cut){
    if(!cut) return true;
    var c=sl&&sl.cuts;
    if(!c||!c.length) return true;
    return c.indexOf(cut)>=0;
  }
  /* SKIPPED, for playback only. Never for the editor: a slide you have
     cut is still a slide you are editing, and hiding it from the strip
     would be how you lose it. */
  function slideSkipped(i){
    var sl=(pres.slides||[])[i];
    if(!sl) return false;
    /* T318: an unstarred alternative is never part of the show -- the
       presenter, the arrows, the counter, the overview dimming and the
       strip's mark all read this one predicate */
    if(slideIsAlt(i)) return true;
    /* T554: a hidden slide never plays, whatever the show */
    if(sl.hide) return true;
    if(!inCut(sl,activeCut())) return true;
    if(lateFrom>=0&&i>lateFrom&&sl.opt) return true;
    return false;
  }
  /* the next slide playback should land on, in a direction. Returns -1
     when there is nothing left that way. */
  function nextShown(from,dir){
    var n=(pres.slides||[]).length;
    for(var i=from+dir;i>=0&&i<n;i+=dir)
      if(!slideSkipped(i)) return i;
    return -1;
  }
  /* One ordered answer for presenter numbering as well as playback.
     Raw deck indexes are wrong as soon as a named cut or Running late
     removes anything between two shown slides (T48). */
  function shownSlides(){
    var out=[];
    (pres.slides||[]).forEach(function(sl,i){
      if(!slideSkipped(i)) out.push(i);
    });
    return out;
  }
  function setCut(id){
    activeCut();
    if(id&&!hasCut(id)) id='';
    showCut=id||'';
    /* landing on a slide the cut excludes would be a talk that starts
       on a slide it is not showing */
    if(mode==='view'&&slideSkipped(cur)){
      var to=nextShown(cur,1);
      if(to<0) to=nextShown(cur,-1);
      if(to>=0) go(to);
    }
    presenterSync&&presenterSync();
    renderFilm();
    toast(id?('Showing the custom show \u201c'+(cutMap()[id]||{}).name
      +'\u201d'):'Showing every slide');
  }
  /* T25. One control, mid-talk, that drops the rest of the optional
     slides. From HERE onward: what you have already shown is not the
     problem, and un-showing it is not on offer. */
  function syncLateButton(){
    var b=$('#deck-late'); if(!b) return;
    var on=lateFrom>=0;
    b.hidden=(mode!=='view');
    b.setAttribute('aria-pressed',on?'true':'false');
    b.innerHTML=bic('flag')+(on?' Running late: on':' Running late');
    b.title=on?'Show the remaining optional slides again (L)'
      :'Skip the remaining optional slides from here (L)';
  }
  function initPresenterControls(){
    var b=$('#deck-late');
    if(b) b.addEventListener('click',function(){
      runLate(lateFrom<0);
    });
    syncLateButton();
  }
  function runLate(on){
    var cut=activeCut();
    lateFrom=on?cur:-1;
    syncLateButton();
    renderFilm();
    presenterSync&&presenterSync();
    if(!on){toast('Back to the full run');return 0;}
    var n=0;
    (pres.slides||[]).forEach(function(sl,i){
      if(i>cur&&sl&&sl.opt&&inCut(sl,cut)) n++;});
    toast(n?(n+' optional slide'+(n===1?'':'s')
      +' will be skipped from here'):'No optional slides left to skip');
    return n;
  }
  function toggleOptional(i){
    var sl=(pres.slides||[])[i]; if(!sl) return;
    if(sl.opt) delete sl.opt; else sl.opt=1;
    markDirty();renderFilm();
    toast(sl.opt?'Optional \u2014 "Running late" will skip it'
      :'No longer optional');
  }
  /* T554: HIDE SLIDE. PowerPoint's: the slide stays in the deck, in its
     place and with its number, and the show goes straight past it. Not
     Optional, which plays unless you are running late. */
  function toggleSlideHidden(i){
    var sl=(pres.slides||[])[i]; if(!sl) return;
    if(sl.hide) delete sl.hide; else sl.hide=1;
    markDirty();renderFilm();
    if(typeof syncHomeDoors==='function') syncHomeDoors();
    toast(sl.hide?'Hidden — the show goes straight past it, and it '
      +'stays out of a PDF':'Shown again');
  }
  function toggleSlideCut(i,id){
    var sl=(pres.slides||[])[i]; if(!sl||!id||!hasCut(id)) return;
    var c=(sl.cuts||[]).slice();
    var at=c.indexOf(id);
    if(at>=0) c.splice(at,1); else c.push(id);
    /* an empty list means "every cut", so it is dropped rather than
       stored — the same empty-is-absent rule sections and styles use */
    if(c.length) sl.cuts=c; else delete sl.cuts;
    markDirty();renderFilm();
  }
  function go(n){
    var prev=cur;
    /* a pending self-advance belongs to the slide that armed it (T169) */
    autoStop();
    cur=Math.max(0,Math.min(pres.slides.length-1,n));
    if(cur===prev) return;   /* clamped no-op: keep build + selection state */
    /* stepping back into a slide shows it fully built; forward starts fresh */
    revealCount=(mode==='view'&&cur<prev)?buildsForSlide(cur):0;
    /* T491: a Zoom in on the last click stayed on the stage while the
       next slide was built, and .deck-stage's transform transition
       then played the clear -- the next slide arrived zoomed 3x and
       shrank back (third review pass). Off, without a transition,
       before the rebuild. */
    if(stage&&stage.style.transform){
      stage.style.transition='none';stage.style.transform='';
      void stage.offsetWidth;stage.style.transition='';
    }
    /* arm on ARRIVAL too: a slide whose first build is delayed should
       start counting the moment you land on it, not on a click that
       would defeat the point (T169). Deferred so it arms against the
       slide that is actually on screen. */
    setTimeout(autoArm,0);
    selAnnot=null;selSet=[];   /* never carry a selection across slides */
    mediaForget();             /* the next slide's clips start afresh (T321) */
    /* MEASURE BEFORE THE REBUILD. renderSlide empties the stage, so the
       outgoing geometry has to be taken here or it is gone (T27). */
    captureFlip(prev);
    /* ...and the time so far belongs to the slide you are LEAVING, which
       is why this is here rather than after the render (T29) */
    rehSlideChanged();
    refreshNav();
    playFlip();
    /* T564: a recording run starts the next slide's take; otherwise
       the slide that arrived speaks, if it has narration */
    if(typeof narrSlideChanged==='function') narrSlideChanged();
    presenterSync();
    /* T289: the transition buttons describe the SLIDE, so they follow
       it. animRibbonSync -- where the rest of the Animation tab syncs
       from -- is driven by the SELECTION, and go() clears the selection
       to null without going through it; driven, the ribbon kept showing
       the previous slide's answer. */
    if(typeof transRibbonSync==='function') transRibbonSync();
    routeSync();   /* a talk's address is written when its clicks pause */
  }
  /* advance: reveal the next build, else move to the next slide (no-op at the
     very end, so the final slide never collapses back to its pre-build state) */
  /* ---- THE TALK PANEL (T88) ---------------------------------------
     Present mode has no ribbon and no rail on purpose, so the two things
     you might want to change mid-talk had nowhere to live. One button in
     the corner beside the slide count, one small panel, and both
     settings also on a key -- because reaching for a panel in front of a
     room is exactly what you do not want to do. */
  function syncTalk(){
    var p=$('#talkpane'); if(!p) return;
    var b=$('#talk-builds');
    if(b){
      b.setAttribute('aria-pressed',talkNoBuilds?'true':'false');
      b.title=talkNoBuilds
        ? 'Animations are off: every slide arrives complete and slides '
          +'change with a plain cut. Press again to play them (A)'
        : 'Skip the animations: builds and slide transitions both, so '
          +'one click is one slide and nothing moves. Flip books still '
          +'step (A)';
      var lab=b.querySelector('.tk-state');
      if(lab) lab.textContent=talkNoBuilds?'skipped':'playing';
    }
    /* the reset button IS the readout: the current size, click to put
       it back. It used to say 100% forever while the real number sat
       in a hidden span (T126). */
    var r=$('#talk-reset');
    if(r){
      r.textContent=Math.round(talkText*100)+'%';
      r.disabled=(talkText===1);
    }
    [['h','head'],['b','body'],['c','cap']].forEach(function(t){
      var v=$('#talk-'+t[0]+'-val');
      if(v){
        v.textContent=Math.round(talkType[t[1]]*100)+'%';
        v.disabled=(talkType[t[1]]===1);
      }
    });
  }
  function talkBuilds(on){
    talkNoBuilds=on?1:0;
    /* a slide part-way through its builds must not be left showing
       fewer things than it now claims to have */
    if(talkNoBuilds) revealCount=0;
    syncTalk();renderSlide();presenterSync();
    toast(talkNoBuilds
      ? 'Animations skipped \u2014 slides arrive complete, and change '
        +'with a plain cut'
      : 'Animations are playing again');
  }
  /* bucket===undefined scales everything; a bucket name scales that
     kind of text on top of the global size. 0 always means "put it
     back", and the GLOBAL reset puts the types back too, because "the
     size the deck was made at" is one state, not four (T126). */
  function talkZoom(mult,bucket){
    if(bucket){
      var w=talkType[bucket];
      talkType[bucket]=Math.max(0.6,Math.min(2.2,
        mult===0?1:Math.round(w*mult*100)/100));
      if(talkType[bucket]===w) return;
      syncTalk();renderSlide();
      return;
    }
    var was=talkText;
    talkText=Math.max(0.6,Math.min(2.2,
      mult===0?1:Math.round(talkText*mult*100)/100));
    if(mult===0) talkType={head:1,body:1,cap:1};
    if(talkText===was&&mult!==0) return;
    syncTalk();renderSlide();
  }
  (function(){
    var btn=$('#talkbtn'),pane=$('#talkpane');
    if(!btn||!pane) return;
    function open(on){
      pane.hidden=!on;
      btn.setAttribute('aria-expanded',on?'true':'false');
      if(on) syncTalk();
    }
    btn.addEventListener('click',function(e){
      e.stopPropagation();open(pane.hidden);});
    var cl=$('#talkpane-close');
    if(cl) cl.addEventListener('click',function(){open(false);});
    var b=$('#talk-builds');
    if(b) b.addEventListener('click',function(){
      talkBuilds(!talkNoBuilds);});
    var sm=$('#talk-smaller');
    if(sm) sm.addEventListener('click',function(){talkZoom(1/1.12);});
    var bg=$('#talk-bigger');
    if(bg) bg.addEventListener('click',function(){talkZoom(1.12);});
    var rs=$('#talk-reset');
    if(rs) rs.addEventListener('click',function(){talkZoom(0);});
    [['h','head'],['b','body'],['c','cap']].forEach(function(t){
      var mi=$('#talk-'+t[0]+'-minus'),pl=$('#talk-'+t[0]+'-plus'),
        vl=$('#talk-'+t[0]+'-val');
      if(mi) mi.addEventListener('click',function(){
        talkZoom(1/1.12,t[1]);});
      if(pl) pl.addEventListener('click',function(){
        talkZoom(1.12,t[1]);});
      if(vl) vl.addEventListener('click',function(){talkZoom(0,t[1]);});
    });
    window.SemDeckTalk={open:open,builds:talkBuilds,zoom:talkZoom,
      sync:syncTalk};
  })();
  /* THE ONE TIMER. A stop with `after` runs on a clock instead of a
     click (T169), so exactly one may be pending at a time and ANY other
     movement cancels it -- a presenter who reaches for the space bar or
     jumps a slide has taken control back, and a talk that then advanced
     twice would be the worst possible bug in front of an audience. */
  var autoT=null;
  function autoStop(){
    if(autoT){clearTimeout(autoT);autoT=null;}
  }
  function autoArm(){
    autoStop();
    if(mode!=='view') return;
    var s=pres.slides[cur]; if(!s) return;
    if(revealCount>=slideStops(s)) return;
    var secs=(typeof autoAfter==='function')?autoAfter(s,revealCount):0;
    if(!secs) return;
    autoT=setTimeout(function(){
      autoT=null;
      if(mode!=='view') return;
      advance();
    },secs*1000);
  }
  function advance(){
    autoStop();
    var s=pres.slides[cur];
    /* a flip book's frames are stops in this same sequence, so the space
       bar walks the figure through its steps exactly as it walks a build
       — one gesture for the whole talk (2026-08-22) */
    if(mode==='view'&&s&&revealCount<slideStops(s)){
      revealCount++;renderSlide(true);presenterSync();autoArm();
    } else {
      /* THE FILTER LIVES HERE, in the two verbs the whole talk runs on,
         rather than in twenty callers. A cut or a running-late skip is
         a fact about what to show NEXT, which is exactly what advance
         asks (T24/T25). */
      var nx=nextShown(cur,1);
      if(nx>=0) go(nx);
    }
  }
  function backStep(){
    autoStop();
    if(mode==='view'&&revealCount>0){revealCount--;renderSlide(true);
      presenterSync();}
    else {
      var pv=nextShown(cur,-1);
      /* At the first slide in a cut, Back is a no-op. Raw cur-1 can be
         a slide this version explicitly leaves out (T50). */
      go(pv>=0?pv:cur);
    }
  }

  /* ---------- create mode: sidebar UI ---------- */
  /* ---------- presentations rail (vertical, left edge) ----------
     One item is active at any time: the "Notebooks" button (builder
     closed) or a presentation (builder open editing it). */
  var presstrip=document.getElementById('presstrip');
  var FOLDERSKEY='sempresfolders:'+SCOPE;
  /* folders exist on their own (created empty, dragged into). They are
     shown in the library dialog since T394; the rail lists only what is
     open. */
  function explicitFolders(){
    try{
      var l=JSON.parse(lsGet(FOLDERSKEY)||'[]');
      return Array.isArray(l)?l:[];
    }catch(e){return [];}
  }
  function saveFolders(list){lsSet(FOLDERSKEY,JSON.stringify(list));}
  /* move ANY presentation (current, saved, draft, embedded) */
  function setPresFolder(nm,folder){
    var f=(folder||'').trim();
    function apply(p){
      if(f) p.folder=f; else delete p.folder;
    }
    if(nm===pres.name){apply(pres);markDirty();renderPresRow();}
    var hit=false;
    if(nm!==pres.name){
      projectPres.forEach(function(p){
        if(p.name===nm){apply(p);hit=true;}});
      nbPres.forEach(function(p){
        if(p.name===nm){apply(p);hit=true;}});
      var raw=draftGet(nm);   /* T429: the draft store */
      if(raw){
        try{
          var d=JSON.parse(raw);apply(d);
          draftSet(nm,JSON.stringify(d));hit=true;
        }catch(e){}
      }
      if(hit&&APP.mode==='app') scheduleAutosave();
    }
    renderPresTabs();
    renderPresentationHub();
  }
  function newFolder(wanted){
    var supplied=typeof wanted==='string'&&wanted.trim();
    /* no name yet: ask for one where folders are shown */
    if(!supplied){
      if(window.SemApp&&window.SemApp.deckNewFolder)
        window.SemApp.deckNewFolder();
      return null;
    }
    var list=explicitFolders();
    var name=wanted.trim();
    var taken=list.indexOf(name)>=0
      ||allSaved().some(function(p){return p.folder===name;});
    if(taken){
      toast('There is already a folder called “'+name+'”');
      return null;
    }
    list.push(name);saveFolders(list);
    renderPresentationHub();
    return name;
  }
  function renameFolder(oldName,newName){
    newName=(newName||'').trim();
    if(!newName||newName===oldName) return;
    var list=explicitFolders().map(function(x){
      return x===oldName?newName:x;});
    if(list.indexOf(newName)<0) list.push(newName);
    saveFolders(list.filter(function(x,i){
      return list.indexOf(x)===i;}));
    allSaved().concat([pres]).forEach(function(p){
      if(p.folder===oldName) setPresFolder(p.name,newName);
    });
    draftNames().forEach(function(nm){
      var d=loadDraft(nm);
      if(d&&d.folder===oldName) setPresFolder(nm,newName);
    });
    renderPresentationHub();
  }
  function deleteFolder(f){
    saveFolders(explicitFolders().filter(function(x){return x!==f;}));
    allSaved().concat([pres]).forEach(function(p){
      if(p.folder===f) setPresFolder(p.name,'');
    });
    draftNames().forEach(function(nm){
      var d=loadDraft(nm);
      if(d&&d.folder===f) setPresFolder(nm,'');
    });
    renderPresentationHub();
  }
  /* ---- T394: THE RAIL IS A TAB LIST, NOT THE LIBRARY -------------------
     It used to be built from allSaved() + draftNames(): every project
     deck, every draft and every deck embedded in an open notebook, grouped
     into folders with drag-and-drop filing -- which is a library, and it
     sat under a label that made it read as "your presentations" while
     Home's Recent column beside it showed one row. Now it lists what is
     OPEN (openPresentationNames, 10-decks.js), the way the notebook strip
     above it lists open notebooks, and two doors under it lead to Recents
     and to the whole library. The library dialog took the folders and the
     filing with it (renderPresentationHub). */
  function presentationTabNames(editing){
    var names=openPresentationNames();
    /* The deck on screen is open whatever the list says: a brand-new,
       never-saved presentation is not yet anywhere the list can find it. */
    if(editing&&pres&&pres.name&&names.indexOf(pres.name)<0)
      names.push(pres.name);
    return names;
  }
  function presItem(nm,savedNames,editing,top){
    var p=presFacts(nm)||{name:nm};   /* its kind and page, not the deck */
    var isCur=nm===pres.name;
    var t=document.createElement(top?'div':'button');
    if(!top) t.type='button';
    /* The same item has a rail and a regular-tab skin. Both call the same
       switch and close paths, so opening a deck cannot drift by location. */
    /* T598: the dot is "changes not where this deck lives yet", judged
       by the deck's own home -- it read the destination of whichever
       deck was on screen, so a deck kept here wore it beside one kept in
       a file, and a file's deck wore it always */
    var sum=presentationSummary(nm);
    t.className=(top?'tab top-pres-tab':'pr-item ptab')
      +(isCur&&editing?' current editing':'')
      +((sum&&sum.draft)?' draftonly':'');
    t.dataset.pres=nm;
    var isPoster=/^a\d/.test(String(p.page||''));
    var isView=isViewPres(p);
    /* A custom view lights up while ITS styling bar is open, not while
       the slide stage is (it never opens the slide stage). */
    var vwOpen=isView&&isCur
      &&document.body.classList.contains('styling');
    /* T606: a collection while its feed is the tab on screen */
    var isCol=isColPres(p);
    if(isCol&&(window.SemApp||{}).active===colKey(nm)
       &&!document.body.classList.contains('welcoming')) vwOpen=true;
    if(vwOpen) t.className+=' current editing';
    var kindWord=isCol?'collection':isView?'custom view'
      :isPoster?'poster':'presentation';
    var selected=isCur&&(editing||vwOpen);
    /* T602: on the editor's title row the tab IS the name, so it is also
       where the rename is -- the centred name steps aside while the tabs
       are there */
    var title=selected
      ?('Editing "'+nm+'"'+(top&&!isView?' — double-click to rename'
        :' — Home returns to the start screen'))
      :('Open '+kindWord+' "'+nm+'"'
        +(isCol?' — cells from your notebooks, with your notes'
          :isView?' — restyles the notebook itself':' in the builder'));
    var action=top?document.createElement('button'):t;
    if(top){
      /* A regular tab has its own focusable button; the close button is
         its sibling, never a button nested inside a tab. */
      action.type='button';action.className='top-pres-main';
      action.setAttribute('role','tab');
      action.setAttribute('aria-selected',selected?'true':'false');
      action.dataset.pres=nm;action.title=title;
    } else {
      t.setAttribute('role','tab');t.title=title;
    }
    var ic=document.createElement('span');
    ic.className=top?'tab-ico':'pr-ico';
    ic.innerHTML=bic(isCol?'newcol':isView?'newview'
      :isPoster?'newposter':'newdeck');
    action.appendChild(ic);
    var lbl=document.createElement('span');lbl.className=top?'tab-t':'pr-t';
    lbl.textContent=nm||'(unnamed)';
    action.appendChild(lbl);
    /* The × closes only this open tab; deletion remains in File where its
       confirmation can guard saved work. */
    var del=document.createElement('button');
    del.type='button';
    del.className=top?'tab-b':'pr-del';
    del.title='Close "'+nm+'" (it stays saved)';
    del.setAttribute('aria-label','Close "'+nm+'"');
    del.innerHTML=bic('exit')||'&#10005;';
    del.addEventListener('click',function(e){
      e.stopPropagation();e.preventDefault();
      var go=(isCur&&typeof closeGuard==='function')
        ?closeGuard(nm):Promise.resolve(true);
      go.then(function(ok){
        if(!ok) return;
        if(isCur&&!deckEl.hidden) closeDeck();
        if(vwOpen) closeCustomView();
        closeOpenPresentation(nm);
        renderPresTabs();
        if(typeof renderDeckPresentationDrawer==='function')
          renderDeckPresentationDrawer();
      });
    });
    if(top) t.appendChild(action);
    t.appendChild(del);
    action.addEventListener('click',function(){
      if(isCur&&!deckEl.hidden) return;
      if(vwOpen) return;              /* already the open custom view */
      choosePresentation(nm);
    });
    /* T602: the tab you are editing renames the deck, the way a
       double-click on a file's name does everywhere else */
    if(top&&!isView&&!isCol) action.addEventListener('dblclick',function(e){
      if(!(isCur&&!deckEl.hidden&&mode==='edit')) return;
      e.preventDefault();startQatRename();
    });
    return t;
  }
  function renderTopPresTabs(){
    var top=$('#top-tabstrip'); if(!top) return;
    presTabsSaveKey=null;   /* only a build of both lists sets it */
    /* SWITCHING NOTEBOOKS DOES NOT REDRAW THE DECKS' TABS (2026-10-09,
       speed: reader #10). renderTabs asks for these on every notebook
       tab switch; when what they are drawn from (presTabsInputs) and the
       tabs themselves are as the last build left them, they stay. */
    if(presTabsTopSame(top)){
      if(APP.refreshOpenTabsRow) APP.refreshOpenTabsRow();
      return;
    }
    $$('.top-pres-tab',top).forEach(function(t){t.remove();});
    var savedNames=savedNameList();   /* the names, nothing copied */
    var editing=!deckEl.hidden;
    presentationTabNames(editing).forEach(function(nm){
      top.appendChild(presItem(nm,savedNames,editing,true));});
    presTabsTop=$$('.top-pres-tab',top);presTabsTopKey=presTabsInputs();
    if(APP.refreshOpenTabsRow) APP.refreshOpenTabsRow();
  }
  function renderPresTabs(){
    if(!presstrip) return;
    /* The rail's filter is re-applied at the end: the strip is rebuilt
       from scratch here, so a deck created while filtering stays filtered. */
    presstrip.innerHTML='';
    var savedNames=savedNameList();   /* the names, nothing copied */
    var editing=!deckEl.hidden;
    var names=presentationTabNames(editing);
    names.forEach(function(nm){
      presstrip.appendChild(presItem(nm,savedNames,editing,false));});
    if(!names.length){
      var none=document.createElement('div');
      none.className='pr-none';
      none.textContent='nothing open';
      presstrip.appendChild(none);
    }
    presTabsSide=[].slice.call(presstrip.childNodes);
    presTabsSideKey=presTabsInputs();
    renderTopPresTabs();
    presTabsSaveKey=presTabsInputs(true);
    /* T606: a collection's feed closes with its tab */
    if(typeof colSync==='function') colSync();
    /* ...and re-applied, now the rail rows are back (T75). */
    var A2=window.SemApp;
    if(A2&&typeof A2.railFilter==='function') A2.railFilter();
  }
  /* ---- A SLIDE CHANGE DOES NOT REBUILD THE TABS (2026-10-08) ---------
     (user: "the slide changing and the clicking on things is super duper
     slow".) renderCreate runs on every slide change, and renderPresRow
     with it, and that rebuilt the side list and the top tabs from
     scratch: every open deck's draft parsed several times over, the
     notebook decks deep-copied, and a forced layout in keepTabInView --
     5-9ms a change here with one to four decks open, several times that
     on a laptop. Not one tab says anything about the slide. So THAT call
     (renderPresRow(true), from renderCreate) first compares what the
     tabs are built FROM -- the stores themselves, read raw and compared
     as they are, a draft or a record parsed only once it has changed --
     with what each list's last build saw, and the built nodes with where
     it left them, and rebuilds only when something differs. Every other
     caller still rebuilds outright.
     Everything presItem and presentationTabNames read is in the key:
     the deck on screen (and its page and kind), whether the editor is
     up, the open list, each open deck's draft and file, the saved decks'
     names, homes and kinds, the deck records, the default home, and
     what a custom view or collection lights its tab by. */
  var presTabsSideKey=null,presTabsTopKey=null,presTabsSide=[],presTabsTop=[];
  /* the deck on screen's draft is rewritten after every edit, and its
     tab only asks whether there is one that loads -- asked once per
     write, not once per change */
  function presTabsDraftOk(name){
    return draftOk(name);   /* 10-decks.js, memoised the same way */
  }
  /* ...and the deck records are rewritten with an `edited` time on every
     draft write; a tab reads only a record's file and home (deckWhere) */
  var presTabsMeta={raw:null,all:{}};
  /* `afterSave` leaves out the two things a finished project save
     changes without changing what a tab draws from them: which list
     object projectPres is, and whether the deck on screen still has a
     draft (that one is its tab's mark, which presTabsAfterSave sets) */
  function presTabsInputs(afterSave){
    var A=window.SemApp||{},cl=document.body.classList;
    var on=pres&&pres.name,metaRaw=lsGet(DECK_META_KEY);
    if(presTabsMeta.raw!==metaRaw)
      presTabsMeta={raw:metaRaw,all:deckMetaAll()};
    var k=[pres,on,pres&&pres.page,pres&&pres.kind,deckEl.hidden,
      ssGet(OPEN_PRES_KEY),cl.contains('styling'),cl.contains('welcoming'),
      /* the tab on screen matters to these tabs only when it is a
         collection's (presItem lights that one): a notebook switch
         changes nothing here */
      presTabsColActive(A.active),(A.cols||[]).join('\n'),
      (typeof defaultSaveTarget==='function')?defaultSaveTarget():'',
      afterSave?0:projectPres,nbPres,projectPres.concat(nbPres).map(function(p){
        return [p.name,p.origin||'',p.page||'',p.kind||''].join('\u0001');
      }).join('\u0002')];
    rawOpenNames().concat(on?[on]:[]).forEach(function(n){
      var h=(typeof fileHandles!=='undefined'&&fileHandles)
        ?fileHandles[n]:null;
      var m=presTabsMeta.all[n]||{};
      k.push(n,n===on?(afterSave?0:presTabsDraftOk(n)):draftGet(n),h,
        h&&h.name,m.file,m.home);
    });
    return k;
  }
  /* ---- A FINISHED SAVE MOVES ONE MARK (2026-10-09) ---------------------
     Every autosave, idle consolidation and Save ended in a full rebuild
     of the side list and the top tabs plus a forced layout to keep the
     tab in view -- 16-49 ms at 4x, every 15 s while editing. Routing it
     through the slide-change gate did not help: the draft mark is in that
     key, and a save is exactly what changes it. A save changes nothing
     else a tab draws, so when everything else is as the last build left
     it, the deck's mark is set in place and the tab kept in view at the
     next frame. Anything else -- a rename, another home, a tab holding
     the keyboard -- is the full rebuild it always was. */
  var presTabsSaveKey=null;
  function presTabsAfterSave(){
    var top=$('#top-tabstrip');
    var ae=document.activeElement;
    if(!presstrip||!top||!presTabsSaveKey
       ||(ae&&ae.closest&&ae.closest('.top-pres-tab,#presstrip'))
       ||!presTabsKeyIs(presTabsSaveKey,presTabsInputs(true))
       ||!presTabsKeyIs(presTabsSide,[].slice.call(presstrip.childNodes))
       ||!presTabsTop.every(function(t){return t.parentNode===top;})
       ||$$('.top-pres-tab',top).length!==presTabsTop.length){
      renderPresTabs();return;
    }
    var on=pres&&pres.name;
    if(on){
      var sum=presentationSummary(on),d=!!(sum&&sum.draft);
      presTabsSide.concat(presTabsTop).forEach(function(t){
        if(t.dataset&&t.dataset.pres===on) t.classList.toggle('draftonly',d);
      });
    }
    presTabsSideKey=presTabsTopKey=presTabsInputs();
    presTabsKeepInView();
  }
  function presTabsColActive(active){
    var pfx=(typeof colKey==='function')?colKey(''):'col::';
    return (active&&String(active).indexOf(pfx)===0)?active:'';
  }
  function presTabsKeyIs(a,b){
    if(!a||a.length!==b.length) return false;
    for(var i=0;i<a.length;i++) if(a[i]!==b[i]) return false;
    return true;
  }
  function presTabsTopSame(top){
    var ae=document.activeElement;
    if(ae&&ae.closest&&ae.closest('.top-pres-tab')) return false;
    if(!presTabsKeyIs(presTabsTopKey,presTabsInputs())) return false;
    return presTabsTop.every(function(t){return t.parentNode===top;})
      &&$$('.top-pres-tab',top).length===presTabsTop.length;
  }
  function presTabsSame(){
    var top=$('#top-tabstrip');
    if(!presstrip||!top) return false;
    /* a deck tab holding the keyboard is rebuilt as it always was, which
       hands the keyboard back to the slide (Tab, Enter work there) */
    var ae=document.activeElement;
    if(ae&&ae.closest&&ae.closest('.top-pres-tab,#presstrip')) return false;
    var k=presTabsInputs();
    if(!presTabsKeyIs(presTabsSideKey,k)||!presTabsKeyIs(presTabsTopKey,k))
      return false;
    if(!presTabsKeyIs(presTabsSide,[].slice.call(presstrip.childNodes)))
      return false;
    return presTabsTop.every(function(t){return t.parentNode===top;})
      &&$$('.top-pres-tab',top).length===presTabsTop.length;
  }
  /* the rebuild kept the tab on screen in view (keepTabInView); so does
     a skipped one, measured with the frame instead of forcing a layout
     in the middle of the change */
  var presTabsViewFrame=0;
  function presTabsKeepInView(){
    if(presTabsViewFrame||!APP.keepTabInView) return;
    presTabsViewFrame=requestAnimationFrame(function(){
      presTabsViewFrame=0;APP.keepTabInView();});
  }
  /* the rail's Folder row opens the library's folder form: a folder is
     made where folders are shown */
  var newFoldBtn=document.getElementById('pr-newfold');
  if(newFoldBtn) newFoldBtn.addEventListener('click',function(){
    if(window.SemApp&&window.SemApp.deckNewFolder)
      window.SemApp.deckNewFolder();
  });

  /* ---- PRESENTATION LIBRARY + PRESENTING DRAWER ----------------------
     The side rail is behind the full-screen deck on purpose: a visible
     but inert rail traps focus and cannot be clicked.  The deck therefore
     owns a small drawer for the presentations open in THIS session, and
     both it and Home share a complete library dialog for recent work,
     folders, new decks and files. */
  function presentationKind(p){
    return p.col?'collection':p.view?'custom view'
      :p.poster?'poster':'presentation';
  }
  function presentationIcon(p){
    return bic(p.col?'newcol':p.view?'newview'
      :p.poster?'newposter':'newdeck');
  }
  /* ---- T599: SEE A PRESENTATION BEFORE OPENING IT --------------------
     (2026-09-30, user: "would be cool when opening files if there was a
     way to preview files. like I have been trying to find the one correct
     file, but I had to keep opening heaps. Like would be cool if when
     hovering or something the little thumbnails that you have during a
     presentation could appear and you could scroll through to see if it
     is the right presentation.")
     The strip's own thumbnails (miniDiagram), of a deck that is not the
     one on screen. The renderer reads `pres` for the palette, the page
     and the masters, so for one synchronous paint `pres` IS that deck,
     and everything the paint touches is put back in a finally. Nothing
     is written: the deck is the library's parsed copy, cached while the
     dialog is open, and no slide is selected, dirtied or staged. The same
     paint serves Home's recent rows (app.js, APP.deckPreview). */
  var PV_LIMIT=60,pvDecks={},pvText={};
  function pvDeck(name){
    if(pres&&pres.name===name) return pres;
    if(!pvDecks.hasOwnProperty(name))
      pvDecks[name]=presentationByName(name)||null;
    return pvDecks[name];
  }
  function pvForget(){pvDecks={};pvText={};}
  /* every word one slide shows, lower-cased, for Find */
  function pvSlideWords(s){
    var bits=[s.title||'',s.sub||'',s.label||'',s.notes||''];
    (s.annots||[]).forEach(function(a){
      if(!a||a.ph) return;
      if(a.k==='text') bits.push(a.text||'');
      else if(a.k==='table'){
        try{tableRows(a).forEach(function(r){bits.push(r.join(' '));});}
        catch(e){}
      }
    });
    return bits.join(' ').toLowerCase();
  }
  function pvWords(name){
    if(!pvText.hasOwnProperty(name)){
      var d=pvDeck(name);
      pvText[name]=((d&&d.slides)||[]).map(pvSlideWords);
    }
    return pvText[name];
  }
  /* the slides (by index) that hold every word of the query */
  function pvMatchWords(words,q){
    var terms=String(q||'').toLowerCase().split(/\s+/).filter(Boolean);
    if(!terms.length) return [];
    var out=[];
    (words||[]).forEach(function(w,i){
      if(terms.every(function(t){return w.indexOf(t)>=0;})) out.push(i);
    });
    return out;
  }
  function pvMatches(name,q){return pvMatchWords(pvWords(name),q);}
  /* paint `name`'s slides into host. opts.w: thumbnail width; opts.q:
     a query whose slides are lit; opts.open: a button that opens it */
  function renderDeckPreview(host,name,opts){
    opts=opts||{};
    host.innerHTML='';
    var d=pvDeck(name);
    function note(t){
      var e=document.createElement('div');e.className='pv-note';
      e.textContent=t;host.appendChild(e);
    }
    if(opts.deck!==undefined) d=opts.deck;   /* a file's, not the library's */
    if(!d){note('Nothing to show for \u201c'+name+'\u201d.');return 0;}
    var head=document.createElement('div');head.className='pv-head';
    var nm=document.createElement('div');nm.className='pv-name';
    nm.textContent=name;
    var sub=document.createElement('div');sub.className='pv-sub';
    sub.textContent=(opts.sub!=null)?opts.sub
      :deckRowWords(presentationSummary(name));
    var tx=document.createElement('div');tx.className='pv-txt';
    tx.appendChild(nm);tx.appendChild(sub);head.appendChild(tx);
    if(opts.open){
      var ob=document.createElement('button');
      ob.type='button';ob.className='dbtn primary pv-open';
      ob.innerHTML=bic('open')+' Open';
      ob.title='Open \u201c'+name+'\u201d';
      ob.addEventListener('click',function(e){
        e.stopPropagation();opts.open(name);});
      head.appendChild(ob);
    }
    host.appendChild(head);
    if(isViewPres(d)){
      note('A custom view restyles its notebook \u2014 it has no slides.');
      return 0;
    }
    if(isColPres(d)){
      var ni=(d.items||[]).length;
      note(ni?('A collection of '+ni+' item'+(ni===1?'':'s')
        +' \u2014 '+(d.items||[]).slice(0,6).map(function(x){
          return colTitleOf(x,true);}).join(' \u00b7 ')
        +(ni>6?' \u2026':'')):'An empty collection.');
      return 0;
    }
    var slides=Array.isArray(d.slides)?d.slides:[];
    if(!slides.length){note('No slides yet.');return 0;}
    var hits=!opts.q?[]:(opts.deck!==undefined)
      ?pvMatchWords((d.slides||[]).map(pvSlideWords),opts.q)
      :pvMatches(name,opts.q);
    var list=document.createElement('div');list.className='pv-list';
    host.appendChild(list);
    var W=opts.w||164,n=0,first=null;
    var keep={p:pres,paint:paintSlide,h:miniHNow};
    /* THE SLIDES ON SCREEN FIRST (2026-10-09, speed). The library drew
       all sixty of a deck's thumbnails the moment a row was pointed at
       or the dialog opened -- 160 ms at 4x, again for every row the
       pointer crossed -- for a column that shows about six. The first
       PV_EAGER and every slide the query lit are drawn now; the rest
       are boxes of the same size, each drawn as it scrolls near view
       (pvLazyWatch). Their numbers and headings are there from the start. */
    if(host._pvIO){host._pvIO.disconnect();host._pvIO=null;}
    var lazy=[],H=0;
    try{
      pres=d;
      var pg=pageOf();
      H=Math.max(24,Math.round(W*pg.mm[1]/pg.mm[0]));
      miniHNow=H;
      /* the deck's own ink for text with no colour of its own: the CSS
         defaults read --tk-* and .page-light, which the stage carries
         for the deck ON screen, not this one */
      applyTokens(list);
      list.classList.toggle('page-light',pageIsLight(tokVal('@page')));
      slides.forEach(function(s,i){
        if(i>=PV_LIMIT) return;
        var fig=document.createElement('figure');fig.className='pv-slide';
        var m;
        if(i>=PV_EAGER&&hits.indexOf(i)<0&&window.IntersectionObserver){
          m=document.createElement('span');
          m.className='mini-diagram free pv-lazy';
          lazy.push({ph:m,s:s});
        } else
        try{m=miniDiagram(s);}
        catch(err){m=document.createElement('span');
          m.className='mini-diagram free';}
        m.style.width=W+'px';m.style.height=H+'px';
        fig.appendChild(m);
        var cap=document.createElement('figcaption');
        var t='';
        try{t=slideHeading(s)||slideTitle(s)||'';}catch(err){t='';}
        var num=document.createElement('b');num.textContent=String(i+1);
        cap.appendChild(num);
        cap.appendChild(document.createTextNode(' '+t));
        cap.title=t;
        fig.appendChild(cap);
        if(hits.indexOf(i)>=0){
          fig.classList.add('pv-hit');
          if(!first) first=fig;
        }
        list.appendChild(fig);n++;
      });
    } finally {
      pres=keep.p;paintSlide=keep.paint;miniHNow=keep.h;
    }
    if(slides.length>PV_LIMIT)
      note('\u2026and '+(slides.length-PV_LIMIT)+' more slide'
        +(slides.length-PV_LIMIT===1?'':'s')+'.');
    if(first) try{first.scrollIntoView({block:'nearest'});}catch(err){}
    if(lazy.length) pvLazyWatch(host,d,lazy,W,H);
    return n;
  }
  var PV_EAGER=8;
  /* a preview's waiting thumbnails, each drawn the way renderDeckPreview
     draws one -- against ITS deck, at its size -- once it comes within a
     screen's reach of view (the observer's root is the viewport, and the
     scrolling column clips what it reports) */
  function pvLazyWatch(host,d,lazy,W,H){
    var io=new IntersectionObserver(function(es){
      es.forEach(function(e){
        if(!e.isIntersecting) return;
        io.unobserve(e.target);
        var it=null;
        for(var k=0;k<lazy.length;k++) if(lazy[k].ph===e.target) it=lazy[k];
        if(!it||!it.ph.parentNode) return;
        var keep={p:pres,paint:paintSlide,h:miniHNow},m;
        try{
          pres=d;miniHNow=H;
          m=miniDiagram(it.s);
        }catch(err){m=null;}
        finally{pres=keep.p;paintSlide=keep.paint;miniHNow=keep.h;}
        if(!m) return;   /* left as the empty box a failed one always was */
        m.style.width=W+'px';m.style.height=H+'px';
        it.ph.parentNode.replaceChild(m,it.ph);
      });
    },{rootMargin:'300px'});
    host._pvIO=io;
    lazy.forEach(function(it){io.observe(it.ph);});
  }
  window.SemApp.deckPreview=renderDeckPreview;
  window.SemApp.deckPreviewForget=pvForget;
  /* the Open dialog's query, lower-cased */
  function hubQuery(){
    var f=$('#presentation-hub-find');
    return f?String(f.value||'').trim().toLowerCase():'';
  }
  /* a row the query keeps: by name, or by words on its slides -- which it
     then carries, so the row can say how many slides matched */
  function hubMatch(p,q){
    if(!q) return true;
    if(String(p.name||'').toLowerCase().indexOf(q)>=0) return true;
    p.hits=pvMatches(p.name,q);
    return p.hits.length>0;
  }
  var hubPvName='',hubPvT=null;
  function hubPreview(name,now){
    clearTimeout(hubPvT);
    function go(){
      var host=$('#presentation-hub-pv'); if(!host) return;
      hubPvName=name;
      if(!name){host.innerHTML='';return;}
      renderDeckPreview(host,name,{w:164,q:hubQuery(),open:function(nm){
        closePresentationHub();choosePresentation(nm);}});
    }
    if(now) go(); else hubPvT=setTimeout(go,90);
  }
  /* ---- T599: THE PRESENTATION FILES IN A FOLDER, SEEN FIRST ----------
     The library only knows decks this browser has opened. The ones on
     disk -- the folder Junoview saves into, or any folder you point it
     at -- are listed here too, newest first, each previewed on pointing
     and searched by its words like any other row, and read only when
     they are pointed at or searched. Opening one goes through File >
     Open's handle path, so Save writes back to that file. */
  var hubDirH=null,hubDirRows=null,hubDirReading=false;
  function hubDirList(dir){
    var hs=[],it;
    try{it=dir.values();}catch(e){return Promise.resolve([]);}
    function step(){
      return it.next().then(function(r){
        if(r.done) return hs;
        var h=r.value;
        if(h&&h.kind==='file'&&/\.junoview(\.html)?$/i.test(h.name||''))
          hs.push(h);
        return step();
      });
    }
    return step().then(function(list){
      return Promise.all(list.map(function(h){
        return h.getFile().then(function(f){
          return {h:h,name:h.name,at:f.lastModified||0,file:f};
        }).catch(function(){return null;});
      }));
    }).then(function(rows){
      return rows.filter(Boolean).sort(function(a,b){return b.at-a.at;});
    });
  }
  function hubDirShow(dir){
    return hubDirList(dir).then(function(rows){
      hubDirH=dir;hubDirRows=rows;
      renderPresentationHub();
      return rows.length;
    }).catch(function(e){
      toast('Could not read that folder: '+((e&&e.message)||e),8000);
      return 0;
    });
  }
  /* the one deck a file holds, parsed once and kept on its row */
  function hubDirDeck(r){
    if(r.deck!==undefined) return Promise.resolve(r.deck);
    return r.file.text().then(function(txt){
      var obj=parseDeckText(txt);
      var list=(obj&&Array.isArray(obj.presentations))?obj.presentations
        :Array.isArray(obj)?obj:(obj&&Array.isArray(obj.slides))?[obj]:[];
      var one=list.filter(function(p){
        return p&&Array.isArray(p.slides);})[0];
      r.deck=one?normPres(one):null;
      r.words=r.deck?r.deck.slides.map(pvSlideWords):[];
      return r.deck;
    }).catch(function(){r.deck=null;r.words=[];return null;});
  }
  function hubDirWords(r){
    var slides=r.deck&&r.deck.slides?r.deck.slides.length:null;
    return [r.name,r.at&&typeof histWhen==='function'?histWhen(r.at):'',
      slides!=null?(slides+' slide'+(slides===1?'':'s')):'']
      .filter(Boolean).join(' \u00b7 ');
  }
  function hubDirOpen(r){
    closePresentationHub();
    openDeckHandles([r.h]);
  }
  function hubDirPreview(r){
    clearTimeout(hubPvT);
    hubPvT=setTimeout(function(){
      hubDirDeck(r).then(function(d){
        var host=$('#presentation-hub-pv'); if(!host) return;
        hubPvName='file:'+r.name;
        renderDeckPreview(host,fileStem(r.name)||r.name,{deck:d,w:164,
          q:hubQuery(),sub:hubDirWords(r),open:function(){hubDirOpen(r);}});
      });
    },90);
  }
  function hubDirRow(r){
    var b=document.createElement('button');
    b.type='button';b.className='presentation-hub-row is-file';
    b.title='Open '+r.name+' \u2014 Save writes back to it';
    var ic=document.createElement('span');ic.innerHTML=bic('doc');
    var nm=document.createElement('span');nm.className='presentation-hub-row-name';
    nm.textContent=fileStem(r.name)||r.name;
    var sub=document.createElement('span');sub.className='presentation-hub-row-sub';
    var hits=hubQuery()&&r.words?pvMatchWords(r.words,hubQuery()).length:0;
    sub.textContent=hubDirWords(r)+(hits?(' \u00b7 '+hits+' slide'
      +(hits===1?'':'s')+' match'):'');
    var tx=document.createElement('span');tx.className='presentation-hub-row-txt';
    tx.appendChild(nm);tx.appendChild(sub);
    b.appendChild(ic);b.appendChild(tx);
    b.addEventListener('mouseenter',function(){hubDirPreview(r);});
    b.addEventListener('focus',function(){hubDirPreview(r);});
    b.addEventListener('click',function(){hubDirOpen(r);});
    return b;
  }
  /* a folder row the query keeps -- by name, or, once every file has
     been read, by its words */
  function hubDirMatch(r,q){
    if(!q) return true;
    if(String(r.name).toLowerCase().indexOf(q)>=0) return true;
    return !!(r.words&&pvMatchWords(r.words,q).length);
  }
  function hubDirRender(q){
    var host=$('#presentation-hub-dir'),head=$('#presentation-hub-dirhead');
    var btn=$('#presentation-hub-dirbtn');
    if(btn){
      var can=!!window.showDirectoryPicker||!!deckDir;
      btn.hidden=!can;
      btn.innerHTML=bic('open')+' '+((deckDir&&!hubDirRows)
        ?('Show the files in '+esc(deckDirName||'your folder'))
        :'Look in a folder\u2026');
    }
    if(!host||!head) return [];
    host.innerHTML='';
    var on=!!hubDirRows;
    host.hidden=head.hidden=!on;
    if(!on) return [];
    head.textContent='In '+((hubDirH&&hubDirH.name)||'the folder');
    /* searching reads the files once, then draws again */
    if(q&&!hubDirReading&&hubDirRows.some(function(r){return !r.words;})){
      hubDirReading=true;
      Promise.all(hubDirRows.map(hubDirDeck)).then(function(){
        hubDirReading=false;renderPresentationHub();});
    }
    var rows=hubDirRows.filter(function(r){return hubDirMatch(r,q);});
    if(!rows.length) emptyPresentationList(host,
      q?'No file here matches.':'No presentation files in this folder.');
    rows.forEach(function(r){host.appendChild(hubDirRow(r));});
    return rows;
  }
  function hubDirDoor(){
    /* the remembered folder, once the browser lets it be read -- the
       click is what lets it */
    if(deckDir&&!hubDirRows){
      var ask=deckDir.requestPermission
        ?deckDir.requestPermission({mode:'read'}):Promise.resolve('granted');
      return Promise.resolve(ask).then(function(st){
        if(st==='granted') return hubDirShow(deckDir);
        toast('Junoview was not allowed to read '+deckDirName,6000);
      }).catch(function(){});
    }
    if(!window.showDirectoryPicker) return Promise.resolve();
    return window.showDirectoryPicker({id:'junoview-decks',mode:'read'})
      .then(hubDirShow).catch(function(e){
        if(!e||e.name!=='AbortError')
          toast('Could not open that folder: '+((e&&e.message)||e),8000);
      });
  }
  function libraryRows(){
    var names=[],seen={};
    function add(name){
      if(!name||seen[name]) return;
      seen[name]=1;names.push(name);
    }
    allSaved().forEach(function(p){add(p.name);});
    draftNames().forEach(add);
    if(pres) add(pres.name);
    return names.map(presentationSummary).filter(Boolean);
  }
  /* T436: a modifier click on a library row puts the presentation on
     the open list without leaving the dialog, so several can be opened
     in one visit; a plain click opens it as it always did */
  /* one verb on a library row: the pin's shape, so all four match */
  function hubRowAct(row,icon,label,run){
    var s=document.createElement('span');
    s.className='presentation-hub-act';
    s.setAttribute('role','button');s.tabIndex=0;
    s.innerHTML=bic(icon);
    s.title=label;s.setAttribute('aria-label',label);
    function go(e){e.stopPropagation();e.preventDefault();run();}
    s.addEventListener('click',go);
    s.addEventListener('keydown',function(e){
      if(e.key==='Enter'||e.key===' ') go(e);});
    row.appendChild(s);
    return s;
  }
  function presentationLibraryRow(p,click){
    var b=document.createElement('button');
    b.type='button';b.className='presentation-hub-row';
    b.title='Open '+presentationKind(p)+' \u201c'+p.name+'\u201d'
      +' \u2014 Ctrl+click to add it to the open list and stay here';
    var ic=document.createElement('span');ic.innerHTML=presentationIcon(p);
    var name=document.createElement('span');name.className='presentation-hub-row-name';
    name.textContent=p.name;
    var kind=document.createElement('span');kind.className='presentation-hub-row-kind';
    /* T598: only when it says something -- every row read PRESENTATION,
       squeezing the line that tells two rows apart */
    var kw=presentationKind(p);
    kind.textContent=(kw==='presentation'?'':kw)
      +(p.folder?((kw==='presentation'?'':' · ')+p.folder):'');
    /* T598: where it lives and when it was touched, under its name --
       two decks both called "talk" are two different lines now */
    var sub=document.createElement('span');
    sub.className='presentation-hub-row-sub';
    sub.textContent=deckRowWords(p)
      +((p.hits&&p.hits.length)?(' \u00b7 '+p.hits.length+' slide'
        +(p.hits.length===1?'':'s')+' match'):'');
    var txt=document.createElement('span');
    txt.className='presentation-hub-row-txt';
    txt.appendChild(name);txt.appendChild(sub);
    b.appendChild(ic);b.appendChild(txt);b.appendChild(kind);
    if(sub.textContent) b.title+='\n'+sub.textContent;
    /* T435: the pin. A pinned row heads Recent and never drops off it. */
    var pinned=isPinnedPresentation(p.name);
    if(pinned) b.classList.add('pinned');
    var pin=document.createElement('span');
    pin.className='presentation-hub-pin'+(pinned?' on':'');
    pin.setAttribute('role','button');pin.tabIndex=0;
    pin.innerHTML=bic('pin');
    pin.title=pinned?'Pinned to the top of Recent \u2014 click to unpin'
      :'Pin to the top of Recent, so it never drops off the list';
    pin.setAttribute('aria-label',pin.title);
    function flip(e){
      e.stopPropagation();e.preventDefault();
      var on=togglePinPresentation(p.name);
      toast(on?('\u201c'+p.name+'\u201d pinned \u2014 it stays at the top '
        +'of Recent'):('\u201c'+p.name+'\u201d unpinned'),4000);
    }
    pin.addEventListener('click',flip);
    pin.addEventListener('keydown',function(e){
      if(e.key==='Enter'||e.key===' ') flip(e);});
    /* ---- T450: THE VERBS, HERE TOO ----------------------------------
       (2026-09-14, user: "you can't duplicate a presentation or delete
       it from the main menu, there is very little controls".) T448 put
       them on the open-items bar; this is the library, which is the
       menu the user meant, and it listed everything you own while
       letting you do nothing to any of it but open it. Spans with
       role="button", not buttons: the row IS a button, and a button
       inside a button is not a thing. */
    hubRowAct(b,'copy','Duplicate \u201c'+p.name+'\u201d',function(){
      var made=duplicatePresentation(p.name);
      if(made) renderPresentationHub();
    });
    hubRowAct(b,'text','Rename \u201c'+p.name+'\u201d',function(){
      askText({title:'Rename this presentation',value:p.name,ok:'Rename'},
      function(v){
      if(!v||!v.trim()) return;
      if(typeof renamePresByName==='function') renamePresByName(p.name,v.trim());
      renderPresentationHub();
      if(typeof renderDeckPresentationDrawer==='function')
        renderDeckPresentationDrawer();
      });
    });
    hubRowAct(b,'minus','Delete \u201c'+p.name+'\u201d for good',function(){
      askDeleteDeck(p.name,function(){
        if(typeof deletePresByName==='function') deletePresByName(p.name);
        renderPresentationHub();
        if(typeof renderDeckPresentationDrawer==='function')
          renderDeckPresentationDrawer();
      });
    });
    b.appendChild(pin);
    /* T599: pointing at it, or tabbing to it, shows its slides */
    b.addEventListener('mouseenter',function(){hubPreview(p.name);});
    b.addEventListener('focus',function(){hubPreview(p.name);});
    b.addEventListener('click',function(e){
      if(e&&(e.ctrlKey||e.metaKey||e.shiftKey)){
        noteSessionOpen(p.name);
        renderPresTabs();
        toast('\u201c'+p.name+'\u201d is on the open list \u2014 Ctrl+click '
          +'adds more; a plain click opens one',5000);
        return;
      }
      click(e);
    });
    return b;
  }
  function emptyPresentationList(host,text){
    var e=document.createElement('div');e.className='presentation-hub-empty';
    e.textContent=text;host.appendChild(e);
  }
  /* The hub sits above the full-screen deck as a real modal, rather than
     merely looking like one.  Keep its keyboard focus out of the deck
     until it closes; Home has no visible deck, so remember only the
     inertness this dialog itself introduced. */
  /* KEPT OUT, NOT MADE INERT (2026-10-09, speed). `inert` on the editor
     is a style of its own, so opening the library restyled every one of
     the editor's 2,000-odd elements and closing it did it again: 60-100
     ms each way at 4x, for a dialog that already covers the window. The
     deck is hidden from assistive technology (aria-hidden, and the hub
     is aria-modal) and the keyboard is kept in the dialog by hand: Tab
     and Shift+Tab go round its own controls, and anything that still
     lands in the deck -- a script, a stray focus() -- is sent back to
     where it came from in the dialog. The backdrop takes the pointer. */
  var presentationHubInertedDeck=false,presentationHubLast=null;
  function hubFocusables(){
    var hub=$('#presentation-hub'); if(!hub) return [];
    return $$('button:not([disabled]),[href],input:not([disabled]),'
      +'select:not([disabled]),textarea:not([disabled]),'
      +'[tabindex]:not([tabindex="-1"])',hub).filter(function(el){
        return !el.hidden&&el.getClientRects().length>0;});
  }
  function hubTrapFocusIn(e){
    var hub=$('#presentation-hub');
    if(!presentationHubInertedDeck||!hub||hub.hidden) return;
    if(hub.contains(e.target)){presentationHubLast=e.target;return;}
    if(!deckEl.contains(e.target)) return;
    var back=(presentationHubLast&&presentationHubLast.isConnected
      &&hub.contains(presentationHubLast))?presentationHubLast
      :hubFocusables()[0];
    if(back) try{back.focus();}catch(err){}
  }
  function hubTrapKey(e){
    var hub=$('#presentation-hub');
    if(e.key!=='Tab'||!presentationHubInertedDeck||!hub||hub.hidden) return;
    /* ...nor is anything while such a dialog stands open: a Tab that has
       left it for the library has to be able to come back to it */
    if(document.querySelector('#ask-dlg:not([hidden]),#opendlg:not([hidden])'))
      return;
    var fs=hubFocusables(); if(!fs.length) return;
    var ae=document.activeElement,at=fs.indexOf(ae),to=null;
    /* a dialog opened over the library (a folder's name, a question)
       keeps its own keyboard: only the library's edges, and a keyboard
       that has somehow reached the editor, are this trap's business */
    if(at<0){if(ae&&deckEl.contains(ae)) to=fs[0];}
    else if(e.shiftKey){if(at===0) to=fs[fs.length-1];}
    else if(at===fs.length-1) to=fs[0];
    if(!to) return;
    e.preventDefault();
    try{to.focus();}catch(err){}
  }
  function presentationHubDeckInert(on){
    if(!deckEl) return;
    if(on){
      if(!deckEl.hidden&&!deckEl.hasAttribute('inert')
         &&!presentationHubInertedDeck){
        deckEl.setAttribute('aria-hidden','true');
        presentationHubInertedDeck=true;presentationHubLast=null;
        document.addEventListener('focusin',hubTrapFocusIn,true);
        document.addEventListener('keydown',hubTrapKey,true);
      }
      return;
    }
    if(!presentationHubInertedDeck) return;
    deckEl.removeAttribute('aria-hidden');
    presentationHubInertedDeck=false;presentationHubLast=null;
    document.removeEventListener('focusin',hubTrapFocusIn,true);
    document.removeEventListener('keydown',hubTrapKey,true);
  }
  /* T394: the All column is the library proper -- grouped by folder, with
     the folder verbs (rename, delete) on the heading and drag-and-drop
     filing between them -- everything the rail used to do before it
     became the list of what is open. */
  var draggingPres=null;
  function hubFolderHead(f,count){
    var h=document.createElement('div');
    h.className='presentation-hub-folder';
    h.dataset.folder=f;
    h.title='Folder “'+f+'” — drag presentations onto it';
    var ic=document.createElement('span');ic.innerHTML=bic('open');
    var t=document.createElement('span');t.className='presentation-hub-folder-name';
    t.textContent=f;
    var n=document.createElement('span');n.className='presentation-hub-folder-count';
    n.textContent=count;
    h.appendChild(ic);h.appendChild(t);h.appendChild(n);
    [[bic('pen'),'Rename folder',function(){
        askText({title:'Rename this folder',value:f,ok:'Rename'},function(v){
          if(v==null) return;
          renameFolder(f,v);
        });
      }],
     [bic('exit'),'Delete folder (its presentations move out)',function(){
        deleteFolder(f);}]].forEach(function(b){
      var btn=document.createElement('button');
      btn.type='button';btn.className='presentation-hub-folder-btn';
      btn.innerHTML=b[0];btn.title=b[1];btn.setAttribute('aria-label',b[1]);
      btn.addEventListener('click',function(e){e.stopPropagation();b[2]();});
      h.appendChild(btn);
    });
    h.addEventListener('dragover',function(e){
      if(!draggingPres) return;
      e.preventDefault();e.dataTransfer.dropEffect='move';
      h.classList.add('dropping');
    });
    h.addEventListener('dragleave',function(){h.classList.remove('dropping');});
    h.addEventListener('drop',function(e){
      if(!draggingPres) return;
      e.preventDefault();e.stopPropagation();
      var nm=draggingPres;draggingPres=null;
      setPresFolder(nm,f);
    });
    return h;
  }
  function renderPresentationHub(){
    var root=$('#presentation-hub');
    var recentHost=$('#presentation-hub-recent'),allHost=$('#presentation-hub-all');
    if(!root||!recentHost||!allHost) return;
    /* A CLOSED LIBRARY IS NOT DRAWN (2026-10-09, speed): every deck
       opened, renamed, pinned or saved rebuilt every row of a dialog
       that was not on screen. openPresentationHub draws it as it opens,
       and every change made while it is open still redraws it here. */
    if(root.hidden) return;
    recentHost.innerHTML='';allHost.innerHTML='';
    var q=hubQuery();
    var recent=savedRecentPresentationNames().filter(function(p){
      return hubMatch(p,q);});
    var all=libraryRows().filter(function(p){return hubMatch(p,q);});
    if(!recent.length) emptyPresentationList(recentHost,
      q?'No recent presentation matches.':
      'No recent presentations yet. Create one or open a saved deck.');
    recent.forEach(function(p){
      recentHost.appendChild(presentationLibraryRow(p,function(){
        closePresentationHub();choosePresentation(p.name);
      }));
    });
    /* loose presentations first, then every folder (an explicitly made
       folder shows even while empty, so there is something to drag onto) */
    var folders={},order=[];
    explicitFolders().forEach(function(f){folders[f]=[];order.push(f);});
    var loose=[];
    all.forEach(function(p){
      var f=p.folder||'';
      if(!f){loose.push(p);return;}
      if(!folders[f]){folders[f]=[];order.push(f);}
      folders[f].push(p);
    });
    function rowFor(p){
      var b=presentationLibraryRow(p,function(){
        closePresentationHub();choosePresentation(p.name);
      });
      b.draggable=true;
      b.addEventListener('dragstart',function(e){
        draggingPres=p.name;b.classList.add('dragging');
        try{e.dataTransfer.setData('text/plain',p.name);}catch(err){}
        e.dataTransfer.effectAllowed='move';
      });
      b.addEventListener('dragend',function(){
        draggingPres=null;b.classList.remove('dragging');
        allHost.classList.remove('dropping-root');
        $$('.presentation-hub-folder.dropping',allHost).forEach(function(el){
          el.classList.remove('dropping');});
      });
      return b;
    }
    if(!all.length&&!order.length&&!q) emptyPresentationList(allHost,
      'No saved presentations yet.');
    loose.forEach(function(p){allHost.appendChild(rowFor(p));});
    order.sort().forEach(function(f){
      /* a folder with nothing matching is not listed while finding */
      if(q&&!folders[f].length) return;
      allHost.appendChild(hubFolderHead(f,folders[f].length));
      folders[f].forEach(function(p){
        var r=rowFor(p);r.classList.add('infolder');allHost.appendChild(r);
      });
    });
    /* T599: the preview follows the rows -- the one it showed if it is
       still listed, else the first that is */
    var dirRows=hubDirRender(q);
    /* found nowhere at all: said once, where the eye starts */
    if(q&&!recent.length&&!all.length&&!dirRows.length){
      recentHost.innerHTML='';
      emptyPresentationList(recentHost,
        'Nothing is called \u201c'+q+'\u201d or has it on a slide.');
    }
    var names=recent.concat(all).map(function(p){return p.name;});
    if(!root.hidden){  /* a list re-drawn behind a closed dialog paints none */
      if(/^file:/.test(hubPvName)){
        var still=dirRows.filter(function(r){
          return 'file:'+r.name===hubPvName;})[0];
        if(still) return;
      }
      if(names.length||!dirRows.length)
        hubPreview(names.indexOf(hubPvName)>=0?hubPvName:(names[0]||''),true);
      else hubDirPreview(dirRows[0]);
    }
  }
  /* dropping on the column's own background takes a presentation OUT of
     its folder; wired once, the column survives every re-render */
  function hubDropBoot(){
    var allHost=$('#presentation-hub-all');if(!allHost) return;
    allHost.addEventListener('dragover',function(e){
      if(!draggingPres) return;
      e.preventDefault();e.dataTransfer.dropEffect='move';
      if(!(e.target.closest&&e.target.closest('.presentation-hub-folder')))
        allHost.classList.add('dropping-root');
    });
    allHost.addEventListener('dragleave',function(e){
      if(e.target===allHost) allHost.classList.remove('dropping-root');
    });
    allHost.addEventListener('drop',function(e){
      if(!draggingPres) return;
      e.preventDefault();
      var nm=draggingPres;draggingPres=null;
      allHost.classList.remove('dropping-root');
      setPresFolder(nm,'');
    });
  }
  function closePresentationHub(){
    var root=$('#presentation-hub');
    if(root) root.hidden=true;
    presentationHubDeckInert(false);
    pvForget();hubPvName='';   /* T599: parsed copies are for one visit */
    hubDirRows=null;hubDirH=null;
  }
  /* T414: OPEN MEANS OPEN (2026-09-13, user: "why when you click open
     is there all the 'new poster options', like THAT WAS THERE ON THE
     LAST MENU"). Every door into this dialog is an Open door except the
     folder one, so the create row shows only when asked for
     ({create:true}); the rest of the time the dialog is the library,
     with "Open a file" first. A door wired straight as a click listener
     passes an event, which is not an options object. */
  function openPresentationHub(opts){
    var root=$('#presentation-hub');if(!root) return;
    var create=!!(opts&&opts.create===true);
    closeDeckPresentationDrawer();
    pvForget();   /* T599: what was saved since the last visit shows */
    var fq=$('#presentation-hub-find'); if(fq) fq.value='';
    root.hidden=false;renderPresentationHub();
    /* T599: the folder Junoview saves into lists itself when the
       browser already lets it be read; otherwise its button asks */
    if(deckDir) permReadOK(deckDir).then(function(ok){
      if(ok&&!root.hidden&&!hubDirRows) hubDirShow(deckDir);});
    ['#presentation-hub-new','#presentation-hub-poster',
     '#presentation-hub-folder'].forEach(function(id){
      var b=$(id); if(b) b.hidden=!create;});
    /* T610's notebook door is for the editor and Home, never a talk: a
       notebook opened from the show's drawer mounted out of sight behind
       the slides (2026-10-08 review) */
    var hn=$('#presentation-hub-nb');
    if(hn) hn.hidden=!(APP.mode==='app'||APP.mode==='web')
      ||(!deckEl.hidden&&mode==='view');
    var ttl=$('#presentation-hub-title');
    if(ttl) ttl.textContent=create?'Open or create':'Open a presentation';
    var form=$('#presentation-hub-folderform');
    if(form&&!create) form.hidden=true;
    presentationHubDeckInert(true);
    setTimeout(function(){
      /* T599: Find is the door when finding is what was asked for */
      var b=$(create?'#presentation-hub-new'
        :(opts&&opts.find)?'#presentation-hub-find':'#presentation-hub-file');
      if(b) b.focus();},0);
  }
  /* The audience view owns one compact open-items drawer. The editor uses
     the real app rail instead, so its logo, tabs and rows cannot drift. */
  function drawerDoors(){
    return [$('#deck-pres-open')].filter(Boolean);
  }
  /* T448: a DOCKED bar does not close. Its whole point is staying
     there, and the pointer wanders off it constantly while you work,
     so the peek's leave rule and the hub's tidy-up would both shut it
     under you. The X in its head unpins it (back to a pop-up) rather
     than hiding a rail the layout has made room for. */
  function closeDeckPresentationDrawer(force){
    var d=$('#deck-pres-drawer');
    if(barDocked()&&!force) return;
    if(d){
      if(typeof overlayHide==='function') overlayHide(d);   /* T482 */
      d.hidden=true;
    }
    drawerDoors().forEach(function(b){b.setAttribute('aria-expanded','false');});
  }
  /* ---- T382: THE DRAWER IS WHAT IS OPEN NOW ------------------------
     It listed every presentation opened this session, which reads as a
     recents list when only one deck is ever on screen (2026-09-12, user:
     "it should show only open items, not all recents, with a separate
     recents button"). Open items are the presentation you are showing
     and the notebooks open in the app -- the things a click can put on
     screen without opening anything. A notebook row stops the talk and
     shows that notebook, the way the old column row did. */
  function openNotebookRows(){
    var out=[];
    var A=window.SemApp||{};
    (A.order||[]).forEach(function(stem){
      var sh=A.shells&&A.shells[stem]; if(!sh) return;
      out.push({stem:stem,label:sh.label||stem,path:sh.path||'',
        kind:sh.kind||'notebook'});
    });
    return out;
  }
  /* ---- T448: THE OPEN-ITEMS BAR --------------------------------------
     (2026-09-14, user: "the button beside home that is the only way to
     show what you currently have open is annoying. Often people want
     to swap a lot between presentation and tabs and version (also you
     can't duplicate a presentation or delete it from the main menu,
     there is very little controls). Having the side bar before was
     good when you could have it open all the time or pop it up more
     easily. Should also be able to make it as a top bar and customise
     a lot about the way you want things. Needs lots of user
     flexibility.")

     Three places it can live, remembered: a POP-UP that peeks from the
     left edge and closes when you leave it (what it was), a RAIL down
     the left that stays open and that the stage makes room for, or a
     STRIP across the top. Three sections it can list, each switchable:
     the presentations open in this tab, the notebooks, and this deck's
     saved versions. And every row carries its verbs -- switch,
     duplicate, rename, pin, close, delete -- because "there is very
     little controls" was the other half of the ask. */
  var OPENBAR_KEY='semopts:'+SCOPE+':openbar';
  var BAR_DEF={dock:'pop',pres:1,nb:1,vers:1};
  function barCfg(){
    var o={};
    try{o=JSON.parse(lsGet(OPENBAR_KEY)||'{}')||{};}catch(e){}
    return {dock:(o.dock==='left'||o.dock==='top')?o.dock:'pop',
      pres:o.pres===0?0:1,nb:o.nb===0?0:1,vers:o.vers===0?0:1};
  }
  function barSet(k,v){
    var c=barCfg();c[k]=v;
    lsSet(OPENBAR_KEY,JSON.stringify(c));
    barApply();
    renderDeckPresentationDrawer();
  }
  function barDocked(){return barCfg().dock!=='pop';}
  /* the deck gives up the room a docked bar takes, the way it does for
     an inspector pane (syncPaneDock) -- and the page is re-fitted,
     because the stage just changed size */
  function barApply(){
    var d=$('#deck-pres-drawer'); if(!d||!deckEl) return;
    var c=barCfg();
    /* The editor has the shared app rail; this configurable drawer is
       reserved for the audience view where the app rail is deliberately
       absent. */
    var audience=mode==='view';
    d.classList.toggle('dock-left',audience&&c.dock==='left');
    d.classList.toggle('dock-top',audience&&c.dock==='top');
    deckEl.classList.toggle('openbar-left',audience&&c.dock==='left');
    deckEl.classList.toggle('openbar-top',audience&&c.dock==='top');
    if(!audience){
      d.hidden=true;
      drawerDoors().forEach(function(b){b.setAttribute('aria-expanded','false');});
      return;
    }
    if(c.dock!=='pop'&&d.hidden){d.hidden=false;renderDeckPresentationDrawer();}
    drawerDoors().forEach(function(b){
      b.setAttribute('aria-expanded',(!d.hidden).toString());});
    /* T470: the door wears the choice -- its icon and its word are the
       menu's own row for where the bar is now */
    var db=$('#deck-pres-dock');
    if(db){
      var w=BAR_DOCK_WORDS[c.dock]||BAR_DOCK_WORDS.pop;
      db.innerHTML=bic(w[0])+' <span id="deck-pres-dock-say">'+w[1]
        +'</span>\u00a0\u25be';
      db.title='This bar is '+w[2]+'. Where it sits, and what it lists';
      db.setAttribute('aria-label',db.title);
    }
    if(typeof applyZoom==='function') applyZoom();
  }
  var BAR_DOCK_WORDS={pop:['objects','Pop-up','a pop-up'],
    left:['dockright','Rail','a rail down the left'],
    top:['docktop','Strip','a strip across the top']};
  /* ---- A COPY OF A PRESENTATION (T448) --------------------------------
     "you can't duplicate a presentation". One deep copy under a free
     name, into the draft store, open beside the original. */
  function duplicatePresentation(nm){
    var src=(pres&&pres.name===nm)?pres:(loadDraft(nm)||savedByName(nm));
    if(!src){toast('“'+nm+'” is not here to copy');return '';}
    var base=nm+' copy',name=base,n2=1;
    while(savedByName(name)||loadDraft(name)){n2++;name=base+' '+n2;}
    var cp=deep(src);cp.name=name;
    if(!draftSet(name,JSON.stringify(cp),true)){
      toast('Could not copy — this browser had no room for it',8000);
      return '';
    }
    noteSessionOpen(name);
    renderPresTabs();renderDeckPresentationDrawer();
    if(typeof renderPresentationHub==='function') renderPresentationHub();
    toast('Copied to “'+name+'” — it is open beside this one');
    return name;
  }
  function barRowActs(host,acts){
    var w=document.createElement('span');
    w.className='deck-pres-acts';
    acts.forEach(function(a){
      if(!a) return;
      var b=document.createElement('button');
      b.type='button';b.className='deck-pres-act'+(a[3]?' on':'');
      b.innerHTML=a[0];b.title=a[1];
      b.setAttribute('aria-label',a[1]);
      b.addEventListener('click',function(e){
        e.stopPropagation();e.preventDefault();a[2]();});
      w.appendChild(b);
    });
    host.appendChild(w);
    return w;
  }
  /* A CLOSED DRAWER IS NOT DRAWN (2026-10-09, speed). Every deck opened
     and every talk started redrew it -- each open deck's summary, and
     the version list read from IndexedDB and formatted -- for a drawer
     nobody could see: 55 ms of Start show at 4x. A hidden one is drawn
     when it opens (openDeckPresentationDrawer, and barApply's docked
     bar), which is the only time its rows can be read or clicked. */
  function renderDeckPresentationDrawer(){
    var host=$('#deck-pres-list');if(!host) return;
    var dr=$('#deck-pres-drawer');
    if(dr&&dr.hidden) return;
    var c=barCfg();
    host.innerHTML='';
    function row(cls,icon,name,kind,title,click){
      var b=document.createElement('div');
      b.className='deck-pres-row'+(cls?' '+cls:'');
      b.title=title;
      if(click){
        b.tabIndex=0;b.setAttribute('role','button');
        b.addEventListener('click',click);
        b.addEventListener('keydown',function(e){
          if(e.key==='Enter'||e.key===' '){e.preventDefault();click(e);}});
      }
      var ic=document.createElement('span');ic.innerHTML=icon;
      var nm=document.createElement('span');nm.className='deck-pres-row-name';
      nm.textContent=name;
      var kd=document.createElement('span');kd.className='deck-pres-row-kind';
      kd.textContent=kind;
      b.appendChild(ic);b.appendChild(nm);b.appendChild(kd);
      host.appendChild(b);
      return b;
    }
    function head(txt){
      var h=document.createElement('div');
      h.className='deck-pres-sec';h.textContent=txt;
      host.appendChild(h);
    }
    /* ---- the presentations open in this tab ---- */
    if(c.pres){
      head('presentations');
      var names=openPresentationNames().slice();
      if(pres&&pres.name&&names.indexOf(pres.name)<0) names.unshift(pres.name);
      names.forEach(function(nm){
        var mine=(nm===pres.name);
        var q=presentationSummary(nm)||{name:nm};
        var r=row(mine?'current':'',presentationIcon(q),nm,
          presentationKind(q),
          mine?'The presentation you are in':('Switch to “'+nm+'”'),
          mine?null:function(){
            if(!barDocked()) closeDeckPresentationDrawer();
            choosePresentation(nm);
          });
        var pinned=(typeof isPinnedPresentation==='function')
          &&isPinnedPresentation(nm);
        barRowActs(r,[
          [bic('copy'),'Duplicate “'+nm+'”',function(){
            duplicatePresentation(nm);}],
          mine?[bic('text'),'Rename “'+nm+'”',function(){
            askText({title:'Rename this presentation',value:nm,ok:'Rename'},
            function(v){
            if(v&&v.trim()&&typeof renamePresentation==='function')
              renamePresentation(v.trim());
            renderDeckPresentationDrawer();
            });
          }]:null,
          [bic('pin'),pinned?('Unpin “'+nm+'”')
            :('Pin “'+nm+'” to the top of Recent'),function(){
            if(typeof togglePinPresentation==='function')
              togglePinPresentation(nm);
            renderDeckPresentationDrawer();
          },pinned],
          [bic('exit'),'Close “'+nm+'” (it stays saved)',
           function(){
            if(mine&&typeof closeGuard==='function'){
              closeGuard(nm).then(function(ok){
                if(!ok) return;
                closeOpenPresentation(nm);closeDeck();
                renderPresTabs();renderDeckPresentationDrawer();
              });
              return;
            }
            closeOpenPresentation(nm);
            renderPresTabs();renderDeckPresentationDrawer();
          }],
          [bic('minus'),'Delete “'+nm+'” for good',function(){
            askDeleteDeck(nm,function(){
              if(typeof deletePresByName==='function') deletePresByName(nm);
              renderDeckPresentationDrawer();
            });
          }]]);
      });
      if(!names.length){
        var e0=document.createElement('div');e0.className='deck-pres-empty';
        e0.textContent='No presentation is open.';
        host.appendChild(e0);
      }
    }
    /* ---- the notebooks ---- */
    if(c.nb){
      head('notebooks');
      var nbs=openNotebookRows();
      nbs.forEach(function(n){
        var r=row('',bic('doc'),n.label,n.kind,
          'Stop presenting and show this notebook'
          +(n.path?(' ('+n.path+')'):''),
          function(){
            if(!barDocked()) closeDeckPresentationDrawer();
            closeDeck();
            var A=window.SemApp||{};
            if(A.activate) A.activate(n.stem);
          });
        barRowActs(r,[[bic('exit'),'Close this notebook',function(){
          var A=window.SemApp||{};
          if(A.closeNotebook) A.closeNotebook(n.stem);
          renderDeckPresentationDrawer();
        }]]);
      });
      if(!nbs.length){
        var e=document.createElement('div');e.className='deck-pres-empty';
        e.textContent='No notebook is open.';
        host.appendChild(e);
      }
    }
    /* ---- this deck's saved versions (T448: "and version") ---- */
    if(c.vers&&typeof histIndex==='function'){
      head('versions of this presentation');
      var vh=document.createElement('div');
      vh.className='deck-pres-empty';vh.textContent='Looking…';
      host.appendChild(vh);
      var want=pres&&pres.name;
      histIndex().then(function(ix){
        /* the deck may have changed under the promise */
        if(!pres||pres.name!==want||!vh.parentNode) return;
        var rows=(ix||[]).slice(-6).reverse();
        if(!rows.length){
          vh.textContent='No versions yet — one is kept when you save, '
            +'open or checkpoint this deck.';
          return;
        }
        vh.remove();
        rows.forEach(function(v){
          /* T465: the index's fields are `nm` (a checkpoint's name),
             `why` (opened / saved / checkpoint) and `at` (ms). This read
             v.name and v.t, which do not exist, so every row said
             "checkpoint" or "opened" with no time and no name, and
             clicking one opened History on the newest version whatever
             you had clicked (2026-09-15 review). The History rail's own
             helpers name a version the same way here. */
          var lab=(typeof histLabel==='function')?histLabel(v)
            :(v.nm||v.why||'version');
          /* T484: the right-hand word is WHY (opened / saved /
             checkpoint); an unnamed version printed its time twice */
          var kind=v.why||'';
          var r=row('',bic('history'),lab,
            kind||((typeof histClock==='function'&&v.at&&v.nm)?histClock(v.at):''),
            'Open the history on this version',function(){
              if(!barDocked()) closeDeckPresentationDrawer();
              if(typeof openHistory==='function') openHistory(v.id||'');
            });
          if(v.at&&typeof histClock==='function')
            r.title=lab+' \u00b7 '+histClock(v.at)+(v.why?(' \u00b7 '+v.why):'');
          r.classList.add('deck-pres-ver');
        });
      }).catch(function(){
        if(vh.parentNode) vh.textContent='Versions could not be read.';
      });
    }
  }
  /* the dock menu: where it sits, and what it lists */
  function barDockMenu(btn){
    var old=$('#openbar-menu'); if(old){overlayDrop(old);return;}
    var m=document.createElement('div');
    m.className='sh-menu vw-menu';m.id='openbar-menu';
    var c=barCfg();
    menuHead(m,'where this bar sits');
    [['pop','A pop-up',
      (APP.filesAt&&APP.filesAt()==='top')
        ?'It opens from Open now, and closes when you leave it'
        :'It opens from the chevron beside Home and when you reach the '
          +'left edge, and closes when you leave it'],
     ['left','A rail down the left',
      'It stays open and the slide makes room for it'],
     ['top','A strip across the top',
      'It stays open above the slide']].forEach(function(o){
      var b=document.createElement('button');
      b.className='dbtn vw-opt';b.type='button';
      b.innerHTML=bic(o[0]==='top'?'docktop':(o[0]==='left'?'dockright'
        :'objects'))+' '+esc(o[1]);
      b.title=o[2];
      b.setAttribute('aria-pressed',(c.dock===o[0]).toString());
      b.addEventListener('click',function(e){
        e.stopPropagation();overlayDrop(m);barSet('dock',o[0]);});
      m.appendChild(b);
    });
    menuHead(m,'what it lists');
    [['pres','Presentations'],['nb','Notebooks'],
     ['vers','Versions']].forEach(function(o){
      var b=document.createElement('button');
      b.className='dbtn vw-opt';b.type='button';
      b.innerHTML=bic(c[o[0]]?'eye':'none')+' '+esc(o[1]);
      b.setAttribute('aria-pressed',(!!c[o[0]]).toString());
      b.addEventListener('click',function(e){
        e.stopPropagation();overlayDrop(m);barSet(o[0],c[o[0]]?0:1);
      });
      m.appendChild(b);
    });
    overlayMount(btn,m);
  }
  function openDeckPresentationDrawer(){
    var d=$('#deck-pres-drawer');
    if(!d||mode!=='view') return;
    /* T482: a POP-UP is on the overlay owner's stack, like every menu:
       File opened underneath it and both stood open (2026-09-15
       review); opening File closes it now, and Escape and an outside
       click work. A docked bar is part of the frame, not an overlay. */
    if(!barDocked()&&typeof overlayShow==='function')
      overlayShow($('#deck-pres-open')||null,d);
    else d.hidden=false;
    /* drawn as it opens: a closed drawer is never kept up to date */
    renderDeckPresentationDrawer();
    drawerDoors().forEach(function(b){b.setAttribute('aria-expanded','true');});
  }
  /* T382: THE DRAWER SLIDES OUT AT THE LEFT EDGE while presenting, the
     way the presentations rail does outside the deck (2026-09-12, user:
     "the auto-hidden sidebar doesn't appear"). The rail's own peek
     handler returns early under body.deck-open, and deckIsolate has made
     the rail inert, so nothing answered the edge during a talk. Same
     14px hit zone as the rail's; it closes when the pointer leaves the
     drawer by the same 40px margin the column and the present bar use.
     T396: WHILE EDITING TOO. "Presenting only" left the editor with no
     sidebar at all -- the rail is behind it -- and the user asked for it
     there in as many words (2026-09-13: "the side bar that shows you all
     the open presentations doesn't appear in presentation mode"). The
     one exception is a slide column set to hide itself, which already
     owns the left edge (initFilmAuto); the chevron beside Home opens the
     drawer there. */
  function initDrawerPeek(){
    document.addEventListener('mousemove',function(e){
      var d=$('#deck-pres-drawer'); if(!d) return;
      /* T448: a docked bar is already open and stays open */
      if(barDocked()) return;
      /* T596: while the open files are tabs across the top, nothing
         pops out of the left edge -- "Open now" on the presenting bar
         is the way to the list during a talk */
      if(APP.filesAt&&APP.filesAt()==='top'&&d.hidden) return;
      if(deckEl.hidden||mode!=='view') return;
      var hub=$('#presentation-hub');
      if(hub&&!hub.hidden) return;
      if(d.hidden){
        if(e.clientX<=14) openDeckPresentationDrawer();
        return;
      }
      var r=d.getBoundingClientRect();
      if(e.clientX>r.right+40||e.clientY>r.bottom+40)
        closeDeckPresentationDrawer();
    });
  }
  function presentationHubBoot(){
    var hub=$('#presentation-hub'),drawer=$('#deck-pres-drawer');
    var drawerBrowse=$('#deck-pres-browse'),drawerRecent=$('#deck-pres-recent');
    drawerDoors().forEach(function(b){
      b.addEventListener('click',function(e){
        e.stopPropagation();
        if(!drawer) return;
        if(drawer.hidden) openDeckPresentationDrawer();
        else closeDeckPresentationDrawer(true);
      });
    });
    /* T448: the bar's own head -- where it sits, a new presentation,
       and an X that un-docks rather than hides */
    var dock=$('#deck-pres-dock');
    if(dock) dock.addEventListener('click',function(e){
      e.stopPropagation();barDockMenu(dock);});
    var dnew=$('#deck-pres-new');
    if(dnew) dnew.addEventListener('click',function(){
      if(!barDocked()) closeDeckPresentationDrawer();
      newPresentation();
    });
    /* T470: AN X CLOSES. On a docked bar it un-docked and left the
       bar open as a pop-up over the thumbnails, under a label that
       said "Close this bar" (2026-09-15 review). It closes: the bar
       goes back to a pop-up, which is the only kind that can be shut,
       and shuts. The door beside it is how you dock it again. */
    var dclose=$('#deck-pres-close');
    if(dclose) dclose.addEventListener('click',function(e){
      e.stopPropagation();
      if(barDocked()) barSet('dock','pop');
      closeDeckPresentationDrawer(true);
    });
    barApply();
    if(drawerBrowse) drawerBrowse.addEventListener('click',openPresentationHub);
    /* the separate Recents door: the same library dialog, opened on its
       Recent column */
    if(drawerRecent) drawerRecent.addEventListener('click',function(){
      openPresentationHub();
      setTimeout(function(){
        var first=$('#presentation-hub-recent .presentation-hub-row');
        if(first) first.focus();},0);
    });
    initDrawerPeek();
    hubDropBoot();
    /* T394: the rail's two doors under its open list */
    var railRecent=$('#pr-recent'),railAll=$('#pr-library');
    if(railRecent) railRecent.addEventListener('click',function(){
      openPresentationHub();
      setTimeout(function(){
        var first=$('#presentation-hub-recent .presentation-hub-row');
        if(first) first.focus();},0);
    });
    if(railAll) railAll.addEventListener('click',openPresentationHub);
    var close=$('#presentation-hub-close');
    if(close) close.addEventListener('click',closePresentationHub);
    if(hub) hub.addEventListener('click',function(e){
      if(e.target===hub) closePresentationHub();
    });
    var newer=$('#presentation-hub-new');
    if(newer) newer.addEventListener('click',function(){
      closePresentationHub();newPresentation();
    });
    var poster=$('#presentation-hub-poster');
    if(poster) poster.addEventListener('click',function(){
      closePresentationHub();newPoster();
    });
    var folder=$('#presentation-hub-folder');
    var form=$('#presentation-hub-folderform');
    var field=$('#presentation-hub-foldername');
    if(folder) folder.addEventListener('click',function(){
      if(!form) return;
      form.hidden=!form.hidden;
      if(!form.hidden&&field){field.focus();field.select();}
    });
    if(form) form.addEventListener('submit',function(e){
      e.preventDefault();
      var name=field&&field.value.trim();
      if(!name) return;
      if(newFolder(name)){
        field.value='';form.hidden=true;renderPresentationHub();
      }
    });
    /* T599: Find filters as you type; Escape clears it before it closes
       the dialog, and Enter opens the first presentation it kept */
    var find=$('#presentation-hub-find');
    if(find){
      find.addEventListener('input',function(){renderPresentationHub();});
      find.addEventListener('keydown',function(e){
        if(e.key==='Escape'&&find.value){
          e.preventDefault();e.stopPropagation();
          find.value='';renderPresentationHub();
        } else if(e.key==='Enter'){
          var first=$('#presentation-hub .presentation-hub-row');
          if(first){e.preventDefault();first.click();}
        } else if(e.key==='ArrowDown'){
          var r0=$('#presentation-hub .presentation-hub-row');
          if(r0){e.preventDefault();r0.focus();}
        }
      });
    }
    var dirb=$('#presentation-hub-dirbtn');
    if(dirb) dirb.addEventListener('click',function(){hubDirDoor();});
    var file=$('#presentation-hub-file');
    if(file) file.addEventListener('click',function(){
      /* T414: the same door the rail's row uses -- a real file handle
         where the browser has one, so Save writes back to the file you
         opened; the bare <input> only where it does not */
      closePresentationHub();openDeckFile();
    });
    /* T610: a notebook, through the one real door */
    var hubNb=$('#presentation-hub-nb');
    if(hubNb) hubNb.addEventListener('click',function(){
      closePresentationHub();var t=$('#tab-open');if(t) t.click();});
    var pptx=$('#presentation-hub-pptx');
    if(pptx) pptx.addEventListener('click',function(){
      closePresentationHub();var input=$('#pptxfile');if(input) input.click();
    });
    document.addEventListener('keydown',function(e){
      if(e.key!=='Escape') return;
      if(hub&&!hub.hidden){e.preventDefault();e.stopPropagation();
        closePresentationHub();return;}
      if(drawer&&!drawer.hidden){e.preventDefault();e.stopPropagation();
        closeDeckPresentationDrawer();}
    },true);
    window.SemApp.deckHub=openPresentationHub;
    window.SemApp.deckNewFolder=function(){
      openPresentationHub({create:true});
      if(form){form.hidden=false;if(field) field.focus();}
    };
    window.SemApp.deckRecentNames=savedRecentPresentationNames;
    window.SemApp.deckRowWords=deckRowWords;   /* T598 */
    window.SemApp.deckPinToggle=togglePinPresentation;   /* T435 */
    renderPresentationHub();renderDeckPresentationDrawer();
    if(APP.refreshChrome) APP.refreshChrome();
  }
  /* ---- T596 / T602: NEW AND OPEN, UNDER FILE ------------------------
     The side panel's doors: New (the same four things the side panel's
     New made -- each row presses the one real button, so there is one
     implementation of each) and Open (the library, where Recents, every
     saved presentation and a file from this computer are). T596 put
     them on the tab row; T602 made them rows of File in both views,
     because the tab row is part of the title row now and "stuff like new
     and open" was what the user asked to go under File. */
  function tabRowBoot(){
    ['#app-file-menu','#dc-menu'].forEach(function(sel){
      var menu=$(sel); if(!menu) return;
      $$('.dc-mi[data-for]',menu).forEach(function(b){
        b.addEventListener('click',function(e){
          e.stopPropagation();overlayHide(menu);
          var real=$('#'+b.dataset.for);
          if(real) real.click();
        });
      });
    });
    [['#ot-open','#app-file-menu'],['#mi-open','#dc-menu']].forEach(function(p){
      var o=$(p[0]),menu=$(p[1]);
      if(o) o.addEventListener('click',function(){
        if(menu) overlayHide(menu);openPresentationHub();});
    });
  }
  function choosePresentation(nm){
    var A=window.SemApp||{};
    /* GOING BACK TO A DECK IS NOT OPENING IT AGAIN (2026-10-09, speed).
       Its tab, Home's Recent or the library, with the deck on screen a
       moment ago still open in its tab and only hidden behind a notebook
       or Home, reopened it from scratch: the undo history went, and the
       strip and the slide were rebuilt from nothing. That is T465's
       resume -- the same editing session, the undo stack kept -- which
       the picker's way back already takes. A deck closed with its X has
       left the open list, and comes back fresh, as before; a pick still
       running is dropped exactly as openDeck's fresh door drops one. */
    var back=(nm===pres.name)&&deckEl.hidden&&mode==='edit'
      &&rawOpenNames().indexOf(nm)>=0;
    if(nm!==pres.name){
      if(A.exitStyling) A.exitStyling();   /* leave any open custom view */
      lsSet(PFX+'last',nm);
      loadPresentation(nm);
      cur=0;activePane=-1;
    }
    noteSessionOpen(nm);   /* T394: it is open now, whichever kind it is */
    /* a custom view is edited in the document; a deck on the slide stage */
    if(isViewPres(pres)){openCustomView();return;}
    if(isColPres(pres)){openCollection(nm);return;}   /* T606 */
    if(back){dropPick();openDeck('edit',true);return;}
    openDeck('edit');   /* land straight in the slide editor */
  }
  function newBlankPresentation(){
    var n2=1,name='presentation';
    while(savedByName(name)||loadDraft(name)){
      n2++;name='presentation-'+n2;}
    /* deliberately NOT persisted yet: a new presentation only starts
       saving (draft + autosave) once you actually edit it, so clicking
       "New" never litters the project with empty decks */
    pres={name:name,slides:[emptySlide()]};
    source='auto';
    cur=0;activePane=0;
    openDeck('edit');   /* land straight in the slide editor */
    /* T283: and ask where it is going to live, the first time only */
    if(typeof askWhereToSave==='function') askWhereToSave();
  }
  /* ---- T559: START FROM A TEMPLATE ------------------------------------
     New presentation asks what kind of talk this is. Blank is still the
     verb (and Enter); beside it are four decks already in the order that
     kind of talk runs. A starting deck is DATA: each slide names a layout
     from the catalogue and what goes in that layout's text slots, in
     order -- a string is real words (a section's own name, "Conclusions"),
     {ph:...} a prompt, the placeholder T366 made: faint while you edit,
     never shown or printed, gone on the first key. The slides are made by
     the applyLayout New slide uses, so every box wears the type its slot
     names, and a slot you redirected to a variation (T368) or a style
     set reaches them as it reaches any slide. `secs` are [name, first
     slide] pairs. */
  var DECK_TEMPLATES=[
    {id:'talk',label:'Conference talk',stem:'talk',
     blurb:'The question, what you did, two results and the take-home, '
       +'in the order a twelve-minute talk runs.',
     secs:[['Introduction',0],['Methods',2],['Results',3],
       ['Conclusions',5]],
     slides:[
      ['title',[{ph:'Talk title \u2014 the finding in one line'},
        {ph:'Your name \u00b7 Institution \u00b7 Meeting, date'}]],
      ['title-body',['Why this matters',{ph:'The question, why this '
        +'room should care, and what was already known.'}]],
      ['text-cell',['Data and method',{ph:'The data, the method in '
        +'brief, and what is new about it.'}]],
      ['title-full',[{ph:'Result 1 \u2014 say it as a sentence'}]],
      ['title-halves',[{ph:'Result 2 \u2014 say it as a sentence'}]],
      ['title-body',['Conclusions',{ph:'Three take-home points, one '
        +'line each.'}]],
      ['section',['Thank you \u2014 questions?']]]},
    {id:'lab',label:'Lab meeting',stem:'lab meeting',
     blurb:'Since last time, a result or two, where you are stuck and '
       +'what is next.',
     slides:[
      ['title',[{ph:'What I have been working on'},
        {ph:'Your name \u00b7 Lab meeting, date'}]],
      ['title-body',['Since last time',{ph:'What you set out to do, '
        +'and what got done.'}]],
      ['cell-text',[{ph:'The result \u2014 say it as a sentence'},
        {ph:'What it shows, and how sure you are.'}]],
      ['title-halves',[{ph:'A comparison \u2014 say it as a sentence'}]],
      ['title-body',['Where I\u2019m stuck',{ph:'The problems, and '
        +'what you want the room\u2019s help with.'}]],
      ['title-body',['Next steps',{ph:'What you will do before the '
        +'next meeting.'}]]]},
    {id:'defence',label:'Thesis defence',stem:'defence',
     blurb:'The question, a section and a result for each chapter, '
       +'contributions and future work.',
     secs:[['Introduction',0],['Chapter 1',4],['Chapter 2',6],
       ['Chapter 3',8],['Conclusions',10]],
     slides:[
      ['title',[{ph:'Thesis title'},{ph:'Your name \u00b7 Department '
        +'\u00b7 Date \u00b7 Supervisors'}]],
      ['title-body',['Outline',{ph:'The chapters, and the question '
        +'that ties them together.'}]],
      ['title-body',['Background',{ph:'What is known, and the gap '
        +'this thesis fills.'}]],
      ['title-body',['The question',{ph:'The question in one '
        +'sentence, and why it matters.'}]],
      ['section',['Chapter 1']],
      ['title-full',[{ph:'Chapter 1\u2019s main result \u2014 say it '
        +'as a sentence'}]],
      ['section',['Chapter 2']],
      ['title-full',[{ph:'Chapter 2\u2019s main result \u2014 say it '
        +'as a sentence'}]],
      ['section',['Chapter 3']],
      ['title-full',[{ph:'Chapter 3\u2019s main result \u2014 say it '
        +'as a sentence'}]],
      ['title-body',['Contributions',{ph:'What the thesis adds \u2014 '
        +'one line per chapter.'}]],
      ['title-body',['Future work',{ph:'The questions this opens, and '
        +'what you would do next.'}]],
      ['title-body',['Acknowledgements',{ph:'Supervisors, '
        +'collaborators, funders, family.'}]],
      ['section',['Thank you \u2014 questions?']]]},
    /* the conference poster hall's classic: the A0 three-column
       template from Layouts, on the white page a new poster gets */
    {id:'poster',label:'Poster',stem:'poster',page:'a0p',
     tokens:{c:{page:'#ffffff'}},
     blurb:'An A0 conference poster in three numbered columns, ready '
       +'for your figures.',
     slides:[['poster-3col',[]]]}
  ];
  function tplSlide(spec){
    var s=emptySlide();
    applyLayout(s,layoutById(spec[0]));
    var words=spec[1]||[],ti=0;
    (s.annots||[]).forEach(function(a){
      if(!a||a.k!=='text') return;
      var w=words[ti++];
      if(w==null) return;
      if(typeof w==='string'){a.text=w;delete a.ph;}
      else if(w.ph){a.text=w.ph;a.ph=1;}
    });
    return s;
  }
  /* the deck a template makes; built with `pres` pointing at it, since
     applyLayout and the section registry read the deck in hand */
  function tplBuild(t){
    var keep=pres,d={name:'',slides:[]};
    if(t.page) d.page=t.page;
    if(t.tokens) d.tokens=deep(t.tokens);
    pres=d;
    try{
      (t.slides||[]).forEach(function(spec){d.slides.push(tplSlide(spec));});
      var secs=t.secs||[];
      secs.forEach(function(sc,k){
        var id=secId();
        secMap()[id]={name:sc[0]};
        var end=k+1<secs.length?secs[k+1][1]:d.slides.length;
        for(var i=sc[1];i<end&&i<d.slides.length;i++) d.slides[i].sec=id;
      });
    } finally {pres=keep;}
    return d;
  }
  function newPresentationFrom(t){
    if(!t){newBlankPresentation();return;}
    var stem=t.stem||'presentation',n2=1,name=stem;
    while(savedByName(name)||loadDraft(name)){n2++;name=stem+'-'+n2;}
    var d=tplBuild(t);
    d.name=name;
    /* not persisted until the first edit, as a blank deck is not */
    pres=d;source='auto';
    cur=0;activePane=-1;
    openDeck('edit');
    if(typeof askWhereToSave==='function') askWhereToSave();
  }
  /* a card draws the deck it makes: its first four slides as a contact
     sheet, or the one page of a one-page template at the sheet's height,
     with the deck's own ink and page (renderDeckPreview's swap) */
  var NT_W=80,NT_H=45;
  function ntSheet(d){
    var sh=document.createElement('span');sh.className='nt-sheet';
    var keep={p:pres,paint:paintSlide,h:miniHNow};
    try{
      pres=d;
      var pg=pageOf(),one=d.slides.length<4;
      var H=one?(NT_H*2+4):NT_H;
      var W=one?Math.round(H*pg.aw/pg.ah):NT_W;
      if(one&&W>NT_W*2+4){W=NT_W*2+4;H=Math.round(W*pg.ah/pg.aw);}
      miniHNow=H;
      applyTokens(sh);
      sh.classList.toggle('page-light',pageIsLight(tokVal('@page')));
      sh.classList.toggle('nt-one',one);
      d.slides.slice(0,one?1:4).forEach(function(s){
        var m;
        try{m=miniDiagram(s);}
        catch(err){m=document.createElement('span');
          m.className='mini-diagram free';}
        m.style.width=W+'px';m.style.height=H+'px';
        m.setAttribute('aria-hidden','true');
        sh.appendChild(m);
      });
    } finally {pres=keep.p;paintSlide=keep.paint;miniHNow=keep.h;}
    return sh;
  }
  function ntClose(){var d=$('#nt-dlg'); if(d) d.hidden=true;}
  function ntCard(t){
    var d=t?tplBuild(t):{name:'',slides:[emptySlide()]};
    var b=document.createElement('button');
    b.type='button';b.className='nt-card';b.setAttribute('role','listitem');
    b.dataset.tpl=t?t.id:'blank';
    b.appendChild(ntSheet(d));
    var nm=document.createElement('span');nm.className='nt-name';
    nm.textContent=t?t.label:'Blank';
    var n=document.createElement('span');n.className='nt-n';
    n.textContent=d.slides.length+(t&&t.page?' page':' slide')
      +(d.slides.length===1?'':'s');
    nm.appendChild(n);
    b.appendChild(nm);
    var bl=document.createElement('span');bl.className='nt-blurb';
    bl.textContent=t?t.blurb:'One empty slide.';
    b.appendChild(bl);
    b.title='Make a '+(t?t.label.toLowerCase():'blank presentation')
      +(t?' presentation':'');
    b.addEventListener('click',function(){ntClose();newPresentationFrom(t);});
    return b;
  }
  var ntWired=false;
  function newPresentation(){
    var dlg=$('#nt-dlg'),grid=$('#nt-grid');
    if(!dlg||!grid){newBlankPresentation();return;}
    if(!ntWired){
      ntWired=true;
      ['#nt-close','#nt-cancel'].forEach(function(sel){
        var x=$(sel); if(x) x.addEventListener('click',ntClose);});
      var bl=$('#nt-blank');
      if(bl) bl.addEventListener('click',function(){
        ntClose();newBlankPresentation();});
      dlg.addEventListener('click',function(e){
        if(e.target===dlg) ntClose();});
    }
    grid.innerHTML='';
    grid.appendChild(ntCard(null));
    DECK_TEMPLATES.forEach(function(t){grid.appendChild(ntCard(t));});
    dlg.hidden=false;
  }
  /* ---- CUSTOM VIEW: a third kind of saved thing (2026-07-29) ---------
     Not slides. A custom view remembers how the NOTEBOOK looks: the
     styling of its markdown cells and headings, plus the whole filter /
     hidden-cell / figure-size state. It opens in the document, not on the
     slide stage, so the styling bar edits what you are looking at. ---- */
  function isViewPres(p){return !!(p&&p.kind==='view');}
  /* rail row icons come from SemIcons (newdeck/newposter/newview) in
     presItem — the RAIL_ICO copy of that path data was deleted
     2026-08-23 so branding.py stays the only place artwork lives */
  function newCustomView(){
    var A=window.SemApp||{};
    var stem=A.active;
    if(!stem||!A.enterStyling){
      toast('Open a notebook first — a custom view restyles a notebook');
      return;
    }
    var n2=1,name='custom view';
    while(savedByName(name)||loadDraft(name)){
      n2++;name='custom view '+n2;}
    /* seeded from what you are looking at right now, so a new view never
       throws away the filters you already set up */
    pres={name:name,kind:'view',nb:stem,style:{},
          view:(A.layoutSnapshot&&A.layoutSnapshot(stem))||{}};
    source='auto';
    cur=0;activePane=-1;
    openCustomView();
  }
  function openCustomView(){
    var A=window.SemApp||{};
    closeDeck();                     /* the document, not the slide stage */
    if(pres.nb&&A.shells&&A.shells[pres.nb]&&A.activate)
      A.activate(pres.nb);
    if(pres.view&&A.applySnapshot)
      A.applySnapshot(pres.nb||A.active,pres.view);
    A.enterStyling(pres,function(){markDirty();});
    renderPresTabs();
    status();
  }
  function closeCustomView(){
    var A=window.SemApp||{};
    if(A.exitStyling) A.exitStyling();
    renderPresTabs();
  }
  window.SemApp.viewClose=closeCustomView;
  function newPoster(){
    var n2=1,name='poster';
    while(savedByName(name)||loadDraft(name)){
      n2++;name='poster-'+n2;}
    /* like a new presentation, nothing persists until the first edit.
       Posters start WHITE: they exist to be printed (2026-08-04) */
    var s=emptySlide();
    /* BLANK, not pre-filled: the 3-column academic template used to be
       applied here, so a new poster opened already covered in headings
       and placeholder frames you had to clear before starting your own
       (2026-08-18, user: "opening a poster should open as blank not a
       default fill"). The templates are all still one click away in
       Layouts — which is where choosing one belongs. Even the blank
       slide's full-page ghost frame goes: on a deck it is the "click to
       fill" idiom, but stretched over an A0 sheet it is one more thing
       you did not put there. */
    s.annots=[];
    pres={name:name,slides:[s],page:'a0p',tokens:{c:{page:'#ffffff'}}};
    source='auto';
    cur=0;activePane=-1;
    openDeck('edit');
    if(typeof askWhereToSave==='function') askWhereToSave();
  }

  function renderPresRow(slideOnly){
    var lbl=$('#pres-current'),nm=pres.name||'(unnamed)';
    if(lbl&&lbl.textContent!==nm) lbl.textContent=nm;
    var inp=$('#pres-name');
    if(document.activeElement!==inp&&inp.value!==pres.name)
      inp.value=pres.name;
    /* a finished project save: its mark in place (presTabsAfterSave) */
    if(slideOnly==='save'){presTabsAfterSave();return;}
    /* renderCreate's call: skipped when no tab would change (above) */
    if(slideOnly&&presTabsSame()){presTabsKeepInView();return;}
    renderPresTabs();
  }
  function renderControls(){
    syncFurnBtns();updateCropLabel();
    var s=pres.slides[cur];
    /* each grid by its id: a selector LIST misses the id fast path and
       walked the whole page, notebook and all, on every slide change */
    var lays=['#layout-row','#layout-menu-grid'].map(function(id){
      var g=$(id);return g?$$('.lay',g):[];});
    lays[0].concat(lays[1])
      .forEach(function(b){
      /* highlight the template last applied to this slide (if any) */
      b.setAttribute('aria-pressed',
        (!!s&&s.lay===b.dataset.lay).toString());
      b.disabled=!s;
    });
    /* T489: THE DOOR SAYS WHICH LAYOUT THIS SLIDE HAS. The pressed
       tile was the only sign, and it sat inside a pop-up you had to
       open to read (2026-09-15 review); the door wears the slide's
       layout beside its word, the way New slide wears the next one. */
    doorVal('#lay-btn',(function(){
      var on=$('#layout-menu-grid .lay[aria-pressed="true"] .lay-lb');
      return on?on.textContent.trim():'';
    })(),function(word){
      return 'Lay THIS slide out one of the ready-made ways. Your words '
        +'and figures stay; they move into the new places'
        +(word?('. It is laid out as '+word+' now'):'');
    });
    /* Home's strip lights the layout the NEXT slide takes (T218) */
    if(typeof syncNewSlideMarks==='function') syncNewSlideMarks();
    var te=$('#title-editor'), eb=$('#dc-edit');
    var isTitle=!!s&&s.layout==='title';
    if(te){
      te.hidden=!isTitle;
      if(isTitle){
        var ti=$('#ts-title'),su=$('#ts-sub');
        if(ti&&document.activeElement!==ti) ti.value=s.title||'';
        if(su&&document.activeElement!==su) su.value=s.sub||'';
      }
    }
    if(eb){
      eb.disabled=!s;
      /* Only "get me into the editor" survives. Going the other way is
         already the Notebooks button on the rail, and this duplicate was
         badly named and awkwardly placed in the bargain (2026-08-07,
         user: "the 'swap to notebooks' button is a stupid name and in a
         stupid place"). */
      eb.hidden=(mode==='edit');
      eb.innerHTML=bic('pen')+' Open the editor';
    }
  }
  /* the current slide's interactive frame editor — embedded inline as
     the big view in the merged slides list (one view, not two) */
  function buildSlideEditor(s){
    var ed=document.createElement('div');
    ed.className='pane-editor freeform';ed.id='pane-editor';
    if(!s){
      ed.innerHTML='<div class="pane empty">'
        +'<span class="pane-t">no slide</span></div>';
      return ed;
    }
    var cells=slideCells(s);
    if(!cells.length){
      ed.innerHTML='<div class="pane empty"><span class="pane-t">'
        +'pick a layout above, or click a card in the document'
        +'</span></div>';
      return ed;
    }
    /* T607: THE SLIDE BEHIND ITS FRAMES. This view drew only the frames,
       each a bare .an-cell without the canvas's frame classes -- so the
       first slide Create slides makes (a heading over a note) showed as
       a white card of grey words cut off after one line, with no heading
       at all, beside a strip whose thumbnails (T522) and a canvas that
       both showed the dark slide. The slide is drawn by the renderer the
       strip uses, at this view's own height, and the frames are the
       outlines over it you click to fill. */
    var back=slideBackdrop(s);
    if(back){ed.appendChild(back);ed.classList.add('has-back');}
    cells.forEach(function(pair){
      var a=pair.a, ai=pair.i;
      var it=a.ref?resolveRef(a.ref):null;
      var p=document.createElement('div');
      p.className='pane slot'+(it?' filled':' empty')
        +(ai===activePane?' active':'');
      var ap7=anchorPos(a,a.w,a.h);
      p.style.left=ap7.x+'%';p.style.top=ap7.y+'%';
      p.style.width=(a.w||10)+'%';p.style.height=(a.h||10)+'%';
      if(it){
        /* render the frame EXACTLY as it appears on the slide: the real
           card content for the chosen part (code / figure / output) */
        var frame=document.createElement('div');frame.className='an-cell';
        var ch=document.createElement('div');ch.className='an-cellhead';
        var chT=document.createElement('span');
        chT.className='an-cellhead-t';chT.textContent=it.title;
        ch.appendChild(chT);
        var pt0=partOf(a),facs0=facetList(it.ns);
        if(facs0.length>1||pt0==='code'){
          var pl=document.createElement('span');
          pl.className='an-cellpart';pl.textContent=pt0;
          ch.appendChild(pl);
        }
        if(multiNb()) ch.appendChild(nbChip('spane-nb',it.nb));
        frame.appendChild(ch);
        /* drawn by the backdrop when there is one; the frame keeps its
           head (shown while chosen) and its hit area */
        var b=back?null:framePart(it.ns,a.part);
        if(b){if(a.ts) b.style.zoom=a.ts;applyCrop(b,a);frame.appendChild(b);}
        applyCellColor(frame,a);
        p.title=it.nb+' — '+it.title;
        p.appendChild(frame);
        var pc=buildPartChooser(s,ai);
        if(pc) p.appendChild(pc);
      } else {
        var t=document.createElement('span');t.className='pane-t';
        t.textContent=a.ref?('missing: '+a.ref)
          :(ai===activePane?'▸ now click a card in the notebook'
            :'empty — click to select this frame');
        p.appendChild(t);
      }
      if(a.ref){
        var x=document.createElement('button');x.className='pane-x';
        x.innerHTML=bic('exit')||'&#10005;';x.title='Clear this frame';
        x.addEventListener('click',function(e){e.stopPropagation();
          a.ref=null;activePane=ai;markDirty();refresh();});
        p.appendChild(x);
      }
      p.addEventListener('click',function(e){
        e.stopPropagation();activePane=ai;refresh();});
      ed.appendChild(p);
    });
    return ed;
  }
  /* the whole slide as the strip draws it, sized for the big view: the
     view is the list's width less its row gutters (it is built before it
     is attached, so it cannot measure itself) and the page's own shape */
  function slideBackdrop(s){
    var l=$('#film-list'),w=l?l.clientWidth-20:0;
    if(w<=0) return null;
    var pg=pageOf(),H=Math.round(w*pg.ah/pg.aw);
    var mh=miniHNow,d;miniHNow=H;
    try{d=miniDiagram(s);}finally{miniHNow=mh;}
    d.classList.add('pe-back');
    d.setAttribute('aria-hidden','true');
    return d;
  }
  /* T303: THE INDEX HAS TO MATCH THE DECK. This read the live card
     first -- the order T298 inverted in cloneBody -- and it is
     miniDiagram's cell branch, so the film strip, the slide overview,
     the outline sheet, the history rows, the layout-card previews, the
     saved-arrangement thumbnails and the trace overview all repainted
     with the notebook's current figure while the slide kept the old
     one. Inside a single miniDiagram the flip branch already used
     framePart (kept) and this one did not, so one thumbnail was drawn
     from two sources. */
  function paneImgSrc(ref){
    var kept=(!ref||refIsLive(ref))?null:embBody(ref);
    var card=ref?(kept||cardEl(ref)||embBody(ref)):null;
    var img=card?$('.figframe img',card):null;
    return img?img.getAttribute('src'):null;
  }
  function paneThumb(ref){
    var w=document.createElement('span');w.className='mini-pane';
    var it=ref?resolveRef(ref):null;
    if(!it){w.className+=' empty';return w;}
    var src=paneImgSrc(ref);
    if(src){
      var m=document.createElement('img');
      m.src=src;m.alt='';m.loading='lazy';
      m.setAttribute('aria-hidden','true');   /* decorative (T105) */
      w.appendChild(m);
    } else if(it.kind==='note'){
      w.className+=' is-note';
    } else if(it.kind==='figure'||it.kind==='diagnostic'){
      w.className+=' is-fig';
    } else {
      w.className+=' is-code';
      w.textContent='</>';
    }
    return w;
  }
  /* ---- slide thumbnails ------------------------------------------------
     A thumbnail is a SCALE MODEL of the slide, not a picture of the
     notebook cells on it. It used to walk slideCells() and nothing else,
     so a slide made of text, arrows, shapes or images showed as an empty
     box and every such slide in the strip looked identical (2026-08-20,
     user: "thumbnails do now show text, or anything else for that matter,
     just the cells").
     Everything is placed in the same page percentages the canvas uses, so
     positions are exactly right at any size. Two things cannot scale
     linearly and get a floor instead — type and stroke width — because
     0.3px of either is nothing at all. That is the opposite of the rule
     fontPx follows on the real page, and deliberately: the page is the
     document and must stay true to itself, a thumbnail is an INDEX and
     has to be legible. */
  var MINI_H=66;      /* mirrors --mini-h in deck.css */
  /* MINI_H is the FLOOR now, not the height: the column is draggable, so
     a thumbnail grows with the room it is given and its type and strokes
     have to grow with it or a 460px strip draws 3px lettering
     (2026-08-22). Measured off the LIST rather than off a thumbnail —
     renderFilm sizes type before the node is in the document, and an
     unattached node has no height to read. Computed once per render, not
     once per item. */
  var MINI_AR=116/66,miniHNow=MINI_H;
  function miniH(){
    var l=$('#film-list');
    var w=l?l.clientWidth:0;
    if(!w) return MINI_H;
    /* the padding and the row's own gutters the CSS spends before the
       thumbnail gets the rest */
    return Math.max(MINI_H,Math.round((w-46)/MINI_AR));
  }
  /* svg ids (gradients) must be unique across every thumbnail in the
     strip, not just within one — a repeated id would silently paint every
     later slide's gradient with the first slide's */
  var miniSeq=0;
  function miniText(d,a,txt,cls,centred){
    if(!String(txt||'').trim()) return;
    var t=document.createElement('span');
    t.className='mini-tx'+(cls?' '+cls:'');
    t.style.left=(a.x||0)+'%';t.style.top=(a.y||0)+'%';
    if(a.w!=null) t.style.width=a.w+'%';
    t.style.fontSize=Math.max(2,miniHNow*(a.size||2.6)/100).toFixed(2)+'px';
    if(a.color) t.style.color=tokVal(a.color);
    if(a.b) t.style.fontWeight='700';
    if(a.i) t.style.fontStyle='italic';
    if(a.align) t.style.textAlign=a.align;
    if(a.font) t.style.fontFamily=fontCss(a.font);
    if(a.bg!==0&&a.bgc) t.style.background=tokVal(a.bgc);
    /* a title is anchored on its CENTRE, the way the canvas anchors it */
    var tr=centred?'translate(-50%,-50%)':'';
    if(a.rot) tr+=(tr?' ':'')+'rotate('+a.rot+'deg)';
    if(tr) t.style.transform=tr;
    if(a.op!=null&&a.op<1) t.style.opacity=a.op;
    t.textContent=String(txt);
    d.appendChild(t);
  }
  /* T522: A PLACED NOTE OR CODE CELL IS DRAWN AS ITSELF. It used to be a
     white card of grey rules (.mini-pane.is-note), so every slide Create
     slides makes -- a heading over a Markdown note -- looked identical in
     the strip, and none of them looked like the dark slide it indexes
     (2026-09-29 audit). The canvas already has the rendered body
     (framePart, cached, a clone per call); the thumbnail takes the same
     clone at the same zoom rule the canvas uses -- a.ts x page height /
     SW_REF_H -- inside a box wearing the canvas's own frame classes, so the
     page's ink, a recoloured note and a light deck all come through the
     one set of rules. A figure keeps its picture (paneThumb): its body is
     megabytes and an <img> of it is the same thing. Returns false when
     there is nothing to draw, and the caller falls back. */
  function miniCell(d,a){
    if(!a.ref||(a.lockver&&a.lockver.commit)) return false;
    if(paneImgSrc(a.ref)) return false;
    var it=resolveRef(a.ref); if(!it) return false;
    var b=framePart(it.ns,a.part); if(!b) return false;
    var box=miniBox(d,a,'is-cell an-cell'+(a.autoNote?' an-auto-note':''));
    applyCellColor(box,a);
    b.style.zoom=((a.ts||1)*miniHNow/SW_REF_H).toFixed(4);
    b.setAttribute('aria-hidden','true');   /* decorative (T105) */
    b.removeAttribute('id');
    $$('[id]',b).forEach(function(n){n.removeAttribute('id');});
    box.appendChild(b);
    return true;
  }
  /* a box-shaped item (shape, image, cell frame) at its page rect */
  function miniBox(d,a,cls){
    var b=document.createElement('span');
    b.className='mini-it'+(cls?' '+cls:'');
    b.style.left=(a.x||0)+'%';b.style.top=(a.y||0)+'%';
    b.style.width=(a.w||10)+'%';b.style.height=(a.h||10)+'%';
    /* T549: a thumbnail has no handles, so the whole box mirrors */
    var mtr=(a.rot?'rotate('+a.rot+'deg)':'')
      +((a.flipH||a.flipV)?' scale('+(a.flipH?-1:1)+','+(a.flipV?-1:1)+')':'');
    if(mtr) b.style.transform=mtr.trim();
    if(a.op!=null&&a.op<1) b.style.opacity=a.op;
    d.appendChild(b);
    return b;
  }
  /* the stroke a thumbnail draws: the page weight scaled down, floored so
     a hairline is still a line */
  function miniSw(a){
    return Math.max(0.6,swOf(a)*miniHNow/SW_REF_H).toFixed(2);
  }
  /* re-weight a borrowed shape/freehand svg for thumbnail scale, and drop
     its dash: dashes are measured in the stroke's own units, so a pattern
     sized for an A0 poster is one long dash across a 116px thumbnail */
  function miniStroke(host,a){
    var p=host.querySelector('path'); if(!p) return;
    p.setAttribute('stroke-width',miniSw(a));
    p.removeAttribute('stroke-dasharray');
  }
  /* ---- THE DESIGN SURFACE (T87, 2026-08-29) ---------------------------
     "Where was the button where people can 'standardise presentation'...
     controlling things like 'global heading layouts'... Then it would be
     cool if you could also 'show outlines of all objects'."

     Three quarters of this was already built and scattered: the style
     registry (pres.styles) decides what a Heading looks like, the
     Standardise pane finds type that has drifted from it, the Apply
     dialog pushes a look across a deck, and T5's selection criteria find
     every box of a kind. What was missing was a PLACE -- one screen that
     puts a deck's type in front of you and lets you change it -- plus
     two things that did not exist at all: a default POSITION for a named
     type, and a way to see every object on every slide as an outline.

     Built on what is there, deliberately:
       * it writes pres.styles, the same registry styleDef reads, so a
         change here is the same change the Styles menu makes;
       * it re-stamps through applyStyleTo, the one function that puts a
         style onto a box, rather than writing size/weight/colour itself;
       * the outline sheet is miniDiagram, the renderer the film strip
         and the overview map already use.
     And it is NOT a second Apply dialog. Apply answers "which slides,
     which properties, which type"; this answers "what does a Heading
     look like in this deck". Position is the one thing here that Apply
     cannot express, and it is a button you press, never something
     applyStyleTo does on your behalf -- a style stamp that yanked boxes
     across the page would be unusable. */
  var dgSel='title', dgView='look', dgSheetOpen=false,
    dgOutline=false;
  /* the smallest a drag proxy in the outline sheet may be, in page
     percent. A horizontal or vertical line's bounding box is
     zero-thickness and there is nothing to grab; the canvas answers the
     same question with a 12px tolerance round the segment (arrowAt).
     6% of a 116x66px miniature is ~7x4px, and the fallback box proxy
     below is already only 8% tall, so this is no outlier. */
  var DG_HIT=6;
  /* WHICH SLIDES (T130). The put gesture was all-wearers-everywhere and
     the outline sheet was every-slide-always; the ask named sections
     and ranges for both. One selector builder, two independent scopes,
     because "move the headings in section 2" and "show me outlines of
     slides 4-9" are different questions asked at different moments. */
  /* T231: the put button's own scope went with the selector -- it
     reads the selection now, so a second answer to "which slides"
     would only be a way to disagree with yourself. The sheet keeps
     one, because it says which slides the column SHOWS. */
  var dgSheetScope={kind:'all'};
  function dgInScope(sc,si){
    if(!sc||sc.kind==='all') return true;
    if(sc.kind==='sec')
      return ((pres.slides||[])[si]||{}).sec===sc.sec;
    return (si+1)>=sc.from&&(si+1)<=sc.to;
  }
  function dgScopeLabel(sc){
    if(!sc||sc.kind==='all') return 'on every slide';
    if(sc.kind==='sec'){
      var meta=(pres.sections||{})[sc.sec];
      return 'in \u00a7'+((meta&&meta.name)||'section');
    }
    return 'slides '+sc.from+'\u2013'+sc.to;
  }
  /* a typed range, made safe (JVR-05). SORT FIRST, then clamp BOTH
     ends: clamping the first endpoint only upward and the second only
     downward and swapping afterwards let a reversed out-of-range input
     like 999-1 store from=1,to=999 on a twelve-slide deck. dgInScope
     compares against real slide numbers, so the SELECTION was never
     wrong -- but dgScopeLabel is the only place a user can read back
     which slides are in scope, and it read those numbers out. An empty
     deck yields 1..1 rather than the degenerate 1..0. */
  function dgRange(a,b,total){
    var last=Math.max(1,total);
    function fit(n){return Math.min(last,Math.max(1,n));}
    return {from:fit(Math.min(a,b)),to:fit(Math.max(a,b))};
  }
  function dgScopeSelect(sc,onchange){
    var sel=document.createElement('select');
    sel.className='dg-scope';
    sel.title='Which slides this applies to';
    function opt(v,label){
      var o=document.createElement('option');
      o.value=v;o.textContent=label;sel.appendChild(o);return o;
    }
    opt('all','on every slide');
    /* only sections actually in use: an empty registry entry is not a
       place a slide can be */
    var used={};
    (pres.slides||[]).forEach(function(sl){
      if(sl&&sl.sec) used[sl.sec]=1;});
    Object.keys(used).forEach(function(id){
      var meta=(pres.sections||{})[id];
      opt('sec:'+id,'in \u00a7'+((meta&&meta.name)||'section'));
    });
    opt('range','slides\u2026');
    sel.value=sc.kind==='all'?'all'
      :sc.kind==='sec'?('sec:'+sc.sec):'range';
    sel.addEventListener('change',function(){
      var v=sel.value;
      if(v==='all'){sc.kind='all';}
      else if(v.indexOf('sec:')===0){sc.kind='sec';sc.sec=v.slice(4);}
      else {
        var total=(pres.slides||[]).length;
        /* T475: the editor's own question; the change lands in its answer */
        askText({title:'Which slides?',label:'A range like 4-9, or one number',
          value:'1-'+total,ok:'Use these'},function(got){
          var mm=got&&got.match(/^\s*(\d+)\s*(?:[-\u2013]\s*(\d+))?\s*$/);
          if(!mm){sel.value=sc.kind==='all'?'all'
            :sc.kind==='sec'?('sec:'+sc.sec):'range';return;}
          sc.kind='range';
          var r=dgRange(parseInt(mm[1],10),
            parseInt(mm[2]||mm[1],10),total);
          sc.from=r.from;sc.to=r.to;
          onchange();
        });
        return;
      }
      onchange();
    });
    return sel;
  }
  /* re-render the body WITHOUT losing where you were in it: a drop in
     the sheet redraws everything, and snapping back to the top of a
     long panel would make a second drag a scroll hunt (T130) */
  /* ...and the table's own scroll too, which a redraw used to throw
     away: tick a box forty rows down and the table jumped back to its
     first row (2026-10-09). Both are put back in the frame that draws
     the new body, before it is painted, rather than by a write that laid
     the new body out inside the click; a second redraw before that frame
     keeps the place the first one was keeping. */
  var dgKeepOwed=null;
  function dgBodyKeep(ov){
    var b=ov&&ov.querySelector('#dg-body');
    var g=ov&&ov.querySelector('.dgt-grid');
    /* the table's place is kept for the same table only: another kind
       or view opens at its top, as it always has */
    var keep=dgKeepOwed||{at:b?b.scrollTop:0,
      gat:(g&&g._dgWhat===dgTableWhat())?g.scrollTop:0};
    dgKeepOwed=keep;
    dgtKeepTop=keep.gat;
    try{dgBody(ov);}finally{dgtKeepTop=0;}
    requestAnimationFrame(function(){
      if(dgKeepOwed!==keep) return;
      dgKeepOwed=null;
      var b2=ov&&ov.querySelector('#dg-body');
      if(b2) b2.scrollTop=keep.at;
      var g2=ov&&ov.querySelector('.dgt-grid');
      if(g2&&keep.gat) g2.scrollTop=keep.gat;
    });
  }

  function dgStyleRec(id){
    var st=deckStyles();
    if(!st[id]) st[id]={};
    return st[id];
  }
  /* every box wearing a named type, as {s, i, a} across the whole deck */
  function dgWearers(id){
    var out=[];
    (pres.slides||[]).forEach(function(sl,si){
      (sl.annots||[]).forEach(function(a,ai){
        if(a&&a.k==='text'&&a.style===id) out.push({s:si,i:ai,a:a});});
    });
    return out;
  }
  /* re-stamp the registry onto everything wearing it. THE point of a
     standardise surface: a definition nobody is wearing is a preference,
     not a standard. */
  /* T608: a look of a type is still that type. */
  function dgInFamily(style,id){
    return !!style&&(style===id
      ||(typeof isVariantOf==='function'&&isVariantOf(style,id)));
  }
  function dgFamilyWearers(id){
    var out=[];
    (pres.slides||[]).forEach(function(sl,si){
      (sl.annots||[]).forEach(function(a,ai){
        if(a&&a.k==='text'&&dgInFamily(a.style,id))
          out.push({s:si,i:ai,a:a});});
    });
    return out;
  }
  function dgRestamp(id){
    var n=0;
    dgFamilyWearers(id).forEach(function(w){
      applyStyleTo(w.a,w.a.style);n++;});
    return n;
  }
  function dgClose(){
    var ov=$('#deck-design');
    if(ov) ov.remove();
    document.removeEventListener('keydown',dgKey,true);
  }
  function dgKey(e){
    if(!$('#deck-design')) return;
    if(e.key==='Escape'){
      /* T470: the Style sets picker may be open over this screen; its
         Escape is its own */
      var sd=$('#ss-dlg'); if(sd&&!sd.hidden) return;
      e.preventDefault();e.stopPropagation();dgClose();}
  }
  function dgSpecimen(el,id){
    var d=styleDef(id); if(!d) return;
    el.style.fontWeight=d.b?'700':'400';
    el.style.fontStyle=d.i?'italic':'normal';
    el.style.fontFamily=d.font?fontCss(d.font):'';
    el.style.color=d.color?tokVal(d.color):'';
    /* the LADDER has to read as a ladder, so sizes are shown in
       proportion to each other rather than at their page size -- 7.2% of
       an A0 sheet does not fit in a rail */
    el.style.fontSize=(11+(d.size||2.6)*1.9)+'px';
  }
  /* ---- T224: EVERY BOX OF A KIND, IN A TABLE --------------------------
     (2026-09-03, user: "I wanted more than just titles, also images
     etc... There should be unselect all, and select all button... I want
     full customisation here as well, font, font size, background colour,
     then why doesn't it show the x and y position as well... Would be
     good if there was also a table of them all to the right, which has
     things like colour, font etc. of them all and you can make them all
     match, or change them individually here, or change title colours in
     a range... it would be good if you could click a bunch and they get
     selected, then you click a button that says 'match style of', then
     click one and they all match to that. And you can choose as well
     what gets matched, whether it's all, or just position, or colour, or
     font etc. Do you get the point of this? So it is hard to make things
     match across slides, so this will help with this."

     The screen already knew how to change what a KIND looks like. What
     it could not do is the thing the ask is actually about: see the
     boxes themselves, side by side, and pull the odd one into line. The
     table is that. It is the same annots the canvas renders -- no copy,
     no import step -- so an edit here is an edit there. */
  var dgMarked={},dgMatchArm=false,dgMatchWhat='all';
  /* T230: the slides you pick in the strip are a SET, and the table
     is what they narrow (2026-09-03, user: "when selecting the
     slide thumbnails on this view it would be good if they stayed
     selected and became cumulative and that fed into things like
     the table"). Empty means every slide. */
  var dgSheetPick={};
  function dgPickedAny(){
    for(var k in dgSheetPick) if(dgSheetPick[k]) return true;
    return false;
  }
  function dgPickedCount(){
    var n=0;
    for(var k in dgSheetPick) if(dgSheetPick[k]) n++;
    return n;
  }
  /* `text` is every text box whatever style it wears, or none: a box
     that has never been given a named style appeared in no table at
     all, and an unstyled box is exactly the thing you go looking for */
  var DG_OBJ_KINDS=[['text','All text boxes','text'],
    ['cell','Figures','cellcard'],
    ['image','Pictures','image'],['rect','Shapes','shapes'],
    ['table','Tables','table'],['flip','Flip books','flipbook'],
    ['arrow','Arrows and lines','arrow']];
  function dgIsObj(){return /^obj:/.test(dgSel);}
  function dgAnyStyleWorn(){
    return styleOrder().some(function(id){return dgWearers(id).length>0;});
  }
  function dgObjKind(){return dgSel.slice(4);}
  function dgKindLabel(){
    if(!dgIsObj()){
      var d=styleDef(dgSel);
      return (d&&d.label)||dgSel;
    }
    var k=dgObjKind(),out=k;
    DG_OBJ_KINDS.forEach(function(p){if(p[0]===k) out=p[1];});
    return out;
  }
  function dgAnnotMatches(a){
    if(!a) return false;
    if(dgIsObj()){
      var k=dgObjKind();
      if(k==='arrow') return a.k==='arrow'||a.k==='line'||a.k==='draw';
      return a.k===k;
    }
    return a.k==='text'&&dgInFamily(a.style,dgSel);
  }
  /* every box of the chosen kind, everywhere, in slide order */
  function dgRows(){
    var out=[];
    (pres.slides||[]).forEach(function(sl,si){
      /* the slides picked in the strip narrow the table to them */
      if(dgPickedAny()&&!dgSheetPick[si]) return;
      (sl.annots||[]).forEach(function(a,ai){
        if(dgAnnotMatches(a)) out.push({si:si,ai:ai,a:a});
      });
    });
    return out;
  }
  function dgRowKey(r){return r.si+':'+r.ai;}
  function dgMarkedRows(rows){
    return rows.filter(function(r){return dgMarked[dgRowKey(r)];});
  }
  /* WHAT TRAVELS when you match. Each answer is a list of annot fields;
     'all' is every field the others name, so the chooser cannot drift
     out of step with itself. */
  var DG_MATCH={
    pos:['x','y'],
    size:['w','h','size'],
    colour:['color','bg','bgc','bdc','fill','fillc'],
    font:['font','b','i','align','lh','pspace']
  };
  function dgMatchFields(){
    if(dgMatchWhat!=='all') return DG_MATCH[dgMatchWhat]||[];
    var out=[];
    Object.keys(DG_MATCH).forEach(function(k){
      DG_MATCH[k].forEach(function(f){
        if(out.indexOf(f)<0) out.push(f);});
    });
    return out;
  }
  function dgMatchTo(src,rows){
    var fields=dgMatchFields(),n=0;
    rows.forEach(function(r){
      if(r.a===src) return;
      fields.forEach(function(f){
        if(src[f]===undefined) delete r.a[f];
        else r.a[f]=(typeof src[f]==='object'&&src[f])
          ?deep(src[f]):src[f];
      });
      /* a matched box is no longer anchored to whatever it was: the
         position it was given is the position it keeps */
      if(fields.indexOf('x')>=0) delete r.a.anch;
      n++;
    });
    return n;
  }
  function dgSwatch(v,fallback){
    var s=document.createElement('span');
    s.className='dgt-sw';
    if(!v||v==='none'){s.classList.add('dgt-none');s.title='none';}
    else {s.style.background=tokVal(v);s.title=v;}
    if(!v&&fallback) s.title='default';
    return s;
  }
  /* T490: THE TABLE EDITS COLOUR, FILL AND FACE TOO. T224's ask was "a
     table of them all ... colour, font etc. ... change them
     individually here", and the three cells were read-only swatches
     and a word (2026-09-15 review). A colour cell is the swatch as a
     picker, with a Default (or None, for the fill) button beside it;
     the Face cell is the ribbon's typeface list. Every write goes the
     way dgNum's does: markDirty, refresh, the strip, the body kept. */
  function dgWrite(){
    markDirty();refresh();renderFilm();
    var ov=$('#deck-design'); if(ov) dgBodyKeep(ov);
  }
  function dgColCell(r,key,isFill){
    var wrap=document.createElement('span');
    wrap.className='dgt-colw';
    var a=r.a;
    var v=isFill?((a.bg===0)?'none':a.bgc):a.color;
    var st=(a.style&&typeof styleDef==='function')?styleDef(a.style):null;
    var eff=v||(st&&(isFill?st.bg:st.color))||'';
    var ci=document.createElement('input');
    ci.type='color';ci.className='dgt-col';
    var rv=(eff&&eff!=='none')?tokVal(eff):'';
    ci.value=/^#[0-9a-f]{6}$/i.test(rv)?rv:(isFill?'#16273a':'#e6eef5');
    ci.classList.toggle('dgt-unset',!v||v==='none');
    ci.title=(isFill?'Fill':'Text colour')+' of this box'
      +(v?(v==='none'?' \u2014 none':''):' \u2014 the type\u2019s own');
    ci.addEventListener('click',function(e){e.stopPropagation();});
    ci.addEventListener('input',function(){
      if(isFill){a.bgc=ci.value;delete a.bg;}
      else a.color=ci.value;
      ci.classList.remove('dgt-unset');
      markDirty();refresh();
    });
    ci.addEventListener('change',function(){dgWrite();});
    wrap.appendChild(ci);
    var nb=document.createElement('button');
    nb.className='dbtn dgt-colb';nb.type='button';
    nb.textContent=isFill?'None':'Default';
    nb.title=isFill?'No fill behind this box'
      :'Back to the type\u2019s own colour';
    nb.setAttribute('aria-pressed',(isFill?(a.bg===0):!a.color).toString());
    nb.addEventListener('click',function(e){
      e.stopPropagation();
      if(isFill){
        if(a.bg===0){delete a.bg;} else {a.bg=0;}
      } else delete a.color;
      dgWrite();
    });
    wrap.appendChild(nb);
    return wrap;
  }
  /* ONE LIST OF TYPEFACES, copied into each row's menu (2026-10-09,
     speed, editor #7): seventeen options built one by one per row was a
     sixth of the table's cost. The copy is the same list, made once. */
  var dgFaceTpl=null;
  function dgFaceList(){
    if(!dgFaceTpl){
      dgFaceTpl=document.createElement('select');
      var o0=document.createElement('option');
      o0.value='';o0.textContent='default';dgFaceTpl.appendChild(o0);
      FONTS.forEach(function(f){
        var o=document.createElement('option');
        o.value=f.id;o.textContent=f.label;dgFaceTpl.appendChild(o);
      });
    }
    return dgFaceTpl;
  }
  function dgFaceCell(r){
    var sel=dgFaceList().cloneNode(true);
    sel.className='dgt-face dgt-facesel';
    var seen={};
    FONTS.forEach(function(f){seen[f.id]=1;});
    /* a typed family name is not in the table: offer it as itself */
    if(r.a.font&&!seen[r.a.font]){
      var ox=document.createElement('option');
      ox.value=r.a.font;ox.textContent=r.a.font;sel.appendChild(ox);
    }
    sel.value=r.a.font||'';
    sel.title='Typeface of this box \u2014 default is the type\u2019s own';
    sel.addEventListener('click',function(e){e.stopPropagation();});
    sel.addEventListener('keydown',function(e){e.stopPropagation();});
    sel.addEventListener('change',function(){
      if(sel.value) r.a.font=sel.value; else delete r.a.font;
      dgWrite();
    });
    return sel;
  }
  /* pt: the cell reads and writes POINTS (T411) -- the unit the ribbon's
     Text size box and the type screen speak -- and a box that says
     nothing shows what it gets, greyed, rather than an empty cell. */
  function dgNum(r,key,step,pt){
    var inp=document.createElement('input');
    inp.type='number';inp.step=step||'0.5';inp.className='dgt-n';
    var v0=r.a[key];
    if(pt){
      inp.value=(v0!=null)?Math.round(v0*5.4):'';
      var st=(r.a.style&&typeof styleDef==='function')
        ?styleDef(r.a.style):null;
      var eff=(st&&st.size)||(r.a.k==='table'?2.2:2.6);
      inp.placeholder=String(Math.round(eff*5.4));
      inp.title='Text size in points — empty means the type’s '
        +'own '+Math.round(eff*5.4)+' pt';
    } else {
      inp.value=(v0!=null)?Math.round(v0*10)/10:'';
      inp.title=key.toUpperCase()+' of this box';
    }
    inp.addEventListener('click',function(e){e.stopPropagation();});
    inp.addEventListener('keydown',function(e){
      e.stopPropagation();
      if(e.key==='Enter') inp.blur();
    });
    inp.addEventListener('change',function(){
      var v=parseFloat(inp.value);
      if(!isFinite(v)){delete r.a[key];}
      else r.a[key]=pt?Math.round(v/5.4*100)/100:Math.round(v*10)/10;
      if(key==='x'||key==='y') delete r.a.anch;
      markDirty();refresh();renderFilm();
      var ov=$('#deck-design'); if(ov) dgBodyKeep(ov);
    });
    return inp;
  }
  function dgTable(body,ov){
    var rows=dgRows();
    var wrap=document.createElement('div');wrap.className='dgt';
    var bar=document.createElement('div');bar.className='dgt-bar';
    function btn(label,title,fn,cls){
      var b=document.createElement('button');
      b.className='dbtn dg-b'+(cls?' '+cls:'');
      b.innerHTML=label;b.title=title;
      b.addEventListener('click',function(e){e.stopPropagation();fn(b);});
      bar.appendChild(b);
      return b;
    }
    btn('Select all','Tick every box of this kind, on every slide',
      function(){
        rows.forEach(function(r){dgMarked[dgRowKey(r)]=1;});
        dgBodyKeep(ov);
      }).disabled=!rows.length;
    btn('Clear selection','Clear every tick',function(){
      dgMarked={};dgBodyKeep(ov);}).disabled=!rows.length;
    var marked=dgMarkedRows(rows);
    var mb=btn(dgMatchArm
        ?'Now click the one to match'
        :(bic('swap')+' Match style of…'),
      dgMatchArm
        ?'Click the row you want the ticked boxes to look like'
        :'Tick the boxes to change, press this, then click the one they '
         +'should match',
      function(){dgMatchArm=!dgMatchArm;dgBodyKeep(ov);},
      dgMatchArm?'primary':'');
    mb.disabled=!marked.length&&!dgMatchArm;
    var what=document.createElement('select');
    what.className='dg-scope';
    [['all','everything'],['pos','only where it sits'],
     ['size','only how big it is'],['colour','only its colours'],
     ['font','only its type']].forEach(function(pr){
      var o=document.createElement('option');
      o.value=pr[0];o.textContent='match '+pr[1];
      if(dgMatchWhat===pr[0]) o.selected=true;
      what.appendChild(o);
    });
    what.title='What travels when you match: everything, or just one '
      +'part of it';
    what.addEventListener('change',function(){
      dgMatchWhat=what.value;dgBodyKeep(ov);});
    bar.appendChild(what);
    /* T411: THE SIZE, FOR ALL OF THEM AT ONCE (2026-09-13, user: "Style
       systems does not have a text size property in the tab. That was
       half the point of this"). A named type had its size on the left;
       the plain-text-boxes bucket had only a table with a blank Size
       cell per row. One box: points, given to the ticked rows, or to
       every row when none is ticked. */
    var isTx=!dgIsObj()||dgObjKind()==='text';
    if(isTx&&rows.length){
      var szw=document.createElement('span');szw.className='dgt-szw';
      var szl=document.createElement('span');szl.className='dgt-szlab';
      szl.textContent='Text size';szw.appendChild(szl);
      var szi=document.createElement('input');
      szi.type='number';szi.className='dgt-n dgt-szin';
      szi.step='1';szi.min='4';szi.max='200';szi.placeholder='pt';
      szi.title='Points. Enter, or Set, gives it to the ticked boxes '
        +'— or to every box when none is ticked';
      var setSize=function(){
        var pt=parseFloat(szi.value);
        if(!isFinite(pt)||pt<=0){toast('Type a size in points first');
          return;}
        var to=marked.length?marked:rows;
        to.forEach(function(r){r.a.size=Math.round(pt/5.4*100)/100;});
        markDirty();refresh();renderFilm();dgBodyKeep(ov);
        toast(to.length+' box'+(to.length===1?'':'es')+' at '
          +Math.round(pt)+' pt — Ctrl+Z undoes it');
      };
      szi.addEventListener('click',function(e){e.stopPropagation();});
      szi.addEventListener('keydown',function(e){
        e.stopPropagation();
        if(e.key==='Enter'){e.preventDefault();setSize();}
      });
      szw.appendChild(szi);
      var szb=document.createElement('button');
      szb.className='dbtn dg-b';szb.textContent='Set';
      szb.title='Give this size to the ticked boxes, or to all of them '
        +'when none is ticked';
      szb.addEventListener('click',function(e){
        e.stopPropagation();setSize();});
      szw.appendChild(szb);
      bar.appendChild(szw);
    }
    var count=document.createElement('span');
    count.className='dgt-count';
    if(dgPickedAny()){
      var np=dgPickedCount();
      var only=document.createElement('button');
      only.className='dbtn dg-b primary';
      only.textContent=np+' slide'+(np===1?'':'s')+' picked — show all';
      only.title='The slides you have picked in the column on the '
        +'right are filtering this table. Click to see every slide '
        +'again.';
      only.addEventListener('click',function(e){
        e.stopPropagation();dgSheetPick={};dgBodyKeep(ov);});
      bar.appendChild(only);
    }
    count.textContent=rows.length
      ?(marked.length?(marked.length+' of '+rows.length+' ticked')
        :(rows.length+' box'+(rows.length===1?'':'es')))
      :'none in this deck';
    bar.appendChild(count);
    wrap.appendChild(bar);

    if(!rows.length){
      var e=document.createElement('div');
      e.className='pf-ok';
      e.textContent='Nothing in this deck is a '+dgKindLabel()+' yet.';
      wrap.appendChild(e);
      body.appendChild(wrap);
      return;
    }
    var tbl=document.createElement('div');tbl.className='dgt-grid';
    /* the size and the face are columns whenever the rows are text,
       whether they were chosen by style or as plain text boxes (isTx,
       decided above the bar since T411) */
    /* T230: the first column is the WORDS, and for a plain text box
       you can type in it (2026-09-03, user: "would be good to edit
       the text in here as well"). A box with a list, and anything
       that is not text, shows its label: a one-line input cannot
       say what a three-level list is. */
    var heads=['','Slide','Contents',' X',' Y',' Width'];
    if(isTx) heads=heads.concat(['Size','Font']);
    heads=heads.concat(['Colour','Fill']); /* T469: fit, and the bar's words */
    heads.forEach(function(h){
      var c=document.createElement('div');
      c.className='dgt-h';c.textContent=h.trim();
      tbl.appendChild(c);
    });
    tbl.style.setProperty('--dgt-cols',heads.length);
    /* ONE ROW'S CELLS, built when the row comes into view (dgtVirtual) */
    function rowCells(r){
      var on=!!dgMarked[dgRowKey(r)];
      /* T367: "you can click on one and it highlights in the table
         below". The table is a CSS grid, so a row is lit cell by cell. */
      var inPl=!!(dgPlacePick&&dgPlaceKey(r.a)===dgPlacePick);
      var cells=[];
      function cell(node,cls){
        var c=document.createElement('div');
        c.className='dgt-c'+(cls?' '+cls:'')+(on?' on':'')
          +(inPl?' dgt-inplace':'');
        if(typeof node==='string') c.textContent=node;
        else if(node) c.appendChild(node);
        cells.push(c);
        return c;
      }
      var ck=document.createElement('input');
      ck.type='checkbox';ck.checked=on;ck.className='dgt-ck';
      ck.title='Tick this box for Match style of';
      ck.addEventListener('click',function(e){e.stopPropagation();});
      ck.addEventListener('change',function(){
        if(ck.checked) dgMarked[dgRowKey(r)]=1;
        else delete dgMarked[dgRowKey(r)];
        dgBodyKeep(ov);
      });
      cell(ck,'dgt-ckc');
      cell(String(r.si+1),'dgt-si');
      if(r.a.k==='text'&&!listOf(r.a)){
        var ti=document.createElement('input');
        ti.type='text';ti.className='dgt-tx';
        ti.value=String(r.a.text||'');
        ti.title='The words in this box. Enter commits it.';
        /* 2026-09-07: "please put the 'text' row as what it looks like
           in the slide ... should be a preview of the text." A column
           of identical grey inputs said nothing about which box was
           which; each is a specimen of its own box now, falling back to
           the style where the box says nothing itself. */
        (function(){
          var st=(r.a.style&&typeof styleDef==='function')
            ?styleDef(r.a.style):null;
          var col=r.a.color||(st&&st.color);
          var bg=(r.a.bg!==0)&&(r.a.bgc||(st&&st.bg));
          var fam=r.a.font||(st&&st.font);
          if(col) ti.style.color=tokVal(col);
          if(bg) ti.style.background=tokVal(bg);
          if(fam) ti.style.fontFamily=fontCss(fam);
          if(r.a.b||(st&&st.b)) ti.style.fontWeight='700';
          if(r.a.i||(st&&st.i)) ti.style.fontStyle='italic';
          if(r.a.align) ti.style.textAlign=r.a.align;
        })();
        ti.addEventListener('click',function(e){e.stopPropagation();});
        ti.addEventListener('keydown',function(e){
          e.stopPropagation();
          if(e.key==='Enter') ti.blur();
        });
        ti.addEventListener('change',function(){
          var v=ti.value;
          r.a.text=v;
          /* the rich copy follows the plain one, escaped -- the
             same pair setListStyle keeps in step */
          if(r.a.html!==undefined) r.a.html=esc(v);
          markDirty();refresh();renderFilm();
          var ov2=$('#deck-design'); if(ov2) dgBodyKeep(ov2);
        });
        cell(ti,'dgt-what');
      } else {
        var lb2=document.createElement('span');
        lb2.className='dgt-lab';lb2.textContent=annotLabel(r.a);
        lb2.title=listOf(r.a)
          ?'A list: edit its words on the slide'
          :annotLabel(r.a);
        cell(lb2,'dgt-what');
      }
      cell(dgNum(r,'x'),'dgt-num');
      cell(dgNum(r,'y'),'dgt-num');
      cell(dgNum(r,'w'),'dgt-num');
      if(isTx){
        cell(dgNum(r,'size','1',true),'dgt-num');   /* T411: in pt */
        cell(dgFaceCell(r),'dgt-face-c');           /* T490: editable */
      }
      cell(dgColCell(r,'color',false),'dgt-swc');   /* T490: editable */
      cell(dgColCell(r,'bgc',true),'dgt-swc');
      cells.forEach(function(c){
        /* the row is the click target: matching, and going to look at it */
        c.addEventListener('click',function(){
          if(dgMatchArm){
            var n=dgMatchTo(r.a,dgMarkedRows(dgRows()));
            dgMatchArm=false;
            if(n){markDirty();refresh();renderFilm();
              toast(n+' box'+(n===1?'':'es')+' now match slide '
                +(r.si+1)+' — Ctrl+Z undoes it');}
            dgBodyKeep(ov);
            return;
          }
          if(ck.checked){delete dgMarked[dgRowKey(r)];ck.checked=false;}
          else {dgMarked[dgRowKey(r)]=1;ck.checked=true;}
          dgBodyKeep(ov);
        });
      });
      return cells;
    }
    tbl._dgWhat=dgTableWhat();   /* which table it is (dgBodyKeep) */
    dgtVirtual(tbl,rows,rowCells);
    wrap.appendChild(tbl);
    body.appendChild(wrap);
  }
  /* ---- THE TABLE DRAWS THE ROWS YOU CAN SEE (2026-10-09, speed,
     editor #7) ------------------------------------------------------------
     "All text boxes" on a 60-slide deck is 120 rows of ten editable
     cells -- a text field, four number boxes, a typeface list, two
     colour pickers -- and every one was built, styled, laid out and
     painted on the click: a 540-680 ms freeze at 4x, 1.0 s of main
     thread, and again on every tick and edit (each redraws the body).
     The table is its own scroller, ten rows tall, so the rows are drawn
     as they come into view: the ones in sight and DGT_OVER either side,
     and a spacer for the rest that is exactly as tall as the rows it
     stands for, so the scrollbar, the scroll position and every row's
     place are the table's as they always were. A row that holds the
     focus is never taken away, and tabbing to the edge of what is drawn
     draws the next rows, so the keyboard walks the whole table. */
  var DGT_OVER=12,dgtPitch=35,dgtHeadH=31,dgtKeepTop=0;
  function dgTableWhat(){return dgSel+'|'+dgView;}
  function dgtVirtual(tbl,rows,rowCells){
    var n=rows.length,drawn={},a=0,b=0;
    var pre=document.createElement('div');pre.className='dgt-spacer';
    var post=document.createElement('div');post.className='dgt-spacer';
    tbl.appendChild(pre);tbl.appendChild(post);
    function spacers(){
      /* a spacer is one grid row standing for k rows: their heights and
         the k-1 gaps between them (the grid adds its own gap after it) */
      pre.hidden=!a;
      if(a) pre.style.height=(a*dgtPitch-1)+'px';
      post.hidden=b>=n;
      if(b<n) post.style.height=((n-b)*dgtPitch-1)+'px';
    }
    function rowAt(el){
      var c=el&&el.closest&&el.closest('.dgt-c');
      return (c&&c.parentNode===tbl&&c.dataset.dgtRow!=null)?+c.dataset.dgtRow:-1;
    }
    function build(i){
      var cs=rowCells(rows[i]);
      cs.forEach(function(c){c.dataset.dgtRow=String(i);});
      return cs;
    }
    function frag(from,to){
      var f=document.createDocumentFragment();
      for(var i=from;i<to;i++){
        drawn[i]=build(i);
        drawn[i].forEach(function(c){f.appendChild(c);});
      }
      return f;
    }
    function show(na,nb){
      na=Math.max(0,Math.min(n,na));nb=Math.max(na,Math.min(n,nb));
      /* the row being typed in stays, and the range stays one run */
      var fi=rowAt(document.activeElement);
      if(fi>=a&&fi<b){na=Math.min(na,fi);nb=Math.max(nb,fi+1);}
      if(na===a&&nb===b) return;
      var i;
      if(nb<=a||na>=b){
        for(i=a;i<b;i++) drawn[i].forEach(function(c){c.remove();});
        drawn={};
        tbl.insertBefore(frag(na,nb),post);
      } else {
        for(i=a;i<na;i++){drawn[i].forEach(function(c){c.remove();});delete drawn[i];}
        for(i=nb;i<b;i++){drawn[i].forEach(function(c){c.remove();});delete drawn[i];}
        if(na<a) tbl.insertBefore(frag(na,a),pre.nextSibling);
        if(nb>b) tbl.insertBefore(frag(b,nb),post);
      }
      a=na;b=nb;
      spacers();
    }
    function wantAt(top,h){
      var first=Math.floor(Math.max(0,top-dgtHeadH)/dgtPitch);
      var vis=Math.ceil(h/dgtPitch)+1;
      return [first-DGT_OVER,first+vis+DGT_OVER];
    }
    /* first draw: the window the table will open at (its kept scroll),
       at most 52vh tall (the table's own max-height) */
    var w0=wantAt(dgtKeepTop,(window.innerHeight||700)*0.52);
    show(w0[0],w0[1]);
    var frame=null;
    function sync(){
      frame=null;
      if(!tbl.isConnected) return;
      var w=wantAt(tbl.scrollTop,tbl.clientHeight);
      show(w[0],w[1]);
    }
    tbl.addEventListener('scroll',function(){
      if(frame==null) frame=requestAnimationFrame(sync);
    },{passive:true});
    /* the keyboard: a field near either edge of what is drawn draws on */
    tbl.addEventListener('focusin',function(e){
      var i=rowAt(e.target); if(i<0) return;
      if(i>=b-2&&b<n) show(a,b+DGT_OVER);
      if(i<=a+1&&a>0) show(a-DGT_OVER,b);
    });
    /* the pitch is the grid's, measured once it is laid out (the frame
       that draws it lays it out anyway) and the spacers corrected */
    requestAnimationFrame(function(){
      if(!tbl.isConnected) return;
      var r0=drawn[a],r1=drawn[a+1];
      if(r0&&r1&&r0[0]&&r1[0]){
        var p=r1[0].getBoundingClientRect().top-r0[0].getBoundingClientRect().top;
        var h0=tbl.querySelector('.dgt-h');
        if(h0) dgtHeadH=h0.getBoundingClientRect().height+1;
        if(p>0&&Math.abs(p-dgtPitch)>0.01){dgtPitch=p;spacers();sync();}
      }
    });
  }
  /* T224: the outline sheet, lifted out of dgBody so the object
     views can show it too. Not one line of it changed. */
  function dgSheet(_unused,ov){
    var body=ov&&ov.querySelector('#dg-sheetcol');
    if(!body) return;
    body.innerHTML='';
    dgSectionHead(body,'Slides',
      'Choose slides to filter this view. Turn on outlines to move objects.');
    var tg=document.createElement('button');
    tg.className='dbtn dg-b';
    tg.setAttribute('aria-pressed',dgOutline?'true':'false');
    tg.innerHTML=bic('outline')+(dgOutline?' Outlines on':' Outlines off');
    tg.title='Draw a box round every object on every slide';
    tg.addEventListener('click',function(){
      dgOutline=!dgOutline;dgBody(ov);});
    body.appendChild(tg);
    var sheetScope=dgScopeSelect(dgSheetScope,function(){dgBodyKeep(ov);});
    sheetScope.title='Outlines from these slides only';
    body.appendChild(sheetScope);
    /* T231: the column picks slides, so it needs the same two buttons
       the table has (2026-09-03, user: "the thumbnails need a select all
       and an unselect all as well"). Select all takes the slides this
       column is actually showing, which is what the scope above says. */
    var picks=document.createElement('div');picks.className='dg-picks';
    function pickBtn(label,title,fn){
      var b=document.createElement('button');
      b.className='dbtn dg-b';b.textContent=label;b.title=title;
      b.addEventListener('click',function(e){e.stopPropagation();fn();});
      picks.appendChild(b);
      return b;
    }
    pickBtn('All slides','Pick every slide shown here',function(){
      (pres.slides||[]).forEach(function(_sl,i){
        if(dgInScope(dgSheetScope,i)) dgSheetPick[i]=1;});
      dgBodyKeep(ov);
    });
    pickBtn('Clear','Clear every picked slide',function(){
      dgSheetPick={};dgBodyKeep(ov);
    }).disabled=!dgPickedAny();
    var pc=document.createElement('span');
    pc.className='dg-pickn';
    /* T367: 2026-09-07, user: "'none picked- everything counts', the
       fucking fuck this text mean?" It meant "you have picked no
       slides, so the table below covers all of them", which is what it
       says now. */
    pc.textContent=dgPickedAny()
      ?(dgPickedCount()+' of these slides')
      :'all slides';
    picks.appendChild(pc);
    body.appendChild(picks);
    var sheet=document.createElement('div');
    sheet.className='dg-sheet'+(dgOutline?' outlined':'');
    (pres.slides||[]).forEach(function(sl,i){
      if(!dgInScope(dgSheetScope,i)) return;
      var cell=document.createElement('button');
      cell.className='dg-cell';
      /* the slide's NAME, not just its number: the whole point of
         hovering is finding out which slide you are looking at (T130) */
      var nm=slideTitle(sl);
      cell.title='Slide '+(i+1)+(nm?' \u2014 '+nm:'')
        +' \u2014 click to go there';
      var mini=miniDiagram(sl);
      cell.appendChild(mini);
      /* MOVE IT FROM HERE (T130). One drag proxy per object, sitting at
         the same page percentages inside the same relatively-positioned
         miniature, shown only while outlines are on. A drag writes the
         move through shiftAnnot -- the one translate helper, so a tied
         caption travels and an arrow moves by its endpoints exactly as
         it would on the canvas. A plain click still navigates: nothing
         is claimed until the pointer has actually moved. */
      (sl.annots||[]).forEach(function(a){
        if(!a||a.hide) return;
        /* AN ARROW IS ITS TWO ENDS, NOT A BOX (JVR-03). It used to be
           skipped here, which made "Every object" untrue for the one
           kind whose geometry is x1/y1,x2/y2 -- but the write-back was
           never the problem: shiftAnnot below already translates both
           endpoints and any dragged corners, exactly as a canvas drag
           does. Only the HANDLE was missing, and that is the bounding
           box of the line the miniature already draws -- arrowEnds is
           the same call the renderer makes, so a tied end puts the
           handle where the line really is rather than on the stale
           stored endpoint. */
        var bx,by,bw,bh;
        if(a.k==='arrow'){
          var ae=arrowEnds(null,sl,a,0);
          var axs=[ae.x1,ae.x2],ays=[ae.y1,ae.y2];
          arrowMids(a).forEach(function(m){
            axs.push(m[0]);ays.push(m[1]);});
          bx=Math.min.apply(null,axs);by=Math.min.apply(null,ays);
          bw=Math.max.apply(null,axs)-bx;bh=Math.max.apply(null,ays)-by;
          if(!isFinite(bx)||!isFinite(by)||!isFinite(bw)||!isFinite(bh))
            return;
          /* grow the HIT TARGET about the line without moving the line */
          if(bw<DG_HIT){bx-=(DG_HIT-bw)/2;bw=DG_HIT;}
          if(bh<DG_HIT){by-=(DG_HIT-bh)/2;bh=DG_HIT;}
        } else {
          bx=(a.x||0);by=(a.y||0);bw=(a.w||10);bh=(a.h||8);
        }
        var px=document.createElement('span');
        px.className='dg-drag'+(a.k==='arrow'?' is-arrow':'');
        px.style.left=bx+'%';px.style.top=by+'%';
        px.style.width=bw+'%';px.style.height=bh+'%';
        px.title=(annotLabel(a)||a.k)+' \u2014 slide '+(i+1)
          +(nm?' ('+nm+')':'')+'. Drag to move it from here.';
        px.addEventListener('pointerdown',function(e){
          var sx=e.clientX,sy=e.clientY,dragging=false;
          var mr=mini.getBoundingClientRect();
          if(!mr.width||!mr.height) return;
          try{px.setPointerCapture(e.pointerId);}catch(err){}
          function mv(ev){
            var dx=ev.clientX-sx,dy=ev.clientY-sy;
            if(!dragging&&Math.abs(dx)+Math.abs(dy)<3) return;
            dragging=true;
            ev.preventDefault();
            px.style.transform='translate('+dx+'px,'+dy+'px)';
          }
          function up(ev){
            px.removeEventListener('pointermove',mv);
            px.removeEventListener('pointerup',up);
            if(!dragging) return;   /* a plain click: the cell navigates */
            ev.preventDefault();ev.stopPropagation();
            px.style.transform='';
            /* pixels in the miniature are percent of the page, which is
               the whole reason the proxies live inside it */
            shiftAnnot(a,(ev.clientX-sx)/mr.width*100,
              (ev.clientY-sy)/mr.height*100);
            markDirty();
            if(i===cur) refresh();
            renderFilm();
            dgBodyKeep(ov);
            toast('Moved on slide '+(i+1)+' \u2014 Ctrl+Z undoes it');
          }
          px.addEventListener('pointermove',mv);
          px.addEventListener('pointerup',up);
        });
        /* a completed drag must not fall through as the cell's click */
        /* T224: a click TICKS this box in the table rather than
           closing the screen (2026-09-03, user: "clicking one of the
           slides down the bottom takes you to the slide, it should
           just select it and bring up the types of objects and you
           can click on the different ones to show where they are").
           A box of another kind switches the rail to ITS kind, which
           is the same gesture read the other way round. */
        px.addEventListener('click',function(e){
          if(px.style.transform) return;
          e.stopPropagation();
          if(!dgAnnotMatches(a)){
            dgSel=(a.k==='text'&&a.style)?a.style:('obj:'+a.k);
            dgMarked={};dgMatchArm=false;
            dgRail(ov);dgBody(ov);
            return;
          }
          var ai=(sl.annots||[]).indexOf(a);
          var k2=i+':'+ai;
          if(dgMarked[k2]) delete dgMarked[k2]; else dgMarked[k2]=1;
          dgBodyKeep(ov);
        });
        mini.appendChild(px);
      });
      var n=document.createElement('span');
      n.className='dg-celln';n.textContent=(i+1);
      cell.appendChild(n);
      /* ...and the slide itself narrows the table to it rather than
         walking you out of the screen. Click it again for all of them. */
      cell.classList.toggle('dg-pick',!!dgSheetPick[i]);
      cell.addEventListener('click',function(){
        /* cumulative: each click adds or removes one */
        if(dgSheetPick[i]) delete dgSheetPick[i]; else dgSheetPick[i]=1;
        dgBodyKeep(ov);
      });
      sheet.appendChild(cell);
    });
    body.appendChild(sheet);
  }
  /* what each colour on the board means, and only for the kinds that
     are actually there */
  /* WHERE THEY ACTUALLY ARE, GROUPED (2026-09-07, user: "What is one
     box outline with Title and the other is yellow? ... should just
     have how many are in each place (and some indication of which
     slides), like group 1, then below they are grouped into those
     groups so you can [see] which slides they are").
     The board drew one dashed rectangle (the default this type is given
     when you Apply) and a filled one per real box, and nothing said
     which was which. It now says so in words, and the real boxes are
     GROUPED by the place they sit in -- so "these nine are all in the
     same spot, these two are somewhere else" is readable without
     comparing rectangles by eye. Rounded to the nearest 2% because a
     box nudged by a pixel is in the same place as far as anyone
     looking at a deck is concerned. */
  function dgPlaceKey(a){
    function q(v){return Math.round((+v||0)/2)*2;}
    return q(a.x)+','+q(a.y)+','+q(a.w);
  }
  /* T367: which place the others are matched to. A group key, not a
     rectangle -- the standard is one of your own slides. */
  var dgPlacePick='';
  function dgPickedPlace(id){
    var hit=null;
    dgPlaceGroups(id).forEach(function(g){
      if(!hit&&g.key===dgPlacePick) hit=g;});
    return hit;
  }
  function dgPlaceGroups(id){
    var by={},order=[];
    dgFamilyWearers(id).forEach(function(w){
      if(dgPickedAny()&&!dgSheetPick[w.s]) return;
      var k=dgPlaceKey(w.a);
      if(!by[k]){by[k]={key:k,a:w.a,ws:[]};order.push(k);}
      by[k].ws.push(w);
    });
    /* the biggest group first: it is the one that IS the standard */
    return order.map(function(k){return by[k];}).sort(function(x,y){
      return y.ws.length-x.ws.length;});
  }
  function dgKeyList(key,id){
    $$('.dg-keyit,.dg-place',key).forEach(function(n){n.remove();});
    var groups=dgPlaceGroups(id);
    groups.forEach(function(g,gi){
      var wrap=document.createElement('div');
      wrap.className='dg-place';
      /* T367: THE GROUP IS THE CHOICE. Click it and its boxes light up
         in the table below and it becomes the one the others are moved
         onto -- "you can click on one and it highlights in the table
         below ... then you can make the others match that one". */
      var head=document.createElement('button');
      head.type='button';
      head.className='dg-placehead'+(dgPlacePick===g.key?' on':'');
      head.textContent=g.ws.length+' box'+(g.ws.length===1?'':'es')+' here';
      head.title=dgPlacePick===g.key
        ?'At x '+Math.round(g.a.x||0)+', y '+Math.round(g.a.y||0)
          +'. The others get moved here. Click again to unpick it.'
        :'Pick this position at x '+Math.round(g.a.x||0)+', y '
          +Math.round(g.a.y||0)+'. Its boxes light up below, and the rest '
          +'can be moved onto it.';
      head.addEventListener('click',function(e){
        e.stopPropagation();
        dgPlacePick=(dgPlacePick===g.key)?'':g.key;
        dgBodyKeep($('#deck-design'));
      });
      wrap.appendChild(head);
      if(dgPlacePick===g.key) wrap.className='dg-place on';
      var list=document.createElement('span');
      list.className='dg-placeslides';
      var slidesLabel=document.createElement('span');
      slidesLabel.className='dg-placeslides-label';
      slidesLabel.textContent='Slides';list.appendChild(slidesLabel);
      g.ws.forEach(function(w){
        var s=document.createElement('button');
        s.className='dg-slidechip';
        s.textContent=(w.s+1);
        s.title='Slide '+(w.s+1)+' \u2014 go to it';
        s.addEventListener('click',function(e){
          e.stopPropagation();dgClose();go(w.s);});
        list.appendChild(s);
      });
      wrap.appendChild(list);
      key.appendChild(wrap);
    });
    if(!groups.length){
      var none=document.createElement('span');
      none.className='dg-keyit';
      none.textContent='No box wears this type yet';
      key.appendChild(none);
    }
    if(!dgShowOthers) return;
    var seen={};
    dgBoardSlides().forEach(function(e){
      (e.sl.annots||[]).forEach(function(a){
        if(!a||a.hide) return;
        if(a.k==='text'&&dgInFamily(a.style,id)) return;
        seen[a.k]=1;
      });
    });
    Object.keys(seen).forEach(function(k){
      var it=document.createElement('span');
      it.className='dg-keyit';
      it.style.setProperty('--dg-kc',DG_KIND_COL[k]||'#8aa0b0');
      it.textContent=DG_KIND_WORD[k]||k;
      key.appendChild(it);
    });
  }
  /* ---- T443: WHO WEARS WHAT (2026-09-14, user: "the fix mismatched
     text makes no sense ... It should tell you something like: 4
     heading with this style, 3 with this ... the style system does a
     better job of this ... this can just be something that is
     incorporated into the style systems better"). One row per style
     the deck uses: how many boxes wear it, how many of those were
     changed by hand since, and the one click that puts the style back
     on them. Then the boxes wearing nothing, banded by size, with the
     style the check would give them. The same survey the old tile ran
     (standardise), read as a table instead of a list of complaints. */
  /* T490: the per-style counts FOLDED INTO THE STYLE ROWS. The rail
     listed every used style twice -- a "who wears what" count row and,
     directly under it, the type row with the same name and number
     (2026-09-15 review). The count, the "changed by hand" note and its
     Match button live on the style's own row now (dgOddNote, under
     styleRow); this table keeps only what has no row of its own: the
     boxes wearing nothing, banded by size. */
  function dgOddNote(id,d,ov,r){
    var list=(r&&r.named&&r.named[id])||[]; if(!list.length) return null;
    var odd=list.filter(function(p){return !stdMatchesStyle(p.a,d);});
    if(!odd.length) return null;
    var row=document.createElement('div');row.className='dg-cnt dg-cnt-odd dg-rownote';
    var note=document.createElement('span');
    note.className='dg-cnt-note';
    note.textContent=odd.length+' box'+(odd.length===1?' differs':'es differ');
    row.appendChild(note);
    var b=document.createElement('button');
    b.type='button';b.className='dbtn dg-cnt-fix';
    b.textContent='Reset';
    b.title='Put the '+(d.label||id)+' style back on the '+odd.length
      +' that were changed by hand';
    b.addEventListener('click',function(e){
      e.stopPropagation();
      stdFix(odd,function(a){applyStyleTo(a,id);},
        odd.length+' box'+(odd.length===1?'':'es')+' put back');
      dgRail(ov);dgBody(ov);
    });
    row.appendChild(b);
    return row;
  }
  function dgCounts(rail,ov){
    if(typeof standardise!=='function') return;
    var r=standardise();
    var host=document.createElement('div');host.className='dg-counts';
    var h=document.createElement('div');
    h.className='dg-family-name';h.textContent='no style yet';
    host.appendChild(h);
    var any=false;
    function cntRow(n,label,cls){
      var row=document.createElement('div');row.className='dg-cnt'+(cls||'');
      var nn=document.createElement('span');
      nn.className='dg-cnt-n';nn.textContent=String(n);
      var l=document.createElement('span');
      l.className='dg-cnt-l';l.textContent=label;l.title=label;
      row.appendChild(nn);row.appendChild(l);
      return row;
    }
    (r.bands||[]).forEach(function(bd){
      if(bd.boxes.length<2) return;
      any=true;
      var sug=(styleDef(bd.suggest)||{}).label||bd.suggest;
      var row=cntRow(bd.boxes.length,'at about '+Math.round(bd.size*5.4)
        +' pt',' dg-cnt-loose');
      var b=document.createElement('button');
      b.type='button';b.className='dbtn dg-cnt-fix';
      b.textContent='Make them '+sug;
      b.title='Give all '+bd.boxes.length+' the '+sug+' style; the odd '
        +'ones move to match the rest, the rest stay put';
      b.addEventListener('click',function(e){
        e.stopPropagation();stdAdopt(bd);dgRail(ov);dgBody(ov);});
      row.appendChild(b);
      host.appendChild(row);
    });
    if(any) rail.appendChild(host);
  }
  function dgRail(ov){
    var rail=ov.querySelector('#dg-list');
    rail.innerHTML='';
    /* T490: one survey for the rail -- the loose bands at the foot,
       the odd-wearer notes under the rows */
    var std=(typeof standardise==='function')?standardise():null;
    function styleRow(id,isVar){
      var d=styleDef(id); if(!d) return;
      var b=document.createElement('button');
      b.className='dg-row'+(id===dgSel?' on':'')+(isVar?' dg-rowvar':'');
      var nm=document.createElement('span');
      nm.className='dg-name';nm.textContent=d.label||id;
      /* Navigation is navigation, not a second specimen. Rendering every
         row at its style's own size made the rail itself look broken; the
         preview belongs in Look. Colour differences remain as chips. */
      var chip=null;
      if(d.color){
        chip=document.createElement('span');
        chip.className='dg-swatch';
        chip.style.background=tokVal(d.color);
      }
      var ct=document.createElement('span');
      ct.className='dg-count';
      var n=dgFamilyWearers(id).length;
      ct.textContent=n?(n+' box'+(n===1?'':'es')):'unused';
      b.appendChild(nm);
      if(chip) b.appendChild(chip);
      /* T314: the ground, as a second chip -- the name itself is left
         unpainted here on purpose (see above) */
      if(d.bg&&d.bg!=='none'){
        var chipBg=document.createElement('span');
        chipBg.className='dg-swatch dg-swatch-bg';
        chipBg.style.background=tokVal(d.bg);
        chipBg.title='Background '+tokVal(d.bg);
        b.appendChild(chipBg);
      }
      b.appendChild(ct);
      var par=isVar?parentOf(id):'';
      b.title=(d.label||id)+' — '+(d.size||2.6)+'% of the page height'
        +(par?(', a variation of '+(styleDef(par)||{}).label):'')
        +(n?(', worn by '+n+' box'+(n===1?'':'es')):', not used yet');
      b.addEventListener('click',function(){
        dgSel=id;dgMatchArm=false;dgRail(ov);dgBody(ov);});
      rail.appendChild(b);
      /* T490: "N changed by hand · Match N", under the row it is about */
      var oddRow=dgOddNote(id,d,ov,std);
      if(oddRow) rail.appendChild(oddRow);
    }
    /* T295: A FAMILY READS AS A FAMILY HERE TOO. styleOrder appends, so
       a variation of Heading 1 sat last, after Caption, with nothing
       saying what it varied -- the same complaint the Text styles menu
       had (T293), on the screen whose whole job is showing you the
       system.
       Each variation keeps its OWN row, its own board and its own
       re-stamp. dgWearers stays an exact match on a.style and must:
       dgRestamp is built on it and calls applyStyleTo with the SELECTED
       id, so one loosened predicate would silently repaint every colour
       variation in its parent's colour the next time anyone nudged
       Heading 1. */
    var stylesHead=document.createElement('div');
    stylesHead.className='hd-lab';stylesHead.textContent='Text styles';
    rail.appendChild(stylesHead);
    var listed={};
    styleOrder().forEach(function(id){
      if(listed[id]||parentOf(id)) return;
      /* The rail is a catalogue of types this deck actually uses, not a
         promise of every built-in role.  Empty Body/Caption rows made the
         left side look like a second settings menu and hid the real types. */
      var vars=variantsOf(id).filter(function(v){
        return dgWearers(v).length||v===dgSel;});
      listed[id]=1;
      variantsOf(id).forEach(function(v){listed[v]=1;});
      if(!dgFamilyWearers(id).length&&!vars.length&&id!==dgSel) return;
      styleRow(id,false);
      vars.forEach(function(v){
        styleRow(v,true);
      });
    });
    styleOrder().forEach(function(id){
      if(listed[id]) return;       /* a variation whose parent has gone */
      if(dgWearers(id).length||id===dgSel) styleRow(id,false);
    });
    /* T224: and the things that are not text. A figure has no style
       registry to edit, but it has a position, a size and a place in
       the table -- which is what the ask was about (2026-09-03,
       user: "I wanted more than just titles, also images etc"). */
    /* Do not print a heading for a section with no rows. Text-only decks
       used to end with a vacant "everything else" label even though the
       rows beneath it correctly filtered unused object kinds. */
    var hd=null;
    DG_OBJ_KINDS.forEach(function(pr){
      var key='obj:'+pr[0];
      var b2=document.createElement('button');
      b2.className='dg-row'+(key===dgSel?' on':'');
      var nm2=document.createElement('span');
      nm2.className='dg-name';
      nm2.innerHTML=bic(pr[2])+' '+esc(pr[1]);
      var ct2=document.createElement('span');ct2.className='dg-count';
      var was=dgSel; dgSel=key;
      var n2=dgRows().length;
      dgSel=was;
      /* T367: a kind this deck has none of is not a row (2026-09-07,
         user: "don't put an object type (e.g. citations) if it isn't
         used"). It listed all seven always, so most decks read as a
         column of "none" with the two kinds you actually have buried in
         it. The one it is showing stays, whatever its count, or
         choosing an empty kind would make its own row vanish. */
      if(!n2&&key!==dgSel) return;
      /* T470: the head says "else" -- with no text styles above it
         there is no else, and with no rows under it there is nothing */
      if(!n2&&!dgAnyStyleWorn()) return;
      if(!hd){
        hd=document.createElement('div');
        hd.className='hd-lab';hd.textContent='Objects';
        rail.appendChild(hd);
      }
      ct2.textContent=String(n2);
      b2.appendChild(nm2);b2.appendChild(ct2);
      b2.title=pr[1]+' in this deck'+(n2?(': '+n2):': none yet');
      b2.addEventListener('click',function(){
        dgSel=key;dgView='boxes';dgMatchArm=false;dgRail(ov);dgBody(ov);});
      rail.appendChild(b2);
    });
    /* T490: the boxes wearing nothing, banded by size, AFTER the rows --
       they are the one thing without a row of their own */
    dgCounts(rail,ov);   /* T443 */
  }
  /* ---- the board: where a named type SITS by default ------------------
     The one genuinely new idea. A style has always said how a Heading
     looks and never where it goes, so "global heading layouts" could not
     be expressed at all. x/y/w live on the same pres.styles record, so
     no new deck key and no new documentation: `styles` is already "this
     deck's overrides of the named text types". */
  /* ---- T230: THE BOARD SHOWS THE REAL BOXES ---------------------------
     (2026-09-03, user: "right now it shows you the masters, but there
     can be individuals. Would be good if you could see not just the
     master, but location of all individual headings, then you can also
     tick a box that shows 'all other items', so you know if your heading
     is going to overlap with something (should be a colour for every
     different thing, but the one in question glows and has a thicker
     border)".)
     The board shows every box that wears the style and, when asked,
     everything else on those slides, one colour per kind. So the question
     "will my heading land on the figure" is answered by looking rather than
     by pressing a button and undoing it. T521 starts focused on the selected
     style; Show other objects is directly above the canvas when overlap
     context is useful. */
  var dgShowOthers=false;
  var DG_KIND_COL={text:'#6b9bff',cell:'#f0a848',image:'#a586e8',
    rect:'#46a892',table:'#e0a5c6',flip:'#39a9c0',arrow:'#ff6b57',
    line:'#ff6b57',draw:'#ff6b57',chart:'#7fd7c0'};
  /* T384: the key said "cell" -- the model's word, not the user's */
  var DG_KIND_WORD={text:'other text',cell:'figure',image:'picture',
    rect:'shape',table:'table',flip:'flip book',arrow:'arrow',line:'line',
    draw:'drawing',chart:'chart'};
  function dgKindCol(a){
    return (a&&DG_KIND_COL[a.k])||'#8aa0b0';
  }
  function dgBoardSlides(){
    var out=[];
    (pres.slides||[]).forEach(function(sl,si){
      if(dgPickedAny()&&!dgSheetPick[si]) return;
      out.push({sl:sl,si:si});
    });
    return out;
  }
  function dgBoardWords(b,a,def){
    var st=def||((a.style&&typeof styleDef==='function')
      ?styleDef(a.style):null)||{};
    var words=String(a.text||'').replace(/\s+/g,' ').trim();
    var t=document.createElement('span');
    t.className='dg-realtx';
    t.textContent=words||annotLabel(a);
    if(!words) t.classList.add('dg-realempty');
    var size=a.size||st.size||2.6;
    t.style.fontSize=size.toFixed(2)+'cqh';
    var col=a.color||st.color;
    t.style.color=tokVal(col||'@ink');
    var fam=a.font||st.font;
    if(fam) t.style.fontFamily=fontCss(fam);
    if(a.b||st.b) t.style.fontWeight='700';
    if(a.i||st.i) t.style.fontStyle='italic';
    t.style.textAlign=a.align||st.align||'left';
    b.appendChild(t);
  }
  function dgGhostsFor(board,id){
    $$('.dg-real,.dg-other',board).forEach(function(n){n.remove();});
    /* T279: the board drew every wearer of the style identically -- same
       1px amber box, same title of just "slide N" -- so it was a map of
       WHERE they are and said nothing about whether any of them had
       stopped keeping to the style. Read the verdict off the same
       predicate the Fix-mismatched-text screen uses, once per repaint. */
    var def=(typeof styleDef==='function')?styleDef(id):null;
    var off=0;
    /* T384: ONE SET OF WORDS PER PLACE. Fourteen headings at 5,4 drew
       fourteen titles on top of each other and read as noise; the first
       box at a place carries the words, the rest are outlines. */
    var wordsAt={};
    dgBoardSlides().forEach(function(e){
      (e.sl.annots||[]).forEach(function(a){
        if(!a||a.hide) return;
        var mine=(a.k==='text'&&dgInFamily(a.style,id));
        if(!mine&&!dgShowOthers) return;
        var own=mine&&a.style!==id?styleDef(a.style):def;
        var bad=!!(mine&&own&&typeof stdMatchesStyle==='function'
          &&!stdMatchesStyle(a,own));
        if(bad) off++;
        var b=document.createElement('div');
        b.className=(mine?'dg-real':'dg-other')+(bad?' dg-off':'');
        /* T465: an arrow has endpoints, not a box -- drawn from a.x/a.w
           every line sat as a 10x6 box in the slide's top-left corner
           (2026-09-15 review). The same bounding box the outline sheet
           draws its proxies from. */
        var gx=a.x||0,gy=a.y||0,gw=a.w||10,gh=a.h||6;
        if(a.k==='arrow'&&typeof arrowEnds==='function'){
          var ae=arrowEnds(null,e.sl,a,0);
          var axs=[ae.x1,ae.x2],ays=[ae.y1,ae.y2];
          if(typeof arrowMids==='function')
            arrowMids(a).forEach(function(m){axs.push(m[0]);ays.push(m[1]);});
          gx=Math.min.apply(null,axs);gy=Math.min.apply(null,ays);
          gw=Math.max.apply(null,axs)-gx;gh=Math.max.apply(null,ays)-gy;
          if(!isFinite(gx)||!isFinite(gy)||!isFinite(gw)||!isFinite(gh)) return;
        }
        b.style.left=gx+'%';
        b.style.top=gy+'%';
        b.style.width=Math.max(1.5,gw)+'%';
        b.style.height=Math.max(1.5,gh)+'%';
        b.style.borderColor=mine?'':dgKindCol(a);
        /* T384: THE WORDS, IN THE BOX. An empty amber rectangle said
           where a heading was and nothing about what it looked like
           (2026-09-12, user: "the visual display is gone and
           confusing"). Each text box carries its own words at its own
           size -- container-query units, so 2.6% of the page height is
           2.6cqh of the board -- in its colour, face, weight and slant,
           the way the Fix-mismatched-text chips do. Other text is drawn
           faint so the board reads as the slide it is. */
        var at=(mine?'m':'o')+a.k+':'+dgPlaceKey(a);
        if(a.k==='text'&&!wordsAt[at]){
          wordsAt[at]=1;
          dgBoardWords(b,a,mine?def:null);
        }
        /* 2026-09-07: "when hovering above an object it should give an
           information bubble that is like 'chart from slide 7' and
           clicking on it takes you to that slide. Or if many gives you
           a list of them all." A title attribute says it after a
           second's wait and cannot be clicked, so the board grew a real
           bubble instead -- see dgBoard. */
        b.dataset.si=e.si;
        b.dataset.what=(mine?((styleDef(id)||{}).label||id):annotLabel(a))
          +' — slide '+(e.si+1)
          +(bad?' — no longer matches this style':'');
        board.appendChild(b);
      });
    });
    /* and say so in words as well as in weight, because a board you have
       to compare box-borders across is not an answer */
    var note=board.parentNode
      &&board.parentNode.querySelector('.dg-offnote');
    if(note){
      note.textContent=off
        ?(off+' of these no longer match the style')
        :'';
      note.hidden=!off;
    }
  }
  /* ---- T368: THE LOOKS THIS TYPE COMES IN ---------------------------
     2026-09-07, user: "when going to heading 1, it would be cool if
     there was like different styles of that etc. that people can change
     between".

     T317's ready-made looks existed and were only ever drawn in the
     Text-styles dropdown, which needs a box selected -- so the screen
     whose job is the type system offered none of them. Here they are on
     the type's own page: the variations that exist, then the ones you
     could make, each a specimen of what it would look like on THIS
     deck. A variation is a type in its own right, so making one puts a
     row in the rail and you swap by choosing it. */
  function dgLooks(host,id,ov){
    /* only a BASE type has variations; a variation is one */
    if(typeof variantsOf!=='function'||typeof parentOf!=='function') return;
    if(parentOf(id)) return;
    var have=variantsOf(id)||[];
    var offer=(typeof PRESET_LOOKS!=='undefined'?PRESET_LOOKS:[])
      .filter(function(look){
        if(typeof presetVariantOf==='function'&&presetVariantOf(id,look))
          return false;
        if(look.id==='by-section'
           &&!(pres.sections&&Object.keys(pres.sections).length)) return false;
        return true;
      });
    if(!have.length&&!offer.length) return;
    var wrap=document.createElement('div');
    wrap.className='dg-looks';
    if(have.length){
      var lab=document.createElement('span');
      lab.className='dg-lookslab';lab.textContent='Variations';
      wrap.appendChild(lab);
    }
    have.forEach(function(v){
      var b=document.createElement('button');
      b.className='dbtn dg-look on';
      b.textContent=(d0(v).label||v);
      dgSpecimen(b,v);
      b.title='Go to this variation';
      b.addEventListener('click',function(){
        dgSel=v;dgMatchArm=false;dgRail(ov);dgBody(ov);});
      wrap.appendChild(b);
    });
    /* T368: WHICH ONE A NEW SLIDE GETS. A layout's slots name the base
       type, so a variation you made and used everywhere still left the
       next new slide on the plain parent (2026-09-07, user: "When you
       select a text style, new slides don't get applied with it"). */
    if(have.length){
      var now=(pres.slot&&pres.slot[id])||id;
      var pick=document.createElement('select');
      pick.className='dg-slotpick';
      [id].concat(have).forEach(function(v){
        var o=document.createElement('option');
        o.value=v;o.textContent=(d0(v).label||v);
        if(v===now) o.selected=true;
        pick.appendChild(o);
      });
      pick.title='Which of these a new slide\u2019s '+(d0(id).label||id)
        +' box is given';
      pick.addEventListener('change',function(){
        pres.slot=pres.slot||{};
        if(pick.value===id) delete pres.slot[id];
        else pres.slot[id]=pick.value;
        if(!Object.keys(pres.slot).length) delete pres.slot;
        markDirty();
        toast('New slides get '+(d0(pick.value).label||pick.value));
      });
      var pl=document.createElement('span');
      pl.className='dg-lookslab';pl.textContent='New slides use';
      wrap.appendChild(pl);
      wrap.appendChild(pick);
    }
    var offers=null;
    if(offer.length){
      var more=document.createElement('details');
      more.className='dg-lookmore';
      var sum=document.createElement('summary');
      sum.className='dbtn dg-lookadd';sum.textContent='Add variation…';
      sum.setAttribute('role','button');
      sum.setAttribute('aria-expanded','false');
      more.appendChild(sum);
      offers=document.createElement('div');offers.className='dg-lookoffers';
      more.appendChild(offers);wrap.appendChild(more);
      more.addEventListener('toggle',function(){
        sum.setAttribute('aria-expanded',more.open?'true':'false');});
    }
    offer.forEach(function(look){
      var b=document.createElement('button');
      b.className='dbtn dg-look';
      b.textContent=look.label;
      /* a specimen of what it WOULD be: the parent's face and size with
         the look's own colours over it, resolved against this deck */
      var d=d0(id),dd=look.delta;
      b.style.fontWeight=(dd.b===0?0:(dd.b||d.b))?'700':'400';
      if(d.i) b.style.fontStyle='italic';
      if(d.font) b.style.fontFamily=fontCss(d.font);
      var col=tokVal(dd.color||d.color||'');
      if(col) b.style.color=col;
      if(dd.bg&&dd.bg!=='none') b.style.background=tokVal(dd.bg);
      if(dd.bdc&&dd.bdc!=='none') b.style.borderColor=tokVal(dd.bdc);
      b.title='Make \u201c'+look.label+'\u201d a variation of '
        +(d.label||id)+' \u2014 '+look.note+'. It keeps following '
        +(d.label||id)+' for everything else.';
      b.addEventListener('click',function(){
        if(typeof ensurePresetLook!=='function') return;
        var vid=ensurePresetLook(id,look);
        if(!vid){toast('Could not make that variation');return;}
        markDirty();
        dgSel=vid;dgMatchArm=false;dgRail(ov);dgBody(ov);
      });
      offers.appendChild(b);
    });
    host.appendChild(wrap);
  }
  function d0(id){return styleDef(id)||{};}
  function dgBoard(host,id){
    var board=document.createElement('div');
    board.className='dg-board';
    var page=pageOf();
    board.style.aspectRatio=(page.mm[0]/page.mm[1]).toFixed(4);
    /* T367: NO DASHED RECTANGLE. It was "the default place" a type gets
       when you Apply -- dragged here and stamped onto every box in the
       deck. The user, 2026-09-07: "there are many different styles of
       headings for depending on the slide ... I don't think that should
       be a thing the default for any." A Heading 1 on a section divider
       and a Heading 1 over two panels share no correct position, so the
       rectangle was a guess and Apply overwrote a real decision with
       it. What the board shows is where these boxes ARE. */
    host.appendChild(board);
    /* T279: the count in words, beside the board. Appended to the same
       host BEFORE the ghosts are drawn, because dgGhostsFor writes into
       it and looks for it as a sibling of the board. */
    var offnote=document.createElement('div');
    offnote.className='dg-offnote';offnote.hidden=true;
    host.appendChild(offnote);
    dgGhostsFor(board,id);
    /* ONE bubble for the whole board, moved and filled on hover -- a
       node per object would be hundreds of them on a real deck. Every
       object under the pointer is named, because "which of these am I
       pointing at" is exactly the question a board of overlapping
       rectangles raises, and each name is a button to its slide. */
    var bub=document.createElement('div');
    bub.className='dg-bub';bub.hidden=true;
    host.appendChild(bub);
    board.addEventListener('mousemove',function(ev){
      var r=board.getBoundingClientRect();
      var hits=$$('.dg-real,.dg-other',board).filter(function(n){
        var q=n.getBoundingClientRect();
        return ev.clientX>=q.left&&ev.clientX<=q.right
          &&ev.clientY>=q.top&&ev.clientY<=q.bottom;
      });
      if(!hits.length){bub.hidden=true;return;}
      bub.innerHTML='';
      hits.slice(0,8).forEach(function(n){
        var line=document.createElement('button');
        line.className='dg-bubline';
        line.textContent=n.dataset.what||'';
        line.addEventListener('click',function(e2){
          e2.stopPropagation();dgClose();go(+n.dataset.si||0);});
        bub.appendChild(line);
      });
      if(hits.length>8){
        var more=document.createElement('span');
        more.className='dg-bubmore';
        more.textContent='and '+(hits.length-8)+' more here';
        bub.appendChild(more);
      }
      bub.hidden=false;
      var bw=bub.offsetWidth||160;
      bub.style.left=Math.max(0,Math.min(r.width-bw,
        ev.clientX-r.left+12))+'px';
      bub.style.top=Math.max(0,ev.clientY-r.top+14)+'px';
    });
    board.addEventListener('mouseleave',function(){bub.hidden=true;});
    /* the key, and the switch that turns the rest of the page on */
    var key=document.createElement('div');key.className='dg-key';
    /* T470: the same switch as the sheet column's Outlines, in the
       same shape -- it was a bare checkbox beside a boxed button on
       one screen (2026-09-15 review) */
    var ck=document.createElement('button');
    ck.type='button';ck.className='dbtn dg-b dg-keyck';
    function ckPaint(){
      ck.setAttribute('aria-pressed',dgShowOthers?'true':'false');
      ck.innerHTML=bic('eye')+' Show other objects';
    }
    ckPaint();
    ck.addEventListener('click',function(e){
      e.stopPropagation();
      dgShowOthers=!dgShowOthers;
      ckPaint();
      dgGhostsFor(board,id);
      dgKeyList(key,id);
    });
    ck.title='Draw every other object on these slides too';
    key.appendChild(ck);
    dgKeyList(key,id);
    /* The board can fill a laptop-height viewport. Put its controls first,
       so the way to reveal context is never hidden below the canvas. */
    host.insertBefore(key,board);

  }
  function dgSectionHead(host,text,sub){
    var h=document.createElement('div');
    h.className='dg-h';h.textContent=text;
    host.appendChild(h);
    if(sub){
      var p=document.createElement('p');
      p.className='dg-sub';p.textContent=sub;
      host.appendChild(p);
    }
  }
  function dgSheetButton(ov){
    var b=document.createElement('button');
    b.type='button';b.className='dbtn dg-sheet-toggle';
    b.setAttribute('aria-pressed',dgSheetOpen?'true':'false');
    b.innerHTML=bic('present')+' Slides'
      +(dgPickedAny()?' ('+dgPickedCount()+')':'');
    b.title='Show slide thumbnails to filter this view';
    b.addEventListener('click',function(){
      dgSheetOpen=!dgSheetOpen;dgBodyKeep(ov);});
    return b;
  }
  function dgTabs(body,ov,count){
    var nav=document.createElement('div');nav.className='dg-navrow';
    var tabs=document.createElement('div');
    tabs.className='dg-tabs';tabs.setAttribute('role','tablist');
    [['look','Appearance'],['place','Placement'],
     ['boxes','Individual boxes ('+count+')']].forEach(function(pr){
      var b=document.createElement('button');
      b.type='button';b.className='dbtn dg-tab';b.textContent=pr[1];
      b.setAttribute('role','tab');
      b.setAttribute('aria-selected',(dgView===pr[0]).toString());
      b.addEventListener('click',function(){
        dgView=pr[0];dgBodyKeep(ov);});
      tabs.appendChild(b);
    });
    nav.appendChild(tabs);
    if(dgView!=='look') nav.appendChild(dgSheetButton(ov));
    body.appendChild(nav);
  }
  function dgBody(ov){
    if(!ov) return;
    var body=ov.querySelector('#dg-body');
    body.innerHTML='';
    body.className='dg-body';
    var sheetcol=ov.querySelector('#dg-sheetcol');
    if(sheetcol){sheetcol.innerHTML='';sheetcol.hidden=true;}
    var id=dgSel,d=styleDef(id);
    /* T224: an object kind has no look to edit -- it has a table */
    if(dgIsObj()){
      /* T470: a deck with nothing to standardise said "Pictures --
         every one in this deck" over an empty table and three dead
         buttons, with no line saying what the screen is for
         (2026-09-15 review) */
      if(!dgRows().length&&!dgAnyStyleWorn()){
        body.innerHTML='<div class="selpane-empty">Nothing to '
          +'standardise yet. Add text and its styles are listed here; '
          +'pictures, tables, shapes and the rest get a table each, so '
          +'the ones that should match can be made to.</div>';
        return;
      }
      var objHead=document.createElement('div');objHead.className='dg-viewhead';
      dgSectionHead(objHead,dgKindLabel()+' \u2014 every one in this deck');
      objHead.appendChild(dgSheetButton(ov));body.appendChild(objHead);
      dgTable(body,ov);
      if(dgSheetOpen){
        if(sheetcol) sheetcol.hidden=false;
        dgSheet(body,ov);
      }
      return;
    }
    if(!d){body.innerHTML='<div class="selpane-empty">Pick a type on '
      +'the left.</div>';return;}
    var rec=dgStyleRec(id);
    var wear=dgFamilyWearers(id);

    /* ---- how it looks ----
       ONE line for the whole screen, and no other prose on it
       (2026-09-07, user: "There is soooo much unnecessary text here. I
       think almost all text is unnecessary, just one short description
       at the top"). Every control below says what it is by being what
       it is. */
    dgSectionHead(body,d.label||id);
    dgTabs(body,ov,wear.length);
    body.className='dg-body dg-view-'+dgView;
    /* T519: ONE QUESTION AT A TIME. Look, Position and the individual
       Boxes used to be two columns over a table with a permanent slide
       column, so all three jobs competed for attention. They keep their
       existing controls and model; the tabs only decide which job is in
       view. */
    var top=document.createElement('div');top.className='dg-top';
    var left=document.createElement('div');left.className='dg-typecol';
    var right=document.createElement('div');right.className='dg-placecol';
    left.hidden=dgView!=='look';right.hidden=dgView!=='place';
    top.appendChild(left);top.appendChild(right);
    body.appendChild(top);
    var spec=document.createElement('div');
    spec.className='dg-spec';
    spec.textContent='The quick brown fox jumps over the lazy dog';
    dgSpecimen(spec,id);
    /* on the deck's actual page colour, so a specimen reads the way the
       slide will */
    spec.style.background=deckPageBg();
    if(!d.color) spec.style.color=tokVal('@ink');
    left.appendChild(spec);
    dgLooks(left,id,ov);

    var row=document.createElement('div');row.className='dg-ctrls';
    /* T230: CLUSTERS, NOT ONE LONG ROW. Thirteen controls sat in one
       wrap with nothing saying which belonged with which (2026-09-03,
       user: "the buttons are a bit crammed. There is a lot of things
       again that feel like they are floating in no where"). Each
       group is a box with its name on it, the way a ribbon run is. */
    var cur_=null;
    function grp(name){
      var g=document.createElement('div');g.className='dg-grp';
      g.dataset.group=name.toLowerCase()||'reset';
      var lb=document.createElement('span');
      lb.className='dg-grplab';lb.textContent=name;
      g.appendChild(lb);
      row.appendChild(g);cur_=g;
      return g;
    }
    function ctl(label,title,on,fn){
      var b=document.createElement('button');
      b.className='dbtn dg-b';b.textContent=label;b.title=title;
      if(on!=null) b.setAttribute('aria-pressed',on?'true':'false');
      b.addEventListener('click',function(){
        fn();dgRestamp(id);markDirty();refresh();dgRail(ov);dgBody(ov);});
      (cur_||row).appendChild(b);
      return b;
    }
    grp('Size');
    ctl('−','Smaller',null,function(){
      rec.size=Math.max(0.6,Math.round(((d.size||2.6)-0.2)*10)/10);});
    /* T411: a number you can TYPE, between the steppers -- "Text size
       26 pt" was a readout, and a readout is not a property */
    var sz=document.createElement('span');
    sz.className='dg-size';
    var typePct=d.size||2.6;
    var szIn=document.createElement('input');
    szIn.type='number';szIn.className='dgt-n dg-sizein';
    szIn.step='1';szIn.min='4';szIn.max='200';
    szIn.value=String(Math.round(typePct*5.4));
    szIn.setAttribute('aria-label','Text size in points');
    szIn.title=Math.round(typePct*5.4)+' pt text ('+typePct.toFixed(1)
      +'% of the page height) — type a size in points';
    szIn.addEventListener('keydown',function(e){
      e.stopPropagation();
      if(e.key==='Enter'){e.preventDefault();szIn.blur();}
    });
    szIn.addEventListener('change',function(){
      var pt=parseFloat(szIn.value);
      if(!isFinite(pt)||pt<=0) return;
      rec.size=Math.max(0.6,Math.min(30,Math.round(pt/5.4*100)/100));
      dgRestamp(id);markDirty();refresh();dgRail(ov);dgBody(ov);
    });
    sz.appendChild(szIn);
    var szU=document.createElement('span');szU.textContent=' pt';
    sz.appendChild(szU);
    (cur_||row).appendChild(sz);
    ctl('+','Bigger',null,function(){
      rec.size=Math.min(30,Math.round(((d.size||2.6)+0.2)*10)/10);});
    grp('Emphasis');
    ctl('B','Bold',!!d.b,function(){
      if(d.b) rec.b=0; else rec.b=1;});
    ctl('I','Italic',!!d.i,function(){
      if(d.i) rec.i=0; else rec.i=1;});
    grp('Alignment');
    ['left','center','right'].forEach(function(al){
      ctl(al==='left'?'←':al==='right'?'→':'↔',
        'Align '+al,(d.align||'left')===al,function(){rec.align=al;});
    });
    /* ---- T223: EVERYTHING A STYLE IS, not size and bold ------------
       (2026-09-03, user: "I said I wanted also colours of text,
       background colour, box border colour, font style. I said I
       wanted everything.") The typeface, then three colours, each
       writing the same override record the size and weight do. */
    grp('Typeface');
    var fsel=document.createElement('select');
    fsel.className='dg-font';
    fsel.title='The typeface every box of this type takes';
    [['','Default face'],['sans','Sans'],['serif','Serif'],
     ['mono','Mono'],['system','System'],['hand','Handwritten']]
      .forEach(function(pr){
        var o=document.createElement('option');
        o.value=pr[0];o.textContent=pr[1];
        if((d.font||'')===pr[0]) o.selected=true;
        fsel.appendChild(o);
      });
    fsel.addEventListener('change',function(){
      if(fsel.value) rec.font=fsel.value; else delete rec.font;
      dgRestamp(id);markDirty();refresh();dgRail(ov);dgBody(ov);
    });
    (cur_||row).appendChild(fsel);
    grp('Colours');
    function dgCol(key,label,fallback,none){
      var wrap=document.createElement('span');wrap.className='dg-colw';
      var lb=document.createElement('span');
      lb.className='dg-collab';lb.textContent=label;
      wrap.appendChild(lb);
      var ci=document.createElement('input');
      ci.type='color';ci.className='dg-col';
      var v=d[key];
      var rv=tokVal(v);   /* T480: what a deck colour resolves to */
      ci.value=(v&&v!=='none'&&/^#[0-9a-f]{6}$/i.test(rv))?rv:fallback;
      ci.title=label+' \u2014 every box of this type'
        +(tokRef(v)?(' (a deck colour: '+tokRef(v)+'; a change here '
          +'unhooks it)'):'');
      ci.addEventListener('input',function(){
        rec[key]=ci.value;dgRestamp(id);markDirty();refresh();});
      ci.addEventListener('change',function(){dgRail(ov);dgBody(ov);});
      wrap.appendChild(ci);
      if(none){
        var nb=document.createElement('button');
        nb.className='dbtn dg-b';nb.textContent=none;
        nb.title='No '+label.toLowerCase()+' at all';
        nb.setAttribute('aria-pressed',(v==='none').toString());
        nb.addEventListener('click',function(){
          if(v==='none') delete rec[key]; else rec[key]='none';
          dgRestamp(id);markDirty();refresh();dgRail(ov);dgBody(ov);
        });
        wrap.appendChild(nb);
      }
      return wrap;
    }
    var cg=cur_;
    /* T469: the format bar's words, as the menu's editor says them */
    cg.appendChild(dgCol('color','Text','#e6eef5',''));
    cg.appendChild(dgCol('bg','Fill','#16273a','None'));
    cg.appendChild(dgCol('bdc','Border','#8aa0b0','None'));
    grp('');
    var rst=document.createElement('button');
    rst.className='dbtn dg-b';rst.textContent='Reset appearance';
    rst.title='Back to this type’s built-in look';
    rst.addEventListener('click',function(){
      var st=deckStyles();
      var keep={};
      ['x','y','w'].forEach(function(k){
        if(st[id]&&st[id][k]!=null) keep[k]=st[id][k];});
      st[id]=keep;
      dgRestamp(id);markDirty();refresh();dgRail(ov);dgBody(ov);
    });
    (cur_||row).appendChild(rst);
    left.appendChild(row);

    /* the bubble is placed against the board's own box, so the board
       needs a positioned parent of its own, not the column with a
       label above it */
    var boardWrap=document.createElement('div');
    boardWrap.className='dg-boardwrap';
    right.appendChild(boardWrap);
    dgBoard(boardWrap,id);
    /* the put, scoped (T130): everywhere stays the default, but "these
       headings, in this section" is the sentence the ask was written
       in, and a numeric range covers the rest */
    var putRow=document.createElement('div');
    putRow.className='dg-putrow';
    /* ---- T231: APPLY TO WHAT IS SELECTED -----------------------------
       (2026-09-03, user: "the apply to x boxes, should just be for the
       selection.") There were three ways to scope this one action --
       a scope select of its own, the ticked rows in the table, and the
       slides picked in the column -- and only the first of them did
       anything. The selector is gone; the button reads the selection,
       in the order you would say it out loud: the boxes you ticked, or
       failing that the slides you picked, or failing that all of them. */
    var pickMode=function(){
      var ticked=wear.filter(function(w){
        return dgMarked[w.s+':'+w.i];});
      if(ticked.length) return {ws:ticked,how:'ticked'};
      if(dgPickedAny()) return {ws:wear.filter(function(w){
        return dgSheetPick[w.s];}),how:'picked'};
      return {ws:wear,how:'all'};
    };
    var inScope=function(){return pickMode().ws;};
    var put=document.createElement('button');
    put.className='dbtn primary dg-put';
    function putWhat(){
      var m=pickMode();
      if(m.how==='ticked') return m.ws.length+' ticked box'
        +(m.ws.length===1?'':'es');
      if(m.how==='picked') return m.ws.length+' box'
        +(m.ws.length===1?'':'es')+' on the '+dgPickedCount()
        +' slide'+(dgPickedCount()===1?'':'s')+' you picked';
      return (m.ws.length>1?'all ':'')+m.ws.length+' box'
        +(m.ws.length===1?'':'es');
    }
    function putSync(){
      var m=pickMode(),ws=m.ws;
      /* a zero-target command was the biggest button on the surface
         (JVUX-10): a zero-target command is an empty state, not a call
         to action */
      /* T223: "the button says 'put all 8 of them there', what the
         heck. Do you think about writing? 'Apply to all'" */
      /* T367: the target is a GROUP you picked on the board, not a
         rectangle nobody chose. With nothing picked there is nothing to
         match to, and the button says which half is missing rather than
         going grey for two different reasons. */
      var tgt=dgPickedPlace(id);
      var others=tgt
        ?ws.filter(function(w){return dgPlaceKey(w.a)!==tgt.key;}):[];
      put.innerHTML=!ws.length
        ?(m.how==='all'
          ?'No boxes wear this style'
          :'None of what you selected wears this style')
        :(!tgt
          ?'Pick a place above to match'
          :(others.length
            ?(bic('align')+' Move the other '+others.length+' box'
              +(others.length===1?'':'es')+' here')
            :'They are all in this place already'));
      put.classList.toggle('primary',!!others.length);
      put.disabled=!others.length;
      put.title=others.length
        ?('Move them onto the place you picked. Ctrl+Z undoes the lot.'
          +(m.how==='all'
            ?' Tick rows in the table, or pick slides on the right, to '
              +'do fewer.':''))
        :(ws.length&&!tgt?'Click a group above first':'');
    }
    put.addEventListener('click',function(){
      var tgt=dgPickedPlace(id); if(!tgt) return;
      var n=0;
      inScope().forEach(function(w){
        if(dgPlaceKey(w.a)===tgt.key) return;
        w.a.x=tgt.a.x;w.a.y=tgt.a.y;
        if(tgt.a.w!=null) w.a.w=tgt.a.w;
        /* an anchored box measures from its anchor, so a moved box has
           to clear the anchor or it lands somewhere else */
        delete w.a.anch;
        n++;
      });
      if(!n) return;
      markDirty();refresh();renderFilm();dgBodyKeep(ov);
      toast(n+' '+(d.label||id)+' box'+(n===1?'':'es')
        +' moved — Ctrl+Z undoes it');
    });
    putRow.appendChild(put);
    putSync();
    right.appendChild(putRow);

    if(dgView==='boxes') dgTable(body,ov);
    if((dgView==='place'||dgView==='boxes')&&dgSheetOpen){
      if(sheetcol) sheetcol.hidden=false;
      dgSheet(body,ov);
    }
  }
  function openDesign(){
    dgClose();
    var ov=document.createElement('div');
    ov.className='deck-design';ov.id='deck-design';
    ov.innerHTML='<div class="dh-head">'
      +'<span class="dh-t">Style system — “'+esc(pres.name||'this deck')
      +'”</span><span class="deck-spring"></span>'
      /* T315: the screen whose job is "what is the standard" had no
         way to pick one */
      +'<button class="dbtn" id="dg-sets">'+bic('styles')
      +' Style sets\u2026</button>'
      +'<button class="dbtn" id="dg-check">'+bic('scope')
      +' Check consistency</button>'
      +'<button class="dbtn" id="dg-close">'+bic('exit')+' Close</button>'
      +'</div><div class="dg-main">'
      +'<div class="dg-rail" id="dg-list"></div>'
      +'<div class="dg-body" id="dg-body"></div>'
      /* T230: the slides go DOWN THE SIDE (2026-09-03, user: "the
         slide thumbnails should be down the side as that's the way
         people are used to viewing them"). One column, wider than
         the four-across grid they were in, so their words can be
         read. */
      +'<div class="dg-sheetcol" id="dg-sheetcol"></div></div>';
    /* T465: the page's colour rides onto the screen. It is mounted on
       body, outside .deck where --page-bg is set, so the board fell to
       its fallback and in Light drew the slide's white words on a white
       board (2026-09-15 review). */
    try{ov.style.setProperty('--page-bg',
      getComputedStyle(deckEl).getPropertyValue('--page-bg')||deckPageBg());
    }catch(err){}
    document.body.appendChild(ov);
    ov.querySelector('#dg-close').addEventListener('click',dgClose);
    /* T384: the door had no handler behind it. Same route the ribbon's
       own Style sets button takes; this screen closes first, because
       the picker is a dialog over the editor, not over this. */
    /* T465: the click that opens the next surface must not reach the
       overlay owner's outside-click, which would pop it the same
       instant -- the standing overlay rule, applied where it was
       missing: Check consistency opened the check and closed it in
       one click, so the Style system had no working door to it. */
    /* T470: ...AND THE SCREEN STAYS. It closed itself first, because
       the picker sits at a lower z-index than the screen -- so picking
       a set threw you out of the Style system and Close on the picker
       left you in the editor, not back where you were (2026-09-15
       review). The picker opens ABOVE the screen instead, and the
       screen redraws when it closes, wearing what was picked. */
    ov.querySelector('#dg-sets').addEventListener('click',function(e){
      e.stopPropagation();
      if(typeof window.SemDeckStyleSets==='function')
        window.SemDeckStyleSets(function(){
          var o2=$('#deck-design');
          if(o2){dgRail(o2);dgBody(o2);}
        });
    });
    ov.querySelector('#dg-check').addEventListener('click',function(e){
      /* the drift CHECK stays where it is: this surface says what the
         standard is, that pane says who is not keeping to it, and one
         doing both would be a screen answering two questions */
      e.stopPropagation();
      dgClose();
      var b=$('#dsg-std');
      if(b) b.click();
    });
    document.addEventListener('keydown',dgKey,true);
    var usedStyles=styleOrder().filter(function(id){
      return !parentOf(id)&&dgFamilyWearers(id).length>0;});
    if(usedStyles.indexOf(dgSel)<0){
      if(usedStyles.length) dgSel=usedStyles[0];
      else {
        var firstKind=DG_OBJ_KINDS.filter(function(pr){
          var old=dgSel;dgSel='obj:'+pr[0];
          var n=dgRows().length;dgSel=old;return n>0;
        })[0];
        dgSel=firstKind?('obj:'+firstKind[0]):'obj:image';
      }
    }
    dgRail(ov);dgBody(ov);
  }
  window.SemDeckDesign=openDesign;
  function miniDiagram(s){
    var d=document.createElement('span');
    d.className='mini-diagram free';
    if(!s) return d;
    if((pres.slides||[]).indexOf(s)>=0) paintSlide=s;   /* T316 */
    /* the slide's own background, so a recoloured slide reads as one --
       T467: and the DECK's, resolved the one way (pageBgOf), so a deck
       made light reads light in the strip rather than navy against a
       white page (2026-09-15 review) */
    if(typeof pageBgOf==='function') d.style.background=pageBgOf(s);
    else if(s.bg) d.style.background=tokVal(s.bg);
    var annots=s.annots||[];
    if(s.layout!=='title'&&!annots.length){
      var e=document.createElement('span');
      e.className='mini-pane empty';
      d.appendChild(e);
      return d;
    }
    if(s.layout==='title'){
      miniText(d,titleProps(s,'t'),s.title||'Title','is-t',true);
      miniText(d,titleProps(s,'s'),s.sub||'','is-s',true);
    }
    /* arrows go last so they sit on top, exactly as on the canvas */
    var arrows=[];
    annots.forEach(function(a,i){
      if(!a||a.hide) return;
      if(a.k==='arrow'){arrows.push(a);return;}
      /* T494: a placeholder is drawn the way the canvas draws it while
         you edit -- faint, in a hairline box -- so the strip still
         shows the SHAPE of an untouched slide without printing "Body
         text" on it at full ink (T366); a thumbnail is an editing
         surface, the words are the slot's, and the class is how a
         reader can tell a hint from a heading */
      if(a.k==='text'){miniText(d,a,a.text||'',a.ph?'is-ph':'');return;}
      if(a.k==='image'){
        var bx=miniBox(d,a,'is-img');
        if(a.src){
          var im=document.createElement('img');
          im.src=a.src;im.alt='';im.loading='lazy';im.draggable=false;
          im.setAttribute('aria-hidden','true');   /* decorative (T105) */
          if(a.crop) bx.classList.add('is-crop');
          /* T587: a finished crop is a window; the thumbnail shows it */
          if(a.win&&a.win.w>0&&a.win.h>0){
            bx.classList.add('is-win');
            im.style.width=(10000/a.win.w).toFixed(2)+'%';
            im.style.height=(10000/a.win.h).toFixed(2)+'%';
            im.style.left=(-(a.win.x||0)*100/a.win.w).toFixed(2)+'%';
            im.style.top=(-(a.win.y||0)*100/a.win.h).toFixed(2)+'%';
          }
          bx.appendChild(im);
        }
        return;
      }
      if(a.k==='flip'){
        /* the thumbnail shows the frame the slide RESTS on, which is the
           one the strip is an index to. Without a branch here a flip book
           is invisible in the film strip and every slide holding one
           looks empty (the lesson miniDiagram was rewritten for). */
        var bf=miniBox(d,a,'is-flip');
        var ff=flipFrames(a)[a.at||0];
        if(ff&&ff.src){
          var fim2=document.createElement('img');
          fim2.src=ff.src;fim2.alt='';fim2.loading='lazy';
          fim2.draggable=false;
          fim2.setAttribute('aria-hidden','true');  /* decorative (T105) */
          bf.appendChild(fim2);
        } else if(ff&&ff.ref){
          var fnode2=framePart(ff.ref,ff.part);
          var fimg2=fnode2?fnode2.querySelector('img'):null;
          if(fimg2&&fimg2.src){
            var fc=document.createElement('img');
            fc.src=fimg2.src;fc.alt='';fc.loading='lazy';fc.draggable=false;
            fc.setAttribute('aria-hidden','true');  /* decorative (T105) */
            bf.appendChild(fc);
          }
        }
        return;
      }
      if(a.k==='rect'){
        var bs=miniBox(d,a,'is-shape');
        bs.appendChild(drawShapeSvg(a.shape||'rect',a.color||'#ff6b57',
          miniSw(a),a,'m'+(miniSeq++),null));
        miniStroke(bs,a);
        return;
      }
      if(a.k==='draw'){
        var bd=miniBox(d,a,'is-shape');
        bd.appendChild(drawFreeSvg(a,null));
        miniStroke(bd,a);
        return;
      }
      if(a.k==='table'){
        /* a real miniature table: at 116px the words are a smudge, but
           the SHAPE of a table is unmistakable and that is what a
           thumbnail is for */
        var bt=miniBox(d,a,'is-tbl');
        var trows=tableRows(a),tcols=tableCols(a);
        var mt=document.createElement('table');
        mt.className='mini-tbl'+(a.grid===0?' nogrid':'');
        if(a.color) mt.style.color=tokVal(a.color);
        if(a.bg!==0&&a.bgc) bt.style.background=tokVal(a.bgc);
        mt.style.fontSize=Math.max(1.5,
          miniHNow*(a.size||2.2)/100).toFixed(2)+'px';
        /* T551: merged regions and the cells' colours, as the slide
           draws them, so a styled table is recognisable in the strip */
        var tcov=tableCover(a),tlk=tableResolvedLook(a);
        trows.forEach(function(row,ri){
          var tr=document.createElement('tr');
          row.forEach(function(v,ci){
            var cv=tcov[ri]&&tcov[ri][ci];
            if(cv&&cv.at) return;
            var td=document.createElement((a.thead&&ri===0)?'th':'td');
            if(cv){td.rowSpan=cv.rs;td.colSpan=cv.cs;}
            td.style.width=tcols[ci]+'%';
            var lk=(tlk[ri]||[])[ci]||{};
            if(lk.bg) td.style.background=lk.bg;
            if(lk.ink) td.style.color=lk.ink;
            td.textContent=v==null?'':String(v);
            tr.appendChild(td);});
          mt.appendChild(tr);});
        bt.appendChild(mt);
        return;
      }
      if(a.k==='cell'){
        if(miniCell(d,a)) return;
        var w2=paneThumb(a.ref);
        w2.style.position='absolute';
        w2.style.left=(a.x||0)+'%';w2.style.top=(a.y||0)+'%';
        w2.style.width=(a.w||10)+'%';w2.style.height=(a.h||10)+'%';
        if(a.rot) w2.style.transform='rotate('+a.rot+'deg)';
        d.appendChild(w2);
      }
    });
    if(arrows.length){
      /* ONE svg for every arrow, in the page's own 0..100 percentage
         space — preserveAspectRatio="none" makes that space the
         thumbnail, so no pixel measurement is needed and nothing has to
         be re-scaled when the strip is resized */
      var sv=document.createElementNS(AN_NS,'svg');
      sv.setAttribute('class','mini-svg');
      sv.setAttribute('viewBox','0 0 100 100');
      sv.setAttribute('preserveAspectRatio','none');
      arrows.forEach(function(a){
        var p=document.createElementNS(AN_NS,'path');
        p.setAttribute('d',arrowPath(arrowEnds(null,s,a,0),a,100,100));
        p.setAttribute('fill','none');
        p.setAttribute('stroke',tokVal(a.color)||'#ff6b57');
        p.setAttribute('stroke-width',miniSw(a));
        p.setAttribute('vector-effect','non-scaling-stroke');
        p.setAttribute('stroke-linecap','round');
        if(a.op!=null&&a.op<1) p.setAttribute('opacity',a.op);
        sv.appendChild(p);
      });
      d.appendChild(sv);
    }
    return d;
  }
  /* ---- the other pages, as a floating pane -----------------------------
     The strip is MOVED into #verpane rather than rebuilt there, so
     reordering, drag-and-drop, delete and the thumbnails keep working
     with no second copy of any of it (2026-08-10, user: "the bar for this
     should appear like the objects bar"). */
  var filmHome=null;
  function filmToPane(){
    var body=$('#verpane-body'),list=$('#film-list'),add=$('#film-adds'),
        head=$('#film-head');
    if(!body||!list||filmHome) return;
    filmHome={parent:list.parentNode,next:list.nextSibling};
    /* the chooser rides along as a THIRD node, above the list it chooses
       for. Building a second copy of it in the pane is how two controls
       that claim to do the same thing start disagreeing (2026-08-22). */
    if(head) body.appendChild(head);
    body.appendChild(list);
    if(add) body.appendChild(add);
  }
  function filmToPanel(){
    if(!filmHome) return;
    var list=$('#film-list'),add=$('#film-adds'),head=$('#film-head');
    if(list&&filmHome.parent){
      var at=(filmHome.next&&filmHome.next.parentNode===filmHome.parent)
        ?filmHome.next:null;
      /* head, list, adds — in that order and all before whatever followed
         the list when it left, so the column comes back exactly as it was
         rather than with its chooser stranded at the bottom */
      if(head) filmHome.parent.insertBefore(head,at);
      filmHome.parent.insertBefore(list,at);
      if(add) filmHome.parent.insertBefore(add,at);
    }
    filmHome=null;
  }
  /* The button reports the state of whichever strip this page kind uses:
     the docked one for a deck, the floating pane for a poster. Written
     once, because two of these drifting apart is a toggle that lies about
     what it will do. */
  function syncStripBtn(){
    var vb=$('#vw-versions'); if(!vb) return;
    var p=$('#verpane');
    var on=pageOf().poster
      ? !!(p&&!p.hidden)
      : !deckEl.classList.contains('strip-off');
    vb.setAttribute('aria-pressed',on.toString());
  }
  function showVerpane(on){
    var p=$('#verpane'); if(!p) return;
    if(on){
      paneShow('verpane');
      filmToPane();
      renderFilm();
    } else paneHide('verpane');
    var t=$('#verpane-title');
    if(t) t.textContent=pageOf().poster?'Versions':'Slides';
    syncStripBtn();
  }
  /* ---- versions --------------------------------------------------------
     A poster's other pages are drafts and variants, so a new one starts as
     a COPY of what you are looking at — that is what a variant is a
     variant OF — and it is named for you, because an unnamed pile of
     near-identical A0 sheets is unusable. The name is a starting point:
     Rename changes it. */
  function nextVersionName(){
    var n=0;
    (pres.slides||[]).forEach(function(s){
      var m=/^Version (\d+)$/.exec((s&&s.label)||'');
      if(m) n=Math.max(n,+m[1]);
    });
    return 'Version '+(n+1);
  }
  /* `lay` is a layout from the catalogue when a Home tile asked for
     this slide (T202), `arr` a saved layout whose shapes it should
     carry; the film strip's + passes its click event, which is
     neither */
  function newVersion(lay,arr){
    if(!(lay&&lay.items)) lay=null;
    /* T494: AFTER THE WHOLE GROUP, the way dupSlide places its copy
       (T318). cur+1 from the MAIN of a version group spliced the new
       slide between the main and its versions; the untagged slide
       closed the run, normAlts dropped the tag from every member, and
       "Version 2" became a numbered slide the talk shows (2026-09-15
       review). A poster has no runs, so its branch is unchanged. */
    var ar=(typeof altRun==='function')?altRun(cur):null;
    var at=ar?(ar.at+ar.n):(pres.slides.length?cur+1:0);
    /* T601: a new slide asked for inside a part goes after the part */
    if(typeof partSafeAt==='function') at=partSafeAt(at);
    if(!pageOf().poster){
      /* a DECK's slides are named by what is on them, which is more use
         than "Slide 3" — so no label is stamped here */
      var ns=emptySlide();
      /* THE LAYOUT YOU LAST CHOSE (T193). A new slide arrives laid out
         the way the last one you picked a layout for was, and a deck
         that has never picked one starts with a title, a panel and
         text -- the shape most slides in a talk have (2026-09-02,
         user: "when click add new it should remember the last one you
         added. The default slide choice should be the panel, title,
         text"). Blank is still one pick away. */
      var key=lsGet(newLayKey())||'cell-text';
      /* T494: a saved layout is remembered by ID ('arr:<id>'), so
         Forget on an earlier one cannot move the choice along; an id
         the store no longer has (or an old numeric key) falls through
         to the default below rather than to a random layout */
      if(!arr&&!lay&&/^arr:/.test(key)&&typeof arrById==='function'){
        var hit=arrById(key.slice(4));
        if(hit&&hit.annots) arr=hit;
      }
      if(arr&&arr.annots){
        /* T494: the shapes arrive as PLACEHOLDERS, like a built-in
           layout's (T366): the words are the slot's kind, drawn faint
           while you edit and nowhere else. deep() alone made them
           content -- printed, shown and exported. A cell arrives
           empty (no ref), so a saved slide's figure cannot ride in
           either; its part -- which facet the slot wanted -- is the
           shape and stays. */
        ns.annots=deep(arr.annots).map(function(a){
          if(a&&a.k==='text') a.ph=1;
          if(a&&a.k==='cell') a.ref=null;
          return a;
        });
      } else {
        /* T494: ...and a layout that no longer exists -- deleted in the
           builder, or another deck's 'my1' -- is the default (T193),
           not a blank slide with no word said */
        lay=lay||layoutById(/^arr:/.test(key)?'cell-text':key)
          ||layoutById('cell-text');
        if(lay&&!lay.poster) applyLayout(ns,lay);
      }
      pres.slides.splice(at,0,ns);
    } else {
      var src=pres.slides[cur];
      /* name the page you were already on first, so the two read as a
         pair rather than "empty slide" and "Version 2" */
      if(src&&!src.label) src.label=nextVersionName();
      var cp=src?deep(src):emptySlide();
      cp.label=nextVersionName();
      pres.slides.splice(at,0,cp);
    }
    /* a new slide joins the section it was inserted into. Without this an
       insert splits the run in two and grows a divider out of nowhere. */
    var prev=pres.slides[at-1];
    if(prev&&prev.sec&&!(typeof partLink==='function'&&partLink(prev.sec)))
      pres.slides[at].sec=prev.sec;
    cur=at;activePane=-1;selAnnot=null;selSet=[];
    normSections();markDirty();refresh();
    if(!$('#verpane').hidden) renderFilm();
  }
  /* ---- THE OUTLINE ----------------------------------------------------
     In headings mode the strip stops being a contact sheet and becomes a
     table of contents, so it must name a slide by its HEADING and not by
     whatever text happens to sit highest on it. A box wearing a heading
     style says outright that it is the slide's title; slideTitle's
     guesswork is the fallback for slides that never used one. */
  function slideHeading(s){
    var best=null,bestAt=99;
    (s.annots||[]).forEach(function(a){
      if(!a||a.k!=='text'||a.hide||!String(a.text||'').trim()) return;
      if(a.ph) return;   /* T494: a hint is not a heading */
      if(!a.style||!isHeadingStyle(a.style)) return;
      var at=headingStyles().indexOf(a.style);
      if(at>=0&&at<bestAt){bestAt=at;best=a;}
    });
    return best?String(best.text).trim().split('\n')[0]:'';
  }
  /* how far the row indents in the outline. A title slide and a section
     divider are always level 0 — they are the top of something, whatever
     style their text happens to wear. */
  function headLevel(s){
    if(!s||s.layout==='title'||s.layout==='section') return 0;
    var lv=0;
    (s.annots||[]).forEach(function(a){
      if(!a||a.k!=='text'||a.hide||!a.style) return;
      var at=headingStyles().indexOf(a.style);
      if(at>=0&&(!lv||at<lv)) lv=at;
    });
    return Math.min(3,lv);
  }
  /* ONE source for the words on a row, so the strip and refreshThumb can
     never disagree about what a slide is called */
  function filmText(s){
    if(filmMode()==='thumb') return slideTitle(s);
    return slideHeading(s)||slideTitle(s);
  }
  function slideTitle(s){
    /* a version carries the name you were given or chose; only posters
       get one, so a deck slide is still named by what is ON it */
    if(s.label) return s.label;
    if(s.layout==='title') return s.title||'title slide';
    var cells=slideCells(s);
    for(var i=0;i<cells.length;i++){
      var it=cells[i].a.ref&&resolveRef(cells[i].a.ref);
      if(it) return it.title;
    }
    /* T494: not a placeholder -- an untouched Title + text slide was
       called "Title" in the strip and in every dialog that names a
       slide, when it holds nothing (T366: a hint is not content) */
    var tx=(s.annots||[]).filter(function(a){
      return a.k==='text'&&a.text&&!a.ph;})[0];
    if(tx){
      /* T469: not the SOURCE -- the strip read "$$ E = mc^2 $$" and
         "# Big heading ## Sub" (2026-09-15 review) */
      var t=String(tx.text);
      if(tx.maths) t=t.replace(/^\s*\$\$?/,'').replace(/\$\$?\s*$/,'').trim()||'equation';
      else if(tx.md) t=(t.split('\n').map(function(l){
        return l.replace(/^\s*(?:#{1,6}|[-*>]|\d+[.)])\s*/,'').trim();})
        .filter(Boolean)[0])||t;
      return t;
    }
    /* a slide that is one big table is named by its first heading, which
       beats calling it "empty slide" (2026-08-20) */
    var tb=(s.annots||[]).filter(function(a){return a.k==='table';})[0];
    if(tb){
      var r0=(tb.rows||[])[0]||[];
      for(var j=0;j<r0.length;j++)
        if(String(r0[j]||'').trim()) return String(r0[j]).trim();
      return 'table';
    }
    return 'empty slide';
  }
  /* ---- SLIDE SECTIONS -------------------------------------------------
     "There should be the ability to create slide sections in the
     thumbnails part" (2026-08-22).

     THE SHAPE, and why it is this one. A section is a TAG on the slide
     (s.sec) plus a name in a keyed map (pres.sections). The ORDER is
     never stored: it is read back off pres.slides. Every slide mutation
     in this file is a raw splice — moveSlide, delSlide, dupSlide,
     newVersion, the strip's drop handler — and histRestore replaces the
     array outright; a tag rides through all six for free, while a stored
     start-INDEX would have to be shifted correctly in every one of them
     and would be silently wrong the first time one was missed.

     The one price of tags is that they permit a section to go
     discontiguous. normSections() below is what pays it, and every verb
     here ends by calling it. */
  var secSeq=0;
  function secId(){
    /* an id has to survive a save, a reload and an undo, so it cannot be
       a plain counter reset on load — two sections would collide the
       moment you reopened a deck and made another one */
    secSeq++;
    return 's'+Date.now().toString(36)+secSeq.toString(36);
  }
  function secMap(){
    if(!pres.sections||typeof pres.sections!=='object') pres.sections={};
    return pres.sections;
  }
  function secName(id){
    var d=(pres.sections||{})[id];
    return (d&&d.name)||'Untitled section';
  }
  /* THE ONE SHARED API. The strip, the Apply dialog's scope picker and
     the outline view must all agree on what a section IS, so all three
     read it from here rather than each grouping the slides their own
     way. Untagged spans come back too, with id '' — a caller that wants
     only real sections filters on run.id. */
  function sectionRuns(){
    var out=[],sl=pres.slides||[],i,id,last=null;
    for(i=0;i<sl.length;i++){
      id=(sl[i]&&sl[i].sec)||'';
      if(!last||last.id!==id){
        last={id:id,name:id?secName(id):'',at:i,n:0,
          fold:!!(id&&(pres.sections||{})[id]&&pres.sections[id].fold),
          color:(id&&(pres.sections||{})[id]&&pres.sections[id].color)||''};
        out.push(last);
      }
      last.n++;
    }
    return out;
  }
  /* THE INVARIANT. A section is a CONTIGUOUS run — that is what a divider
     in a strip means, and nothing in the UI can express anything else. A
     tag can still end up out of place (drag a slide past a boundary, or
     swap one across it with the arrows), so every mutation ends here: a
     tag that reappears after its run has closed is re-tagged to the run
     it now sits in, and any section no slide uses is thrown away.
     Dropping the map entirely when it empties is what keeps a deck that
     never used sections serialising exactly as it did before. */
  function normSections(){
    var sl=pres.slides||[],seen={},closed={},prev='',i,id;
    for(i=0;i<sl.length;i++){
      if(!sl[i]) continue;
      id=sl[i].sec||'';
      if(id&&id!==prev&&(closed[id]||seen[id])) id=prev;
      if(id) seen[id]=1;
      if(prev&&prev!==id) closed[prev]=1;
      if(id) sl[i].sec=id; else delete sl[i].sec;
      prev=id;
    }
    /* T601: a part's slide that left its section is the talk's own now */
    if(typeof partNorm==='function') partNorm();
    var m=pres.sections;
    if(m){
      Object.keys(m).forEach(function(k){if(!seen[k]) delete m[k];});
      if(!Object.keys(m).length) delete pres.sections;
    }
    if(typeof normAlts==='function') normAlts();   /* T318 */
  }
  /* the five verbs. Everything that touches sections goes through one of
     these, so normSections() is guaranteed to have run before markDirty
     writes the deck out. */
  /* T499: `quiet` for the strip's Section button, whose rename question
     follows at once -- the naming is the entry, see #film-sec */
  function newSection(at,name,quiet){
    /* T601: a part's sections are made in the part */
    if(typeof partOfSlide==='function'&&partOfSlide(pres.slides[at])){
      toast(partSays(partOfSlide(pres.slides[at])),7000);return;}
    var id=secId(),i;
    secMap()[id]={name:name||'New section'};
    /* a new section OWNS everything from `at` down to the next divider —
       that is what "start a section here" means in PowerPoint, and it is
       the only reading that leaves no orphan slides behind */
    var was=(pres.slides[at]&&pres.slides[at].sec)||'';
    for(i=at;i<pres.slides.length;i++){
      if(((pres.slides[i].sec)||'')!==was) break;
      pres.slides[i].sec=id;
    }
    /* T316: refresh, not renderFilm -- every other membership verb
       ends in refresh(), and a heading wearing '@section' has to
       repaint the moment the section it now sits in exists */
    normSections();markDirty(!!quiet);refresh();
  }
  /* T499: `then(named)` runs once the question is answered either way
     -- the strip's Section button commits the section's own entry there
     when the name was declined, so a cancel is undoable too */
  function renameSection(id,then){
    /* prompt(), not an inline edit on the row. The row's own click
       re-renders the strip, so by the time a dblclick handler arrived the
       node it was editing had already been replaced — the same reason the
       poster version rename is a button and a prompt (2026-08-10) */
    askText({title:'Name this section',value:secName(id),ok:'Rename'},
    function(v){
    v=(v==null)?'':v.trim();
    if(v){
    /* T316: in place, so the arrival and the colour survive a rename
       (the rebuild here was already dropping `trans`) */
    var rec=secMap()[id]||(secMap()[id]={});
    rec.name=v;
    markDirty();renderFilm();
    }
    if(then) then(!!v);
    });
  }
  function foldSection(id,on){
    var d=secMap()[id]; if(!d) return;
    if(on) d.fold=1; else delete d.fold;
    /* markDirty(true): folding is a way of LOOKING at the deck, not an
       edit to it, so it persists in the file but never lands on the undo
       stack — Ctrl+Z must never open or close a section */
    markDirty(true);renderFilm();
  }
  function removeSection(id,withSlides){
    var runs=sectionRuns(),r=null,i;
    for(i=0;i<runs.length;i++) if(runs[i].id===id) r=runs[i];
    if(!r) return;
    if(withSlides) pres.slides.splice(r.at,r.n);
    /* the slides MERGE UPWARDS into whatever section is above — removing
       a divider must never delete work, which is why the destructive form
       is a separate and differently-worded verb */
    else for(i=r.at;i<r.at+r.n;i++){
      if(r.at>0&&pres.slides[r.at-1].sec)
        pres.slides[i].sec=pres.slides[r.at-1].sec;
      else delete pres.slides[i].sec;
    }
    if(pres.sections) delete pres.sections[id];
    if(cur>=pres.slides.length) cur=Math.max(0,pres.slides.length-1);
    normSections();markDirty();refresh();
  }
