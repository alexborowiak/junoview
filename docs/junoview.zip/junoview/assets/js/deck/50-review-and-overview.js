/* 50-review-and-overview.js — the deck as words, the overview map, cuts, and the builder's sidebar.
   ONE FRAGMENT of deck.js's single IIFE, concatenated with its
   siblings in filename order by assets.deck_js(). It does not
   parse alone and is not meant to: see 00-page.js. */
  /* ---- WHAT THE DECK SAYS, IN WORDS -----------------------------------
     (TASKS T35.) Two halves of one idea: write the deck out as text a
     person or a language model can read, and say what looks wrong with
     it while you are in there.

     WHY THIS IS NOT PREFLIGHT. `preflight` asks "will this print" — per
     slide, physical, millimetres and dpi and contrast. This asks "does
     this hold together" — deck-wide, editorial, about words and figures
     and whether the same thing is called two things. They share no
     question and no unit, and folding one into the other would give you
     a list where "0.2mm line" sits next to "slide 12 has 90 words on
     it" as if those were the same kind of problem.

     THE EXPORT IS TEXT, AND MARKDOWN. junoview is offline and stays
     offline; what travels is the words. Markdown because it pastes into
     anything, because a model reads structure out of it without being
     told the format, and because a colleague can read it as it stands —
     which is the difference between an export and a dump.

     IT SAYS WHERE A FIGURE CAME FROM, and that is the part no other
     export can do: a deck knows its figures by notebook anchor, so the
     review can say "the toe map, from demo::toe_map" rather than
     "[image]". Reviewing a talk without knowing which figure is which
     is reviewing a talk with the pictures cut out.

     THE FOUR LINTS ARE THE FOUR TASKS.md NAMES, and each one reports
     what it counted rather than a verdict, because a heuristic that
     will not show its working is one you cannot argue with:
       - a figure nobody mentions: on the slide, no caption, and no text
         or note on that slide that names it.
       - a caption with no figure: `capOf` pointing at nothing, or text
         that reads like a caption and is tied to nothing. T17 made the
         tie explicit, which is what makes this answerable at all.
       - two spellings of one thing: terms that are the same once
         hyphens, spaces and case are taken out. Grouped that way,
         "sea-level"/"sea level" and "Toe Map"/"toe map" fall out
         together, and "The"/"the" — which differ only in the first
         letter, i.e. a sentence beginning — deliberately do not.
       - a slide with a lot on it: words and items, both counted. */
  var DENSE_WORDS=55, DENSE_ITEMS=12;
  function revText(a){
    if(!a) return '';
    if(a.k==='text') return String(a.text||'');
    if(a.k==='table'&&Array.isArray(a.rows))
      return a.rows.map(function(r){
        return (r||[]).map(function(c){
          return typeof c==='string'?c:((c&&c.t)||'');}).join(' | ');
      }).join('\n');
    return '';
  }
  function slideWordCount(sl){
    var n=0;
    (sl.annots||[]).forEach(function(a){
      if(!a||a.hide||a.priv) return;
      var t=revText(a).trim();
      if(t) n+=t.split(/\s+/).length;
    });
    if(sl.layout==='title')
      n+=String((sl.title||'')+' '+(sl.sub||'')).trim()
        .split(/\s+/).filter(Boolean).length;
    return n;
  }
  /* capOfFig answers the editor's MODEL question and must see every tied
     caption. A review asks the narrower audience question instead. */
  function reviewCaption(sl,a){
    var ci=capOfFig(sl,a);
    var ca=ci>=0?(sl.annots||[])[ci]:null;
    return ca&&!ca.hide&&!ca.priv?ca:null;
  }
  /* WHERE A FIGURE CAME FROM, in one line. The deck knows this and no
     other export of it does. */
  function revFigLine(sl,a,map){
    var bits=[];
    var nm=a.ref?String(a.ref).split('::').pop():'';
    bits.push(nm||(a.k==='image'?'a placed picture'
      :a.k==='flip'?'a flip book':'a frame'));
    var num=(a.cap&&map[a.cap])?map[a.cap].n:0;
    if(num) bits[0]='Figure '+num+' — '+bits[0];
    var ca=reviewCaption(sl,a);
    /* A caption normally travels WITH its figure, which used to bypass
       deckReview's private/hidden guard entirely. Apply the same audience
       boundary before borrowing its words (T49). */
    var cap=ca?revText(ca).trim():'';
    if(cap) bits.push('“'+figSubst(cap,ca,map)+'”');
    if(a.ref) bits.push('from '+a.ref);
    else if(a.k==='image') bits.push('pasted in, not from a notebook');
    if(a.k==='flip'&&Array.isArray(a.frames))
      bits.push(a.frames.length+' frames');
    return bits.join(' · ');
  }
  /* WHAT TO CALL A SLIDE IN AN EXPORT THAT TRAVELS. `filmText` names a
     slide by the first thing written on it, which is right in the strip
     — you are looking at the slide, private items and all. Here it is
     wrong: a slide whose only text is an "only me" note would be
     HEADED with that note, and the whole promise of T31 is that those
     words do not leave. So the heading is taken from the same reading
     order with the private items already dropped. */
  function revHeading(sl){
    if(!sl) return '';
    if(sl.label) return String(sl.label);
    if(sl.layout==='title'&&sl.title) return String(sl.title);
    var out='';
    orderedIdx(sl).forEach(function(j){
      if(out) return;
      var a=(sl.annots||[])[j];
      if(!a||a.hide||a.priv||a.capOf) return;
      var t=revText(a).trim();
      if(t) out=t.split(/[\r\n]/)[0];
    });
    return out;
  }
  function deckReview(){
    var L=[],map=figNumbers();
    var runs=sectionRuns();
    var n=(pres.slides||[]).length;
    var mins=goalTotal();
    L.push('# '+(pres.name||'Untitled deck'));
    L.push('');
    L.push(n+' slide'+(n===1?'':'s')
      +(runs.filter(function(r){return r.id;}).length
        ?(' in '+runs.filter(function(r){return r.id;}).length
          +' sections'):'')
      +(mins?(' · '+fmtMins(mins)+' planned'):'')
      +(pres.talkMins?(' · '+pres.talkMins+' minute slot'):''));
    if(pres.notes){
      L.push('');
      L.push('## About the whole talk');
      L.push('');
      L.push(String(pres.notes).trim());
    }
    runs.forEach(function(run){
      L.push('');
      L.push('## '+(run.id?(run.name||'Section')
        :(runs.length>1?'(no section)':'The slides')));
      for(var k=0;k<run.n;k++){
        (function(i){
          var sl=pres.slides[i];
          if(!sl) return;
          L.push('');
          L.push('### '+(i+1)+'. '+(revHeading(sl)||'(untitled)'));
          var tags=[];
          if(sl.opt) tags.push('optional');
          if(sl.cuts&&sl.cuts.length)
            tags.push('only in: '+sl.cuts.map(function(c){
              return (cutMap()[c]||{}).name||c;}).join(', '));
          if(slideGoal(sl)) tags.push(fmtMins(slideGoal(sl))+' planned');
          if(tags.length) L.push('*'+tags.join(' · ')+'*');
          if(sl.layout==='title'){
            if(sl.title) L.push('');
            if(sl.title) L.push('**'+sl.title+'**');
            if(sl.sub) L.push(sl.sub);
          }
          /* IN READING ORDER, not storage order: the review has to say
             the slide in the order somebody looking at it would */
          var words=[],figs=[];
          orderedIdx(sl).forEach(function(j){
            var a=(sl.annots||[])[j];
            /* a private note is not part of the talk, and this export
               travels (T31) */
            if(!a||a.hide||a.priv) return;
            if(isFigure(a)){figs.push(revFigLine(sl,a,map));return;}
            if(a.capOf) return;         /* said with its figure */
            var t=figSubst(revText(a),a,map).trim();
            if(t) words.push(t);
          });
          if(words.length){
            L.push('');
            words.forEach(function(t){
              L.push(t.split('\n').map(function(ln,li){
                return (li?'  ':'- ')+ln;}).join('\n'));
            });
          }
          if(figs.length){
            L.push('');
            L.push('Figures:');
            figs.forEach(function(f){L.push('- '+f);});
          }
          if(sl.notes){
            L.push('');
            L.push('Speaker notes:');
            String(sl.notes).trim().split('\n').forEach(function(ln){
              L.push('> '+ln);});
          }
        })(run.at+k);
      }
    });
    L.push('');
    return L.join('\n');
  }
  /* the terms, normalised: hyphens, spaces and case out, so the
     variants of one thing land in one bucket */
  function termKey(w){
    return String(w||'').toLowerCase().replace(/[^a-z0-9]+/g,'');
  }
  function reviewLints(){
    var out=[],map=figNumbers();
    var surfaces={};
    (pres.slides||[]).forEach(function(sl,si){
      var texts=[];
      (sl.annots||[]).forEach(function(a){
        if(!a||a.hide||a.priv) return;
        var t=revText(a); if(t) texts.push(t);
      });
      if(sl.notes) texts.push(String(sl.notes));
      if(sl.layout==='title') texts.push((sl.title||'')+' '+(sl.sub||''));
      var all=texts.join(' ');
      /* --- 1. a figure nobody mentions --- */
      (sl.annots||[]).forEach(function(a,i){
        if(!isFigure(a)||a.hide||a.priv) return;
        if(reviewCaption(sl,a)) return;       /* a PUBLIC caption */
        var num=(a.cap&&map[a.cap])?map[a.cap].n:0;
        var nm=a.ref?String(a.ref).split('::').pop():'';
        var named=(num&&new RegExp('\\bfig(?:ure)?\\.?\\s*'+num+'\\b','i')
          .test(all))
          ||(nm&&all.toLowerCase().indexOf(nm.toLowerCase().replace(
            /[_-]+/g,' '))>=0)
          ||(nm&&all.toLowerCase().indexOf(nm.toLowerCase())>=0);
        if(named) return;
        out.push({sev:'warn',si:si,i:i,
          head:'Slide '+(si+1)+': a figure nothing mentions',
          why:(num?('Figure '+num):'This figure')+' has no caption, and '
            +'no text or note on the slide names it. An audience does '
            +'not know what they are looking at.'});
      });
      /* --- 2. a caption with no figure --- */
      (sl.annots||[]).forEach(function(a,i){
        if(!a||a.hide||a.priv||a.k!=='text') return;
        var t=revText(a).trim();
        var looks=/^\s*(fig(ure)?\.?\s*\d|table\s*\d)/i.test(t);
        if(a.capOf){
          if(figOfCap(sl,a)>=0) return;
          out.push({sev:'err',si:si,i:i,
            head:'Slide '+(si+1)+': a caption whose figure is gone',
            why:'“'+t.slice(0,60)+'” is tied to a figure that is no '
              +'longer on this slide. It will number as [missing '
              +'figure] and read as a caption for nothing.'});
        } else if(looks){
          out.push({sev:'warn',si:si,i:i,
            head:'Slide '+(si+1)+': a caption that is not tied to '
              +'anything',
            why:'“'+t.slice(0,60)+'” reads like a caption but belongs '
              +'to no figure, so it will not follow one, and its '
              +'number will not update when the slides move.'});
        }
      });
      /* --- 4. a slide with a lot on it --- */
      var wc=slideWordCount(sl);
      var ic=(sl.annots||[]).filter(function(a){
        return a&&!a.hide&&!a.priv&&!a.capOf;}).length;
      if(wc>DENSE_WORDS||ic>DENSE_ITEMS)
        out.push({sev:'warn',si:si,i:null,
          head:'Slide '+(si+1)+': a lot on one slide',
          why:wc+' words and '+ic+' things on it. Above about '
            +DENSE_WORDS+' words an audience reads instead of '
            +'listening.'});
      /* COLLECT THE SURFACES for lint 3. Single words AND adjacent
         pairs, because the whole point is that "sea-level" and "sea
         level" are the same term written two ways -- and one of those
         is one token while the other is two. A first pass that only
         looked at single tokens found the hyphenated form and never
         the spaced one, so the two could never meet in a bucket. */
      var toks=all.match(/[A-Za-z][A-Za-z0-9'-]*/g)||[];
      function surf(w){
        var k=termKey(w);
        if(k.length<4) return;
        (surfaces[k]=surfaces[k]||{})[w]=(surfaces[k][w]||0)+1;
      }
      toks.forEach(function(w,i){
        if(w.length>=4) surf(w);
        if(i+1<toks.length){
          var pair=w+' '+toks[i+1];
          if(termKey(pair).length>=6) surf(pair);
        }
      });
    });
    /* --- 3. two spellings of one thing --- */
    Object.keys(surfaces).forEach(function(k){
      var forms=Object.keys(surfaces[k]);
      if(forms.length<2) return;
      /* forms differing ONLY in the first letter's case are a sentence
         beginning, not an inconsistency */
      var real=forms.some(function(a){
        return forms.some(function(b){
          return a!==b&&a.slice(1)!==b.slice(1);});});
      if(!real) return;
      /* NO MINIMUM COUNT. A first pass wanted three occurrences before
         reporting, which silently hid the commonest real case -- the
         term said once each way, which is exactly the inconsistency
         worth catching. Two surfaces that normalise to the same string
         and differ by more than a capital is already a strong enough
         signal; the count is shown so you can judge it yourself. */
      var total=forms.reduce(function(t,f){return t+surfaces[k][f];},0);
      out.push({sev:'warn',si:null,i:null,
        head:'Two spellings of one thing',
        why:forms.map(function(f){
          return '“'+f+'” ×'+surfaces[k][f];}).join(', ')
          +'. Pick one — an audience reads the difference as a '
          +'distinction.'});
    });
    /* --- 4. a picture nobody has described (T105) ---
       Deliberately NOT "has no alt text": a picture is allowed to carry
       nothing, and saying so is a real answer. What this reports is the
       picture nobody has decided about, which is the only state that is
       an omission rather than a choice. It reads the same field the
       renderer does, so a deck this is quiet about is a deck whose alt
       text is really there. */
    (pres.slides||[]).forEach(function(sl,si){
      (sl.annots||[]).forEach(function(a,i){
        if(!a||a.priv) return;
        if(a.k!=='image'&&a.k!=='flip') return;
        if(a.dec||(a.alt&&String(a.alt).trim())) return;
        out.push({sev:'warn',si:si,i:i,
          head:'This picture does not say what it shows',
          why:'Somebody who cannot see it gets “'
            +(annotLabel(a)||'image')+'” — the name of the box, not '
            +'what is in it. Right-click the picture and write its alt '
            +'text, or leave that empty to mark it decorative if it '
            +'really carries nothing.'});
      });
    });
    /* --- 5. the talk does not fit the time it has (T121) ---
       Every part of this already existed and none of it was a LINT:
       slideGoal and goalTotal add the goals up, rehStats holds what
       each slide actually took, and the notes pane shows the verdict
       while you are presenting. That is the wrong moment -- the review
       is where you still have time to cut a slide. So this restates
       what those already know rather than measuring anything new. */
    var goal=goalTotal();
    var st=rehStats(),runs=(st.runs||[]).length;
    if(goal&&runs){
      var real=0,timed=0;
      (pres.slides||[]).forEach(function(sl){
        var a=sl&&sl.sid?st.by[sl.sid]:null;
        if(a&&a.n){real+=a.mean/60;timed++;}
      });
      /* only worth saying when most of the deck has actually been
         rehearsed -- half a run extrapolated to a whole talk is a
         number that looks like evidence and is not */
      if(timed>=Math.ceil((pres.slides||[]).length/2)&&real){
        var over=real-goal;
        if(Math.abs(over)>=Math.max(1,goal*0.1))
          out.push({sev:over>0?'err':'warn',si:null,i:null,
            head:over>0?'This runs long':'This runs short',
            why:'The goals add up to '+fmtMins(goal)+' and '+timed
              +' rehearsed slide'+(timed===1?'':'s')+' averaged '
              +fmtMins(real)+' \u2014 '+fmtMins(Math.abs(over))
              +(over>0?' over. Cut a slide, or move the goal.'
                :' under. There is room for the thing you left out.')});
      }
    }
    /* --- 6. a link that goes nowhere (T118) ---
       An internal jump is stored by `sid` precisely so reordering
       cannot repoint it -- but DELETING the target still can, and
       silently. This is the one lint that reports a broken thing
       rather than a debatable one. */
    (pres.slides||[]).forEach(function(sl,si){
      (sl.annots||[]).forEach(function(a,i){
        var l=a&&a.link;
        if(!l||l.to!=='slide') return;
        if(linkSlideIdx(l.sid)>=0) return;
        out.push({sev:'err',si:si,i:i,
          head:'This link goes nowhere',
          why:'It points at a slide that is no longer in the deck. '
            +'Clicking it while presenting says so and stays put, '
            +'which is not what you want an audience to see.'});
      });
    });
    /* --- 7. two slides that are the same slide --- */
    var seen={};
    (pres.slides||[]).forEach(function(sl,si){
      var key=(sl.annots||[]).filter(function(a){
        return a&&!a.hide&&!a.priv;
      }).map(function(a){
        return a.k+':'+(revText(a)||a.src||'').slice(0,80);
      }).sort().join('|');
      if(!key||key.length<20) return;    /* an empty slide is not a copy */
      if(seen[key]!=null){
        out.push({sev:'warn',si:si,i:null,
          head:'This slide is a copy of an earlier one',
          why:'Slide '+(seen[key]+1)+' has the same objects and the '
            +'same words. A duplicate left in by accident reads as a '
            +'stutter; one left in on purpose usually wants a build '
            +'instead.'});
      } else seen[key]=si;
    });
    return out;
  }
  /* THE WHOLE REVIEW AS ONE THING (T121).
     The panel showed the lints and the readable text side by side and
     then exported only the text, so the half you would send to a
     co-author was the half without the findings in it. The .md now
     carries both, and there is a JSON door beside it for anything that
     is not a person -- a pre-submission check in CI, most obviously.
     Neither recomputes: both read reviewLints(), so an export can never
     disagree with what the panel just showed you. */
  function reviewMarkdown(text,lints){
    if(!lints.length) return text;
    var head='## What this review found\n\n';
    var body=lints.map(function(l){
      var where=(l.si!=null)?('Slide '+(l.si+1)+' \u2014 '):'';
      return '- **'+(l.sev==='err'?'':'')+where+l.head+'.** '+l.why;
    }).join('\n');
    return head+body+'\n\n---\n\n'+text;
  }
  function reviewJson(lints){
    return JSON.stringify({
      deck:pres.name||'',
      slides:(pres.slides||[]).length,
      findings:lints.map(function(l){
        return {severity:l.sev,slide:(l.si==null?null:l.si+1),
          object:(l.i==null?null:l.i),title:l.head,detail:l.why};
      })
    },null,2);
  }
  /* THE PANEL. The lints first, because they are the reason to open it
     twice; the text below them, because it is the reason to open it at
     all. Both at once rather than two doors: what a lint says and what
     the reviewer will read are the same deck, and having to switch
     between them to check one against the other is the whole problem
     with a separate report. */
  function reviewClose(){
    var ov=$('#deck-review');
    if(ov) ov.remove();
    document.removeEventListener('keydown',reviewKey,true);
  }
  function reviewKey(e){
    if(!$('#deck-review')) return;
    if(e.key==='Escape'){
      e.preventDefault();e.stopPropagation();reviewClose();}
  }
  function openReview(){
    reviewClose();
    var text=deckReview(),lints=reviewLints();
    var ov=document.createElement('div');
    ov.className='deck-review';ov.id='deck-review';
    ov.innerHTML='<div class="rv-head">'
      +'<span class="rv-t">Send this deck out to be read</span>'
      +'<span class="deck-spring"></span>'
      +'<button class="dbtn" id="rv-copy">'+bic('copy')+' Copy</button>'
      +'<button class="dbtn" id="rv-dl">'+bic('markdown')
      +' Save as .md</button>'
      +'<button class="dbtn" id="rv-json" title="The same findings as '
      +'JSON, for something that is not a person to read \u2014 a '
      +'pre-submission check, say">'+bic('code')
      +' Save as .json</button>'
      +'<button class="dbtn" id="rv-close">'+bic('exit')
      +' Close</button></div>'
      +'<div class="rv-main">'
      +'<div class="rv-lints" id="rv-lints"></div>'
      +'<div class="rv-textwrap"><span class="rv-lab">'
      +'what a reader gets — markdown, so it pastes anywhere</span>'
      +'<textarea class="rv-text" id="rv-text" readonly '
      +'spellcheck="false"></textarea></div></div>';
    document.body.appendChild(ov);
    ov.querySelector('#rv-text').value=text;
    var host=ov.querySelector('#rv-lints');
    var hd=document.createElement('div');
    hd.className='rv-lhead';
    var errs=lints.filter(function(l){return l.sev==='err';}).length;
    hd.textContent=lints.length
      ?(lints.length+' thing'+(lints.length===1?'':'s')+' to look at'
        +(errs?(' · '+errs+' serious'):''))
      :'Nothing looks wrong with the content';
    host.appendChild(hd);
    var note=document.createElement('div');
    note.className='rv-note';
    note.textContent='About what the deck says. “Before you print” '
      +'is the other list — that one is about ink and millimetres.';
    host.appendChild(note);
    lints.forEach(function(l){
      var b=document.createElement('button');
      b.className='rv-lint sev-'+l.sev;
      var h=document.createElement('span');
      h.className='rv-lh';h.textContent=l.head;
      var w=document.createElement('span');
      w.className='rv-lw';w.textContent=l.why;
      b.appendChild(h);b.appendChild(w);
      if(l.si!=null){
        b.title='Go to slide '+(l.si+1);
        b.addEventListener('click',function(){
          reviewClose();
          cur=l.si;selAnnot=(l.i==null?null:l.i);
          selSet=(l.i==null?[]:[l.i]);
          refresh();
        });
      } else b.classList.add('nogo');
      host.appendChild(b);
    });
    ov.querySelector('#rv-close').addEventListener('click',reviewClose);
    ov.querySelector('#rv-copy').addEventListener('click',function(){
      var ta=ov.querySelector('#rv-text');
      ta.select();
      var done=false;
      try{done=document.execCommand('copy');}catch(e){}
      if(!done&&navigator.clipboard)
        navigator.clipboard.writeText(text).then(function(){
          toast('Copied — paste it wherever it is being read');});
      else toast(done?'Copied — paste it wherever it is being read'
        :'Select the text and copy it');
    });
    ov.querySelector('#rv-dl').addEventListener('click',function(){
      /* the findings AND the readable text: the half you send to a
         co-author used to be the half without the findings (T121) */
      var blob=new Blob([reviewMarkdown(text,lints)],
        {type:'text/markdown'});
      var a=document.createElement('a');
      a.href=URL.createObjectURL(blob);
      a.download=(pres.name||'deck')+'.review.md';
      a.click();
      setTimeout(function(){URL.revokeObjectURL(a.href);},2000);
      toast('Saved — it travels; junoview stays here');
    });
    ov.querySelector('#rv-json').addEventListener('click',function(){
      var blob=new Blob([reviewJson(lints)],{type:'application/json'});
      var a=document.createElement('a');
      a.href=URL.createObjectURL(blob);
      a.download=(pres.name||'deck')+'.review.json';
      a.click();
      setTimeout(function(){URL.revokeObjectURL(a.href);},2000);
      toast(lints.length+' finding'+(lints.length===1?'':'s')
        +' saved as JSON');
    });
    document.addEventListener('keydown',reviewKey,true);
  }
  /* ---- THE OVERVIEW: THE WHOLE TALK AT ONCE ---------------------------
     (TASKS T26.) TASKS.md is careful about what this is: "the realistic
     scope of the infinite-canvas wish — an overview/navigation layer,
     not canvas-based authoring". So it navigates and it does not author,
     and that boundary is the reason it can be an overlay over the
     existing model rather than a second editor.

     WHY AN OVERLAY AND NOT A PANE. Every pane in this app docks beside
     the stage and takes width from the page; this needs the opposite —
     all the room there is, for as long as you are looking, and none
     afterwards. It is the same shape as the spotlight and the presenter
     view, which are the other two things here that take the screen and
     give it straight back.

     WHAT IT DRAWS is what already exists: sectionRuns() for the
     clusters, miniDiagram() for the tiles, and the same reading of
     optional/cut membership the playback filter uses. Nothing here
     computes a fact of its own, which is why it cannot disagree with
     the strip it is a zoom-out of. */
  function overviewClose(){
    var ov=$('#deck-overview');
    if(ov) ov.remove();
    document.removeEventListener('keydown',overviewKey,true);
  }
  function overviewKey(e){
    if(!$('#deck-overview')) return;
    if(e.key==='Escape'){
      e.preventDefault();e.stopPropagation();
      /* T482: a search still typed is cleared first, like the ribbon
         gallery's; the map closes on the next Escape */
      var fi=$('#ovw-find');
      if(fi&&document.activeElement===fi&&fi.value){
        fi.value='';fi.dispatchEvent(new Event('input',{bubbles:true}));
        fi.focus();return;
      }
      overviewClose();
    }
  }
  function openOverview(){
    overviewClose();
    var ov=document.createElement('div');
    ov.className='deck-overview';ov.id='deck-overview';
    var head=document.createElement('div');
    head.className='ovw-head';
    var t=document.createElement('span');
    t.className='ovw-t';
    var runs=sectionRuns();
    var n=(pres.slides||[]).length;
    t.textContent=(pres.name||'This deck')+' \u2014 '+n+' slide'
      +(n===1?'':'s')
      +(function(){
        var ns=runs.filter(function(r){return r.id;}).length;
        return ns?(' in '+ns+' section'+(ns===1?'':'s')):'';
      })();
    head.appendChild(t);
    var sp=document.createElement('span');
    sp.className='deck-spring';head.appendChild(sp);
    /* THE SEARCH BOX IS THE MAP'S (T30). Filtering a map you can already
       see beats a separate results list you cannot. */
    var find=document.createElement('input');
    find.className='ovw-find';find.id='ovw-find';find.type='search';
    find.placeholder='Find a slide\u2026';
    find.setAttribute('aria-label','Find a slide by its words or notes');
    head.appendChild(find);
    var cnt=document.createElement('span');
    cnt.className='ovw-fn';head.appendChild(cnt);
    var cl=document.createElement('button');
    cl.className='dbtn';cl.innerHTML=bic('exit')+' Close';
    cl.title='Esc';
    cl.addEventListener('click',overviewClose);
    head.appendChild(cl);
    ov.appendChild(head);
    var body=document.createElement('div');
    body.className='ovw-body';
    runs.forEach(function(r){
      var grp=document.createElement('div');
      grp.className='ovw-grp';
      var gh=document.createElement('div');
      gh.className='ovw-gh';
      gh.textContent=r.id?(r.name||'Section')
        :(runs.length>1?'(no section)':'');
      if(gh.textContent) grp.appendChild(gh);
      var tiles=document.createElement('div');
      tiles.className='ovw-tiles';
      for(var k=0;k<r.n;k++){
        (function(i){
          var sl=pres.slides[i];
          var tile=document.createElement('button');
          tile.className='ovw-tile'+(i===cur?' cur':'')
            +(sl&&sl.opt?' opt':'')
            +(slideSkipped(i)?' cut':'');
          var num=document.createElement('span');
          num.className='ovw-n';num.textContent=String(i+1);
          tile.appendChild(num);
          tile.appendChild(miniDiagram(sl));
          var lab=document.createElement('span');
          lab.className='ovw-lab';
          lab.textContent=filmText(sl)||'';
          tile.appendChild(lab);
          tile.dataset.i=String(i);
          tile.title=(sl&&sl.opt?'Optional \u2014 ':'')
            +'Go to slide '+(i+1);
          tile.addEventListener('click',function(){
            overviewClose();
            /* PRESENTING, go() -- so the transition plays, the rehearsal
               clock attributes the time and the presenter view follows.
               Setting cur by hand would skip all three (T30). */
            if(mode==='view'){go(i);return;}
            cur=i;activePane=-1;selAnnot=null;selSet=[];
            refresh();
          });
          tiles.appendChild(tile);
        })(r.at+k);
      }
      grp.appendChild(tiles);
      body.appendChild(grp);
    });
    ov.appendChild(body);
    /* TYPE TO NARROW. The tiles are already drawn; a hit hides the ones
       that do not match rather than rebuilding the map, so the slides
       do not jump about under the pointer as you type. */
    function applyFind(){
      var q=find.value.trim();
      if(!q){
        $$('.ovw-tile',ov).forEach(function(t){t.hidden=false;
          t.classList.remove('hit');
          var w=t.querySelector('.ovw-why'); if(w) w.remove();});
        $$('.ovw-grp',ov).forEach(function(g){g.hidden=false;});
        cnt.textContent='';
        return;
      }
      var hits={},n=0;
      slideHits(q).forEach(function(h){hits[h.i]=h;n++;});
      $$('.ovw-tile',ov).forEach(function(t){
        var i=+t.dataset.i;
        var h=hits[i];
        t.hidden=!h;
        t.classList.toggle('hit',!!h);
        var w=t.querySelector('.ovw-why');
        if(w) w.remove();
        if(h){
          var e=document.createElement('span');
          e.className='ovw-why';
          e.textContent=(h.where?(h.where+': '):'')+h.snip;
          t.appendChild(e);
        }
      });
      /* a section with nothing left in it stops taking up a heading */
      $$('.ovw-grp',ov).forEach(function(g){
        g.hidden=!$$('.ovw-tile',g).some(function(t){return !t.hidden;});
      });
      cnt.textContent=n?(n+' slide'+(n===1?'':'s')):'nothing';
    }
    find.addEventListener('input',applyFind);
    find.addEventListener('keydown',function(e){
      e.stopPropagation();
      if(e.key==='Escape'){
        if(find.value){find.value='';applyFind();e.preventDefault();}
        return;
      }
      /* Enter goes to the first one, which is what you meant */
      if(e.key==='Enter'){
        var first=$$('.ovw-tile',ov).filter(function(t){
          return !t.hidden;})[0];
        if(first){e.preventDefault();first.click();}
      }
    });
    document.body.appendChild(ov);
    /* CAPTURE, so Esc closes the map before the editor's own Esc ladder
       reads it as "drop the tool" — the innermost state wins, which is
       the rule that ladder already follows */
    document.addEventListener('keydown',overviewKey,true);
  }
  /* ---- OPTIONAL SLIDES, NAMED CUTS, AND RUNNING LATE ------------------
     (TASKS T24 and T25 — one model, and T25 is three lines once T24
     exists, so they are built together.)

     THE PROBLEM: three files called talk-45.deck, talk-20.deck and
     talk-5.deck, diverging from the day they were copied.

     THE MODEL. A slide carries `opt:1` when it is optional, and a set of
     cut names in `cuts` — a slide IS IN a cut when it names it. Both
     live ON THE SLIDE, for the reason sections chose the same shape and
     recorded it: membership stored on the slide travels through every
     splice, every drag, every duplicate and every undo for free, while a
     stored list of indexes has to be repaired after each of them and
     will eventually not be.

     `pres.cuts` holds only the NAMES, exactly as `pres.sections` holds
     only section names, and for the same reason: the order and the
     membership are read back off the slide list.

     WHAT A CUT MEANS. A slide with no `cuts` is in EVERY cut — that is
     what makes the feature adoptable, because an existing deck is
     already a complete "everything" cut and turning one on excludes
     nothing until you say so. Naming cuts on a slide narrows it.

     RUNNING LATE (T25) is then not a fourth concept: it is a live
     filter that also drops anything marked optional, from wherever you
     have got to. It is deliberately NOT a cut — you do not choose it
     before the talk, you reach for it at minute 34 — and it applies
     from the CURRENT slide onward, because the ones you have already
     shown are not the problem. */
  function cutMap(){
    /* Reads must not recreate an empty map after the last version is
       deleted. newCut is the one lifecycle verb allowed to create it. */
    return (pres&&pres.cuts)||{};
  }
  function hasCut(id){
    return Object.prototype.hasOwnProperty.call(cutMap(),id);
  }
  function cutList(){
    var m=cutMap();
    return Object.keys(m).map(function(id){
      return {id:id,name:String((m[id]&&m[id].name)||id)};
    }).sort(function(a,b){return a.name.localeCompare(b.name);});
  }
  function cutId(){
    var m=cutMap(),n=1;
    while(Object.prototype.hasOwnProperty.call(m,'k'+n)) n++;
    return 'k'+n;
  }
  function cutNameTaken(name,except){
    var want=String(name||'').toLowerCase();
    return cutList().some(function(c){
      return c.id!==except&&c.name.toLowerCase()===want;});
  }
  function newCut(name){
    name=String(name||'').trim()||'Short version';
    if(cutNameTaken(name,'')){
      toast('There is already a version called “'+name+'”');return '';
    }
    var id=cutId();
    if(!pres.cuts) pres.cuts={};
    pres.cuts[id]={name:name};
    markDirty();
    return id;
  }
  /* the cut currently being SHOWN, or '' for the whole deck. Session
     state, not deck state: which version you are rehearsing today is
     not a property of the document, and sending someone a deck must not
     send them your rehearsal. Same argument matchPick makes. */
  var showCut='',lateFrom=-1;
  var runFilterPres=null;
  /* A cut and Running late belong to one open deck, not to the next deck
     that happens to reuse k1. Also repair a deleted/stale active id at the
     one read boundary rather than asking every caller to remember (T50). */
  function activeCut(){
    if(runFilterPres!==pres){
      runFilterPres=pres;showCut='';lateFrom=-1;
    }
    if(showCut&&!hasCut(showCut)) showCut='';
    return showCut;
  }
  function renameCut(id){
    if(!hasCut(id)) return false;
    var d=cutMap()[id]; if(!d) return false;
    var old=d.name||id;
    /* T475: the editor's own question; the menu re-syncs itself once
       the answer lands, so this returns false to its caller */
    askText({title:'Name this version',value:old,ok:'Rename'},function(v){
    if(v==null) return;
    v=v.trim(); if(!v||v===old) return;
    if(cutNameTaken(v,id)){
      toast('There is already a version called “'+v+'”');return;
    }
    d.name=v;
    markDirty();renderFilm();presenterSync&&presenterSync();
    toast('Version renamed to “'+v+'”');
    cutsSync();   /* T477: the menu and the tab's strip */
    });
    return false;
  }
  function delCut(id){
    if(!hasCut(id)) return false;
    var d=cutMap()[id]; if(!d) return false;
    var name=d.name||id;
    var universal=(pres.slides||[]).filter(function(sl){
      return sl&&Array.isArray(sl.cuts)&&sl.cuts.length
        &&sl.cuts.every(function(c){return c===id;});}).length;
    if(!confirm('Delete the version “'+name+'”? Slides stay in the deck. '
      +(universal?(universal+' slide'+(universal===1?'':'s')
        +' that names no other version will return to every version.')
        :'No slide will become universal.')))
      return false;
    var wasActive=activeCut()===id;
    delete pres.cuts[id];
    (pres.slides||[]).forEach(function(sl){
      if(!sl||!Array.isArray(sl.cuts)) return;
      var keep=sl.cuts.filter(function(c){return c!==id;});
      if(keep.length) sl.cuts=keep; else delete sl.cuts;
    });
    if(!Object.keys(pres.cuts).length) delete pres.cuts;
    if(wasActive) showCut='';
    markDirty();renderFilm();presenterSync&&presenterSync();
    toast('Deleted “'+name+'” — every slide stayed'
      +(wasActive?' · showing every slide':''));
    return true;
  }
  /* a slide is in a cut when it names it — and a slide that names no
     cuts is in all of them, which is what makes an existing deck a
     complete "everything" version on the day this ships. */
  function inCut(sl,cut){
    if(!cut) return true;
    var c=sl&&sl.cuts;
    if(!c||!c.length) return true;
    return c.indexOf(cut)>=0;
  }
  /* SKIPPED, for playback only. Never for the editor: a slide you have
     cut is still a slide you are editing, and hiding it from the strip
     would be how you lose it. */
  function slideSkipped(i){
    var sl=(pres.slides||[])[i];
    if(!sl) return false;
    /* T318: an unstarred alternative is never part of the show -- the
       presenter, the arrows, the counter, the overview dimming and the
       strip's mark all read this one predicate */
    if(slideIsAlt(i)) return true;
    if(!inCut(sl,activeCut())) return true;
    if(lateFrom>=0&&i>lateFrom&&sl.opt) return true;
    return false;
  }
  /* the next slide playback should land on, in a direction. Returns -1
     when there is nothing left that way. */
  function nextShown(from,dir){
    var n=(pres.slides||[]).length;
    for(var i=from+dir;i>=0&&i<n;i+=dir)
      if(!slideSkipped(i)) return i;
    return -1;
  }
  /* One ordered answer for presenter numbering as well as playback.
     Raw deck indexes are wrong as soon as a named cut or Running late
     removes anything between two shown slides (T48). */
  function shownSlides(){
    var out=[];
    (pres.slides||[]).forEach(function(sl,i){
      if(!slideSkipped(i)) out.push(i);
    });
    return out;
  }
  function setCut(id){
    activeCut();
    if(id&&!hasCut(id)) id='';
    showCut=id||'';
    /* landing on a slide the cut excludes would be a talk that starts
       on a slide it is not showing */
    if(mode==='view'&&slideSkipped(cur)){
      var to=nextShown(cur,1);
      if(to<0) to=nextShown(cur,-1);
      if(to>=0) go(to);
    }
    presenterSync&&presenterSync();
    renderFilm();
    toast(id?('Showing the \u201c'+(cutMap()[id]||{}).name
      +'\u201d version'):'Showing every slide');
  }
  /* T25. One control, mid-talk, that drops the rest of the optional
     slides. From HERE onward: what you have already shown is not the
     problem, and un-showing it is not on offer. */
  function syncLateButton(){
    var b=$('#deck-late'); if(!b) return;
    var on=lateFrom>=0;
    b.hidden=(mode!=='view');
    b.setAttribute('aria-pressed',on?'true':'false');
    b.innerHTML=bic('flag')+(on?' Running late: on':' Running late');
    b.title=on?'Show the remaining optional slides again (L)'
      :'Skip the remaining optional slides from here (L)';
  }
  function initPresenterControls(){
    var b=$('#deck-late');
    if(b) b.addEventListener('click',function(){
      runLate(lateFrom<0);
    });
    syncLateButton();
  }
  function runLate(on){
    var cut=activeCut();
    lateFrom=on?cur:-1;
    syncLateButton();
    renderFilm();
    presenterSync&&presenterSync();
    if(!on){toast('Back to the full run');return 0;}
    var n=0;
    (pres.slides||[]).forEach(function(sl,i){
      if(i>cur&&sl&&sl.opt&&inCut(sl,cut)) n++;});
    toast(n?(n+' optional slide'+(n===1?'':'s')
      +' will be skipped from here'):'No optional slides left to skip');
    return n;
  }
  function toggleOptional(i){
    var sl=(pres.slides||[])[i]; if(!sl) return;
    if(sl.opt) delete sl.opt; else sl.opt=1;
    markDirty();renderFilm();
    toast(sl.opt?'Optional \u2014 "Running late" will skip it'
      :'No longer optional');
  }
  function toggleSlideCut(i,id){
    var sl=(pres.slides||[])[i]; if(!sl||!id||!hasCut(id)) return;
    var c=(sl.cuts||[]).slice();
    var at=c.indexOf(id);
    if(at>=0) c.splice(at,1); else c.push(id);
    /* an empty list means "every cut", so it is dropped rather than
       stored — the same empty-is-absent rule sections and styles use */
    if(c.length) sl.cuts=c; else delete sl.cuts;
    markDirty();renderFilm();
  }
  function go(n){
    var prev=cur;
    /* a pending self-advance belongs to the slide that armed it (T169) */
    autoStop();
    cur=Math.max(0,Math.min(pres.slides.length-1,n));
    if(cur===prev) return;   /* clamped no-op: keep build + selection state */
    /* stepping back into a slide shows it fully built; forward starts fresh */
    revealCount=(mode==='view'&&cur<prev)?buildsForSlide(cur):0;
    /* arm on ARRIVAL too: a slide whose first build is delayed should
       start counting the moment you land on it, not on a click that
       would defeat the point (T169). Deferred so it arms against the
       slide that is actually on screen. */
    setTimeout(autoArm,0);
    selAnnot=null;selSet=[];   /* never carry a selection across slides */
    mediaForget();             /* the next slide's clips start afresh (T321) */
    /* MEASURE BEFORE THE REBUILD. renderSlide empties the stage, so the
       outgoing geometry has to be taken here or it is gone (T27). */
    captureFlip(prev);
    /* ...and the time so far belongs to the slide you are LEAVING, which
       is why this is here rather than after the render (T29) */
    rehSlideChanged();
    refresh();
    playFlip();
    presenterSync();
    /* T289: the transition buttons describe the SLIDE, so they follow
       it. animRibbonSync -- where the rest of the Animation tab syncs
       from -- is driven by the SELECTION, and go() clears the selection
       to null without going through it; driven, the ribbon kept showing
       the previous slide's answer. */
    if(typeof transRibbonSync==='function') transRibbonSync();
    if(window.SemApp&&window.SemApp.updateHash) window.SemApp.updateHash();
  }
  /* advance: reveal the next build, else move to the next slide (no-op at the
     very end, so the final slide never collapses back to its pre-build state) */
  /* ---- THE TALK PANEL (T88) ---------------------------------------
     Present mode has no ribbon and no rail on purpose, so the two things
     you might want to change mid-talk had nowhere to live. One button in
     the corner beside the slide count, one small panel, and both
     settings also on a key -- because reaching for a panel in front of a
     room is exactly what you do not want to do. */
  function syncTalk(){
    var p=$('#talkpane'); if(!p) return;
    var b=$('#talk-builds');
    if(b){
      b.setAttribute('aria-pressed',talkNoBuilds?'true':'false');
      b.title=talkNoBuilds
        ? 'Animations are off: every slide arrives complete and slides '
          +'change with a plain cut. Press again to play them (A)'
        : 'Skip the animations: builds and slide transitions both, so '
          +'one click is one slide and nothing moves. Flip books still '
          +'step (A)';
      var lab=b.querySelector('.tk-state');
      if(lab) lab.textContent=talkNoBuilds?'skipped':'playing';
    }
    /* the reset button IS the readout: the current size, click to put
       it back. It used to say 100% forever while the real number sat
       in a hidden span (T126). */
    var r=$('#talk-reset');
    if(r){
      r.textContent=Math.round(talkText*100)+'%';
      r.disabled=(talkText===1);
    }
    [['h','head'],['b','body'],['c','cap']].forEach(function(t){
      var v=$('#talk-'+t[0]+'-val');
      if(v){
        v.textContent=Math.round(talkType[t[1]]*100)+'%';
        v.disabled=(talkType[t[1]]===1);
      }
    });
  }
  function talkBuilds(on){
    talkNoBuilds=on?1:0;
    /* a slide part-way through its builds must not be left showing
       fewer things than it now claims to have */
    if(talkNoBuilds) revealCount=0;
    syncTalk();renderSlide();presenterSync();
    toast(talkNoBuilds
      ? 'Animations skipped \u2014 slides arrive complete, and change '
        +'with a plain cut'
      : 'Animations are playing again');
  }
  /* bucket===undefined scales everything; a bucket name scales that
     kind of text on top of the global size. 0 always means "put it
     back", and the GLOBAL reset puts the types back too, because "the
     size the deck was made at" is one state, not four (T126). */
  function talkZoom(mult,bucket){
    if(bucket){
      var w=talkType[bucket];
      talkType[bucket]=Math.max(0.6,Math.min(2.2,
        mult===0?1:Math.round(w*mult*100)/100));
      if(talkType[bucket]===w) return;
      syncTalk();renderSlide();
      return;
    }
    var was=talkText;
    talkText=Math.max(0.6,Math.min(2.2,
      mult===0?1:Math.round(talkText*mult*100)/100));
    if(mult===0) talkType={head:1,body:1,cap:1};
    if(talkText===was&&mult!==0) return;
    syncTalk();renderSlide();
  }
  (function(){
    var btn=$('#talkbtn'),pane=$('#talkpane');
    if(!btn||!pane) return;
    function open(on){
      pane.hidden=!on;
      btn.setAttribute('aria-expanded',on?'true':'false');
      if(on) syncTalk();
    }
    btn.addEventListener('click',function(e){
      e.stopPropagation();open(pane.hidden);});
    var cl=$('#talkpane-close');
    if(cl) cl.addEventListener('click',function(){open(false);});
    var b=$('#talk-builds');
    if(b) b.addEventListener('click',function(){
      talkBuilds(!talkNoBuilds);});
    var sm=$('#talk-smaller');
    if(sm) sm.addEventListener('click',function(){talkZoom(1/1.12);});
    var bg=$('#talk-bigger');
    if(bg) bg.addEventListener('click',function(){talkZoom(1.12);});
    var rs=$('#talk-reset');
    if(rs) rs.addEventListener('click',function(){talkZoom(0);});
    [['h','head'],['b','body'],['c','cap']].forEach(function(t){
      var mi=$('#talk-'+t[0]+'-minus'),pl=$('#talk-'+t[0]+'-plus'),
        vl=$('#talk-'+t[0]+'-val');
      if(mi) mi.addEventListener('click',function(){
        talkZoom(1/1.12,t[1]);});
      if(pl) pl.addEventListener('click',function(){
        talkZoom(1.12,t[1]);});
      if(vl) vl.addEventListener('click',function(){talkZoom(0,t[1]);});
    });
    window.SemDeckTalk={open:open,builds:talkBuilds,zoom:talkZoom,
      sync:syncTalk};
  })();
  /* THE ONE TIMER. A stop with `after` runs on a clock instead of a
     click (T169), so exactly one may be pending at a time and ANY other
     movement cancels it -- a presenter who reaches for the space bar or
     jumps a slide has taken control back, and a talk that then advanced
     twice would be the worst possible bug in front of an audience. */
  var autoT=null;
  function autoStop(){
    if(autoT){clearTimeout(autoT);autoT=null;}
  }
  function autoArm(){
    autoStop();
    if(mode!=='view') return;
    var s=pres.slides[cur]; if(!s) return;
    if(revealCount>=slideStops(s)) return;
    var secs=(typeof autoAfter==='function')?autoAfter(s,revealCount):0;
    if(!secs) return;
    autoT=setTimeout(function(){
      autoT=null;
      if(mode!=='view') return;
      advance();
    },secs*1000);
  }
  function advance(){
    autoStop();
    var s=pres.slides[cur];
    /* a flip book's frames are stops in this same sequence, so the space
       bar walks the figure through its steps exactly as it walks a build
       — one gesture for the whole talk (2026-08-22) */
    if(mode==='view'&&s&&revealCount<slideStops(s)){
      revealCount++;renderSlide();presenterSync();autoArm();
    } else {
      /* THE FILTER LIVES HERE, in the two verbs the whole talk runs on,
         rather than in twenty callers. A cut or a running-late skip is
         a fact about what to show NEXT, which is exactly what advance
         asks (T24/T25). */
      var nx=nextShown(cur,1);
      if(nx>=0) go(nx);
    }
  }
  function backStep(){
    autoStop();
    if(mode==='view'&&revealCount>0){revealCount--;renderSlide();
      presenterSync();}
    else {
      var pv=nextShown(cur,-1);
      /* At the first slide in a cut, Back is a no-op. Raw cur-1 can be
         a slide this version explicitly leaves out (T50). */
      go(pv>=0?pv:cur);
    }
  }

  /* ---------- create mode: sidebar UI ---------- */
  /* ---------- presentations rail (vertical, left edge) ----------
     One item is active at any time: the "Notebooks" button (builder
     closed) or a presentation (builder open editing it). */
  var presstrip=document.getElementById('presstrip');
  var FOLDERSKEY='sempresfolders:'+SCOPE;
  /* folders exist on their own (created empty, dragged into). They are
     shown in the library dialog since T394; the rail lists only what is
     open. */
  function explicitFolders(){
    try{
      var l=JSON.parse(lsGet(FOLDERSKEY)||'[]');
      return Array.isArray(l)?l:[];
    }catch(e){return [];}
  }
  function saveFolders(list){lsSet(FOLDERSKEY,JSON.stringify(list));}
  /* move ANY presentation (current, saved, draft, embedded) */
  function setPresFolder(nm,folder){
    var f=(folder||'').trim();
    function apply(p){
      if(f) p.folder=f; else delete p.folder;
    }
    if(nm===pres.name){apply(pres);markDirty();renderPresRow();}
    var hit=false;
    if(nm!==pres.name){
      projectPres.forEach(function(p){
        if(p.name===nm){apply(p);hit=true;}});
      nbPres.forEach(function(p){
        if(p.name===nm){apply(p);hit=true;}});
      var raw=draftGet(nm);   /* T429: the draft store */
      if(raw){
        try{
          var d=JSON.parse(raw);apply(d);
          draftSet(nm,JSON.stringify(d));hit=true;
        }catch(e){}
      }
      if(hit&&APP.mode==='app') scheduleAutosave();
    }
    renderPresTabs();
    renderPresentationHub();
  }
  function newFolder(wanted){
    var supplied=typeof wanted==='string'&&wanted.trim();
    /* no name yet: ask for one where folders are shown */
    if(!supplied){
      if(window.SemApp&&window.SemApp.deckNewFolder)
        window.SemApp.deckNewFolder();
      return null;
    }
    var list=explicitFolders();
    var name=wanted.trim();
    var taken=list.indexOf(name)>=0
      ||allSaved().some(function(p){return p.folder===name;});
    if(taken){
      toast('There is already a folder called “'+name+'”');
      return null;
    }
    list.push(name);saveFolders(list);
    renderPresentationHub();
    return name;
  }
  function renameFolder(oldName,newName){
    newName=(newName||'').trim();
    if(!newName||newName===oldName) return;
    var list=explicitFolders().map(function(x){
      return x===oldName?newName:x;});
    if(list.indexOf(newName)<0) list.push(newName);
    saveFolders(list.filter(function(x,i){
      return list.indexOf(x)===i;}));
    allSaved().concat([pres]).forEach(function(p){
      if(p.folder===oldName) setPresFolder(p.name,newName);
    });
    draftNames().forEach(function(nm){
      var d=loadDraft(nm);
      if(d&&d.folder===oldName) setPresFolder(nm,newName);
    });
    renderPresentationHub();
  }
  function deleteFolder(f){
    saveFolders(explicitFolders().filter(function(x){return x!==f;}));
    allSaved().concat([pres]).forEach(function(p){
      if(p.folder===f) setPresFolder(p.name,'');
    });
    draftNames().forEach(function(nm){
      var d=loadDraft(nm);
      if(d&&d.folder===f) setPresFolder(nm,'');
    });
    renderPresentationHub();
  }
  /* ---- T394: THE RAIL IS A TAB LIST, NOT THE LIBRARY -------------------
     It used to be built from allSaved() + draftNames(): every project
     deck, every draft and every deck embedded in an open notebook, grouped
     into folders with drag-and-drop filing -- which is a library, and it
     sat under a label that made it read as "your presentations" while
     Home's Recent column beside it showed one row. Now it lists what is
     OPEN (openPresentationNames, 10-decks.js), the way the notebook strip
     above it lists open notebooks, and two doors under it lead to Recents
     and to the whole library. The library dialog took the folders and the
     filing with it (renderPresentationHub). */
  function renderPresTabs(){
    if(!presstrip) return;
    /* the rail's filter is re-applied at the end of this: the strip is
       rebuilt from scratch here, so it arrives unfiltered and a deck
       created while a filter is live would otherwise appear out of
       nowhere in a list that is meant to be showing only matches (T75) */
    presstrip.innerHTML='';
    var savedNames=allSaved().map(function(p){return p.name;});
    var editing=!deckEl.hidden;
    var names=openPresentationNames();
    /* the deck on screen is open whatever the list says: a brand-new,
       never-saved presentation is not yet anywhere the list can find it */
    if(editing&&pres&&pres.name&&names.indexOf(pres.name)<0)
      names.push(pres.name);

    function presItem(nm){
      var p=presentationByName(nm)||{name:nm};
      var isCur=nm===pres.name;
      var t=document.createElement('button');
      /* radio model: a row lights up ONLY while its deck is open — back on
         the notebook view, no presentation stays highlighted */
      t.className='pr-item ptab'+(isCur&&editing?' current editing':'')
        +((savedNames.indexOf(nm)<0&&saveTarget!=='browser')?' draftonly':'');   /* T483 */
      t.setAttribute('role','tab');
      t.dataset.pres=nm;
      var isPoster=/^a\d/.test(String(p.page||''));
      var isView=isViewPres(p);
      /* a custom view lights up while ITS styling bar is open, not while
         the slide stage is (it never opens the slide stage) */
      var vwOpen=isView&&isCur
        &&document.body.classList.contains('styling');
      if(vwOpen) t.className+=' current editing';
      var kindWord=isView?'custom view':isPoster?'poster':'presentation';
      t.title=(isCur&&(editing||vwOpen))
        ?('Editing "'+nm+'" — Home, in the top bar, goes back')
        :('Open '+kindWord+' "'+nm+'"'
          +(isView?' — restyles the notebook itself':' in the builder'));
      /* the same drawn icons as the "+ New ..." buttons, so a row and the
         button that made it read as the same kind of thing — straight
         from SemIcons, where the "+ New" template tokens also resolve */
      t.innerHTML='<span class="pr-ico">'
        +bic(isView?'newview':isPoster?'newposter':'newdeck')
        +'</span>';
      var lbl=document.createElement('span');lbl.className='pr-t';
      lbl.textContent=nm||'(unnamed)';
      t.appendChild(lbl);
      /* the × CLOSES the row, the way a notebook tab's does: the
         presentation stays saved and stays in Recents. Deleting is File ›
         Delete presentation, where a confirm guards it. A real <button>,
         focusable and named for screen readers (2026-08-24). */
      var del=document.createElement('button');
      del.type='button';
      del.className='pr-del';del.title='Close "'+nm+'" (it stays saved)';
      del.setAttribute('aria-label','Close "'+nm+'"');
      del.innerHTML=bic('exit')||'&#10005;';
      del.addEventListener('click',function(e){
        e.stopPropagation();e.preventDefault();
        /* T434: the deck on screen with changes not yet in its file
           asks first */
        var go=(isCur&&typeof closeGuard==='function')
          ?closeGuard(nm):Promise.resolve(true);
        go.then(function(ok){
          if(!ok) return;
          if(isCur&&!deckEl.hidden) closeDeck();
          if(vwOpen) closeCustomView();
          closeOpenPresentation(nm);
          renderPresTabs();
          if(typeof renderDeckPresentationDrawer==='function')
            renderDeckPresentationDrawer();
        });
      });
      t.appendChild(del);
      t.addEventListener('click',function(){
        if(isCur&&!deckEl.hidden) return;
        if(vwOpen) return;            /* already the open custom view */
        choosePresentation(nm);
      });
      return t;
    }
    names.forEach(function(nm){presstrip.appendChild(presItem(nm));});
    if(!names.length){
      var none=document.createElement('div');
      none.className='pr-none';
      none.textContent='nothing open';
      presstrip.appendChild(none);
    }
    var docsBtn=document.getElementById('pr-docs');
    if(docsBtn) docsBtn.classList.toggle('current',!editing);
    /* ...and re-applied, now the rows are back (T75) */
    var A2=window.SemApp;
    if(A2&&typeof A2.railFilter==='function') A2.railFilter();
  }
  /* the rail's Folder row opens the library's folder form: a folder is
     made where folders are shown */
  var newFoldBtn=document.getElementById('pr-newfold');
  if(newFoldBtn) newFoldBtn.addEventListener('click',function(){
    if(window.SemApp&&window.SemApp.deckNewFolder)
      window.SemApp.deckNewFolder();
  });

  /* ---- PRESENTATION LIBRARY + PRESENTING DRAWER ----------------------
     The side rail is behind the full-screen deck on purpose: a visible
     but inert rail traps focus and cannot be clicked.  The deck therefore
     owns a small drawer for the presentations open in THIS session, and
     both it and Home share a complete library dialog for recent work,
     folders, new decks and files. */
  function presentationKind(p){
    return p.view?'custom view':p.poster?'poster':'presentation';
  }
  function presentationIcon(p){
    return bic(p.view?'newview':p.poster?'newposter':'newdeck');
  }
  function libraryRows(){
    var names=[],seen={};
    function add(name){
      if(!name||seen[name]) return;
      seen[name]=1;names.push(name);
    }
    allSaved().forEach(function(p){add(p.name);});
    draftNames().forEach(add);
    if(pres) add(pres.name);
    return names.map(presentationSummary).filter(Boolean);
  }
  /* T436: a modifier click on a library row puts the presentation on
     the open list without leaving the dialog, so several can be opened
     in one visit; a plain click opens it as it always did */
  /* one verb on a library row: the pin's shape, so all four match */
  function hubRowAct(row,icon,label,run){
    var s=document.createElement('span');
    s.className='presentation-hub-act';
    s.setAttribute('role','button');s.tabIndex=0;
    s.innerHTML=bic(icon);
    s.title=label;s.setAttribute('aria-label',label);
    function go(e){e.stopPropagation();e.preventDefault();run();}
    s.addEventListener('click',go);
    s.addEventListener('keydown',function(e){
      if(e.key==='Enter'||e.key===' ') go(e);});
    row.appendChild(s);
    return s;
  }
  function presentationLibraryRow(p,click){
    var b=document.createElement('button');
    b.type='button';b.className='presentation-hub-row';
    b.title='Open '+presentationKind(p)+' \u201c'+p.name+'\u201d'
      +' \u2014 Ctrl+click to add it to the open list and stay here';
    var ic=document.createElement('span');ic.innerHTML=presentationIcon(p);
    var name=document.createElement('span');name.className='presentation-hub-row-name';
    name.textContent=p.name;
    var kind=document.createElement('span');kind.className='presentation-hub-row-kind';
    kind.textContent=presentationKind(p)+(p.folder?' · '+p.folder:'');
    b.appendChild(ic);b.appendChild(name);b.appendChild(kind);
    /* T435: the pin. A pinned row heads Recent and never drops off it. */
    var pinned=isPinnedPresentation(p.name);
    if(pinned) b.classList.add('pinned');
    var pin=document.createElement('span');
    pin.className='presentation-hub-pin'+(pinned?' on':'');
    pin.setAttribute('role','button');pin.tabIndex=0;
    pin.innerHTML=bic('pin');
    pin.title=pinned?'Pinned to the top of Recent \u2014 click to unpin'
      :'Pin to the top of Recent, so it never drops off the list';
    pin.setAttribute('aria-label',pin.title);
    function flip(e){
      e.stopPropagation();e.preventDefault();
      var on=togglePinPresentation(p.name);
      toast(on?('\u201c'+p.name+'\u201d pinned \u2014 it stays at the top '
        +'of Recent'):('\u201c'+p.name+'\u201d unpinned'),4000);
    }
    pin.addEventListener('click',flip);
    pin.addEventListener('keydown',function(e){
      if(e.key==='Enter'||e.key===' ') flip(e);});
    /* ---- T450: THE VERBS, HERE TOO ----------------------------------
       (2026-09-14, user: "you can't duplicate a presentation or delete
       it from the main menu, there is very little controls".) T448 put
       them on the open-items bar; this is the library, which is the
       menu the user meant, and it listed everything you own while
       letting you do nothing to any of it but open it. Spans with
       role="button", not buttons: the row IS a button, and a button
       inside a button is not a thing. */
    hubRowAct(b,'copy','Duplicate \u201c'+p.name+'\u201d',function(){
      var made=duplicatePresentation(p.name);
      if(made) renderPresentationHub();
    });
    hubRowAct(b,'text','Rename \u201c'+p.name+'\u201d',function(){
      askText({title:'Rename this presentation',value:p.name,ok:'Rename'},
      function(v){
      if(!v||!v.trim()) return;
      if(typeof renamePresByName==='function') renamePresByName(p.name,v.trim());
      renderPresentationHub();
      if(typeof renderDeckPresentationDrawer==='function')
        renderDeckPresentationDrawer();
      });
    });
    hubRowAct(b,'minus','Delete \u201c'+p.name+'\u201d for good',function(){
      if(!window.confirm('Delete \u201c'+p.name+'\u201d?\n\nThis cannot '
        +'be undone.')) return;
      if(typeof deletePresByName==='function') deletePresByName(p.name);
      renderPresentationHub();
      if(typeof renderDeckPresentationDrawer==='function')
        renderDeckPresentationDrawer();
    });
    b.appendChild(pin);
    b.addEventListener('click',function(e){
      if(e&&(e.ctrlKey||e.metaKey||e.shiftKey)){
        noteSessionOpen(p.name);
        renderPresTabs();
        toast('\u201c'+p.name+'\u201d is on the open list \u2014 Ctrl+click '
          +'adds more; a plain click opens one',5000);
        return;
      }
      click(e);
    });
    return b;
  }
  function emptyPresentationList(host,text){
    var e=document.createElement('div');e.className='presentation-hub-empty';
    e.textContent=text;host.appendChild(e);
  }
  /* The hub sits above the full-screen deck as a real modal, rather than
     merely looking like one.  Keep its keyboard focus out of the deck
     until it closes; Home has no visible deck, so remember only the
     inertness this dialog itself introduced. */
  var presentationHubInertedDeck=false;
  function presentationHubDeckInert(on){
    if(!deckEl) return;
    if(on){
      if(!deckEl.hidden&&!deckEl.hasAttribute('inert')){
        deckEl.setAttribute('inert','');
        deckEl.setAttribute('aria-hidden','true');
        presentationHubInertedDeck=true;
      }
      return;
    }
    if(!presentationHubInertedDeck) return;
    deckEl.removeAttribute('inert');
    deckEl.removeAttribute('aria-hidden');
    presentationHubInertedDeck=false;
  }
  /* T394: the All column is the library proper -- grouped by folder, with
     the folder verbs (rename, delete) on the heading and drag-and-drop
     filing between them -- everything the rail used to do before it
     became the list of what is open. */
  var draggingPres=null;
  function hubFolderHead(f,count){
    var h=document.createElement('div');
    h.className='presentation-hub-folder';
    h.dataset.folder=f;
    h.title='Folder “'+f+'” — drag presentations onto it';
    var ic=document.createElement('span');ic.innerHTML=bic('open');
    var t=document.createElement('span');t.className='presentation-hub-folder-name';
    t.textContent=f;
    var n=document.createElement('span');n.className='presentation-hub-folder-count';
    n.textContent=count;
    h.appendChild(ic);h.appendChild(t);h.appendChild(n);
    [[bic('pen'),'Rename folder',function(){
        askText({title:'Rename this folder',value:f,ok:'Rename'},function(v){
          if(v==null) return;
          renameFolder(f,v);
        });
      }],
     [bic('exit'),'Delete folder (its presentations move out)',function(){
        deleteFolder(f);}]].forEach(function(b){
      var btn=document.createElement('button');
      btn.type='button';btn.className='presentation-hub-folder-btn';
      btn.innerHTML=b[0];btn.title=b[1];btn.setAttribute('aria-label',b[1]);
      btn.addEventListener('click',function(e){e.stopPropagation();b[2]();});
      h.appendChild(btn);
    });
    h.addEventListener('dragover',function(e){
      if(!draggingPres) return;
      e.preventDefault();e.dataTransfer.dropEffect='move';
      h.classList.add('dropping');
    });
    h.addEventListener('dragleave',function(){h.classList.remove('dropping');});
    h.addEventListener('drop',function(e){
      if(!draggingPres) return;
      e.preventDefault();e.stopPropagation();
      var nm=draggingPres;draggingPres=null;
      setPresFolder(nm,f);
    });
    return h;
  }
  function renderPresentationHub(){
    var root=$('#presentation-hub');
    var recentHost=$('#presentation-hub-recent'),allHost=$('#presentation-hub-all');
    if(!root||!recentHost||!allHost) return;
    recentHost.innerHTML='';allHost.innerHTML='';
    var recent=savedRecentPresentationNames();
    var all=libraryRows();
    if(!recent.length) emptyPresentationList(recentHost,
      'No recent presentations yet. Create one or open a saved deck.');
    recent.forEach(function(p){
      recentHost.appendChild(presentationLibraryRow(p,function(){
        closePresentationHub();choosePresentation(p.name);
      }));
    });
    /* loose presentations first, then every folder (an explicitly made
       folder shows even while empty, so there is something to drag onto) */
    var folders={},order=[];
    explicitFolders().forEach(function(f){folders[f]=[];order.push(f);});
    var loose=[];
    all.forEach(function(p){
      var f=p.folder||'';
      if(!f){loose.push(p);return;}
      if(!folders[f]){folders[f]=[];order.push(f);}
      folders[f].push(p);
    });
    function rowFor(p){
      var b=presentationLibraryRow(p,function(){
        closePresentationHub();choosePresentation(p.name);
      });
      b.draggable=true;
      b.addEventListener('dragstart',function(e){
        draggingPres=p.name;b.classList.add('dragging');
        try{e.dataTransfer.setData('text/plain',p.name);}catch(err){}
        e.dataTransfer.effectAllowed='move';
      });
      b.addEventListener('dragend',function(){
        draggingPres=null;b.classList.remove('dragging');
        allHost.classList.remove('dropping-root');
        $$('.presentation-hub-folder.dropping',allHost).forEach(function(el){
          el.classList.remove('dropping');});
      });
      return b;
    }
    if(!all.length&&!order.length) emptyPresentationList(allHost,
      'No saved presentations yet.');
    loose.forEach(function(p){allHost.appendChild(rowFor(p));});
    order.sort().forEach(function(f){
      allHost.appendChild(hubFolderHead(f,folders[f].length));
      folders[f].forEach(function(p){
        var r=rowFor(p);r.classList.add('infolder');allHost.appendChild(r);
      });
    });
  }
  /* dropping on the column's own background takes a presentation OUT of
     its folder; wired once, the column survives every re-render */
  function hubDropBoot(){
    var allHost=$('#presentation-hub-all');if(!allHost) return;
    allHost.addEventListener('dragover',function(e){
      if(!draggingPres) return;
      e.preventDefault();e.dataTransfer.dropEffect='move';
      if(!(e.target.closest&&e.target.closest('.presentation-hub-folder')))
        allHost.classList.add('dropping-root');
    });
    allHost.addEventListener('dragleave',function(e){
      if(e.target===allHost) allHost.classList.remove('dropping-root');
    });
    allHost.addEventListener('drop',function(e){
      if(!draggingPres) return;
      e.preventDefault();
      var nm=draggingPres;draggingPres=null;
      allHost.classList.remove('dropping-root');
      setPresFolder(nm,'');
    });
  }
  function closePresentationHub(){
    var root=$('#presentation-hub');
    if(root) root.hidden=true;
    presentationHubDeckInert(false);
  }
  /* T414: OPEN MEANS OPEN (2026-09-13, user: "why when you click open
     is there all the 'new poster options', like THAT WAS THERE ON THE
     LAST MENU"). Every door into this dialog is an Open door except the
     folder one, so the create row shows only when asked for
     ({create:true}); the rest of the time the dialog is the library,
     with "Open a file" first. A door wired straight as a click listener
     passes an event, which is not an options object. */
  function openPresentationHub(opts){
    var root=$('#presentation-hub');if(!root) return;
    var create=!!(opts&&opts.create===true);
    closeDeckPresentationDrawer();
    renderPresentationHub();root.hidden=false;
    ['#presentation-hub-new','#presentation-hub-poster',
     '#presentation-hub-folder'].forEach(function(id){
      var b=$(id); if(b) b.hidden=!create;});
    var ttl=$('#presentation-hub-title');
    if(ttl) ttl.textContent=create?'Open or create':'Open a presentation';
    var form=$('#presentation-hub-folderform');
    if(form&&!create) form.hidden=true;
    presentationHubDeckInert(true);
    setTimeout(function(){
      var b=$(create?'#presentation-hub-new':'#presentation-hub-file');
      if(b) b.focus();},0);
  }
  /* two doors, one drawer: the presenting bar's button and the editing
     bar's chevron beside Home (T396) both say whether it is open */
  function drawerDoors(){
    return [$('#deck-pres-open'),$('#qat-open')].filter(Boolean);
  }
  /* T448: a DOCKED bar does not close. Its whole point is staying
     there, and the pointer wanders off it constantly while you work,
     so the peek's leave rule and the hub's tidy-up would both shut it
     under you. The X in its head unpins it (back to a pop-up) rather
     than hiding a rail the layout has made room for. */
  function closeDeckPresentationDrawer(force){
    var d=$('#deck-pres-drawer');
    if(barDocked()&&!force) return;
    if(d){
      if(typeof overlayHide==='function') overlayHide(d);   /* T482 */
      d.hidden=true;
    }
    drawerDoors().forEach(function(b){b.setAttribute('aria-expanded','false');});
  }
  /* ---- T382: THE DRAWER IS WHAT IS OPEN NOW ------------------------
     It listed every presentation opened this session, which reads as a
     recents list when only one deck is ever on screen (2026-09-12, user:
     "it should show only open items, not all recents, with a separate
     recents button"). Open items are the presentation you are showing
     and the notebooks open in the app -- the things a click can put on
     screen without opening anything. A notebook row stops the talk and
     shows that notebook, the way the old column row did. */
  function openNotebookRows(){
    var out=[];
    var A=window.SemApp||{};
    (A.order||[]).forEach(function(stem){
      var sh=A.shells&&A.shells[stem]; if(!sh) return;
      out.push({stem:stem,label:sh.label||stem,path:sh.path||'',
        kind:sh.kind||'notebook'});
    });
    return out;
  }
  /* ---- T448: THE OPEN-ITEMS BAR --------------------------------------
     (2026-09-14, user: "the button beside home that is the only way to
     show what you currently have open is annoying. Often people want
     to swap a lot between presentation and tabs and version (also you
     can't duplicate a presentation or delete it from the main menu,
     there is very little controls). Having the side bar before was
     good when you could have it open all the time or pop it up more
     easily. Should also be able to make it as a top bar and customise
     a lot about the way you want things. Needs lots of user
     flexibility.")

     Three places it can live, remembered: a POP-UP that peeks from the
     left edge and closes when you leave it (what it was), a RAIL down
     the left that stays open and that the stage makes room for, or a
     STRIP across the top. Three sections it can list, each switchable:
     the presentations open in this tab, the notebooks, and this deck's
     saved versions. And every row carries its verbs -- switch,
     duplicate, rename, pin, close, delete -- because "there is very
     little controls" was the other half of the ask. */
  var OPENBAR_KEY='semopts:'+SCOPE+':openbar';
  var BAR_DEF={dock:'pop',pres:1,nb:1,vers:1};
  function barCfg(){
    var o={};
    try{o=JSON.parse(lsGet(OPENBAR_KEY)||'{}')||{};}catch(e){}
    return {dock:(o.dock==='left'||o.dock==='top')?o.dock:'pop',
      pres:o.pres===0?0:1,nb:o.nb===0?0:1,vers:o.vers===0?0:1};
  }
  function barSet(k,v){
    var c=barCfg();c[k]=v;
    lsSet(OPENBAR_KEY,JSON.stringify(c));
    barApply();
    renderDeckPresentationDrawer();
  }
  function barDocked(){return barCfg().dock!=='pop';}
  /* the deck gives up the room a docked bar takes, the way it does for
     an inspector pane (syncPaneDock) -- and the page is re-fitted,
     because the stage just changed size */
  function barApply(){
    var d=$('#deck-pres-drawer'); if(!d||!deckEl) return;
    var c=barCfg();
    d.classList.toggle('dock-left',c.dock==='left');
    d.classList.toggle('dock-top',c.dock==='top');
    deckEl.classList.toggle('openbar-left',c.dock==='left');
    deckEl.classList.toggle('openbar-top',c.dock==='top');
    if(c.dock!=='pop'&&d.hidden){d.hidden=false;renderDeckPresentationDrawer();}
    drawerDoors().forEach(function(b){
      b.setAttribute('aria-expanded',(!d.hidden).toString());});
    /* T470: the door wears the choice -- its icon and its word are the
       menu's own row for where the bar is now */
    var db=$('#deck-pres-dock');
    if(db){
      var w=BAR_DOCK_WORDS[c.dock]||BAR_DOCK_WORDS.pop;
      db.innerHTML=bic(w[0])+' <span id="deck-pres-dock-say">'+w[1]
        +'</span>\u00a0\u25be';
      db.title='This bar is '+w[2]+'. Where it sits, and what it lists';
      db.setAttribute('aria-label',db.title);
    }
    if(typeof applyZoom==='function') applyZoom();
  }
  var BAR_DOCK_WORDS={pop:['objects','Pop-up','a pop-up'],
    left:['dockright','Rail','a rail down the left'],
    top:['docktop','Strip','a strip across the top']};
  /* ---- A COPY OF A PRESENTATION (T448) --------------------------------
     "you can't duplicate a presentation". One deep copy under a free
     name, into the draft store, open beside the original. */
  function duplicatePresentation(nm){
    var src=(pres&&pres.name===nm)?pres:(loadDraft(nm)||savedByName(nm));
    if(!src){toast('“'+nm+'” is not here to copy');return '';}
    var base=nm+' copy',name=base,n2=1;
    while(savedByName(name)||loadDraft(name)){n2++;name=base+' '+n2;}
    var cp=deep(src);cp.name=name;
    if(!draftSet(name,JSON.stringify(cp),true)){
      toast('Could not copy — this browser had no room for it',8000);
      return '';
    }
    noteSessionOpen(name);
    renderPresTabs();renderDeckPresentationDrawer();
    if(typeof renderPresentationHub==='function') renderPresentationHub();
    toast('Copied to “'+name+'” — it is open beside this one');
    return name;
  }
  function barRowActs(host,acts){
    var w=document.createElement('span');
    w.className='deck-pres-acts';
    acts.forEach(function(a){
      if(!a) return;
      var b=document.createElement('button');
      b.type='button';b.className='deck-pres-act'+(a[3]?' on':'');
      b.innerHTML=a[0];b.title=a[1];
      b.setAttribute('aria-label',a[1]);
      b.addEventListener('click',function(e){
        e.stopPropagation();e.preventDefault();a[2]();});
      w.appendChild(b);
    });
    host.appendChild(w);
    return w;
  }
  function renderDeckPresentationDrawer(){
    var host=$('#deck-pres-list');if(!host) return;
    var c=barCfg();
    host.innerHTML='';
    function row(cls,icon,name,kind,title,click){
      var b=document.createElement('div');
      b.className='deck-pres-row'+(cls?' '+cls:'');
      b.title=title;
      if(click){
        b.tabIndex=0;b.setAttribute('role','button');
        b.addEventListener('click',click);
        b.addEventListener('keydown',function(e){
          if(e.key==='Enter'||e.key===' '){e.preventDefault();click(e);}});
      }
      var ic=document.createElement('span');ic.innerHTML=icon;
      var nm=document.createElement('span');nm.className='deck-pres-row-name';
      nm.textContent=name;
      var kd=document.createElement('span');kd.className='deck-pres-row-kind';
      kd.textContent=kind;
      b.appendChild(ic);b.appendChild(nm);b.appendChild(kd);
      host.appendChild(b);
      return b;
    }
    function head(txt){
      var h=document.createElement('div');
      h.className='deck-pres-sec';h.textContent=txt;
      host.appendChild(h);
    }
    /* ---- the presentations open in this tab ---- */
    if(c.pres){
      head('presentations');
      var names=openPresentationNames().slice();
      if(pres&&pres.name&&names.indexOf(pres.name)<0) names.unshift(pres.name);
      names.forEach(function(nm){
        var mine=(nm===pres.name);
        var q=presentationSummary(nm)||{name:nm};
        var r=row(mine?'current':'',presentationIcon(q),nm,
          presentationKind(q),
          mine?'The presentation you are in':('Switch to “'+nm+'”'),
          mine?null:function(){
            if(!barDocked()) closeDeckPresentationDrawer();
            choosePresentation(nm);
          });
        var pinned=(typeof isPinnedPresentation==='function')
          &&isPinnedPresentation(nm);
        barRowActs(r,[
          [bic('copy'),'Duplicate “'+nm+'”',function(){
            duplicatePresentation(nm);}],
          mine?[bic('text'),'Rename “'+nm+'”',function(){
            askText({title:'Rename this presentation',value:nm,ok:'Rename'},
            function(v){
            if(v&&v.trim()&&typeof renamePresentation==='function')
              renamePresentation(v.trim());
            renderDeckPresentationDrawer();
            });
          }]:null,
          [bic('pin'),pinned?('Unpin “'+nm+'”')
            :('Pin “'+nm+'” to the top of Recent'),function(){
            if(typeof togglePinPresentation==='function')
              togglePinPresentation(nm);
            renderDeckPresentationDrawer();
          },pinned],
          [bic('exit'),'Close “'+nm+'” (it stays saved)',
           function(){
            if(mine&&typeof closeGuard==='function'){
              closeGuard(nm).then(function(ok){
                if(!ok) return;
                closeOpenPresentation(nm);closeDeck();
                renderPresTabs();renderDeckPresentationDrawer();
              });
              return;
            }
            closeOpenPresentation(nm);
            renderPresTabs();renderDeckPresentationDrawer();
          }],
          [bic('minus'),'Delete “'+nm+'” for good',function(){
            if(!window.confirm('Delete “'+nm+'”?\n\nThis cannot '
              +'be undone.')) return;
            if(typeof deletePresByName==='function') deletePresByName(nm);
            renderDeckPresentationDrawer();
          }]]);
      });
      if(!names.length){
        var e0=document.createElement('div');e0.className='deck-pres-empty';
        e0.textContent='No presentation is open.';
        host.appendChild(e0);
      }
    }
    /* ---- the notebooks ---- */
    if(c.nb){
      head('notebooks');
      var nbs=openNotebookRows();
      nbs.forEach(function(n){
        var r=row('',bic('doc'),n.label,n.kind,
          'Stop presenting and show this notebook'
          +(n.path?(' ('+n.path+')'):''),
          function(){
            if(!barDocked()) closeDeckPresentationDrawer();
            closeDeck();
            var A=window.SemApp||{};
            if(A.activate) A.activate(n.stem);
          });
        barRowActs(r,[[bic('exit'),'Close this notebook',function(){
          var A=window.SemApp||{};
          if(A.closeNotebook) A.closeNotebook(n.stem);
          renderDeckPresentationDrawer();
        }]]);
      });
      if(!nbs.length){
        var e=document.createElement('div');e.className='deck-pres-empty';
        e.textContent='No notebook is open.';
        host.appendChild(e);
      }
    }
    /* ---- this deck's saved versions (T448: "and version") ---- */
    if(c.vers&&typeof histIndex==='function'){
      head('versions of this presentation');
      var vh=document.createElement('div');
      vh.className='deck-pres-empty';vh.textContent='Looking…';
      host.appendChild(vh);
      var want=pres&&pres.name;
      histIndex().then(function(ix){
        /* the deck may have changed under the promise */
        if(!pres||pres.name!==want||!vh.parentNode) return;
        var rows=(ix||[]).slice(-6).reverse();
        if(!rows.length){
          vh.textContent='No versions yet — one is kept when you save, '
            +'open or checkpoint this deck.';
          return;
        }
        vh.remove();
        rows.forEach(function(v){
          /* T465: the index's fields are `nm` (a checkpoint's name),
             `why` (opened / saved / checkpoint) and `at` (ms). This read
             v.name and v.t, which do not exist, so every row said
             "checkpoint" or "opened" with no time and no name, and
             clicking one opened History on the newest version whatever
             you had clicked (2026-09-15 review). The History rail's own
             helpers name a version the same way here. */
          var lab=(typeof histLabel==='function')?histLabel(v)
            :(v.nm||v.why||'version');
          /* T484: the right-hand word is WHY (opened / saved /
             checkpoint); an unnamed version printed its time twice */
          var kind=v.why||'';
          var r=row('',bic('history'),lab,
            kind||((typeof histClock==='function'&&v.at&&v.nm)?histClock(v.at):''),
            'Open the history on this version',function(){
              if(!barDocked()) closeDeckPresentationDrawer();
              if(typeof openHistory==='function') openHistory(v.id||'');
            });
          if(v.at&&typeof histClock==='function')
            r.title=lab+' \u00b7 '+histClock(v.at)+(v.why?(' \u00b7 '+v.why):'');
          r.classList.add('deck-pres-ver');
        });
      }).catch(function(){
        if(vh.parentNode) vh.textContent='Versions could not be read.';
      });
    }
  }
  /* the dock menu: where it sits, and what it lists */
  function barDockMenu(btn){
    var old=$('#openbar-menu'); if(old){overlayDrop(old);return;}
    var m=document.createElement('div');
    m.className='sh-menu vw-menu';m.id='openbar-menu';
    var c=barCfg();
    menuHead(m,'where this bar sits');
    [['pop','A pop-up',
      'It opens from the chevron beside Home and when you reach the left '
      +'edge, and closes when you leave it'],
     ['left','A rail down the left',
      'It stays open and the slide makes room for it'],
     ['top','A strip across the top',
      'It stays open above the slide']].forEach(function(o){
      var b=document.createElement('button');
      b.className='dbtn vw-opt';b.type='button';
      b.innerHTML=bic(o[0]==='top'?'docktop':(o[0]==='left'?'dockright'
        :'objects'))+' '+esc(o[1]);
      b.title=o[2];
      b.setAttribute('aria-pressed',(c.dock===o[0]).toString());
      b.addEventListener('click',function(e){
        e.stopPropagation();overlayDrop(m);barSet('dock',o[0]);});
      m.appendChild(b);
    });
    menuHead(m,'what it lists');
    [['pres','Presentations'],['nb','Notebooks'],
     ['vers','Versions']].forEach(function(o){
      var b=document.createElement('button');
      b.className='dbtn vw-opt';b.type='button';
      b.innerHTML=bic(c[o[0]]?'eye':'none')+' '+esc(o[1]);
      b.setAttribute('aria-pressed',(!!c[o[0]]).toString());
      b.addEventListener('click',function(e){
        e.stopPropagation();overlayDrop(m);barSet(o[0],c[o[0]]?0:1);
      });
      m.appendChild(b);
    });
    overlayMount(btn,m);
  }
  function openDeckPresentationDrawer(){
    var d=$('#deck-pres-drawer');
    if(!d) return;
    renderDeckPresentationDrawer();
    /* T482: a POP-UP is on the overlay owner's stack, like every menu:
       File opened underneath it and both stood open (2026-09-15
       review); opening File closes it now, and Escape and an outside
       click work. A docked bar is part of the frame, not an overlay. */
    if(!barDocked()&&typeof overlayShow==='function')
      overlayShow($('#qat-open')||null,d);
    else d.hidden=false;
    drawerDoors().forEach(function(b){b.setAttribute('aria-expanded','true');});
  }
  /* T382: THE DRAWER SLIDES OUT AT THE LEFT EDGE while presenting, the
     way the presentations rail does outside the deck (2026-09-12, user:
     "the auto-hidden sidebar doesn't appear"). The rail's own peek
     handler returns early under body.deck-open, and deckIsolate has made
     the rail inert, so nothing answered the edge during a talk. Same
     14px hit zone as the rail's; it closes when the pointer leaves the
     drawer by the same 40px margin the column and the present bar use.
     T396: WHILE EDITING TOO. "Presenting only" left the editor with no
     sidebar at all -- the rail is behind it -- and the user asked for it
     there in as many words (2026-09-13: "the side bar that shows you all
     the open presentations doesn't appear in presentation mode"). The
     one exception is a slide column set to hide itself, which already
     owns the left edge (initFilmAuto); the chevron beside Home opens the
     drawer there. */
  function initDrawerPeek(){
    document.addEventListener('mousemove',function(e){
      var d=$('#deck-pres-drawer'); if(!d) return;
      /* T448: a docked bar is already open and stays open */
      if(barDocked()) return;
      if(deckEl.hidden||(mode!=='view'&&mode!=='edit')) return;
      if(mode==='edit'&&filmAutoOn()) return;
      var hub=$('#presentation-hub');
      if(hub&&!hub.hidden) return;
      if(d.hidden){
        if(e.clientX<=14) openDeckPresentationDrawer();
        return;
      }
      var r=d.getBoundingClientRect();
      if(e.clientX>r.right+40||e.clientY>r.bottom+40)
        closeDeckPresentationDrawer();
    });
  }
  function presentationHubBoot(){
    var hub=$('#presentation-hub'),drawer=$('#deck-pres-drawer');
    var drawerBrowse=$('#deck-pres-browse'),drawerRecent=$('#deck-pres-recent');
    drawerDoors().forEach(function(b){
      b.addEventListener('click',function(e){
        e.stopPropagation();
        if(!drawer) return;
        if(drawer.hidden) openDeckPresentationDrawer();
        else closeDeckPresentationDrawer(true);
      });
    });
    /* T448: the bar's own head -- where it sits, a new presentation,
       and an X that un-docks rather than hides */
    var dock=$('#deck-pres-dock');
    if(dock) dock.addEventListener('click',function(e){
      e.stopPropagation();barDockMenu(dock);});
    var dnew=$('#deck-pres-new');
    if(dnew) dnew.addEventListener('click',function(){
      if(!barDocked()) closeDeckPresentationDrawer();
      newPresentation();
    });
    /* T470: AN X CLOSES. On a docked bar it un-docked and left the
       bar open as a pop-up over the thumbnails, under a label that
       said "Close this bar" (2026-09-15 review). It closes: the bar
       goes back to a pop-up, which is the only kind that can be shut,
       and shuts. The door beside it is how you dock it again. */
    var dclose=$('#deck-pres-close');
    if(dclose) dclose.addEventListener('click',function(e){
      e.stopPropagation();
      if(barDocked()) barSet('dock','pop');
      closeDeckPresentationDrawer(true);
    });
    barApply();
    /* T396: Home from the editor's own bar */
    var home=$('#qat-home');
    if(home) home.addEventListener('click',function(){
      if(window.SemApp&&window.SemApp.goHome) window.SemApp.goHome(true);
      else closeDeck();
    });
    if(drawerBrowse) drawerBrowse.addEventListener('click',openPresentationHub);
    /* the separate Recents door: the same library dialog, opened on its
       Recent column */
    if(drawerRecent) drawerRecent.addEventListener('click',function(){
      openPresentationHub();
      setTimeout(function(){
        var first=$('#presentation-hub-recent .presentation-hub-row');
        if(first) first.focus();},0);
    });
    initDrawerPeek();
    hubDropBoot();
    /* T394: the rail's two doors under its open list */
    var railRecent=$('#pr-recent'),railAll=$('#pr-library');
    if(railRecent) railRecent.addEventListener('click',function(){
      openPresentationHub();
      setTimeout(function(){
        var first=$('#presentation-hub-recent .presentation-hub-row');
        if(first) first.focus();},0);
    });
    if(railAll) railAll.addEventListener('click',openPresentationHub);
    var close=$('#presentation-hub-close');
    if(close) close.addEventListener('click',closePresentationHub);
    if(hub) hub.addEventListener('click',function(e){
      if(e.target===hub) closePresentationHub();
    });
    var newer=$('#presentation-hub-new');
    if(newer) newer.addEventListener('click',function(){
      closePresentationHub();newPresentation();
    });
    var poster=$('#presentation-hub-poster');
    if(poster) poster.addEventListener('click',function(){
      closePresentationHub();newPoster();
    });
    var folder=$('#presentation-hub-folder');
    var form=$('#presentation-hub-folderform');
    var field=$('#presentation-hub-foldername');
    if(folder) folder.addEventListener('click',function(){
      if(!form) return;
      form.hidden=!form.hidden;
      if(!form.hidden&&field){field.focus();field.select();}
    });
    if(form) form.addEventListener('submit',function(e){
      e.preventDefault();
      var name=field&&field.value.trim();
      if(!name) return;
      if(newFolder(name)){
        field.value='';form.hidden=true;renderPresentationHub();
      }
    });
    var file=$('#presentation-hub-file');
    if(file) file.addEventListener('click',function(){
      /* T414: the same door the rail's row uses -- a real file handle
         where the browser has one, so Save writes back to the file you
         opened; the bare <input> only where it does not */
      closePresentationHub();openDeckFile();
    });
    var pptx=$('#presentation-hub-pptx');
    if(pptx) pptx.addEventListener('click',function(){
      closePresentationHub();var input=$('#pptxfile');if(input) input.click();
    });
    document.addEventListener('keydown',function(e){
      if(e.key!=='Escape') return;
      if(hub&&!hub.hidden){e.preventDefault();e.stopPropagation();
        closePresentationHub();return;}
      if(drawer&&!drawer.hidden){e.preventDefault();e.stopPropagation();
        closeDeckPresentationDrawer();}
    },true);
    window.SemApp.deckHub=openPresentationHub;
    window.SemApp.deckNewFolder=function(){
      openPresentationHub({create:true});
      if(form){form.hidden=false;if(field) field.focus();}
    };
    window.SemApp.deckRecentNames=savedRecentPresentationNames;
    window.SemApp.deckPinToggle=togglePinPresentation;   /* T435 */
    renderPresentationHub();renderDeckPresentationDrawer();
    if(APP.refreshChrome) APP.refreshChrome();
  }
  function choosePresentation(nm){
    var A=window.SemApp||{};
    if(nm!==pres.name){
      if(A.exitStyling) A.exitStyling();   /* leave any open custom view */
      lsSet(PFX+'last',nm);
      loadPresentation(nm);
      cur=0;activePane=-1;
    }
    noteSessionOpen(nm);   /* T394: it is open now, whichever kind it is */
    /* a custom view is edited in the document; a deck on the slide stage */
    if(isViewPres(pres)){openCustomView();return;}
    openDeck('edit');   /* land straight in the slide editor */
  }
  function newPresentation(){
    var n2=1,name='presentation';
    while(savedByName(name)||loadDraft(name)){
      n2++;name='presentation-'+n2;}
    /* deliberately NOT persisted yet: a new presentation only starts
       saving (draft + autosave) once you actually edit it, so clicking
       "New" never litters the project with empty decks */
    pres={name:name,slides:[emptySlide()]};
    source='auto';
    cur=0;activePane=0;
    openDeck('edit');   /* land straight in the slide editor */
    /* T283: and ask where it is going to live, the first time only */
    if(typeof askWhereToSave==='function') askWhereToSave();
  }
  /* ---- CUSTOM VIEW: a third kind of saved thing (2026-07-29) ---------
     Not slides. A custom view remembers how the NOTEBOOK looks: the
     styling of its markdown cells and headings, plus the whole filter /
     hidden-cell / figure-size state. It opens in the document, not on the
     slide stage, so the styling bar edits what you are looking at. ---- */
  function isViewPres(p){return !!(p&&p.kind==='view');}
  /* rail row icons come from SemIcons (newdeck/newposter/newview) in
     presItem — the RAIL_ICO copy of that path data was deleted
     2026-08-23 so branding.py stays the only place artwork lives */
  function newCustomView(){
    var A=window.SemApp||{};
    var stem=A.active;
    if(!stem||!A.enterStyling){
      toast('Open a notebook first — a custom view restyles a notebook');
      return;
    }
    var n2=1,name='custom view';
    while(savedByName(name)||loadDraft(name)){
      n2++;name='custom view '+n2;}
    /* seeded from what you are looking at right now, so a new view never
       throws away the filters you already set up */
    pres={name:name,kind:'view',nb:stem,style:{},
          view:(A.layoutSnapshot&&A.layoutSnapshot(stem))||{}};
    source='auto';
    cur=0;activePane=-1;
    openCustomView();
  }
  function openCustomView(){
    var A=window.SemApp||{};
    closeDeck();                     /* the document, not the slide stage */
    if(pres.nb&&A.shells&&A.shells[pres.nb]&&A.activate)
      A.activate(pres.nb);
    if(pres.view&&A.applySnapshot)
      A.applySnapshot(pres.nb||A.active,pres.view);
    A.enterStyling(pres,function(){markDirty();});
    renderPresTabs();
    status();
  }
  function closeCustomView(){
    var A=window.SemApp||{};
    if(A.exitStyling) A.exitStyling();
    renderPresTabs();
  }
  window.SemApp.viewClose=closeCustomView;
  function newPoster(){
    var n2=1,name='poster';
    while(savedByName(name)||loadDraft(name)){
      n2++;name='poster-'+n2;}
    /* like a new presentation, nothing persists until the first edit.
       Posters start WHITE: they exist to be printed (2026-08-04) */
    var s=emptySlide();
    /* BLANK, not pre-filled: the 3-column academic template used to be
       applied here, so a new poster opened already covered in headings
       and placeholder frames you had to clear before starting your own
       (2026-08-18, user: "opening a poster should open as blank not a
       default fill"). The templates are all still one click away in
       Layouts — which is where choosing one belongs. Even the blank
       slide's full-page ghost frame goes: on a deck it is the "click to
       fill" idiom, but stretched over an A0 sheet it is one more thing
       you did not put there. */
    s.annots=[];
    pres={name:name,slides:[s],page:'a0p',tokens:{c:{page:'#ffffff'}}};
    source='auto';
    cur=0;activePane=-1;
    openDeck('edit');
    if(typeof askWhereToSave==='function') askWhereToSave();
  }

  function renderPresRow(){
    var lbl=$('#pres-current');
    if(lbl) lbl.textContent=pres.name||'(unnamed)';
    var inp=$('#pres-name');
    if(document.activeElement!==inp&&inp.value!==pres.name)
      inp.value=pres.name;
    renderPresTabs();
  }
  function renderControls(){
    syncFurnBtns();updateCropLabel();
    var s=pres.slides[cur];
    $$('#layout-row .lay,#layout-menu-grid .lay')
      .forEach(function(b){
      /* highlight the template last applied to this slide (if any) */
      b.setAttribute('aria-pressed',
        (!!s&&s.lay===b.dataset.lay).toString());
      b.disabled=!s;
    });
    /* Home's strip lights the layout the NEXT slide takes (T218) */
    if(typeof syncNewSlideMarks==='function') syncNewSlideMarks();
    var te=$('#title-editor'), eb=$('#dc-edit');
    var isTitle=!!s&&s.layout==='title';
    if(te){
      te.hidden=!isTitle;
      if(isTitle){
        var ti=$('#ts-title'),su=$('#ts-sub');
        if(ti&&document.activeElement!==ti) ti.value=s.title||'';
        if(su&&document.activeElement!==su) su.value=s.sub||'';
      }
    }
    if(eb){
      eb.disabled=!s;
      /* Only "get me into the editor" survives. Going the other way is
         already the Notebooks button on the rail, and this duplicate was
         badly named and awkwardly placed in the bargain (2026-08-07,
         user: "the 'swap to notebooks' button is a stupid name and in a
         stupid place"). */
      eb.hidden=(mode==='edit');
      eb.innerHTML=bic('pen')+' Open the editor';
    }
  }
  /* the current slide's interactive frame editor — embedded inline as
     the big view in the merged slides list (one view, not two) */
  function buildSlideEditor(s){
    var ed=document.createElement('div');
    ed.className='pane-editor freeform';ed.id='pane-editor';
    if(!s){
      ed.innerHTML='<div class="pane empty">'
        +'<span class="pane-t">no slide</span></div>';
      return ed;
    }
    var cells=slideCells(s);
    if(!cells.length){
      ed.innerHTML='<div class="pane empty"><span class="pane-t">'
        +'pick a layout above, or click a card in the document'
        +'</span></div>';
      return ed;
    }
    cells.forEach(function(pair){
      var a=pair.a, ai=pair.i;
      var it=a.ref?resolveRef(a.ref):null;
      var p=document.createElement('div');
      p.className='pane slot'+(it?' filled':' empty')
        +(ai===activePane?' active':'');
      var ap7=anchorPos(a,a.w,a.h);
      p.style.left=ap7.x+'%';p.style.top=ap7.y+'%';
      p.style.width=(a.w||10)+'%';p.style.height=(a.h||10)+'%';
      if(it){
        /* render the frame EXACTLY as it appears on the slide: the real
           card content for the chosen part (code / figure / output) */
        var frame=document.createElement('div');frame.className='an-cell';
        var ch=document.createElement('div');ch.className='an-cellhead';
        var chT=document.createElement('span');
        chT.className='an-cellhead-t';chT.textContent=it.title;
        ch.appendChild(chT);
        var pt0=partOf(a),facs0=facetList(it.ns);
        if(facs0.length>1||pt0==='code'){
          var pl=document.createElement('span');
          pl.className='an-cellpart';pl.textContent=pt0;
          ch.appendChild(pl);
        }
        if(multiNb()) ch.appendChild(nbChip('spane-nb',it.nb));
        frame.appendChild(ch);
        var b=framePart(it.ns,a.part);
        if(b){if(a.ts) b.style.zoom=a.ts;applyCrop(b,a);frame.appendChild(b);}
        applyCellColor(frame,a);
        p.title=it.nb+' — '+it.title;
        p.appendChild(frame);
        var pc=buildPartChooser(s,ai);
        if(pc) p.appendChild(pc);
      } else {
        var t=document.createElement('span');t.className='pane-t';
        t.textContent=a.ref?('missing: '+a.ref)
          :(ai===activePane?'▸ now click a card in the notebook'
            :'empty — click to select this frame');
        p.appendChild(t);
      }
      if(a.ref){
        var x=document.createElement('button');x.className='pane-x';
        x.innerHTML=bic('exit')||'&#10005;';x.title='Clear this frame';
        x.addEventListener('click',function(e){e.stopPropagation();
          a.ref=null;activePane=ai;markDirty();refresh();});
        p.appendChild(x);
      }
      p.addEventListener('click',function(e){
        e.stopPropagation();activePane=ai;refresh();});
      ed.appendChild(p);
    });
    return ed;
  }
  /* T303: THE INDEX HAS TO MATCH THE DECK. This read the live card
     first -- the order T298 inverted in cloneBody -- and it is
     miniDiagram's cell branch, so the film strip, the slide overview,
     the outline sheet, the history rows, the layout-card previews, the
     saved-arrangement thumbnails and the trace overview all repainted
     with the notebook's current figure while the slide kept the old
     one. Inside a single miniDiagram the flip branch already used
     framePart (kept) and this one did not, so one thumbnail was drawn
     from two sources. */
  function paneImgSrc(ref){
    var kept=(!ref||refIsLive(ref))?null:embBody(ref);
    var card=ref?(kept||cardEl(ref)||embBody(ref)):null;
    var img=card?$('.figframe img',card):null;
    return img?img.getAttribute('src'):null;
  }
  function paneThumb(ref){
    var w=document.createElement('span');w.className='mini-pane';
    var it=ref?resolveRef(ref):null;
    if(!it){w.className+=' empty';return w;}
    var src=paneImgSrc(ref);
    if(src){
      var m=document.createElement('img');
      m.src=src;m.alt='';m.loading='lazy';
      m.setAttribute('aria-hidden','true');   /* decorative (T105) */
      w.appendChild(m);
    } else if(it.kind==='note'){
      w.className+=' is-note';
    } else if(it.kind==='figure'||it.kind==='diagnostic'){
      w.className+=' is-fig';
    } else {
      w.className+=' is-code';
      w.textContent='</>';
    }
    return w;
  }
  /* ---- slide thumbnails ------------------------------------------------
     A thumbnail is a SCALE MODEL of the slide, not a picture of the
     notebook cells on it. It used to walk slideCells() and nothing else,
     so a slide made of text, arrows, shapes or images showed as an empty
     box and every such slide in the strip looked identical (2026-08-20,
     user: "thumbnails do now show text, or anything else for that matter,
     just the cells").
     Everything is placed in the same page percentages the canvas uses, so
     positions are exactly right at any size. Two things cannot scale
     linearly and get a floor instead — type and stroke width — because
     0.3px of either is nothing at all. That is the opposite of the rule
     fontPx follows on the real page, and deliberately: the page is the
     document and must stay true to itself, a thumbnail is an INDEX and
     has to be legible. */
  var MINI_H=66;      /* mirrors --mini-h in deck.css */
  /* MINI_H is the FLOOR now, not the height: the column is draggable, so
     a thumbnail grows with the room it is given and its type and strokes
     have to grow with it or a 460px strip draws 3px lettering
     (2026-08-22). Measured off the LIST rather than off a thumbnail —
     renderFilm sizes type before the node is in the document, and an
     unattached node has no height to read. Computed once per render, not
     once per item. */
  var MINI_AR=116/66,miniHNow=MINI_H;
  function miniH(){
    var l=$('#film-list');
    var w=l?l.clientWidth:0;
    if(!w) return MINI_H;
    /* the padding and the row's own gutters the CSS spends before the
       thumbnail gets the rest */
    return Math.max(MINI_H,Math.round((w-46)/MINI_AR));
  }
  /* svg ids (gradients) must be unique across every thumbnail in the
     strip, not just within one — a repeated id would silently paint every
     later slide's gradient with the first slide's */
  var miniSeq=0;
  function miniText(d,a,txt,cls,centred){
    if(!String(txt||'').trim()) return;
    var t=document.createElement('span');
    t.className='mini-tx'+(cls?' '+cls:'');
    t.style.left=(a.x||0)+'%';t.style.top=(a.y||0)+'%';
    if(a.w!=null) t.style.width=a.w+'%';
    t.style.fontSize=Math.max(2,miniHNow*(a.size||2.6)/100).toFixed(2)+'px';
    if(a.color) t.style.color=tokVal(a.color);
    if(a.b) t.style.fontWeight='700';
    if(a.i) t.style.fontStyle='italic';
    if(a.align) t.style.textAlign=a.align;
    if(a.font) t.style.fontFamily=fontCss(a.font);
    if(a.bg!==0&&a.bgc) t.style.background=tokVal(a.bgc);
    /* a title is anchored on its CENTRE, the way the canvas anchors it */
    var tr=centred?'translate(-50%,-50%)':'';
    if(a.rot) tr+=(tr?' ':'')+'rotate('+a.rot+'deg)';
    if(tr) t.style.transform=tr;
    if(a.op!=null&&a.op<1) t.style.opacity=a.op;
    t.textContent=String(txt);
    d.appendChild(t);
  }
  /* a box-shaped item (shape, image, cell frame) at its page rect */
  function miniBox(d,a,cls){
    var b=document.createElement('span');
    b.className='mini-it'+(cls?' '+cls:'');
    b.style.left=(a.x||0)+'%';b.style.top=(a.y||0)+'%';
    b.style.width=(a.w||10)+'%';b.style.height=(a.h||10)+'%';
    if(a.rot) b.style.transform='rotate('+a.rot+'deg)';
    if(a.op!=null&&a.op<1) b.style.opacity=a.op;
    d.appendChild(b);
    return b;
  }
  /* the stroke a thumbnail draws: the page weight scaled down, floored so
     a hairline is still a line */
  function miniSw(a){
    return Math.max(0.6,swOf(a)*miniHNow/SW_REF_H).toFixed(2);
  }
  /* re-weight a borrowed shape/freehand svg for thumbnail scale, and drop
     its dash: dashes are measured in the stroke's own units, so a pattern
     sized for an A0 poster is one long dash across a 116px thumbnail */
  function miniStroke(host,a){
    var p=host.querySelector('path'); if(!p) return;
    p.setAttribute('stroke-width',miniSw(a));
    p.removeAttribute('stroke-dasharray');
  }
  /* ---- THE DESIGN SURFACE (T87, 2026-08-29) ---------------------------
     "Where was the button where people can 'standardise presentation'...
     controlling things like 'global heading layouts'... Then it would be
     cool if you could also 'show outlines of all objects'."

     Three quarters of this was already built and scattered: the style
     registry (pres.styles) decides what a Heading looks like, the
     Standardise pane finds type that has drifted from it, the Apply
     dialog pushes a look across a deck, and T5's selection criteria find
     every box of a kind. What was missing was a PLACE -- one screen that
     puts a deck's type in front of you and lets you change it -- plus
     two things that did not exist at all: a default POSITION for a named
     type, and a way to see every object on every slide as an outline.

     Built on what is there, deliberately:
       * it writes pres.styles, the same registry styleDef reads, so a
         change here is the same change the Styles menu makes;
       * it re-stamps through applyStyleTo, the one function that puts a
         style onto a box, rather than writing size/weight/colour itself;
       * the outline sheet is miniDiagram, the renderer the film strip
         and the overview map already use.
     And it is NOT a second Apply dialog. Apply answers "which slides,
     which properties, which type"; this answers "what does a Heading
     look like in this deck". Position is the one thing here that Apply
     cannot express, and it is a button you press, never something
     applyStyleTo does on your behalf -- a style stamp that yanked boxes
     across the page would be unusable. */
  var dgSel='title', dgOutline=false, dgVarOpen={};
  /* the smallest a drag proxy in the outline sheet may be, in page
     percent. A horizontal or vertical line's bounding box is
     zero-thickness and there is nothing to grab; the canvas answers the
     same question with a 12px tolerance round the segment (arrowAt).
     6% of a 116x66px miniature is ~7x4px, and the fallback box proxy
     below is already only 8% tall, so this is no outlier. */
  var DG_HIT=6;
  /* WHICH SLIDES (T130). The put gesture was all-wearers-everywhere and
     the outline sheet was every-slide-always; the ask named sections
     and ranges for both. One selector builder, two independent scopes,
     because "move the headings in section 2" and "show me outlines of
     slides 4-9" are different questions asked at different moments. */
  /* T231: the put button's own scope went with the selector -- it
     reads the selection now, so a second answer to "which slides"
     would only be a way to disagree with yourself. The sheet keeps
     one, because it says which slides the column SHOWS. */
  var dgSheetScope={kind:'all'};
  function dgInScope(sc,si){
    if(!sc||sc.kind==='all') return true;
    if(sc.kind==='sec')
      return ((pres.slides||[])[si]||{}).sec===sc.sec;
    return (si+1)>=sc.from&&(si+1)<=sc.to;
  }
  function dgScopeLabel(sc){
    if(!sc||sc.kind==='all') return 'on every slide';
    if(sc.kind==='sec'){
      var meta=(pres.sections||{})[sc.sec];
      return 'in \u00a7'+((meta&&meta.name)||'section');
    }
    return 'slides '+sc.from+'\u2013'+sc.to;
  }
  /* a typed range, made safe (JVR-05). SORT FIRST, then clamp BOTH
     ends: clamping the first endpoint only upward and the second only
     downward and swapping afterwards let a reversed out-of-range input
     like 999-1 store from=1,to=999 on a twelve-slide deck. dgInScope
     compares against real slide numbers, so the SELECTION was never
     wrong -- but dgScopeLabel is the only place a user can read back
     which slides are in scope, and it read those numbers out. An empty
     deck yields 1..1 rather than the degenerate 1..0. */
  function dgRange(a,b,total){
    var last=Math.max(1,total);
    function fit(n){return Math.min(last,Math.max(1,n));}
    return {from:fit(Math.min(a,b)),to:fit(Math.max(a,b))};
  }
  function dgScopeSelect(sc,onchange){
    var sel=document.createElement('select');
    sel.className='dg-scope';
    sel.title='Which slides this applies to';
    function opt(v,label){
      var o=document.createElement('option');
      o.value=v;o.textContent=label;sel.appendChild(o);return o;
    }
    opt('all','on every slide');
    /* only sections actually in use: an empty registry entry is not a
       place a slide can be */
    var used={};
    (pres.slides||[]).forEach(function(sl){
      if(sl&&sl.sec) used[sl.sec]=1;});
    Object.keys(used).forEach(function(id){
      var meta=(pres.sections||{})[id];
      opt('sec:'+id,'in \u00a7'+((meta&&meta.name)||'section'));
    });
    opt('range','slides\u2026');
    sel.value=sc.kind==='all'?'all'
      :sc.kind==='sec'?('sec:'+sc.sec):'range';
    sel.addEventListener('change',function(){
      var v=sel.value;
      if(v==='all'){sc.kind='all';}
      else if(v.indexOf('sec:')===0){sc.kind='sec';sc.sec=v.slice(4);}
      else {
        var total=(pres.slides||[]).length;
        /* T475: the editor's own question; the change lands in its answer */
        askText({title:'Which slides?',label:'A range like 4-9, or one number',
          value:'1-'+total,ok:'Use these'},function(got){
          var mm=got&&got.match(/^\s*(\d+)\s*(?:[-\u2013]\s*(\d+))?\s*$/);
          if(!mm){sel.value=sc.kind==='all'?'all'
            :sc.kind==='sec'?('sec:'+sc.sec):'range';return;}
          sc.kind='range';
          var r=dgRange(parseInt(mm[1],10),
            parseInt(mm[2]||mm[1],10),total);
          sc.from=r.from;sc.to=r.to;
          onchange();
        });
        return;
      }
      onchange();
    });
    return sel;
  }
  /* re-render the body WITHOUT losing where you were in it: a drop in
     the sheet redraws everything, and snapping back to the top of a
     long panel would make a second drag a scroll hunt (T130) */
  function dgBodyKeep(ov){
    var b=ov&&ov.querySelector('#dg-body');
    var at=b?b.scrollTop:0;
    dgBody(ov);
    b=ov&&ov.querySelector('#dg-body');
    if(b) b.scrollTop=at;
  }

  function dgStyleRec(id){
    var st=deckStyles();
    if(!st[id]) st[id]={};
    return st[id];
  }
  /* every box wearing a named type, as {s, i, a} across the whole deck */
  function dgWearers(id){
    var out=[];
    (pres.slides||[]).forEach(function(sl,si){
      (sl.annots||[]).forEach(function(a,ai){
        if(a&&a.k==='text'&&a.style===id) out.push({s:si,i:ai,a:a});});
    });
    return out;
  }
  /* re-stamp the registry onto everything wearing it. THE point of a
     standardise surface: a definition nobody is wearing is a preference,
     not a standard. */
  function dgRestamp(id){
    var n=0;
    dgWearers(id).forEach(function(w){applyStyleTo(w.a,id);n++;});
    return n;
  }
  function dgClose(){
    var ov=$('#deck-design');
    if(ov) ov.remove();
    document.removeEventListener('keydown',dgKey,true);
  }
  function dgKey(e){
    if(!$('#deck-design')) return;
    if(e.key==='Escape'){
      /* T470: the Style sets picker may be open over this screen; its
         Escape is its own */
      var sd=$('#ss-dlg'); if(sd&&!sd.hidden) return;
      e.preventDefault();e.stopPropagation();dgClose();}
  }
  function dgSpecimen(el,id){
    var d=styleDef(id); if(!d) return;
    el.style.fontWeight=d.b?'700':'400';
    el.style.fontStyle=d.i?'italic':'normal';
    el.style.fontFamily=d.font?fontCss(d.font):'';
    el.style.color=d.color?tokVal(d.color):'';
    /* the LADDER has to read as a ladder, so sizes are shown in
       proportion to each other rather than at their page size -- 7.2% of
       an A0 sheet does not fit in a rail */
    el.style.fontSize=(11+(d.size||2.6)*1.9)+'px';
  }
  /* ---- T224: EVERY BOX OF A KIND, IN A TABLE --------------------------
     (2026-09-03, user: "I wanted more than just titles, also images
     etc... There should be unselect all, and select all button... I want
     full customisation here as well, font, font size, background colour,
     then why doesn't it show the x and y position as well... Would be
     good if there was also a table of them all to the right, which has
     things like colour, font etc. of them all and you can make them all
     match, or change them individually here, or change title colours in
     a range... it would be good if you could click a bunch and they get
     selected, then you click a button that says 'match style of', then
     click one and they all match to that. And you can choose as well
     what gets matched, whether it's all, or just position, or colour, or
     font etc. Do you get the point of this? So it is hard to make things
     match across slides, so this will help with this."

     The screen already knew how to change what a KIND looks like. What
     it could not do is the thing the ask is actually about: see the
     boxes themselves, side by side, and pull the odd one into line. The
     table is that. It is the same annots the canvas renders -- no copy,
     no import step -- so an edit here is an edit there. */
  var dgMarked={},dgMatchArm=false,dgMatchWhat='all';
  /* T230: the slides you pick in the strip are a SET, and the table
     is what they narrow (2026-09-03, user: "when selecting the
     slide thumbnails on this view it would be good if they stayed
     selected and became cumulative and that fed into things like
     the table"). Empty means every slide. */
  var dgSheetPick={};
  function dgPickedAny(){
    for(var k in dgSheetPick) if(dgSheetPick[k]) return true;
    return false;
  }
  function dgPickedCount(){
    var n=0;
    for(var k in dgSheetPick) if(dgSheetPick[k]) n++;
    return n;
  }
  /* `text` is every text box whatever style it wears, or none: a box
     that has never been given a named style appeared in no table at
     all, and an unstyled box is exactly the thing you go looking for */
  var DG_OBJ_KINDS=[['text','Text boxes, all of them','text'],
    ['cell','Figures','cellcard'],
    ['image','Pictures','image'],['rect','Shapes','shapes'],
    ['table','Tables','table'],['flip','Flip books','flipbook'],
    ['arrow','Arrows and lines','arrow']];
  function dgIsObj(){return /^obj:/.test(dgSel);}
  function dgAnyStyleWorn(){
    return styleOrder().some(function(id){return dgWearers(id).length>0;});
  }
  function dgObjKind(){return dgSel.slice(4);}
  function dgKindLabel(){
    if(!dgIsObj()){
      var d=styleDef(dgSel);
      return (d&&d.label)||dgSel;
    }
    var k=dgObjKind(),out=k;
    DG_OBJ_KINDS.forEach(function(p){if(p[0]===k) out=p[1];});
    return out;
  }
  function dgAnnotMatches(a){
    if(!a) return false;
    if(dgIsObj()){
      var k=dgObjKind();
      if(k==='arrow') return a.k==='arrow'||a.k==='line'||a.k==='draw';
      return a.k===k;
    }
    return a.k==='text'&&a.style===dgSel;
  }
  /* every box of the chosen kind, everywhere, in slide order */
  function dgRows(){
    var out=[];
    (pres.slides||[]).forEach(function(sl,si){
      /* the slides picked in the strip narrow the table to them */
      if(dgPickedAny()&&!dgSheetPick[si]) return;
      (sl.annots||[]).forEach(function(a,ai){
        if(dgAnnotMatches(a)) out.push({si:si,ai:ai,a:a});
      });
    });
    return out;
  }
  function dgRowKey(r){return r.si+':'+r.ai;}
  function dgMarkedRows(rows){
    return rows.filter(function(r){return dgMarked[dgRowKey(r)];});
  }
  /* WHAT TRAVELS when you match. Each answer is a list of annot fields;
     'all' is every field the others name, so the chooser cannot drift
     out of step with itself. */
  var DG_MATCH={
    pos:['x','y'],
    size:['w','h','size'],
    colour:['color','bg','bgc','bdc','fill','fillc'],
    font:['font','b','i','align','lh','pspace']
  };
  function dgMatchFields(){
    if(dgMatchWhat!=='all') return DG_MATCH[dgMatchWhat]||[];
    var out=[];
    Object.keys(DG_MATCH).forEach(function(k){
      DG_MATCH[k].forEach(function(f){
        if(out.indexOf(f)<0) out.push(f);});
    });
    return out;
  }
  function dgMatchTo(src,rows){
    var fields=dgMatchFields(),n=0;
    rows.forEach(function(r){
      if(r.a===src) return;
      fields.forEach(function(f){
        if(src[f]===undefined) delete r.a[f];
        else r.a[f]=(typeof src[f]==='object'&&src[f])
          ?deep(src[f]):src[f];
      });
      /* a matched box is no longer anchored to whatever it was: the
         position it was given is the position it keeps */
      if(fields.indexOf('x')>=0) delete r.a.anch;
      n++;
    });
    return n;
  }
  function dgSwatch(v,fallback){
    var s=document.createElement('span');
    s.className='dgt-sw';
    if(!v||v==='none'){s.classList.add('dgt-none');s.title='none';}
    else {s.style.background=tokVal(v);s.title=v;}
    if(!v&&fallback) s.title='default';
    return s;
  }
  /* pt: the cell reads and writes POINTS (T411) -- the unit the ribbon's
     Text size box and the type screen speak -- and a box that says
     nothing shows what it gets, greyed, rather than an empty cell. */
  function dgNum(r,key,step,pt){
    var inp=document.createElement('input');
    inp.type='number';inp.step=step||'0.5';inp.className='dgt-n';
    var v0=r.a[key];
    if(pt){
      inp.value=(v0!=null)?Math.round(v0*5.4):'';
      var st=(r.a.style&&typeof styleDef==='function')
        ?styleDef(r.a.style):null;
      var eff=(st&&st.size)||(r.a.k==='table'?2.2:2.6);
      inp.placeholder=String(Math.round(eff*5.4));
      inp.title='Text size in points — empty means the type’s '
        +'own '+Math.round(eff*5.4)+' pt';
    } else {
      inp.value=(v0!=null)?Math.round(v0*10)/10:'';
      inp.title=key.toUpperCase()+' of this box';
    }
    inp.addEventListener('click',function(e){e.stopPropagation();});
    inp.addEventListener('keydown',function(e){
      e.stopPropagation();
      if(e.key==='Enter') inp.blur();
    });
    inp.addEventListener('change',function(){
      var v=parseFloat(inp.value);
      if(!isFinite(v)){delete r.a[key];}
      else r.a[key]=pt?Math.round(v/5.4*100)/100:Math.round(v*10)/10;
      if(key==='x'||key==='y') delete r.a.anch;
      markDirty();refresh();renderFilm();
      var ov=$('#deck-design'); if(ov) dgBodyKeep(ov);
    });
    return inp;
  }
  function dgTable(body,ov){
    var rows=dgRows();
    var wrap=document.createElement('div');wrap.className='dgt';
    var bar=document.createElement('div');bar.className='dgt-bar';
    function btn(label,title,fn,cls){
      var b=document.createElement('button');
      b.className='dbtn dg-b'+(cls?' '+cls:'');
      b.innerHTML=label;b.title=title;
      b.addEventListener('click',function(e){e.stopPropagation();fn(b);});
      bar.appendChild(b);
      return b;
    }
    btn('Select all','Tick every box of this kind, on every slide',
      function(){
        rows.forEach(function(r){dgMarked[dgRowKey(r)]=1;});
        dgBodyKeep(ov);
      }).disabled=!rows.length;
    btn('Unselect all','Clear every tick',function(){
      dgMarked={};dgBodyKeep(ov);}).disabled=!rows.length;
    var marked=dgMarkedRows(rows);
    var mb=btn(dgMatchArm
        ?'Now click the one to match'
        :(bic('swap')+' Match style of…'),
      dgMatchArm
        ?'Click the row you want the ticked boxes to look like'
        :'Tick the boxes to change, press this, then click the one they '
         +'should match',
      function(){dgMatchArm=!dgMatchArm;dgBodyKeep(ov);},
      dgMatchArm?'primary':'');
    mb.disabled=!marked.length&&!dgMatchArm;
    var what=document.createElement('select');
    what.className='dg-scope';
    [['all','everything'],['pos','only where it sits'],
     ['size','only how big it is'],['colour','only its colours'],
     ['font','only its type']].forEach(function(pr){
      var o=document.createElement('option');
      o.value=pr[0];o.textContent='match '+pr[1];
      if(dgMatchWhat===pr[0]) o.selected=true;
      what.appendChild(o);
    });
    what.title='What travels when you match: everything, or just one '
      +'part of it';
    what.addEventListener('change',function(){
      dgMatchWhat=what.value;dgBodyKeep(ov);});
    bar.appendChild(what);
    /* T411: THE SIZE, FOR ALL OF THEM AT ONCE (2026-09-13, user: "Style
       systems does not have a text size property in the tab. That was
       half the point of this"). A named type had its size on the left;
       the plain-text-boxes bucket had only a table with a blank Size
       cell per row. One box: points, given to the ticked rows, or to
       every row when none is ticked. */
    var isTx=!dgIsObj()||dgObjKind()==='text';
    if(isTx&&rows.length){
      var szw=document.createElement('span');szw.className='dgt-szw';
      var szl=document.createElement('span');szl.className='dgt-szlab';
      szl.textContent='Text size';szw.appendChild(szl);
      var szi=document.createElement('input');
      szi.type='number';szi.className='dgt-n dgt-szin';
      szi.step='1';szi.min='4';szi.max='200';szi.placeholder='pt';
      szi.title='Points. Enter, or Set, gives it to the ticked boxes '
        +'— or to every box when none is ticked';
      var setSize=function(){
        var pt=parseFloat(szi.value);
        if(!isFinite(pt)||pt<=0){toast('Type a size in points first');
          return;}
        var to=marked.length?marked:rows;
        to.forEach(function(r){r.a.size=Math.round(pt/5.4*100)/100;});
        markDirty();refresh();renderFilm();dgBodyKeep(ov);
        toast(to.length+' box'+(to.length===1?'':'es')+' at '
          +Math.round(pt)+' pt — Ctrl+Z undoes it');
      };
      szi.addEventListener('click',function(e){e.stopPropagation();});
      szi.addEventListener('keydown',function(e){
        e.stopPropagation();
        if(e.key==='Enter'){e.preventDefault();setSize();}
      });
      szw.appendChild(szi);
      var szb=document.createElement('button');
      szb.className='dbtn dg-b';szb.textContent='Set';
      szb.title='Give this size to the ticked boxes, or to all of them '
        +'when none is ticked';
      szb.addEventListener('click',function(e){
        e.stopPropagation();setSize();});
      szw.appendChild(szb);
      bar.appendChild(szw);
    }
    var count=document.createElement('span');
    count.className='dgt-count';
    if(dgPickedAny()){
      var np=dgPickedCount();
      var only=document.createElement('button');
      only.className='dbtn dg-b primary';
      only.textContent=np+' slide'+(np===1?'':'s')+' picked — show all';
      only.title='The slides you have picked in the column on the '
        +'right are filtering this table. Click to see every slide '
        +'again.';
      only.addEventListener('click',function(e){
        e.stopPropagation();dgSheetPick={};dgBodyKeep(ov);});
      bar.appendChild(only);
    }
    count.textContent=rows.length
      ?(marked.length?(marked.length+' of '+rows.length+' ticked')
        :(rows.length+' box'+(rows.length===1?'':'es')))
      :'none in this deck';
    bar.appendChild(count);
    wrap.appendChild(bar);

    if(!rows.length){
      var e=document.createElement('div');
      e.className='pf-ok';
      e.textContent='Nothing in this deck is a '+dgKindLabel()+' yet.';
      wrap.appendChild(e);
      body.appendChild(wrap);
      return;
    }
    var tbl=document.createElement('div');tbl.className='dgt-grid';
    /* the size and the face are columns whenever the rows are text,
       whether they were chosen by style or as plain text boxes (isTx,
       decided above the bar since T411) */
    /* T230: the first column is the WORDS, and for a plain text box
       you can type in it (2026-09-03, user: "would be good to edit
       the text in here as well"). A box with a list, and anything
       that is not text, shows its label: a one-line input cannot
       say what a three-level list is. */
    var heads=['','Slide','Text',' X',' Y',' Width'];
    if(isTx) heads=heads.concat(['Size','Face']);
    heads=heads.concat(['Text','Fill']);   /* T469: fit, and the bar's words */
    heads.forEach(function(h){
      var c=document.createElement('div');
      c.className='dgt-h';c.textContent=h.trim();
      tbl.appendChild(c);
    });
    tbl.style.setProperty('--dgt-cols',heads.length);
    rows.forEach(function(r){
      var on=!!dgMarked[dgRowKey(r)];
      /* T367: "you can click on one and it highlights in the table
         below". The table is a CSS grid, so a row is lit cell by cell. */
      var inPl=!!(dgPlacePick&&dgPlaceKey(r.a)===dgPlacePick);
      var cells=[];
      function cell(node,cls){
        var c=document.createElement('div');
        c.className='dgt-c'+(cls?' '+cls:'')+(on?' on':'')
          +(inPl?' dgt-inplace':'');
        if(typeof node==='string') c.textContent=node;
        else if(node) c.appendChild(node);
        cells.push(c);
        return c;
      }
      var ck=document.createElement('input');
      ck.type='checkbox';ck.checked=on;ck.className='dgt-ck';
      ck.title='Tick this box for Match style of';
      ck.addEventListener('click',function(e){e.stopPropagation();});
      ck.addEventListener('change',function(){
        if(ck.checked) dgMarked[dgRowKey(r)]=1;
        else delete dgMarked[dgRowKey(r)];
        dgBodyKeep(ov);
      });
      cell(ck,'dgt-ckc');
      cell(String(r.si+1),'dgt-si');
      if(r.a.k==='text'&&!listOf(r.a)){
        var ti=document.createElement('input');
        ti.type='text';ti.className='dgt-tx';
        ti.value=String(r.a.text||'');
        ti.title='The words in this box. Enter commits it.';
        /* 2026-09-07: "please put the 'text' row as what it looks like
           in the slide ... should be a preview of the text." A column
           of identical grey inputs said nothing about which box was
           which; each is a specimen of its own box now, falling back to
           the style where the box says nothing itself. */
        (function(){
          var st=(r.a.style&&typeof styleDef==='function')
            ?styleDef(r.a.style):null;
          var col=r.a.color||(st&&st.color);
          var bg=(r.a.bg!==0)&&(r.a.bgc||(st&&st.bg));
          var fam=r.a.font||(st&&st.font);
          if(col) ti.style.color=tokVal(col);
          if(bg) ti.style.background=tokVal(bg);
          if(fam) ti.style.fontFamily=fontCss(fam);
          if(r.a.b||(st&&st.b)) ti.style.fontWeight='700';
          if(r.a.i||(st&&st.i)) ti.style.fontStyle='italic';
          if(r.a.align) ti.style.textAlign=r.a.align;
        })();
        ti.addEventListener('click',function(e){e.stopPropagation();});
        ti.addEventListener('keydown',function(e){
          e.stopPropagation();
          if(e.key==='Enter') ti.blur();
        });
        ti.addEventListener('change',function(){
          var v=ti.value;
          r.a.text=v;
          /* the rich copy follows the plain one, escaped -- the
             same pair setListStyle keeps in step */
          if(r.a.html!==undefined) r.a.html=esc(v);
          markDirty();refresh();renderFilm();
          var ov2=$('#deck-design'); if(ov2) dgBodyKeep(ov2);
        });
        cell(ti,'dgt-what');
      } else {
        var lb2=document.createElement('span');
        lb2.className='dgt-lab';lb2.textContent=annotLabel(r.a);
        lb2.title=listOf(r.a)
          ?'A list: edit its words on the slide'
          :annotLabel(r.a);
        cell(lb2,'dgt-what');
      }
      cell(dgNum(r,'x'),'dgt-num');
      cell(dgNum(r,'y'),'dgt-num');
      cell(dgNum(r,'w'),'dgt-num');
      if(isTx){
        cell(dgNum(r,'size','1',true),'dgt-num');   /* T411: in pt */
        var f=document.createElement('span');
        f.className='dgt-face';f.textContent=r.a.font||'default';
        cell(f,'dgt-face-c');
      }
      cell(dgSwatch(r.a.color,1),'dgt-swc');
      cell(dgSwatch(r.a.bg===0?'none':r.a.bgc,1),'dgt-swc');
      cells.forEach(function(c){
        /* the row is the click target: matching, and going to look at it */
        c.addEventListener('click',function(){
          if(dgMatchArm){
            var n=dgMatchTo(r.a,dgMarkedRows(dgRows()));
            dgMatchArm=false;
            if(n){markDirty();refresh();renderFilm();
              toast(n+' box'+(n===1?'':'es')+' now match slide '
                +(r.si+1)+' — Ctrl+Z undoes it');}
            dgBodyKeep(ov);
            return;
          }
          if(ck.checked){delete dgMarked[dgRowKey(r)];ck.checked=false;}
          else {dgMarked[dgRowKey(r)]=1;ck.checked=true;}
          dgBodyKeep(ov);
        });
        tbl.appendChild(c);
      });
    });
    wrap.appendChild(tbl);
    body.appendChild(wrap);
  }
  /* T224: the outline sheet, lifted out of dgBody so the object
     views can show it too. Not one line of it changed. */
  function dgSheet(_unused,ov){
    var body=ov&&ov.querySelector('#dg-sheetcol');
    if(!body) return;
    body.innerHTML='';
    dgSectionHead(body,'Every object, outlined',
      'With outlines on, drag a box in a thumbnail to move that object; '
      +'click one to find it in the table.');
    var tg=document.createElement('button');
    tg.className='dbtn dg-b';
    tg.setAttribute('aria-pressed',dgOutline?'true':'false');
    tg.innerHTML=bic('outline')+(dgOutline?' Outlines on':' Outlines off');
    tg.title='Draw a box round every object on every slide';
    tg.addEventListener('click',function(){
      dgOutline=!dgOutline;dgBody(ov);});
    body.appendChild(tg);
    var sheetScope=dgScopeSelect(dgSheetScope,function(){dgBodyKeep(ov);});
    sheetScope.title='Outlines from these slides only';
    body.appendChild(sheetScope);
    /* T231: the column picks slides, so it needs the same two buttons
       the table has (2026-09-03, user: "the thumbnails need a select all
       and an unselect all as well"). Select all takes the slides this
       column is actually showing, which is what the scope above says. */
    var picks=document.createElement('div');picks.className='dg-picks';
    function pickBtn(label,title,fn){
      var b=document.createElement('button');
      b.className='dbtn dg-b';b.textContent=label;b.title=title;
      b.addEventListener('click',function(e){e.stopPropagation();fn();});
      picks.appendChild(b);
      return b;
    }
    pickBtn('Select all','Pick every slide shown here',function(){
      (pres.slides||[]).forEach(function(_sl,i){
        if(dgInScope(dgSheetScope,i)) dgSheetPick[i]=1;});
      dgBodyKeep(ov);
    });
    pickBtn('Unselect all','Clear every picked slide',function(){
      dgSheetPick={};dgBodyKeep(ov);
    }).disabled=!dgPickedAny();
    var pc=document.createElement('span');
    pc.className='dg-pickn';
    /* T367: 2026-09-07, user: "'none picked- everything counts', the
       fucking fuck this text mean?" It meant "you have picked no
       slides, so the table below covers all of them", which is what it
       says now. */
    pc.textContent=dgPickedAny()
      ?(dgPickedCount()+' of these slides')
      :'all slides';
    picks.appendChild(pc);
    body.appendChild(picks);
    var sheet=document.createElement('div');
    sheet.className='dg-sheet'+(dgOutline?' outlined':'');
    (pres.slides||[]).forEach(function(sl,i){
      if(!dgInScope(dgSheetScope,i)) return;
      var cell=document.createElement('button');
      cell.className='dg-cell';
      /* the slide's NAME, not just its number: the whole point of
         hovering is finding out which slide you are looking at (T130) */
      var nm=slideTitle(sl);
      cell.title='Slide '+(i+1)+(nm?' \u2014 '+nm:'')
        +' \u2014 click to go there';
      var mini=miniDiagram(sl);
      cell.appendChild(mini);
      /* MOVE IT FROM HERE (T130). One drag proxy per object, sitting at
         the same page percentages inside the same relatively-positioned
         miniature, shown only while outlines are on. A drag writes the
         move through shiftAnnot -- the one translate helper, so a tied
         caption travels and an arrow moves by its endpoints exactly as
         it would on the canvas. A plain click still navigates: nothing
         is claimed until the pointer has actually moved. */
      (sl.annots||[]).forEach(function(a){
        if(!a||a.hide) return;
        /* AN ARROW IS ITS TWO ENDS, NOT A BOX (JVR-03). It used to be
           skipped here, which made "Every object" untrue for the one
           kind whose geometry is x1/y1,x2/y2 -- but the write-back was
           never the problem: shiftAnnot below already translates both
           endpoints and any dragged corners, exactly as a canvas drag
           does. Only the HANDLE was missing, and that is the bounding
           box of the line the miniature already draws -- arrowEnds is
           the same call the renderer makes, so a tied end puts the
           handle where the line really is rather than on the stale
           stored endpoint. */
        var bx,by,bw,bh;
        if(a.k==='arrow'){
          var ae=arrowEnds(null,sl,a,0);
          var axs=[ae.x1,ae.x2],ays=[ae.y1,ae.y2];
          arrowMids(a).forEach(function(m){
            axs.push(m[0]);ays.push(m[1]);});
          bx=Math.min.apply(null,axs);by=Math.min.apply(null,ays);
          bw=Math.max.apply(null,axs)-bx;bh=Math.max.apply(null,ays)-by;
          if(!isFinite(bx)||!isFinite(by)||!isFinite(bw)||!isFinite(bh))
            return;
          /* grow the HIT TARGET about the line without moving the line */
          if(bw<DG_HIT){bx-=(DG_HIT-bw)/2;bw=DG_HIT;}
          if(bh<DG_HIT){by-=(DG_HIT-bh)/2;bh=DG_HIT;}
        } else {
          bx=(a.x||0);by=(a.y||0);bw=(a.w||10);bh=(a.h||8);
        }
        var px=document.createElement('span');
        px.className='dg-drag'+(a.k==='arrow'?' is-arrow':'');
        px.style.left=bx+'%';px.style.top=by+'%';
        px.style.width=bw+'%';px.style.height=bh+'%';
        px.title=(annotLabel(a)||a.k)+' \u2014 slide '+(i+1)
          +(nm?' ('+nm+')':'')+'. Drag to move it from here.';
        px.addEventListener('pointerdown',function(e){
          var sx=e.clientX,sy=e.clientY,dragging=false;
          var mr=mini.getBoundingClientRect();
          if(!mr.width||!mr.height) return;
          try{px.setPointerCapture(e.pointerId);}catch(err){}
          function mv(ev){
            var dx=ev.clientX-sx,dy=ev.clientY-sy;
            if(!dragging&&Math.abs(dx)+Math.abs(dy)<3) return;
            dragging=true;
            ev.preventDefault();
            px.style.transform='translate('+dx+'px,'+dy+'px)';
          }
          function up(ev){
            px.removeEventListener('pointermove',mv);
            px.removeEventListener('pointerup',up);
            if(!dragging) return;   /* a plain click: the cell navigates */
            ev.preventDefault();ev.stopPropagation();
            px.style.transform='';
            /* pixels in the miniature are percent of the page, which is
               the whole reason the proxies live inside it */
            shiftAnnot(a,(ev.clientX-sx)/mr.width*100,
              (ev.clientY-sy)/mr.height*100);
            markDirty();
            if(i===cur) refresh();
            renderFilm();
            dgBodyKeep(ov);
            toast('Moved on slide '+(i+1)+' \u2014 Ctrl+Z undoes it');
          }
          px.addEventListener('pointermove',mv);
          px.addEventListener('pointerup',up);
        });
        /* a completed drag must not fall through as the cell's click */
        /* T224: a click TICKS this box in the table rather than
           closing the screen (2026-09-03, user: "clicking one of the
           slides down the bottom takes you to the slide, it should
           just select it and bring up the types of objects and you
           can click on the different ones to show where they are").
           A box of another kind switches the rail to ITS kind, which
           is the same gesture read the other way round. */
        px.addEventListener('click',function(e){
          if(px.style.transform) return;
          e.stopPropagation();
          if(!dgAnnotMatches(a)){
            dgSel=(a.k==='text'&&a.style)?a.style:('obj:'+a.k);
            dgMarked={};dgMatchArm=false;
            dgRail(ov);dgBody(ov);
            return;
          }
          var ai=(sl.annots||[]).indexOf(a);
          var k2=i+':'+ai;
          if(dgMarked[k2]) delete dgMarked[k2]; else dgMarked[k2]=1;
          dgBodyKeep(ov);
        });
        mini.appendChild(px);
      });
      var n=document.createElement('span');
      n.className='dg-celln';n.textContent=(i+1);
      cell.appendChild(n);
      /* ...and the slide itself narrows the table to it rather than
         walking you out of the screen. Click it again for all of them. */
      cell.classList.toggle('dg-pick',!!dgSheetPick[i]);
      cell.addEventListener('click',function(){
        /* cumulative: each click adds or removes one */
        if(dgSheetPick[i]) delete dgSheetPick[i]; else dgSheetPick[i]=1;
        dgBodyKeep(ov);
      });
      sheet.appendChild(cell);
    });
    body.appendChild(sheet);
  }
  /* what each colour on the board means, and only for the kinds that
     are actually there */
  /* WHERE THEY ACTUALLY ARE, GROUPED (2026-09-07, user: "What is one
     box outline with Title and the other is yellow? ... should just
     have how many are in each place (and some indication of which
     slides), like group 1, then below they are grouped into those
     groups so you can [see] which slides they are").
     The board drew one dashed rectangle (the default this type is given
     when you Apply) and a filled one per real box, and nothing said
     which was which. It now says so in words, and the real boxes are
     GROUPED by the place they sit in -- so "these nine are all in the
     same spot, these two are somewhere else" is readable without
     comparing rectangles by eye. Rounded to the nearest 2% because a
     box nudged by a pixel is in the same place as far as anyone
     looking at a deck is concerned. */
  function dgPlaceKey(a){
    function q(v){return Math.round((+v||0)/2)*2;}
    return q(a.x)+','+q(a.y)+','+q(a.w);
  }
  /* T367: which place the others are matched to. A group key, not a
     rectangle -- the standard is one of your own slides. */
  var dgPlacePick='';
  function dgPickedPlace(id){
    var hit=null;
    dgPlaceGroups(id).forEach(function(g){
      if(!hit&&g.key===dgPlacePick) hit=g;});
    return hit;
  }
  function dgPlaceGroups(id){
    var by={},order=[];
    dgWearers(id).forEach(function(w){
      if(dgPickedAny()&&!dgSheetPick[w.s]) return;
      var k=dgPlaceKey(w.a);
      if(!by[k]){by[k]={key:k,a:w.a,ws:[]};order.push(k);}
      by[k].ws.push(w);
    });
    /* the biggest group first: it is the one that IS the standard */
    return order.map(function(k){return by[k];}).sort(function(x,y){
      return y.ws.length-x.ws.length;});
  }
  function dgKeyList(key,id){
    $$('.dg-keyit,.dg-place',key).forEach(function(n){n.remove();});
    var groups=dgPlaceGroups(id);
    groups.forEach(function(g,gi){
      var wrap=document.createElement('div');
      wrap.className='dg-place';
      /* T367: THE GROUP IS THE CHOICE. Click it and its boxes light up
         in the table below and it becomes the one the others are moved
         onto -- "you can click on one and it highlights in the table
         below ... then you can make the others match that one". */
      var head=document.createElement('button');
      head.type='button';
      head.className='dg-placehead'+(dgPlacePick===g.key?' on':'');
      head.textContent='Group '+(gi+1)+' \u2014 '+g.ws.length+' box'
        +(g.ws.length===1?'':'es')+' at '+Math.round(g.a.x||0)+', '
        +Math.round(g.a.y||0);
      head.title=dgPlacePick===g.key
        ?'The others get moved here. Click again to unpick it.'
        :'Pick this place: its boxes light up below, and the rest can be '
          +'moved onto it';
      head.addEventListener('click',function(e){
        e.stopPropagation();
        dgPlacePick=(dgPlacePick===g.key)?'':g.key;
        dgBodyKeep($('#deck-design'));
      });
      wrap.appendChild(head);
      if(dgPlacePick===g.key) wrap.className='dg-place on';
      var list=document.createElement('span');
      list.className='dg-placeslides';
      g.ws.forEach(function(w){
        var s=document.createElement('button');
        s.className='dg-slidechip';
        s.textContent=(w.s+1);
        s.title='Slide '+(w.s+1)+' \u2014 go to it';
        s.addEventListener('click',function(e){
          e.stopPropagation();dgClose();go(w.s);});
        list.appendChild(s);
      });
      wrap.appendChild(list);
      key.appendChild(wrap);
    });
    if(!groups.length){
      var none=document.createElement('span');
      none.className='dg-keyit';
      none.textContent='No box wears this type yet';
      key.appendChild(none);
    }
    if(!dgShowOthers) return;
    var seen={};
    dgBoardSlides().forEach(function(e){
      (e.sl.annots||[]).forEach(function(a){
        if(!a||a.hide) return;
        if(a.k==='text'&&a.style===id) return;
        seen[a.k]=1;
      });
    });
    Object.keys(seen).forEach(function(k){
      var it=document.createElement('span');
      it.className='dg-keyit';
      it.style.setProperty('--dg-kc',DG_KIND_COL[k]||'#8aa0b0');
      it.textContent=DG_KIND_WORD[k]||k;
      key.appendChild(it);
    });
  }
  /* ---- T443: WHO WEARS WHAT (2026-09-14, user: "the fix mismatched
     text makes no sense ... It should tell you something like: 4
     heading with this style, 3 with this ... the style system does a
     better job of this ... this can just be something that is
     incorporated into the style systems better"). One row per style
     the deck uses: how many boxes wear it, how many of those were
     changed by hand since, and the one click that puts the style back
     on them. Then the boxes wearing nothing, banded by size, with the
     style the check would give them. The same survey the old tile ran
     (standardise), read as a table instead of a list of complaints. */
  function dgCounts(rail,ov){
    if(typeof standardise!=='function') return;
    var r=standardise();
    var host=document.createElement('div');host.className='dg-counts';
    var h=document.createElement('div');
    h.className='dg-family-name';h.textContent='who wears what';
    host.appendChild(h);
    var any=false;
    function cntRow(n,label,cls){
      var row=document.createElement('div');row.className='dg-cnt'+(cls||'');
      var nn=document.createElement('span');
      nn.className='dg-cnt-n';nn.textContent=String(n);
      var l=document.createElement('span');
      l.className='dg-cnt-l';l.textContent=label;l.title=label;
      row.appendChild(nn);row.appendChild(l);
      return row;
    }
    styleOrder().forEach(function(id){
      var list=(r.named&&r.named[id])||[]; if(!list.length) return;
      any=true;
      var d=styleDef(id)||{label:id};
      var odd=list.filter(function(p){return !stdMatchesStyle(p.a,d);});
      var row=cntRow(list.length,d.label||id,odd.length?' dg-cnt-odd':'');
      if(odd.length){
        /* T470: the note on its own line, like the button under it --
           on one line with the name it was the note that got cut
           ("Heading 1 -- 1 changed by…", 2026-09-15 review) */
        var note=document.createElement('span');
        note.className='dg-cnt-note';
        note.textContent=odd.length+' changed by hand';
        row.appendChild(note);
        var b=document.createElement('button');
        b.type='button';b.className='dbtn dg-cnt-fix';
        b.textContent='Match '+odd.length;
        b.title='Put the '+(d.label||id)+' style back on the '+odd.length
          +' that were changed by hand';
        b.addEventListener('click',function(e){
          e.stopPropagation();
          stdFix(odd,function(a){applyStyleTo(a,id);},
            odd.length+' box'+(odd.length===1?'':'es')+' put back');
          dgRail(ov);dgBody(ov);
        });
        row.appendChild(b);
      }
      row.addEventListener('click',function(){
        dgSel=id;dgMatchArm=false;dgRail(ov);dgBody(ov);});
      host.appendChild(row);
    });
    (r.bands||[]).forEach(function(bd){
      if(bd.boxes.length<2) return;
      any=true;
      var sug=(styleDef(bd.suggest)||{}).label||bd.suggest;
      var row=cntRow(bd.boxes.length,'at about '+Math.round(bd.size*5.4)
        +' pt, no style yet',' dg-cnt-loose');
      var b=document.createElement('button');
      b.type='button';b.className='dbtn dg-cnt-fix';
      b.textContent='Make them '+sug;
      b.title='Give all '+bd.boxes.length+' the '+sug+' style; the odd '
        +'ones move to match the rest, the rest stay put';
      b.addEventListener('click',function(e){
        e.stopPropagation();stdAdopt(bd);dgRail(ov);dgBody(ov);});
      row.appendChild(b);
      host.appendChild(row);
    });
    if(any) rail.appendChild(host);
  }
  function dgRail(ov){
    var rail=ov.querySelector('#dg-list');
    rail.innerHTML='';
    dgCounts(rail,ov);   /* T443 */
    function styleRow(id,isVar){
      var d=styleDef(id); if(!d) return;
      var b=document.createElement('button');
      b.className='dg-row'+(id===dgSel?' on':'')+(isVar?' dg-rowvar':'');
      var nm=document.createElement('span');
      nm.className='dg-name';nm.textContent=d.label||id;
      dgSpecimen(nm,id);
      /* the rail is chrome, not a slide: the style's own colour could be
         the page's ink and vanish here (2026-09-03, "a lot of the text
         can't be read"); weight, italic and size still draw the ladder */
      nm.style.color='';
      /* T295: ...WHICH MEANT TWO VARIATIONS DIFFERING ONLY IN COLOUR
         DREW AS IDENTICAL ROWS -- in the one place the user asked for
         "the preview should show the colours". Blanking the text is
         still right; the colour goes on a CHIP instead, which sits on a
         known ground and so cannot disappear into it. */
      var chip=null;
      if(d.color){
        chip=document.createElement('span');
        chip.className='dg-swatch';
        chip.style.background=tokVal(d.color);
      }
      var ct=document.createElement('span');
      ct.className='dg-count';
      var n=dgWearers(id).length;
      ct.textContent=n?(n+' box'+(n===1?'':'es')):'unused';
      b.appendChild(nm);
      if(chip) b.appendChild(chip);
      /* T314: the ground, as a second chip -- the name itself is left
         unpainted here on purpose (see above) */
      if(d.bg&&d.bg!=='none'){
        var chipBg=document.createElement('span');
        chipBg.className='dg-swatch dg-swatch-bg';
        chipBg.style.background=tokVal(d.bg);
        chipBg.title='Background '+tokVal(d.bg);
        b.appendChild(chipBg);
      }
      b.appendChild(ct);
      var par=isVar?parentOf(id):'';
      b.title=(d.label||id)+' — '+(d.size||2.6)+'% of the page height'
        +(par?(', a variation of '+(styleDef(par)||{}).label):'')
        +(n?(', worn by '+n+' box'+(n===1?'':'es')):', not used yet');
      b.addEventListener('click',function(){
        dgSel=id;dgMatchArm=false;dgRail(ov);dgBody(ov);});
      rail.appendChild(b);
    }
    /* T295: A FAMILY READS AS A FAMILY HERE TOO. styleOrder appends, so
       a variation of Heading 1 sat last, after Caption, with nothing
       saying what it varied -- the same complaint the Text styles menu
       had (T293), on the screen whose whole job is showing you the
       system.
       Each variation keeps its OWN row, its own board and its own
       re-stamp. dgWearers stays an exact match on a.style and must:
       dgRestamp is built on it and calls applyStyleTo with the SELECTED
       id, so one loosened predicate would silently repaint every colour
       variation in its parent's colour the next time anyone nudged
       Heading 1. */
    var listed={};
    styleOrder().forEach(function(id){
      if(listed[id]||parentOf(id)) return;
      /* The rail is a catalogue of types this deck actually uses, not a
         promise of every built-in role.  Empty Body/Caption rows made the
         left side look like a second settings menu and hid the real types. */
      var vars=variantsOf(id).filter(function(v){
        return dgWearers(v).length||v===dgSel;});
      listed[id]=1;
      variantsOf(id).forEach(function(v){listed[v]=1;});
      if(!dgWearers(id).length&&!vars.length&&id!==dgSel) return;
      var baseUsed=dgWearers(id).length||id===dgSel;
      if(baseUsed) styleRow(id,false);
      else{
        /* A used variation needs its family label, but an unused parent
           is not itself a selectable type in this deck. */
        var family=document.createElement('div');
        family.className='dg-family-name';
        family.textContent=(styleDef(id)||{}).label||id;
        rail.appendChild(family);
      }
      if(vars.length){
        var more=document.createElement('button');
        more.type='button';more.className='dg-var-toggle';
        more.textContent=(dgVarOpen[id]?'− Hide ':'+ Show ')
          +vars.length+' variation'+(vars.length===1?'':'s');
        more.title='Show the looks that vary '+(styleDef(id)||{}).label;
        more.addEventListener('click',function(){
          dgVarOpen[id]=!dgVarOpen[id];dgRail(ov);dgBody(ov);});
        rail.appendChild(more);
      }
      if(!dgVarOpen[id]) return;
      vars.forEach(function(v){
        styleRow(v,true);
      });
    });
    styleOrder().forEach(function(id){
      if(listed[id]) return;       /* a variation whose parent has gone */
      if(dgWearers(id).length||id===dgSel) styleRow(id,false);
    });
    /* T224: and the things that are not text. A figure has no style
       registry to edit, but it has a position, a size and a place in
       the table -- which is what the ask was about (2026-09-03,
       user: "I wanted more than just titles, also images etc"). */
    /* Do not print a heading for a section with no rows. Text-only decks
       used to end with a vacant "everything else" label even though the
       rows beneath it correctly filtered unused object kinds. */
    var hd=null;
    DG_OBJ_KINDS.forEach(function(pr){
      var key='obj:'+pr[0];
      var b2=document.createElement('button');
      b2.className='dg-row'+(key===dgSel?' on':'');
      var nm2=document.createElement('span');
      nm2.className='dg-name';
      nm2.innerHTML=bic(pr[2])+' '+esc(pr[1]);
      var ct2=document.createElement('span');ct2.className='dg-count';
      var was=dgSel; dgSel=key;
      var n2=dgRows().length;
      dgSel=was;
      /* T367: a kind this deck has none of is not a row (2026-09-07,
         user: "don't put an object type (e.g. citations) if it isn't
         used"). It listed all seven always, so most decks read as a
         column of "none" with the two kinds you actually have buried in
         it. The one it is showing stays, whatever its count, or
         choosing an empty kind would make its own row vanish. */
      if(!n2&&key!==dgSel) return;
      /* T470: the head says "else" -- with no text styles above it
         there is no else, and with no rows under it there is nothing */
      if(!n2&&!dgAnyStyleWorn()) return;
      if(!hd){
        hd=document.createElement('div');
        hd.className='hd-lab';hd.textContent='everything else';
        rail.appendChild(hd);
      }
      ct2.textContent=String(n2);
      b2.appendChild(nm2);b2.appendChild(ct2);
      b2.title=pr[1]+' in this deck'+(n2?(': '+n2):': none yet');
      b2.addEventListener('click',function(){
        dgSel=key;dgMatchArm=false;dgRail(ov);dgBody(ov);});
      rail.appendChild(b2);
    });
  }
  /* ---- the board: where a named type SITS by default ------------------
     The one genuinely new idea. A style has always said how a Heading
     looks and never where it goes, so "global heading layouts" could not
     be expressed at all. x/y/w live on the same pres.styles record, so
     no new deck key and no new documentation: `styles` is already "this
     deck's overrides of the named text types". */
  /* ---- T230: THE BOARD SHOWS THE REAL BOXES ---------------------------
     (2026-09-03, user: "right now it shows you the masters, but there
     can be individuals. Would be good if you could see not just the
     master, but location of all individual headings, then you can also
     tick a box that shows 'all other items', so you know if your heading
     is going to overlap with something (should be a colour for every
     different thing, but the one in question glows and has a thicker
     border)".)
     The dragged rectangle is still the default this style stamps. Behind
     it now sit every box that actually wears the style, and -- when you
     ask -- everything else on those slides, one colour per kind. So the
     question "will my heading land on the figure" is answered by looking
     rather than by pressing the button and undoing it.
     T384: ON by default. With the dashed prototype gone (T367) a board
     of one amber outline on a grey page was "the visual display is
     gone" (2026-09-12); the board reads as a slide only when the slide
     is on it. */
  var dgShowOthers=true;
  var DG_KIND_COL={text:'#6b9bff',cell:'#f0a848',image:'#a586e8',
    rect:'#46a892',table:'#e0a5c6',flip:'#39a9c0',arrow:'#ff6b57',
    line:'#ff6b57',draw:'#ff6b57',chart:'#7fd7c0'};
  /* T384: the key said "cell" -- the model's word, not the user's */
  var DG_KIND_WORD={text:'other text',cell:'figure',image:'picture',
    rect:'shape',table:'table',flip:'flip book',arrow:'arrow',line:'line',
    draw:'drawing',chart:'chart'};
  function dgKindCol(a){
    return (a&&DG_KIND_COL[a.k])||'#8aa0b0';
  }
  function dgBoardSlides(){
    var out=[];
    (pres.slides||[]).forEach(function(sl,si){
      if(dgPickedAny()&&!dgSheetPick[si]) return;
      out.push({sl:sl,si:si});
    });
    return out;
  }
  function dgBoardWords(b,a,def){
    var st=def||((a.style&&typeof styleDef==='function')
      ?styleDef(a.style):null)||{};
    var words=String(a.text||'').replace(/\s+/g,' ').trim();
    var t=document.createElement('span');
    t.className='dg-realtx';
    t.textContent=words||annotLabel(a);
    if(!words) t.classList.add('dg-realempty');
    var size=a.size||st.size||2.6;
    t.style.fontSize=size.toFixed(2)+'cqh';
    var col=a.color||st.color;
    t.style.color=tokVal(col||'@ink');
    var fam=a.font||st.font;
    if(fam) t.style.fontFamily=fontCss(fam);
    if(a.b||st.b) t.style.fontWeight='700';
    if(a.i||st.i) t.style.fontStyle='italic';
    t.style.textAlign=a.align||st.align||'left';
    b.appendChild(t);
  }
  function dgGhostsFor(board,id){
    $$('.dg-real,.dg-other',board).forEach(function(n){n.remove();});
    /* T279: the board drew every wearer of the style identically -- same
       1px amber box, same title of just "slide N" -- so it was a map of
       WHERE they are and said nothing about whether any of them had
       stopped keeping to the style. Read the verdict off the same
       predicate the Fix-mismatched-text screen uses, once per repaint. */
    var def=(typeof styleDef==='function')?styleDef(id):null;
    var off=0;
    /* T384: ONE SET OF WORDS PER PLACE. Fourteen headings at 5,4 drew
       fourteen titles on top of each other and read as noise; the first
       box at a place carries the words, the rest are outlines. */
    var wordsAt={};
    dgBoardSlides().forEach(function(e){
      (e.sl.annots||[]).forEach(function(a){
        if(!a||a.hide) return;
        var mine=(a.k==='text'&&a.style===id);
        if(!mine&&!dgShowOthers) return;
        var bad=!!(mine&&def&&typeof stdMatchesStyle==='function'
          &&!stdMatchesStyle(a,def));
        if(bad) off++;
        var b=document.createElement('div');
        b.className=(mine?'dg-real':'dg-other')+(bad?' dg-off':'');
        /* T465: an arrow has endpoints, not a box -- drawn from a.x/a.w
           every line sat as a 10x6 box in the slide's top-left corner
           (2026-09-15 review). The same bounding box the outline sheet
           draws its proxies from. */
        var gx=a.x||0,gy=a.y||0,gw=a.w||10,gh=a.h||6;
        if(a.k==='arrow'&&typeof arrowEnds==='function'){
          var ae=arrowEnds(null,e.sl,a,0);
          var axs=[ae.x1,ae.x2],ays=[ae.y1,ae.y2];
          if(typeof arrowMids==='function')
            arrowMids(a).forEach(function(m){axs.push(m[0]);ays.push(m[1]);});
          gx=Math.min.apply(null,axs);gy=Math.min.apply(null,ays);
          gw=Math.max.apply(null,axs)-gx;gh=Math.max.apply(null,ays)-gy;
          if(!isFinite(gx)||!isFinite(gy)||!isFinite(gw)||!isFinite(gh)) return;
        }
        b.style.left=gx+'%';
        b.style.top=gy+'%';
        b.style.width=Math.max(1.5,gw)+'%';
        b.style.height=Math.max(1.5,gh)+'%';
        b.style.borderColor=mine?'':dgKindCol(a);
        /* T384: THE WORDS, IN THE BOX. An empty amber rectangle said
           where a heading was and nothing about what it looked like
           (2026-09-12, user: "the visual display is gone and
           confusing"). Each text box carries its own words at its own
           size -- container-query units, so 2.6% of the page height is
           2.6cqh of the board -- in its colour, face, weight and slant,
           the way the Fix-mismatched-text chips do. Other text is drawn
           faint so the board reads as the slide it is. */
        var at=(mine?'m':'o')+a.k+':'+dgPlaceKey(a);
        if(a.k==='text'&&!wordsAt[at]){
          wordsAt[at]=1;
          dgBoardWords(b,a,mine?def:null);
        }
        /* 2026-09-07: "when hovering above an object it should give an
           information bubble that is like 'chart from slide 7' and
           clicking on it takes you to that slide. Or if many gives you
           a list of them all." A title attribute says it after a
           second's wait and cannot be clicked, so the board grew a real
           bubble instead -- see dgBoard. */
        b.dataset.si=e.si;
        b.dataset.what=(mine?((styleDef(id)||{}).label||id):annotLabel(a))
          +' — slide '+(e.si+1)
          +(bad?' — no longer matches this style':'');
        board.appendChild(b);
      });
    });
    /* and say so in words as well as in weight, because a board you have
       to compare box-borders across is not an answer */
    var note=board.parentNode
      &&board.parentNode.querySelector('.dg-offnote');
    if(note){
      note.textContent=off
        ?(off+' of these no longer match the style')
        :'';
      note.hidden=!off;
    }
  }
  /* ---- T368: THE LOOKS THIS TYPE COMES IN ---------------------------
     2026-09-07, user: "when going to heading 1, it would be cool if
     there was like different styles of that etc. that people can change
     between".

     T317's ready-made looks existed and were only ever drawn in the
     Text-styles dropdown, which needs a box selected -- so the screen
     whose job is the type system offered none of them. Here they are on
     the type's own page: the variations that exist, then the ones you
     could make, each a specimen of what it would look like on THIS
     deck. A variation is a type in its own right, so making one puts a
     row in the rail and you swap by choosing it. */
  function dgLooks(host,id,ov){
    /* only a BASE type has variations; a variation is one */
    if(typeof variantsOf!=='function'||typeof parentOf!=='function') return;
    if(parentOf(id)) return;
    var have=variantsOf(id)||[];
    var offer=(typeof PRESET_LOOKS!=='undefined'?PRESET_LOOKS:[])
      .filter(function(look){
        if(typeof presetVariantOf==='function'&&presetVariantOf(id,look))
          return false;
        if(look.id==='by-section'
           &&!(pres.sections&&Object.keys(pres.sections).length)) return false;
        return true;
      });
    if(!have.length&&!offer.length) return;
    var wrap=document.createElement('div');
    wrap.className='dg-looks';
    var lab=document.createElement('span');
    lab.className='dg-lookslab';
    lab.textContent=(d0(id).label||id)+' comes in';
    wrap.appendChild(lab);
    have.forEach(function(v){
      var b=document.createElement('button');
      b.className='dbtn dg-look on';
      b.textContent=(d0(v).label||v);
      dgSpecimen(b,v);
      b.title='Go to this variation';
      b.addEventListener('click',function(){
        dgSel=v;dgMatchArm=false;dgRail(ov);dgBody(ov);});
      wrap.appendChild(b);
    });
    /* T368: WHICH ONE A NEW SLIDE GETS. A layout's slots name the base
       type, so a variation you made and used everywhere still left the
       next new slide on the plain parent (2026-09-07, user: "When you
       select a text style, new slides don't get applied with it"). */
    if(have.length){
      var now=(pres.slot&&pres.slot[id])||id;
      var pick=document.createElement('select');
      pick.className='dg-slotpick';
      [id].concat(have).forEach(function(v){
        var o=document.createElement('option');
        o.value=v;o.textContent=(d0(v).label||v);
        if(v===now) o.selected=true;
        pick.appendChild(o);
      });
      pick.title='Which of these a new slide\u2019s '+(d0(id).label||id)
        +' box is given';
      pick.addEventListener('change',function(){
        pres.slot=pres.slot||{};
        if(pick.value===id) delete pres.slot[id];
        else pres.slot[id]=pick.value;
        if(!Object.keys(pres.slot).length) delete pres.slot;
        markDirty();
        toast('New slides get '+(d0(pick.value).label||pick.value));
      });
      var pl=document.createElement('span');
      pl.className='dg-lookslab';pl.textContent='new slides get';
      wrap.appendChild(pl);
      wrap.appendChild(pick);
    }
    offer.forEach(function(look){
      var b=document.createElement('button');
      b.className='dbtn dg-look dg-lookadd';
      b.textContent=look.label;
      /* a specimen of what it WOULD be: the parent's face and size with
         the look's own colours over it, resolved against this deck */
      var d=d0(id),dd=look.delta;
      b.style.fontWeight=(dd.b===0?0:(dd.b||d.b))?'700':'400';
      if(d.i) b.style.fontStyle='italic';
      if(d.font) b.style.fontFamily=fontCss(d.font);
      var col=tokVal(dd.color||d.color||'');
      if(col) b.style.color=col;
      if(dd.bg&&dd.bg!=='none') b.style.background=tokVal(dd.bg);
      if(dd.bdc&&dd.bdc!=='none') b.style.borderColor=tokVal(dd.bdc);
      b.title='Make \u201c'+look.label+'\u201d a variation of '
        +(d.label||id)+' \u2014 '+look.note+'. It keeps following '
        +(d.label||id)+' for everything else.';
      b.addEventListener('click',function(){
        if(typeof ensurePresetLook!=='function') return;
        var vid=ensurePresetLook(id,look);
        if(!vid){toast('Could not make that variation');return;}
        markDirty();
        dgSel=vid;dgMatchArm=false;dgRail(ov);dgBody(ov);
      });
      wrap.appendChild(b);
    });
    host.appendChild(wrap);
  }
  function d0(id){return styleDef(id)||{};}
  function dgBoard(host,id){
    var board=document.createElement('div');
    board.className='dg-board';
    var page=pageOf();
    board.style.aspectRatio=(page.mm[0]/page.mm[1]).toFixed(4);
    /* T367: NO DASHED RECTANGLE. It was "the default place" a type gets
       when you Apply -- dragged here and stamped onto every box in the
       deck. The user, 2026-09-07: "there are many different styles of
       headings for depending on the slide ... I don't think that should
       be a thing the default for any." A Heading 1 on a section divider
       and a Heading 1 over two panels share no correct position, so the
       rectangle was a guess and Apply overwrote a real decision with
       it. What the board shows is where these boxes ARE. */
    host.appendChild(board);
    /* T279: the count in words, beside the board. Appended to the same
       host BEFORE the ghosts are drawn, because dgGhostsFor writes into
       it and looks for it as a sibling of the board. */
    var offnote=document.createElement('div');
    offnote.className='dg-offnote';offnote.hidden=true;
    host.appendChild(offnote);
    dgGhostsFor(board,id);
    /* ONE bubble for the whole board, moved and filled on hover -- a
       node per object would be hundreds of them on a real deck. Every
       object under the pointer is named, because "which of these am I
       pointing at" is exactly the question a board of overlapping
       rectangles raises, and each name is a button to its slide. */
    var bub=document.createElement('div');
    bub.className='dg-bub';bub.hidden=true;
    host.appendChild(bub);
    board.addEventListener('mousemove',function(ev){
      var r=board.getBoundingClientRect();
      var hits=$$('.dg-real,.dg-other',board).filter(function(n){
        var q=n.getBoundingClientRect();
        return ev.clientX>=q.left&&ev.clientX<=q.right
          &&ev.clientY>=q.top&&ev.clientY<=q.bottom;
      });
      if(!hits.length){bub.hidden=true;return;}
      bub.innerHTML='';
      hits.slice(0,8).forEach(function(n){
        var line=document.createElement('button');
        line.className='dg-bubline';
        line.textContent=n.dataset.what||'';
        line.addEventListener('click',function(e2){
          e2.stopPropagation();dgClose();go(+n.dataset.si||0);});
        bub.appendChild(line);
      });
      if(hits.length>8){
        var more=document.createElement('span');
        more.className='dg-bubmore';
        more.textContent='and '+(hits.length-8)+' more here';
        bub.appendChild(more);
      }
      bub.hidden=false;
      var bw=bub.offsetWidth||160;
      bub.style.left=Math.max(0,Math.min(r.width-bw,
        ev.clientX-r.left+12))+'px';
      bub.style.top=Math.max(0,ev.clientY-r.top+14)+'px';
    });
    board.addEventListener('mouseleave',function(){bub.hidden=true;});
    /* the key, and the switch that turns the rest of the page on */
    var key=document.createElement('div');key.className='dg-key';
    /* T470: the same switch as the sheet column's Outlines, in the
       same shape -- it was a bare checkbox beside a boxed button on
       one screen (2026-09-15 review) */
    var ck=document.createElement('button');
    ck.type='button';ck.className='dbtn dg-b dg-keyck';
    function ckPaint(){
      ck.setAttribute('aria-pressed',dgShowOthers?'true':'false');
      ck.innerHTML=bic('eye')+(dgShowOthers?' Everything else on'
        :' Everything else off');
    }
    ckPaint();
    ck.addEventListener('click',function(e){
      e.stopPropagation();
      dgShowOthers=!dgShowOthers;
      ckPaint();
      dgGhostsFor(board,id);
      dgKeyList(key,id);
    });
    ck.title='Draw every other object on these slides too';
    key.appendChild(ck);
    dgKeyList(key,id);
    host.appendChild(key);

  }
  function dgSectionHead(host,text,sub){
    var h=document.createElement('div');
    h.className='dg-h';h.textContent=text;
    host.appendChild(h);
    if(sub){
      var p=document.createElement('p');
      p.className='dg-sub';p.textContent=sub;
      host.appendChild(p);
    }
  }
  function dgBody(ov){
    if(!ov) return;
    var body=ov.querySelector('#dg-body');
    body.innerHTML='';
    var id=dgSel,d=styleDef(id);
    /* T224: an object kind has no look to edit -- it has a table */
    if(dgIsObj()){
      /* T470: a deck with nothing to standardise said "Pictures --
         every one in this deck" over an empty table and three dead
         buttons, with no line saying what the screen is for
         (2026-09-15 review) */
      if(!dgRows().length&&!dgAnyStyleWorn()){
        body.innerHTML='<div class="selpane-empty">Nothing to '
          +'standardise yet. Add text and its styles are listed here; '
          +'pictures, tables, shapes and the rest get a table each, so '
          +'the ones that should match can be made to.</div>';
        return;
      }
      dgSectionHead(body,dgKindLabel()+' \u2014 every one in this deck');
      dgTable(body,ov);
      dgSheet(body,ov);
      return;
    }
    if(!d){body.innerHTML='<div class="selpane-empty">Pick a type on '
      +'the left.</div>';return;}
    var rec=dgStyleRec(id);
    var wear=dgWearers(id);

    /* ---- how it looks ----
       ONE line for the whole screen, and no other prose on it
       (2026-09-07, user: "There is soooo much unnecessary text here. I
       think almost all text is unnecessary, just one short description
       at the top"). Every control below says what it is by being what
       it is. */
    dgSectionHead(body,(d.label||id)
      +' \u2014 changes every box wearing it, on every slide');
    /* ---- T384: TWO COLUMNS, NOT NINE STACKED SECTIONS -------------
       (2026-09-12, user: "the style systems box is confusing; needs a
       better layout"). What the type looks like on the left -- specimen,
       looks, the control clusters -- and where its boxes sit on the
       right -- the board, its key, the groups and the move. The table
       of every box runs full width underneath. The dead "Exactly X / Y
       / Width" inputs are gone: T367 removed the Apply that read them,
       and the table's own number cells are where a box is typed into
       place. */
    var top=document.createElement('div');top.className='dg-top';
    var left=document.createElement('div');left.className='dg-typecol';
    var right=document.createElement('div');right.className='dg-placecol';
    function colHead(host,text){
      var h=document.createElement('div');
      h.className='dg-colh';h.textContent=text;host.appendChild(h);
    }
    colHead(left,'how it looks');
    colHead(right,'where its boxes sit');
    top.appendChild(left);top.appendChild(right);
    body.appendChild(top);
    var spec=document.createElement('div');
    spec.className='dg-spec';
    spec.textContent='The quick brown fox jumps over the lazy dog';
    dgSpecimen(spec,id);
    /* on the deck's actual page colour, so a specimen reads the way the
       slide will */
    spec.style.background=deckPageBg();
    if(!d.color) spec.style.color=tokVal('@ink');
    left.appendChild(spec);
    dgLooks(left,id,ov);

    var row=document.createElement('div');row.className='dg-ctrls';
    /* T230: CLUSTERS, NOT ONE LONG ROW. Thirteen controls sat in one
       wrap with nothing saying which belonged with which (2026-09-03,
       user: "the buttons are a bit crammed. There is a lot of things
       again that feel like they are floating in no where"). Each
       group is a box with its name on it, the way a ribbon run is. */
    var cur_=null;
    function grp(name){
      var g=document.createElement('div');g.className='dg-grp';
      var lb=document.createElement('span');
      lb.className='dg-grplab';lb.textContent=name;
      g.appendChild(lb);
      row.appendChild(g);cur_=g;
      return g;
    }
    function ctl(label,title,on,fn){
      var b=document.createElement('button');
      b.className='dbtn dg-b';b.textContent=label;b.title=title;
      if(on!=null) b.setAttribute('aria-pressed',on?'true':'false');
      b.addEventListener('click',function(){
        fn();markDirty();dgRestamp(id);refresh();dgRail(ov);dgBody(ov);});
      (cur_||row).appendChild(b);
      return b;
    }
    grp('Size');
    ctl('−','Smaller',null,function(){
      rec.size=Math.max(0.6,Math.round(((d.size||2.6)-0.2)*10)/10);});
    /* T411: a number you can TYPE, between the steppers -- "Text size
       26 pt" was a readout, and a readout is not a property */
    var sz=document.createElement('span');
    sz.className='dg-size';
    var typePct=d.size||2.6;
    var szIn=document.createElement('input');
    szIn.type='number';szIn.className='dgt-n dg-sizein';
    szIn.step='1';szIn.min='4';szIn.max='200';
    szIn.value=String(Math.round(typePct*5.4));
    szIn.setAttribute('aria-label','Text size in points');
    szIn.title=Math.round(typePct*5.4)+' pt text ('+typePct.toFixed(1)
      +'% of the page height) — type a size in points';
    szIn.addEventListener('keydown',function(e){
      e.stopPropagation();
      if(e.key==='Enter'){e.preventDefault();szIn.blur();}
    });
    szIn.addEventListener('change',function(){
      var pt=parseFloat(szIn.value);
      if(!isFinite(pt)||pt<=0) return;
      rec.size=Math.max(0.6,Math.min(30,Math.round(pt/5.4*100)/100));
      markDirty();dgRestamp(id);refresh();dgRail(ov);dgBody(ov);
    });
    sz.appendChild(szIn);
    var szU=document.createElement('span');szU.textContent=' pt';
    sz.appendChild(szU);
    (cur_||row).appendChild(sz);
    ctl('+','Bigger',null,function(){
      rec.size=Math.min(30,Math.round(((d.size||2.6)+0.2)*10)/10);});
    grp('Weight');
    ctl('B','Bold',!!d.b,function(){
      if(d.b) rec.b=0; else rec.b=1;});
    ctl('I','Italic',!!d.i,function(){
      if(d.i) rec.i=0; else rec.i=1;});
    grp('Alignment');
    ['left','center','right'].forEach(function(al){
      ctl(al==='left'?'←':al==='right'?'→':'↔',
        'Align '+al,(d.align||'left')===al,function(){rec.align=al;});
    });
    /* ---- T223: EVERYTHING A STYLE IS, not size and bold ------------
       (2026-09-03, user: "I said I wanted also colours of text,
       background colour, box border colour, font style. I said I
       wanted everything.") The typeface, then three colours, each
       writing the same override record the size and weight do. */
    grp('Typeface');
    var fsel=document.createElement('select');
    fsel.className='dg-font';
    fsel.title='The typeface every box of this type takes';
    [['','Default face'],['sans','Sans'],['serif','Serif'],
     ['mono','Mono'],['system','System'],['hand','Handwritten']]
      .forEach(function(pr){
        var o=document.createElement('option');
        o.value=pr[0];o.textContent=pr[1];
        if((d.font||'')===pr[0]) o.selected=true;
        fsel.appendChild(o);
      });
    fsel.addEventListener('change',function(){
      if(fsel.value) rec.font=fsel.value; else delete rec.font;
      markDirty();dgRestamp(id);refresh();dgRail(ov);dgBody(ov);
    });
    (cur_||row).appendChild(fsel);
    grp('Colours');
    function dgCol(key,label,fallback,none){
      var wrap=document.createElement('span');wrap.className='dg-colw';
      var lb=document.createElement('span');
      lb.className='dg-collab';lb.textContent=label;
      wrap.appendChild(lb);
      var ci=document.createElement('input');
      ci.type='color';ci.className='dg-col';
      var v=d[key];
      var rv=tokVal(v);   /* T480: what a deck colour resolves to */
      ci.value=(v&&v!=='none'&&/^#[0-9a-f]{6}$/i.test(rv))?rv:fallback;
      ci.title=label+' \u2014 every box of this type'
        +(tokRef(v)?(' (a deck colour: '+tokRef(v)+'; a change here '
          +'unhooks it)'):'');
      ci.addEventListener('input',function(){
        rec[key]=ci.value;markDirty();dgRestamp(id);refresh();});
      ci.addEventListener('change',function(){dgRail(ov);dgBody(ov);});
      wrap.appendChild(ci);
      if(none){
        var nb=document.createElement('button');
        nb.className='dbtn dg-b';nb.textContent=none;
        nb.title='No '+label.toLowerCase()+' at all';
        nb.setAttribute('aria-pressed',(v==='none').toString());
        nb.addEventListener('click',function(){
          if(v==='none') delete rec[key]; else rec[key]='none';
          markDirty();dgRestamp(id);refresh();dgRail(ov);dgBody(ov);
        });
        wrap.appendChild(nb);
      }
      return wrap;
    }
    var cg=cur_;
    /* T469: the format bar's words, as the menu's editor says them */
    cg.appendChild(dgCol('color','Text','#e6eef5',''));
    cg.appendChild(dgCol('bg','Fill','#16273a','None'));
    cg.appendChild(dgCol('bdc','Border','#8aa0b0','None'));
    grp('');
    var rst=document.createElement('button');
    rst.className='dbtn dg-b';rst.textContent='Reset';
    rst.title='Back to this type’s built-in look';
    rst.addEventListener('click',function(){
      var st=deckStyles();
      var keep={};
      ['x','y','w'].forEach(function(k){
        if(st[id]&&st[id][k]!=null) keep[k]=st[id][k];});
      st[id]=keep;
      markDirty();dgRestamp(id);refresh();dgRail(ov);dgBody(ov);
    });
    (cur_||row).appendChild(rst);
    left.appendChild(row);

    /* the bubble is placed against the board's own box, so the board
       needs a positioned parent of its own, not the column with a
       label above it */
    var boardWrap=document.createElement('div');
    boardWrap.className='dg-boardwrap';
    right.appendChild(boardWrap);
    dgBoard(boardWrap,id);
    /* the put, scoped (T130): everywhere stays the default, but "these
       headings, in this section" is the sentence the ask was written
       in, and a numeric range covers the rest */
    var putRow=document.createElement('div');
    putRow.className='dg-putrow';
    /* ---- T231: APPLY TO WHAT IS SELECTED -----------------------------
       (2026-09-03, user: "the apply to x boxes, should just be for the
       selection.") There were three ways to scope this one action --
       a scope select of its own, the ticked rows in the table, and the
       slides picked in the column -- and only the first of them did
       anything. The selector is gone; the button reads the selection,
       in the order you would say it out loud: the boxes you ticked, or
       failing that the slides you picked, or failing that all of them. */
    var pickMode=function(){
      var ticked=wear.filter(function(w){
        return dgMarked[w.s+':'+w.i];});
      if(ticked.length) return {ws:ticked,how:'ticked'};
      if(dgPickedAny()) return {ws:wear.filter(function(w){
        return dgSheetPick[w.s];}),how:'picked'};
      return {ws:wear,how:'all'};
    };
    var inScope=function(){return pickMode().ws;};
    var put=document.createElement('button');
    put.className='dbtn primary dg-put';
    function putWhat(){
      var m=pickMode();
      if(m.how==='ticked') return m.ws.length+' ticked box'
        +(m.ws.length===1?'':'es');
      if(m.how==='picked') return m.ws.length+' box'
        +(m.ws.length===1?'':'es')+' on the '+dgPickedCount()
        +' slide'+(dgPickedCount()===1?'':'s')+' you picked';
      return (m.ws.length>1?'all ':'')+m.ws.length+' box'
        +(m.ws.length===1?'':'es');
    }
    function putSync(){
      var m=pickMode(),ws=m.ws;
      /* a zero-target command was the biggest button on the surface
         (JVUX-10): a zero-target command is an empty state, not a call
         to action */
      /* T223: "the button says 'put all 8 of them there', what the
         heck. Do you think about writing? 'Apply to all'" */
      /* T367: the target is a GROUP you picked on the board, not a
         rectangle nobody chose. With nothing picked there is nothing to
         match to, and the button says which half is missing rather than
         going grey for two different reasons. */
      var tgt=dgPickedPlace(id);
      var others=tgt
        ?ws.filter(function(w){return dgPlaceKey(w.a)!==tgt.key;}):[];
      put.innerHTML=!ws.length
        ?(m.how==='all'
          ?'No boxes wear this style'
          :'None of what you selected wears this style')
        :(!tgt
          ?'Pick a place above to match'
          :(others.length
            ?(bic('align')+' Move the other '+others.length+' box'
              +(others.length===1?'':'es')+' here')
            :'They are all in this place already'));
      put.classList.toggle('primary',!!others.length);
      put.disabled=!others.length;
      put.title=others.length
        ?('Move them onto the place you picked. Ctrl+Z undoes the lot.'
          +(m.how==='all'
            ?' Tick rows in the table, or pick slides on the right, to '
              +'do fewer.':''))
        :(ws.length&&!tgt?'Click a group above first':'');
    }
    put.addEventListener('click',function(){
      var tgt=dgPickedPlace(id); if(!tgt) return;
      var n=0;
      inScope().forEach(function(w){
        if(dgPlaceKey(w.a)===tgt.key) return;
        w.a.x=tgt.a.x;w.a.y=tgt.a.y;
        if(tgt.a.w!=null) w.a.w=tgt.a.w;
        /* an anchored box measures from its anchor, so a moved box has
           to clear the anchor or it lands somewhere else */
        delete w.a.anch;
        n++;
      });
      if(!n) return;
      markDirty();refresh();renderFilm();dgBodyKeep(ov);
      toast(n+' '+(d.label||id)+' box'+(n===1?'':'es')
        +' moved — Ctrl+Z undoes it');
    });
    putRow.appendChild(put);
    putSync();
    right.appendChild(putRow);

    dgSectionHead(body,'Every box wearing it');
    dgTable(body,ov);
    dgSheet(body,ov);
  }
  function openDesign(){
    dgClose();
    var ov=document.createElement('div');
    ov.className='deck-design';ov.id='deck-design';
    ov.innerHTML='<div class="dh-head">'
      +'<span class="dh-t">Style system — “'+esc(pres.name||'this deck')
      +'”</span><span class="deck-spring"></span>'
      /* T315: the screen whose job is "what is the standard" had no
         way to pick one */
      +'<button class="dbtn" id="dg-sets">'+bic('styles')
      +' Style sets\u2026</button>'
      +'<button class="dbtn" id="dg-check">'+bic('scope')
      +' Check consistency</button>'
      +'<button class="dbtn" id="dg-close">'+bic('exit')+' Close</button>'
      +'</div><div class="dg-main">'
      +'<div class="dg-rail" id="dg-list"></div>'
      +'<div class="dg-body" id="dg-body"></div>'
      /* T230: the slides go DOWN THE SIDE (2026-09-03, user: "the
         slide thumbnails should be down the side as that's the way
         people are used to viewing them"). One column, wider than
         the four-across grid they were in, so their words can be
         read. */
      +'<div class="dg-sheetcol" id="dg-sheetcol"></div></div>';
    /* T465: the page's colour rides onto the screen. It is mounted on
       body, outside .deck where --page-bg is set, so the board fell to
       its fallback and in Light drew the slide's white words on a white
       board (2026-09-15 review). */
    try{ov.style.setProperty('--page-bg',
      getComputedStyle(deckEl).getPropertyValue('--page-bg')||deckPageBg());
    }catch(err){}
    document.body.appendChild(ov);
    ov.querySelector('#dg-close').addEventListener('click',dgClose);
    /* T384: the door had no handler behind it. Same route the ribbon's
       own Style sets button takes; this screen closes first, because
       the picker is a dialog over the editor, not over this. */
    /* T465: the click that opens the next surface must not reach the
       overlay owner's outside-click, which would pop it the same
       instant -- the standing overlay rule, applied where it was
       missing: Check consistency opened the check and closed it in
       one click, so the Style system had no working door to it. */
    /* T470: ...AND THE SCREEN STAYS. It closed itself first, because
       the picker sits at a lower z-index than the screen -- so picking
       a set threw you out of the Style system and Close on the picker
       left you in the editor, not back where you were (2026-09-15
       review). The picker opens ABOVE the screen instead, and the
       screen redraws when it closes, wearing what was picked. */
    ov.querySelector('#dg-sets').addEventListener('click',function(e){
      e.stopPropagation();
      if(typeof window.SemDeckStyleSets==='function')
        window.SemDeckStyleSets(function(){
          var o2=$('#deck-design');
          if(o2){dgRail(o2);dgBody(o2);}
        });
    });
    ov.querySelector('#dg-check').addEventListener('click',function(e){
      /* the drift CHECK stays where it is: this surface says what the
         standard is, that pane says who is not keeping to it, and one
         doing both would be a screen answering two questions */
      e.stopPropagation();
      dgClose();
      var b=$('#dsg-std');
      if(b) b.click();
    });
    document.addEventListener('keydown',dgKey,true);
    var usedStyles=styleOrder().filter(function(id){
      return dgWearers(id).length>0;});
    if(usedStyles.indexOf(dgSel)<0){
      if(usedStyles.length) dgSel=usedStyles[0];
      else {
        var firstKind=DG_OBJ_KINDS.filter(function(pr){
          var old=dgSel;dgSel='obj:'+pr[0];
          var n=dgRows().length;dgSel=old;return n>0;
        })[0];
        dgSel=firstKind?('obj:'+firstKind[0]):'obj:image';
      }
    }
    dgRail(ov);dgBody(ov);
  }
  window.SemDeckDesign=openDesign;
  function miniDiagram(s){
    var d=document.createElement('span');
    d.className='mini-diagram free';
    if(!s) return d;
    if((pres.slides||[]).indexOf(s)>=0) paintSlide=s;   /* T316 */
    /* the slide's own background, so a recoloured slide reads as one --
       T467: and the DECK's, resolved the one way (pageBgOf), so a deck
       made light reads light in the strip rather than navy against a
       white page (2026-09-15 review) */
    if(typeof pageBgOf==='function') d.style.background=pageBgOf(s);
    else if(s.bg) d.style.background=tokVal(s.bg);
    var annots=s.annots||[];
    if(s.layout!=='title'&&!annots.length){
      var e=document.createElement('span');
      e.className='mini-pane empty';
      d.appendChild(e);
      return d;
    }
    if(s.layout==='title'){
      miniText(d,titleProps(s,'t'),s.title||'Title','is-t',true);
      miniText(d,titleProps(s,'s'),s.sub||'','is-s',true);
    }
    /* arrows go last so they sit on top, exactly as on the canvas */
    var arrows=[];
    annots.forEach(function(a,i){
      if(!a||a.hide) return;
      if(a.k==='arrow'){arrows.push(a);return;}
      if(a.k==='text'){miniText(d,a,a.text||'');return;}
      if(a.k==='image'){
        var bx=miniBox(d,a,'is-img');
        if(a.src){
          var im=document.createElement('img');
          im.src=a.src;im.alt='';im.loading='lazy';im.draggable=false;
          im.setAttribute('aria-hidden','true');   /* decorative (T105) */
          if(a.crop) bx.classList.add('is-crop');
          bx.appendChild(im);
        }
        return;
      }
      if(a.k==='flip'){
        /* the thumbnail shows the frame the slide RESTS on, which is the
           one the strip is an index to. Without a branch here a flip book
           is invisible in the film strip and every slide holding one
           looks empty (the lesson miniDiagram was rewritten for). */
        var bf=miniBox(d,a,'is-flip');
        var ff=flipFrames(a)[a.at||0];
        if(ff&&ff.src){
          var fim2=document.createElement('img');
          fim2.src=ff.src;fim2.alt='';fim2.loading='lazy';
          fim2.draggable=false;
          fim2.setAttribute('aria-hidden','true');  /* decorative (T105) */
          bf.appendChild(fim2);
        } else if(ff&&ff.ref){
          var fnode2=framePart(ff.ref,ff.part);
          var fimg2=fnode2?fnode2.querySelector('img'):null;
          if(fimg2&&fimg2.src){
            var fc=document.createElement('img');
            fc.src=fimg2.src;fc.alt='';fc.loading='lazy';fc.draggable=false;
            fc.setAttribute('aria-hidden','true');  /* decorative (T105) */
            bf.appendChild(fc);
          }
        }
        return;
      }
      if(a.k==='rect'){
        var bs=miniBox(d,a,'is-shape');
        bs.appendChild(drawShapeSvg(a.shape||'rect',a.color||'#ff6b57',
          miniSw(a),a,'m'+(miniSeq++),null));
        miniStroke(bs,a);
        return;
      }
      if(a.k==='draw'){
        var bd=miniBox(d,a,'is-shape');
        bd.appendChild(drawFreeSvg(a,null));
        miniStroke(bd,a);
        return;
      }
      if(a.k==='table'){
        /* a real miniature table: at 116px the words are a smudge, but
           the SHAPE of a table is unmistakable and that is what a
           thumbnail is for */
        var bt=miniBox(d,a,'is-tbl');
        var trows=tableRows(a),tcols=tableCols(a);
        var mt=document.createElement('table');
        mt.className='mini-tbl'+(a.grid===0?' nogrid':'');
        if(a.color) mt.style.color=tokVal(a.color);
        if(a.bg!==0&&a.bgc) bt.style.background=tokVal(a.bgc);
        mt.style.fontSize=Math.max(1.5,
          miniHNow*(a.size||2.2)/100).toFixed(2)+'px';
        trows.forEach(function(row,ri){
          var tr=document.createElement('tr');
          row.forEach(function(v,ci){
            var td=document.createElement((a.thead&&ri===0)?'th':'td');
            td.style.width=tcols[ci]+'%';
            td.textContent=v==null?'':String(v);
            tr.appendChild(td);});
          mt.appendChild(tr);});
        bt.appendChild(mt);
        return;
      }
      if(a.k==='cell'){
        var w2=paneThumb(a.ref);
        w2.style.position='absolute';
        w2.style.left=(a.x||0)+'%';w2.style.top=(a.y||0)+'%';
        w2.style.width=(a.w||10)+'%';w2.style.height=(a.h||10)+'%';
        if(a.rot) w2.style.transform='rotate('+a.rot+'deg)';
        d.appendChild(w2);
      }
    });
    if(arrows.length){
      /* ONE svg for every arrow, in the page's own 0..100 percentage
         space — preserveAspectRatio="none" makes that space the
         thumbnail, so no pixel measurement is needed and nothing has to
         be re-scaled when the strip is resized */
      var sv=document.createElementNS(AN_NS,'svg');
      sv.setAttribute('class','mini-svg');
      sv.setAttribute('viewBox','0 0 100 100');
      sv.setAttribute('preserveAspectRatio','none');
      arrows.forEach(function(a){
        var p=document.createElementNS(AN_NS,'path');
        p.setAttribute('d',arrowPath(arrowEnds(null,s,a,0),a,100,100));
        p.setAttribute('fill','none');
        p.setAttribute('stroke',tokVal(a.color)||'#ff6b57');
        p.setAttribute('stroke-width',miniSw(a));
        p.setAttribute('vector-effect','non-scaling-stroke');
        p.setAttribute('stroke-linecap','round');
        if(a.op!=null&&a.op<1) p.setAttribute('opacity',a.op);
        sv.appendChild(p);
      });
      d.appendChild(sv);
    }
    return d;
  }
  /* ---- the other pages, as a floating pane -----------------------------
     The strip is MOVED into #verpane rather than rebuilt there, so
     reordering, drag-and-drop, delete and the thumbnails keep working
     with no second copy of any of it (2026-08-10, user: "the bar for this
     should appear like the objects bar"). */
  var filmHome=null;
  function filmToPane(){
    var body=$('#verpane-body'),list=$('#film-list'),add=$('#film-adds'),
        head=$('#film-head');
    if(!body||!list||filmHome) return;
    filmHome={parent:list.parentNode,next:list.nextSibling};
    /* the chooser rides along as a THIRD node, above the list it chooses
       for. Building a second copy of it in the pane is how two controls
       that claim to do the same thing start disagreeing (2026-08-22). */
    if(head) body.appendChild(head);
    body.appendChild(list);
    if(add) body.appendChild(add);
  }
  function filmToPanel(){
    if(!filmHome) return;
    var list=$('#film-list'),add=$('#film-adds'),head=$('#film-head');
    if(list&&filmHome.parent){
      var at=(filmHome.next&&filmHome.next.parentNode===filmHome.parent)
        ?filmHome.next:null;
      /* head, list, adds — in that order and all before whatever followed
         the list when it left, so the column comes back exactly as it was
         rather than with its chooser stranded at the bottom */
      if(head) filmHome.parent.insertBefore(head,at);
      filmHome.parent.insertBefore(list,at);
      if(add) filmHome.parent.insertBefore(add,at);
    }
    filmHome=null;
  }
  /* The button reports the state of whichever strip this page kind uses:
     the docked one for a deck, the floating pane for a poster. Written
     once, because two of these drifting apart is a toggle that lies about
     what it will do. */
  function syncStripBtn(){
    var vb=$('#vw-versions'); if(!vb) return;
    var p=$('#verpane');
    var on=pageOf().poster
      ? !!(p&&!p.hidden)
      : !deckEl.classList.contains('strip-off');
    vb.setAttribute('aria-pressed',on.toString());
  }
  function showVerpane(on){
    var p=$('#verpane'); if(!p) return;
    if(on){
      paneShow('verpane');
      filmToPane();
      renderFilm();
    } else paneHide('verpane');
    var t=$('#verpane-title');
    if(t) t.textContent=pageOf().poster?'Versions':'Slides';
    syncStripBtn();
  }
  /* ---- versions --------------------------------------------------------
     A poster's other pages are drafts and variants, so a new one starts as
     a COPY of what you are looking at — that is what a variant is a
     variant OF — and it is named for you, because an unnamed pile of
     near-identical A0 sheets is unusable. The name is a starting point:
     Rename changes it. */
  function nextVersionName(){
    var n=0;
    (pres.slides||[]).forEach(function(s){
      var m=/^Version (\d+)$/.exec((s&&s.label)||'');
      if(m) n=Math.max(n,+m[1]);
    });
    return 'Version '+(n+1);
  }
  /* `lay` is a layout from the catalogue when a Home tile asked for
     this slide (T202), `arr` a saved layout whose shapes it should
     carry; the film strip's + passes its click event, which is
     neither */
  function newVersion(lay,arr){
    if(!(lay&&lay.items)) lay=null;
    var at=pres.slides.length?cur+1:0;
    if(!pageOf().poster){
      /* a DECK's slides are named by what is on them, which is more use
         than "Slide 3" — so no label is stamped here */
      var ns=emptySlide();
      /* THE LAYOUT YOU LAST CHOSE (T193). A new slide arrives laid out
         the way the last one you picked a layout for was, and a deck
         that has never picked one starts with a title, a panel and
         text -- the shape most slides in a talk have (2026-09-02,
         user: "when click add new it should remember the last one you
         added. The default slide choice should be the panel, title,
         text"). Blank is still one pick away. */
      var key=lsGet(newLayKey())||'cell-text';
      if(!arr&&!lay&&/^arr:/.test(key)&&typeof arrList==='function'){
        var hit=arrList()[+key.slice(4)];
        if(hit&&hit.annots) arr=hit;
      }
      if(arr&&arr.annots){
        ns.annots=deep(arr.annots);
      } else {
        lay=lay||layoutById(/^arr:/.test(key)?'cell-text':key);
        if(lay&&!lay.poster) applyLayout(ns,lay);
      }
      pres.slides.splice(at,0,ns);
    } else {
      var src=pres.slides[cur];
      /* name the page you were already on first, so the two read as a
         pair rather than "empty slide" and "Version 2" */
      if(src&&!src.label) src.label=nextVersionName();
      var cp=src?deep(src):emptySlide();
      cp.label=nextVersionName();
      pres.slides.splice(at,0,cp);
    }
    /* a new slide joins the section it was inserted into. Without this an
       insert splits the run in two and grows a divider out of nowhere. */
    var prev=pres.slides[at-1];
    if(prev&&prev.sec) pres.slides[at].sec=prev.sec;
    cur=at;activePane=-1;selAnnot=null;selSet=[];
    normSections();markDirty();refresh();
    if(!$('#verpane').hidden) renderFilm();
  }
  /* ---- THE OUTLINE ----------------------------------------------------
     In headings mode the strip stops being a contact sheet and becomes a
     table of contents, so it must name a slide by its HEADING and not by
     whatever text happens to sit highest on it. A box wearing a heading
     style says outright that it is the slide's title; slideTitle's
     guesswork is the fallback for slides that never used one. */
  function slideHeading(s){
    var best=null,bestAt=99;
    (s.annots||[]).forEach(function(a){
      if(!a||a.k!=='text'||a.hide||!String(a.text||'').trim()) return;
      if(!a.style||!isHeadingStyle(a.style)) return;
      var at=headingStyles().indexOf(a.style);
      if(at>=0&&at<bestAt){bestAt=at;best=a;}
    });
    return best?String(best.text).trim().split('\n')[0]:'';
  }
  /* how far the row indents in the outline. A title slide and a section
     divider are always level 0 — they are the top of something, whatever
     style their text happens to wear. */
  function headLevel(s){
    if(!s||s.layout==='title'||s.layout==='section') return 0;
    var lv=0;
    (s.annots||[]).forEach(function(a){
      if(!a||a.k!=='text'||a.hide||!a.style) return;
      var at=headingStyles().indexOf(a.style);
      if(at>=0&&(!lv||at<lv)) lv=at;
    });
    return Math.min(3,lv);
  }
  /* ONE source for the words on a row, so the strip and refreshThumb can
     never disagree about what a slide is called */
  function filmText(s){
    if(filmMode()==='thumb') return slideTitle(s);
    return slideHeading(s)||slideTitle(s);
  }
  function slideTitle(s){
    /* a version carries the name you were given or chose; only posters
       get one, so a deck slide is still named by what is ON it */
    if(s.label) return s.label;
    if(s.layout==='title') return s.title||'title slide';
    var cells=slideCells(s);
    for(var i=0;i<cells.length;i++){
      var it=cells[i].a.ref&&resolveRef(cells[i].a.ref);
      if(it) return it.title;
    }
    var tx=(s.annots||[]).filter(function(a){
      return a.k==='text'&&a.text;})[0];
    if(tx){
      /* T469: not the SOURCE -- the strip read "$$ E = mc^2 $$" and
         "# Big heading ## Sub" (2026-09-15 review) */
      var t=String(tx.text);
      if(tx.maths) t=t.replace(/^\s*\$\$?/,'').replace(/\$\$?\s*$/,'').trim()||'equation';
      else if(tx.md) t=(t.split('\n').map(function(l){
        return l.replace(/^\s*(?:#{1,6}|[-*>]|\d+[.)])\s*/,'').trim();})
        .filter(Boolean)[0])||t;
      return t;
    }
    /* a slide that is one big table is named by its first heading, which
       beats calling it "empty slide" (2026-08-20) */
    var tb=(s.annots||[]).filter(function(a){return a.k==='table';})[0];
    if(tb){
      var r0=(tb.rows||[])[0]||[];
      for(var j=0;j<r0.length;j++)
        if(String(r0[j]||'').trim()) return String(r0[j]).trim();
      return 'table';
    }
    return 'empty slide';
  }
  /* ---- SLIDE SECTIONS -------------------------------------------------
     "There should be the ability to create slide sections in the
     thumbnails part" (2026-08-22).

     THE SHAPE, and why it is this one. A section is a TAG on the slide
     (s.sec) plus a name in a keyed map (pres.sections). The ORDER is
     never stored: it is read back off pres.slides. Every slide mutation
     in this file is a raw splice — moveSlide, delSlide, dupSlide,
     newVersion, the strip's drop handler — and histRestore replaces the
     array outright; a tag rides through all six for free, while a stored
     start-INDEX would have to be shifted correctly in every one of them
     and would be silently wrong the first time one was missed.

     The one price of tags is that they permit a section to go
     discontiguous. normSections() below is what pays it, and every verb
     here ends by calling it. */
  var secSeq=0;
  function secId(){
    /* an id has to survive a save, a reload and an undo, so it cannot be
       a plain counter reset on load — two sections would collide the
       moment you reopened a deck and made another one */
    secSeq++;
    return 's'+Date.now().toString(36)+secSeq.toString(36);
  }
  function secMap(){
    if(!pres.sections||typeof pres.sections!=='object') pres.sections={};
    return pres.sections;
  }
  function secName(id){
    var d=(pres.sections||{})[id];
    return (d&&d.name)||'Untitled section';
  }
  /* THE ONE SHARED API. The strip, the Apply dialog's scope picker and
     the outline view must all agree on what a section IS, so all three
     read it from here rather than each grouping the slides their own
     way. Untagged spans come back too, with id '' — a caller that wants
     only real sections filters on run.id. */
  function sectionRuns(){
    var out=[],sl=pres.slides||[],i,id,last=null;
    for(i=0;i<sl.length;i++){
      id=(sl[i]&&sl[i].sec)||'';
      if(!last||last.id!==id){
        last={id:id,name:id?secName(id):'',at:i,n:0,
          fold:!!(id&&(pres.sections||{})[id]&&pres.sections[id].fold),
          color:(id&&(pres.sections||{})[id]&&pres.sections[id].color)||''};
        out.push(last);
      }
      last.n++;
    }
    return out;
  }
  /* THE INVARIANT. A section is a CONTIGUOUS run — that is what a divider
     in a strip means, and nothing in the UI can express anything else. A
     tag can still end up out of place (drag a slide past a boundary, or
     swap one across it with the arrows), so every mutation ends here: a
     tag that reappears after its run has closed is re-tagged to the run
     it now sits in, and any section no slide uses is thrown away.
     Dropping the map entirely when it empties is what keeps a deck that
     never used sections serialising exactly as it did before. */
  function normSections(){
    var sl=pres.slides||[],seen={},closed={},prev='',i,id;
    for(i=0;i<sl.length;i++){
      if(!sl[i]) continue;
      id=sl[i].sec||'';
      if(id&&id!==prev&&(closed[id]||seen[id])) id=prev;
      if(id) seen[id]=1;
      if(prev&&prev!==id) closed[prev]=1;
      if(id) sl[i].sec=id; else delete sl[i].sec;
      prev=id;
    }
    var m=pres.sections;
    if(m){
      Object.keys(m).forEach(function(k){if(!seen[k]) delete m[k];});
      if(!Object.keys(m).length) delete pres.sections;
    }
    if(typeof normAlts==='function') normAlts();   /* T318 */
  }
  /* the five verbs. Everything that touches sections goes through one of
     these, so normSections() is guaranteed to have run before markDirty
     writes the deck out. */
  function newSection(at,name){
    var id=secId(),i;
    secMap()[id]={name:name||'New section'};
    /* a new section OWNS everything from `at` down to the next divider —
       that is what "start a section here" means in PowerPoint, and it is
       the only reading that leaves no orphan slides behind */
    var was=(pres.slides[at]&&pres.slides[at].sec)||'';
    for(i=at;i<pres.slides.length;i++){
      if(((pres.slides[i].sec)||'')!==was) break;
      pres.slides[i].sec=id;
    }
    /* T316: refresh, not renderFilm -- every other membership verb
       ends in refresh(), and a heading wearing '@section' has to
       repaint the moment the section it now sits in exists */
    normSections();markDirty();refresh();
  }
  function renameSection(id){
    /* prompt(), not an inline edit on the row. The row's own click
       re-renders the strip, so by the time a dblclick handler arrived the
       node it was editing had already been replaced — the same reason the
       poster version rename is a button and a prompt (2026-08-10) */
    askText({title:'Name this section',value:secName(id),ok:'Rename'},
    function(v){
    if(v==null) return;
    v=v.trim(); if(!v) return;
    /* T316: in place, so the arrival and the colour survive a rename
       (the rebuild here was already dropping `trans`) */
    var rec=secMap()[id]||(secMap()[id]={});
    rec.name=v;
    markDirty();renderFilm();
    });
  }
  function foldSection(id,on){
    var d=secMap()[id]; if(!d) return;
    if(on) d.fold=1; else delete d.fold;
    /* markDirty(true): folding is a way of LOOKING at the deck, not an
       edit to it, so it persists in the file but never lands on the undo
       stack — Ctrl+Z must never open or close a section */
    markDirty(true);renderFilm();
  }
  function removeSection(id,withSlides){
    var runs=sectionRuns(),r=null,i;
    for(i=0;i<runs.length;i++) if(runs[i].id===id) r=runs[i];
    if(!r) return;
    if(withSlides) pres.slides.splice(r.at,r.n);
    /* the slides MERGE UPWARDS into whatever section is above — removing
       a divider must never delete work, which is why the destructive form
       is a separate and differently-worded verb */
    else for(i=r.at;i<r.at+r.n;i++){
      if(r.at>0&&pres.slides[r.at-1].sec)
        pres.slides[i].sec=pres.slides[r.at-1].sec;
      else delete pres.slides[i].sec;
    }
    if(pres.sections) delete pres.sections[id];
    if(cur>=pres.slides.length) cur=Math.max(0,pres.slides.length-1);
    normSections();markDirty();refresh();
  }
