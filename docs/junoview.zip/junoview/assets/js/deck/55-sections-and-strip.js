/* 55-sections-and-strip.js — sections as units, the film strip and its menus, and mode switching.
   ONE FRAGMENT of deck.js's single IIFE, concatenated with its
   siblings in filename order by assets.deck_js(). It does not
   parse alone and is not meant to: see 00-page.js. */
  /* ---- A SECTION AS A UNIT (TASKS T23) ---------------------------------
     Sections already existed as a model and half a UI: a `sec` tag on
     the slide, a names map, a contiguous-run invariant that normSections
     restores after every mutation, dividers in the strip, fold, rename,
     remove, and move-a-slide-into-one. Three things were missing, and
     each of them is "the section behaves like one thing" rather than a
     new model.

     MOVE AS A UNIT. Dragging the divider moved nothing; the arrows moved
     one slide at a time. `moveSection` lifts the whole run out and puts
     it back somewhere else, and because membership is the tag ON each
     slide, the tags travel with the slides and normSections has nothing
     to repair.

     DUPLICATE AS A UNIT. dupSlide clones one. A section's copy needs a
     NEW id — two runs sharing one id is exactly the state the
     contiguity invariant exists to forbid — and its own name, because
     "Methods" appearing twice in a strip is not a section, it is a
     puzzle.

     SECTION-SCOPED NUMBERING. Slide numbers are global by deliberate
     decision (renderFilm's comment says so, and the furniture resolves
     {n} to the deck index). That decision is right for the strip and
     wrong for a talk in parts, so it becomes a CHOICE rather than a
     reversal: {sn} and {sN} are the number within the section and the
     size of the section, alongside the {n} and {N} that already mean
     the whole deck. Nothing that exists changes meaning. */
  function moveSection(id,dir){
    var runs=sectionRuns(),at=-1,i;
    for(i=0;i<runs.length;i++) if(runs[i].id===id) at=i;
    if(at<0) return 0;
    var to=at+dir;
    if(to<0||to>=runs.length) return 0;
    var me=runs[at],other=runs[to];
    var block=pres.slides.splice(me.at,me.n);
    /* removing the block shifts anything after it, so the destination is
       computed from where the OTHER run sits once the hole is closed */
    var dest=(dir<0)?other.at:(other.at+other.n-me.n);
    for(i=0;i<block.length;i++) pres.slides.splice(dest+i,0,block[i]);
    normSections();
    cur=dest;activePane=-1;selAnnot=null;selSet=[];
    markDirty();refresh();
    return block.length;
  }
  function dupSection(id){
    var runs=sectionRuns(),run=null;
    runs.forEach(function(r){if(r.id===id) run=r;});
    if(!run) return 0;
    var nid=secId();
    var name=(secName(id)||'Section')+' copy';
    secMap()[nid]={name:name};
    var copies=[];
    for(var i=0;i<run.n;i++){
      var cp=deep(pres.slides[run.at+i]);
      cp.sec=nid;          /* a NEW id: two runs cannot share one */
      delete cp.label;
      copies.push(cp);
    }
    for(var j=0;j<copies.length;j++)
      pres.slides.splice(run.at+run.n+j,0,copies[j]);
    normSections();
    cur=run.at+run.n;activePane=-1;selAnnot=null;selSet=[];
    markDirty();refresh();
    return copies.length;
  }
  /* which section a slide is in, and where in it — the numbers {sn}/{sN}
     resolve to. Derived from the slide list like everything else about
     sections; nothing is stored. */
  /* ---- T318: ALTERNATIVE VERSIONS OF ONE SLIDE ---------------------
     (2026-09-06, user: "create different version of slides e.g. like the
     version collapse under one version that is starred and that is the
     main version that appears in presenter mode or when you click
     through with arrows, but you can uncollapse and have different
     versions of the one slide".)

     THE MODEL IS ONE TAG. A group is a contiguous run of slides sharing
     `alt` (a group id minted like a section's); the FIRST of the run is
     the main and nothing stores that -- starring an alternative moves it
     to the head, which the ordinary slides snapshot already undoes. The
     alternatives stay real entries in pres.slides, never nested: ~430
     reads of that list then treat one as a full slide for free (edit,
     thumbnails, undo, sids, links), and the four places that must skip
     it are exactly the four the request names -- what plays
     (slideSkipped), what exports (outputSlides), what the strip shows
     (renderFilm) and what the numbers count (slideNo).

     Not `opt` or a cut: those skip only after Running late or under a
     session-scoped cut, and every surface would say "optional". Not
     `label`: a poster page name that dupSlide deletes on decks. Not the
     history store: whole-deck snapshots. And "alternative", not
     "version", in the UI -- "version" already means a cut, a poster
     page and a history snapshot here.

     Expand/collapse is session state, default collapsed, never a file
     key: a way of looking at the strip, and Ctrl+Z must never open or
     close a group. The slide you are ON always shows, because
     refreshThumb looks its row up by data-idx. */
  var altSeq=0,altOpen={};
  function altId(){
    altSeq++;
    return 'v'+Date.now().toString(36)+altSeq.toString(36);
  }
  /* the run this slide belongs to, or null when it is on its own */
  function altRun(i){
    var sl=pres.slides||[],s=sl[i];
    if(!s||!s.alt) return null;
    var a=i,b=i;
    while(a>0&&sl[a-1]&&sl[a-1].alt===s.alt) a--;
    while(b<sl.length-1&&sl[b+1]&&sl[b+1].alt===s.alt) b++;
    if(b===a) return null;
    return {at:a,n:b-a+1,gid:s.alt};
  }
  /* an alternative is any member of a run that is not its head */
  function slideIsAlt(i){
    var r=altRun(i);
    return !!(r&&i>r.at);
  }
  /* the numbers a person sees count MAINS only, so the strip, the
     furniture and the counter agree with the talk and with the paper */
  function slideNo(i){
    var n=0;
    for(var k=0;k<=i&&k<(pres.slides||[]).length;k++)
      if(!slideIsAlt(k)) n++;
    return n;
  }
  function slideCount(){
    var n=0;
    (pres.slides||[]).forEach(function(s,k){if(!slideIsAlt(k)) n++;});
    return n;
  }
  /* THE INVARIANT, paid the way normSections pays for sections: a run
     is contiguous and has at least two members. A tag that reappears
     after its run has closed is dropped (a stray alternative becomes a
     slide of its own rather than being teleported); a run of one
     dissolves; every member takes the head's section so a divider can
     never split a group. Called from normSections, which every
     membership verb already ends by calling. */
  function normAlts(){
    var sl=pres.slides||[],seen={},closed={},prev='',i,g;
    for(i=0;i<sl.length;i++){
      if(!sl[i]) continue;
      g=sl[i].alt||'';
      if(g&&g!==prev&&(closed[g]||seen[g])) g='';
      if(g) seen[g]=(seen[g]||0)+1;
      if(prev&&prev!==g) closed[prev]=1;
      if(g) sl[i].alt=g; else delete sl[i].alt;
      prev=g;
    }
    for(i=0;i<sl.length;i++){
      if(!sl[i]||!sl[i].alt) continue;
      if(seen[sl[i].alt]<2){delete sl[i].alt;continue;}
      var r=altRun(i);
      if(r&&i>r.at){
        var head=sl[r.at];
        if(head&&head.sec) sl[i].sec=head.sec; else delete sl[i].sec;
      }
    }
  }
  /* the verbs */
  function addVersion(i){
    var s=pres.slides[i]; if(!s) return;
    var r=altRun(i);
    var gid=(r&&r.gid)||s.alt||altId();
    if(!s.alt) s.alt=gid;
    var cp=deep(s);
    cp.alt=gid;delete cp.sid;
    var n=(r?r.n:1)+1;
    cp.label='Version '+n;
    var at=r?(r.at+r.n):(i+1);
    pres.slides.splice(at,0,cp);
    altOpen[gid]=1;
    cur=at;activePane=-1;selAnnot=null;selSet=[];
    normSections();markDirty();refresh();
    toast('\u201c'+cp.label+'\u201d added \u2014 the talk still shows '
      +'the starred one. Right-click a version to make it the main.',6000);
  }
  function starVersion(i){
    var r=altRun(i); if(!r||i===r.at) return;
    var keep=pres.slides[i];
    var s=pres.slides.splice(i,1)[0];
    pres.slides.splice(r.at,0,s);
    cur=pres.slides.indexOf(keep);
    normSections();markDirty();refresh();
    toast('\u201c'+(s.label||slideTitle(s)||'This version')+'\u201d is the '
      +'main version now \u2014 it is what the talk shows. Ctrl+Z undoes it.');
  }
  function sectionPos(i){
    var runs=sectionRuns();
    for(var k=0;k<runs.length;k++){
      var r=runs[k];
      if(i>=r.at&&i<r.at+r.n)
        return {n:i-r.at+1,of:r.n,id:r.id,name:r.name};
    }
    return {n:i+1,of:(pres.slides||[]).length,id:'',name:''};
  }
  function moveSlideToSection(i,id){
    var runs=sectionRuns(),r=null,j,to;
    for(j=0;j<runs.length;j++) if(runs[j].id===id) r=runs[j];
    /* a tag on its own would break contiguity, so the slide MOVES to the
       end of that section's run — re-tagging without moving is the bug
       normSections would then immediately have to undo */
    to=r?(r.at+r.n):pres.slides.length;
    var moved=pres.slides.splice(i,1)[0]; if(!moved) return;
    if(to>i) to--;
    if(id) moved.sec=id; else delete moved.sec;
    pres.slides.splice(to,0,moved);
    cur=to;normSections();markDirty();refresh();
  }
  /* a WHOLE-SECTION drop is a different move: lift the run out and put it
     back at a divider boundary. `cur` is refound by IDENTITY afterwards —
     the single-slide path's four-branch arithmetic does not generalise to
     moving n slides at once, and getting it wrong strands you on somebody
     else's slide.

     NAMED moveSectionTo, and it matters. This was `moveSection` too, and
     deck/ is ONE scope in fifteen files: two declarations of a name are
     not two functions, they are the later one. "Move the section up"
     called it with dir=-1, which this body read as beforeAt=-1 and
     spliced the run in before the LAST slide; "down" with 1 was a no-op
     for any section already at the front. Neither toasted either, since
     this one returns nothing (2026-08-25). */
  function moveSectionTo(id,beforeAt){
    var runs=sectionRuns(),r=null,i;
    for(i=0;i<runs.length;i++) if(runs[i].id===id) r=runs[i];
    if(!r||(beforeAt>=r.at&&beforeAt<=r.at+r.n)) return;
    var keep=pres.slides[cur];
    var block=pres.slides.splice(r.at,r.n);
    var to=beforeAt>r.at?beforeAt-r.n:beforeAt;
    for(i=0;i<block.length;i++) pres.slides.splice(to+i,0,block[i]);
    var k=pres.slides.indexOf(keep);
    cur=k<0?0:k;
    normSections();markDirty();refresh();
  }
  var draggingSlide=-1,draggingSec=null;
  /* ONE divider row. Deliberately NOT class `film-row` and deliberately
     without a data-idx: refreshThumb looks up
     '.film-row[data-idx="N"]' and takes the first match, so a divider
     wearing either would quietly collect a slide's thumbnail. */
  function secRow(r){
    var el=document.createElement('div');
    el.className='film-sec'+(r.fold?' folded':'');
    el.dataset.sec=r.id;el.dataset.at=r.at;
    el.draggable=true;
    el.title='Drag to move the whole section';
    var f=document.createElement('button');
    f.className='film-sec-fold';
    f.innerHTML=r.fold?'&#9656;':'&#9662;';
    f.title=r.fold?'Show these slides':'Hide these slides';
    f.addEventListener('click',function(e){
      e.stopPropagation();foldSection(r.id,!r.fold);});
    el.appendChild(f);
    /* T316: the section's colour, as a dot before its name. Visible
       on every divider, so the cycle is discoverable without a menu;
       click to choose one, and the divider's menu puts it back. */
    var dot=document.createElement('button');
    dot.className='film-sec-dot';dot.type='button';
    var sc=sectionColorFor(pres.slides[r.at]||{sec:r.id});
    dot.style.background=sc||'transparent';
    dot.title=(r.color?'This section\u2019s own colour':'Automatic section '
      +'colour')+' \u2014 click to choose one';
    dot.setAttribute('aria-label','Section colour');
    dot.addEventListener('click',function(e){
      e.stopPropagation();
      var inp=document.createElement('input');
      inp.type='color';inp.value=/^#[0-9a-f]{6}$/i.test(sc)?sc:'#4fb3d9';
      inp.style.position='fixed';inp.style.opacity='0';
      inp.addEventListener('change',function(){
        setSectionColor(r.id,inp.value);inp.remove();});
      inp.addEventListener('blur',function(){setTimeout(function(){
        if(inp.parentNode) inp.remove();},300);});
      document.body.appendChild(inp);inp.click();
    });
    el.appendChild(dot);
    var t=document.createElement('span');
    t.className='film-sec-t';t.textContent=r.name;el.appendChild(t);
    var n=document.createElement('span');
    n.className='film-sec-n';
    /* the count is the whole point of a collapsed section — a divider
       that hides four slides and does not say four is just a deck with
       slides missing */
    n.textContent=r.fold?(r.n+' hidden'):String(r.n);
    el.appendChild(n);
    var ctr=document.createElement('span');ctr.className='film-ctr';
    [[bic('pen'),function(){renameSection(r.id);},'Rename this section'],
     [bic('minus'),function(){removeSection(r.id,false);},
      'Remove this divider — the slides stay, and join the section '
      +'above']]
      .forEach(function(p){
        var b=document.createElement('button');b.className='film-mini';
        b.innerHTML=p[0];b.title=p[2];
        b.setAttribute('aria-label',p[2]);
        b.addEventListener('click',function(ev){
          ev.stopPropagation();p[1]();});
        ctr.appendChild(b);
      });
    el.appendChild(ctr);
    el.addEventListener('dragstart',function(e){
      draggingSec=r.id;el.classList.add('dragging');
      try{e.dataTransfer.setData('text/plain','sec-'+r.id);}catch(err){}
      try{e.dataTransfer.setDragImage(el,12,12);}catch(err){}
      e.dataTransfer.effectAllowed='move';
    });
    el.addEventListener('dragend',function(){
      draggingSec=null;el.classList.remove('dragging');clearFilmMarks();});
    el.addEventListener('contextmenu',function(ev){
      ev.preventDefault();openFilmMenu(r.at,ev,r);});
    return el;
  }
  function renderFilm(){
    var list=$('#film-list');
    /* T412: THE STRIP STAYS WHERE YOU SCROLLED IT (2026-09-13, user:
       "Everytime you click a slide on the thumbnails, or add a slide
       or anything it always jumps and moves around the scroll
       position ... It always takes you back to the top"). Emptying the
       list zeroes its scrollTop, and every repaint empties it -- a
       click on a thumbnail, a new slide, an edit. So the position is
       read first and put back after, and the current slide is then
       brought on screen only when it is off it, by the least that
       does (filmKeepCurrent). */
    var keepTop=list.scrollTop,keepLeft=list.scrollLeft;
    list.innerHTML='';
    /* the strip rebuilds every row, so a context menu left open is
       holding an index into nodes that no longer exist */
    var om=$('#film-menu'); if(om) om.remove();
    /* Headers are INSERTED into the flat loop rather than the loop being
       rewritten sections-outer / slides-inner. `i` stays the ARRAY index,
       which is what keeps the numbers global (1..n straight through every
       section) and keeps row.dataset.idx equal to the array index —
       refreshThumb and the drop maths both read it back. */
    var runs=sectionRuns(),head={},fold={};
    runs.forEach(function(r){
      if(r.id) head[r.at]=r;
      if(r.fold) for(var k=r.at;k<r.at+r.n;k++) fold[k]=1;
    });
    /* the mode is stamped ONCE on the list and the CSS branches off it,
       the way applyTab() stamps data-off — not a style per row, and not
       on the body or the deck, because filmToPane MOVES this list into
       the Versions pane and an ancestor class would be left behind */
    var fv=filmMode();
    list.setAttribute('data-fv',fv);
    miniHNow=miniH();
    pres.slides.forEach(function(s,i){
      if(head[i]) list.appendChild(secRow(head[i]));
      /* the CURRENT slide is drawn even inside a folded section: it is
         where you are standing, and it is also the row refreshThumb goes
         looking for on every edit — hide it and the live thumbnail dies */
      if(fold[i]&&i!==cur) return;
      /* T318: an alternative hides under its main unless the group is
         open -- or it is the slide you are on, for the same reason */
      var ar=altRun(i),isAlt=!!(ar&&i>ar.at);
      if(isAlt&&!altOpen[ar.gid]&&i!==cur) return;
      var filmCut=activeCut(),skipped=slideSkipped(i);
      var row=document.createElement('div');
      row.className='film-row'+(i===cur?' current':'')
        +(fold[i]?' peek':'')+(s.sec?' in-sec':'')
        +(s.opt?' opt':'')+(skipped&&!isAlt?' cut':'')
        +(isAlt?' alt':'')+(ar&&!isAlt?' has-alt':'');
      row.dataset.idx=i;
      row.draggable=true;
      var rowTips=['Drag to reorder'];
      if(s.opt) rowTips.push('Optional: Running late can skip this slide');
      if(skipped) rowTips.push(filmCut&&!inCut(s,filmCut)
        ?'Not shown in the “'+((cutMap()[filmCut]||{}).name||filmCut)
          +'” version'
        :'Skipped by Running late');
      row.title=rowTips.join('\n');
      row.addEventListener('contextmenu',function(ev){
        ev.preventDefault();openFilmMenu(i,ev,null);});
      row.addEventListener('dragstart',function(e){
        draggingSlide=i;
        row.classList.add('dragging');
        try{e.dataTransfer.setData('text/plain','slide-'+i);}
        catch(err){}
        /* drag the ROW as the ghost — the browser otherwise picks up the
           figure <img> inside the thumbnail as the drag image/payload */
        try{e.dataTransfer.setDragImage(row,12,12);}catch(err){}
        e.dataTransfer.effectAllowed='move';
      });
      row.addEventListener('dragend',function(){
        draggingSlide=-1;
        row.classList.remove('dragging');
        clearFilmMarks();
      });
      row.dataset.lvl=headLevel(s);
      var lbl=document.createElement('div');lbl.className='film-label';
      var num=document.createElement('span');num.className='film-n';
      /* T318: mains are numbered as the talk counts them; an
         alternative shows its name where a number would be */
      num.textContent=isAlt?'\u2022':slideNo(i);
      lbl.appendChild(num);
      if(i===cur&&mode==='create'&&s.layout!=='title'){
        /* notebook view: the current slide IS the big inline pane editor
           (paired with your visible notebook cells to fill it). In slide
           view the CANVAS is the single editor, so the strip stays thumbnails */
        var view=document.createElement('div');view.className='film-view';
        view.appendChild(buildSlideEditor(s));
        lbl.appendChild(view);
      } else if(fv!=='head'){
        /* in headings mode no thumbnail is BUILT, rather than one being
           built and hidden: miniDiagram emits an <img> per figure, a real
           <table> per table and an <svg> per slide, and a sixty-slide
           deck should not pay for all of that to draw a list of names */
        lbl.appendChild(miniDiagram(s));
      }
      var tt=document.createElement('span');tt.className='film-t';
      tt.textContent=filmText(s);lbl.appendChild(tt);
      var marks=document.createElement('span');marks.className='film-marks';
      function mark(cls,text,title){
        var tag=document.createElement('span');
        tag.className='film-mark '+cls;tag.textContent=text;tag.title=title;
        marks.appendChild(tag);
      }
      if(s.opt) mark('opt','optional','Running late can skip this slide');
      /* T318: the main wears the group's pill, and the pill IS the
         fold toggle -- secRow's chevron in the marks row's clothes,
         not a control over the thumbnail (T228). An alternative says
         what it is instead of "not shown". */
      if(ar&&!isAlt){
        var open=!!altOpen[ar.gid];
        var pill=document.createElement('button');
        pill.type='button';
        pill.className='film-mark alt-pill';
        pill.textContent=(open?'\u25be ':'\u25b8 ')+(ar.n-1)
          +' version'+(ar.n===2?'':'s');
        pill.title=(open?'Hide':'Show')+' the other version'
          +(ar.n===2?'':'s')+' of this slide. The starred one is what '
          +'the talk shows.';
        pill.addEventListener('click',function(e){
          e.stopPropagation();
          if(open) delete altOpen[ar.gid]; else altOpen[ar.gid]=1;
          renderFilm();
        });
        marks.appendChild(pill);
      }
      if(isAlt) mark('alt',s.label||('Version '+(i-ar.at+1)),
        'A version of slide '+slideNo(ar.at)+'. The talk shows the '
        +'starred one; right-click to make this the main.');
      /* T76: the numbered bubbles on the slide now show only while the
         Timeline pane is open, so the STRIP is what tells you a slide is
         animated at all. A COUNT, not a dot — "three builds" is the thing
         you want to know before you click into the slide, and it is the
         same number the bubbles are showing. */
      /* THE NUMBER THE SPACE BAR WILL USE (T162). This counted
         `slideBuildSteps`, i.e. anim-order builds only -- so a slide
         whose whole reveal is a six-figure flip book, or a chart built
         by series, was marked as having NOTHING on it. `flipPlan` is
         the sequence playback actually walks, and `slideStops` is its
         length; three surfaces used to re-derive a weaker answer from
         `slideBuildSteps` and each told the reader a different number
         from the one the space bar takes. The door named in the tip is
         the one that exists: T140 retired "Timeline". */
      var nbuild=slideStops(s);
      if(nbuild) mark('anim','▸'+nbuild,
        nbuild+(nbuild===1?' click':' clicks')+' to walk this slide'
        +'\nOpen Insert ▸ Animations to see the order');
      if(skipped&&!isAlt) mark('cut','not shown',filmCut&&!inCut(s,filmCut)
        ?'Not shown in the “'+((cutMap()[filmCut]||{}).name||filmCut)
          +'” version'
        :'Skipped by Running late');
      if(marks.childNodes.length) lbl.appendChild(marks);
      /* WHILE ARMED the thumbnail is a target, not a destination --
         and every row is one, including the current slide, which is why
         this listener is no longer conditional on i!==cur (T66) */
      lbl.addEventListener('click',function(){
        if(slideMatchHit(i)) return;
        if(i===cur) return;
        cur=i;activePane=-1;selAnnot=null;selSet=[];refresh();});
      /* T228: NO CONTROLS ON THE ROW. Four buttons appeared over
         every slide on hover -- move up, move down, duplicate,
         delete -- on top of the thumbnail you were trying to click
         (2026-09-03, user: "when you hover over a slide it brings up
         all the options around moving and duplicating. These are not
         needed here as you can just do that with other buttons or
         click and drag and just make it really hard to actually click
         on a slide"). Reordering is the drag the row already is;
         Duplicate and Delete are on Home; and the right-click menu
         keeps every one of them, move included. A poster's Rename
         goes there too. */
      row.appendChild(lbl);
      list.appendChild(row);
    });
    list.scrollTop=keepTop;list.scrollLeft=keepLeft;   /* T412 */
    filmKeepCurrent(list);
    /* T318: the Home doors follow the slide you are ON. Synced here,
       at the end of the one repaint every change of `cur` goes through
       -- the strip click, the arrows, go(), undo -- rather than in
       renderCreate, which the strip's own click does not reach
       (driven: the star stayed in the main's state on an alternative). */
    if(typeof syncHomeDoors==='function') syncHomeDoors();
    /* T477: the Present tab's version strip follows the deck (a new
       deck, a cut chosen, renamed or deleted all come through here) */
    if(typeof cutsSync==='function') cutsSync();
  }
  /* T412: the current row, on screen -- and only when it is not. A row
     you can already see is left exactly where it is; one that is off
     the edge (a new slide at the end, the arrow keys, undo) comes in by
     the least that shows it, never to the top. */
  function filmKeepCurrent(list){
    var cr=list.querySelector('.film-row.current'); if(!cr) return;
    var lr=list.getBoundingClientRect(),rr=cr.getBoundingClientRect();
    if(!lr.height) return;                  /* the strip is not showing */
    if(rr.top>=lr.top&&rr.bottom<=lr.bottom) return;
    if(rr.top<lr.top) list.scrollTop-=(lr.top-rr.top);
    else list.scrollTop+=(rr.bottom-lr.bottom);
  }
  function clearFilmMarks(){
    $$('#film-list .film-row.drop-above,#film-list .film-row.drop-below,'
      +'#film-list .film-sec.drop-above,#film-list .film-sec.drop-below')
      .forEach(function(r){
        r.classList.remove('drop-above');
        r.classList.remove('drop-below');
      });
  }
  /* ---- WHERE A DROP LANDS ----------------------------------------------
     Before sections a drop was one number: the row's dataset.idx, plus
     one if you were past its midpoint. With dividers interleaved a drop
     is TWO answers — where in the array, and which section the slide now
     belongs to — and on a divider they are decided by the SAME midpoint
     from opposite sides: above the divider is the last slide of the run
     before it, below it is the first slide of the run after. Same index,
     different owner. That is the whole change. */
  function filmDropTarget(row,clientY){
    var r=row.getBoundingClientRect(),below=clientY>r.top+r.height/2;
    if(row.classList.contains('film-sec')){
      var at=+row.dataset.at,id=row.dataset.sec;
      if(!below){
        var prev=pres.slides[at-1];
        return {to:at,sec:(prev&&prev.sec)||''};
      }
      if(row.classList.contains('folded')){
        /* a folded section shows no rows to aim between, so a drop onto
           it can only mean "put this one in there", at the end */
        var runs=sectionRuns(),k,n=0;
        for(k=0;k<runs.length;k++) if(runs[k].id===id) n=runs[k].n;
        return {to:at+n,sec:id};
      }
      return {to:at,sec:id};
    }
    var idx=+row.dataset.idx,s=pres.slides[idx];
    return {to:below?idx+1:idx,sec:(s&&s.sec)||''};
  }
  (function(){
    var list=$('#film-list'); if(!list) return;
    list.addEventListener('dragover',function(e){
      if(draggingSlide<0&&!draggingSec) return;
      e.preventDefault();
      e.dataTransfer.dropEffect='move';
      clearFilmMarks();
      var row=e.target.closest&&e.target.closest('.film-row,.film-sec');
      if(!row) return;
      var r=row.getBoundingClientRect();
      row.classList.add(
        e.clientY>r.top+r.height/2?'drop-below':'drop-above');
    });
    list.addEventListener('dragleave',function(e){
      if(e.target===list) clearFilmMarks();
    });
    list.addEventListener('drop',function(e){
      if(draggingSlide<0&&!draggingSec) return;
      e.preventDefault();
      var from=draggingSlide,sec=draggingSec;
      draggingSlide=-1;draggingSec=null;
      clearFilmMarks();
      var row=e.target.closest&&e.target.closest('.film-row,.film-sec');
      if(!row) return;
      var tgt=filmDropTarget(row,e.clientY);
      /* a whole section moves as a block and refinds `cur` by identity */
      if(sec){moveSectionTo(sec,tgt.to);return;}
      var to=tgt.to;
      if(to>from) to--;
      var moved=pres.slides.splice(from,1)[0];
      /* the slide joins whatever section it landed in — a slide dragged
         under a divider that kept its old tag would make the section
         discontiguous, and normSections would drag it straight back */
      if(tgt.sec) moved.sec=tgt.sec; else delete moved.sec;
      pres.slides.splice(to,0,moved);
      if(cur===from) cur=to;
      else if(from<cur&&to>=cur) cur--;
      else if(from>cur&&to<=cur) cur++;
      normSections();markDirty();refresh();
    });
  })();
  /* ---- the strip's right-click menu ------------------------------------
     The section verbs live HERE rather than on a ribbon button because
     this is where the thing being sectioned is visible, and because Home
     has no room to give (2026-08-22). Mounted on the body like
     openMatchMenu, and closed at the top of renderFilm — the strip
     rebuilds every row, so a menu left open holds a dead index. */
  function openFilmMenu(i,ev,run){
    var old=$('#film-menu'); if(old) old.remove();
    var m=document.createElement('div');
    m.className='sh-menu film-menu';m.id='film-menu';
    var poster=pageOf().poster;
    function row(label,fn,title,icon){
      var b=document.createElement('button');
      b.className='dbtn vw-opt';
      /* the icon arrives as trusted bic() markup; the LABEL stays a
         text node — section names are user data */
      if(icon) b.innerHTML=bic(icon)+' ';
      b.appendChild(document.createTextNode(label));
      if(title) b.title=title;
      b.addEventListener('click',function(e){
        e.stopPropagation();m.remove();fn();});
      m.appendChild(b);
      /* RETURNED, so a caller can mark the row the deck is currently in
         — the canvas menu's row() has always done this, and the two are
         otherwise the same idiom (2026-08-25, T27) */
      return b;
    }
    if(run){
      menuHead(m,'this section');
      row('Rename…',function(){renameSection(run.id);},null,'pen');
      if(run.color)
        row('Back to the automatic colour',function(){
          setSectionColor(run.id,'');},
          'Drop this section\u2019s own colour and take its turn in '
          +'the cycle again');
      row(run.fold?'▾ Show these slides':'▸ Hide these slides',
        function(){foldSection(run.id,!run.fold);});
      /* THE UNIT VERBS (T23): the whole run moves and copies as one
         thing, which is what makes a section an object rather than a
         label on a slide */
      row('↑ Move the section up',function(){
        var n=moveSection(run.id,-1);
        if(n) toast(n+' slide'+(n===1?'':'s')+' moved as one');},
        'The whole run, in order, above the section before it');
      row('↓ Move the section down',function(){
        var n=moveSection(run.id,1);
        if(n) toast(n+' slide'+(n===1?'':'s')+' moved as one');},
        'The whole run, in order, below the section after it');
      row('Duplicate the whole section',function(){
        var n=dupSection(run.id);
        if(n) toast(n+' slide'+(n===1?'':'s')+' copied into a new '
          +'section');},
        'A copy of every slide in it, under a new name — two runs '
        +'cannot share one section','copy');
      /* a SECTION default, which is what T23's "section transitions"
         asked for and had no substrate for until now */
      menuHead(m,'how its slides arrive'
        +(motionOK()?'':' — not on this machine'));
      TRANS.forEach(function(t){
        var m2=(pres.sections||{})[run.id]||{};
        var b=row(t[1],function(){setSectionTrans(run.id,t[0]);},t[2]);
        if((m2.trans||'')===t[0]) b.classList.add('on');
      });
      menuHead(m,'this section');
      row('Remove the divider',function(){removeSection(run.id,false);},
        'The slides stay — they join the section above','minus');
      row('Delete the section AND its '+run.n+' slide'
        +(run.n===1?'':'s'),function(){
          if(confirm('Delete '+run.n+' slide'+(run.n===1?'':'s')
            +' along with the section "'+run.name+'"?'))
            removeSection(run.id,true);
        },null,'exit');
      floatAt(m,ev);
      return;
    }
    var ar0=altRun(i),isAlt0=!!(ar0&&i>ar0.at);
    menuHead(m,poster?'this page':(isAlt0?'a version of slide '+slideNo(ar0.at)
      :'slide '+slideNo(i)));
    if(!poster){
      /* T318: the version verbs, on the thing being versioned */
      row('New version of this slide',function(){addVersion(i);},
        'A copy, kept under this slide as an alternative. The talk keeps '
        +'showing the starred one until you change that.','copy');
      if(isAlt0){
        row('\u2605 Make this the main version',function(){starVersion(i);},
          'The talk, the arrows and every export show this one instead',
          'star');
        row('Name this version\u2026',function(){
          var s2=pres.slides[i]; if(!s2) return;
          askText({title:'Name this version',value:s2.label||'',ok:'Name it'},
          function(v){
          if(v==null) return;
          v=v.trim();
          if(v) s2.label=v; else delete s2.label;
          markDirty();renderFilm();
          });
        },null,'pen');
        row('Make it a slide of its own',function(){
          var s3=pres.slides[i]; if(!s3) return;
          var moved=pres.slides.splice(i,1)[0];
          var to=ar0.at+ar0.n-1;
          delete moved.alt;
          pres.slides.splice(to,0,moved);
          cur=to;normSections();markDirty();refresh();
        },'Take it out of the group and put it after, as an ordinary slide');
      } else if(ar0){
        row((altOpen[ar0.gid]?'\u25be Hide':'\u25b8 Show')+' its '+(ar0.n-1)
          +' version'+(ar0.n===2?'':'s'),function(){
          if(altOpen[ar0.gid]) delete altOpen[ar0.gid]; else altOpen[ar0.gid]=1;
          renderFilm();
        });
      }
    }
    /* T413: MATCHING, WHERE THE THUMBNAILS ARE (2026-09-13, user: "What
       happened to the feature of matching slides"). The Design tab's
       "Match slide" door arms a click on a thumbnail; these are the same
       arming, on the thumbnail's own menu, so the feature is found from
       where the slides are. The slide you right-clicked is the one that
       takes, or gives, the layout. */
    if(!poster&&(pres.slides||[]).length>1){
      var goTo=function(){
        if(cur!==i){cur=i;activePane=-1;selAnnot=null;selSet=[];refresh();}
      };
      row('Match this slide to another\u2026',function(){
        goTo();armSlideMatch('from');},
        'Then click the thumbnail this slide should sit like. Positions '
        +'and sizes travel; the words and figures stay','swap');
      row('Give this slide\u2019s layout to slides I click\u2026',function(){
        goTo();armSlideMatch('to');},
        'Then click each thumbnail that should sit like this one; Esc '
        +'when you are done','swap');
    }
    if(!isAlt0) row('§ Start a section here',function(){newSection(i,'New section');},
      'Everything from here down to the next divider goes in it');
    var runs=sectionRuns().filter(function(r){return r.id;});
    if(runs.length){
      menuHead(m,'move this one into');
      runs.forEach(function(r){
        if(pres.slides[i]&&pres.slides[i].sec===r.id) return;
        row('→ '+r.name,function(){moveSlideToSection(i,r.id);});
      });
      if(pres.slides[i]&&pres.slides[i].sec)
        row('→ (no section)',function(){moveSlideToSection(i,'');});
    }
    /* OPTIONAL, and which versions this slide is in (T24). On the SLIDE
       menu because that is where you are looking when you decide a
       slide is a nice-to-have. */
    var oSl=pres.slides[i];
    /* HOW IT ARRIVES (T27). On the slide menu: a transition is a fact
       about one slide, and this is where you are looking at it.
       T399: ONE heading per group. There were three "this slide"
       headings, one of them directly above this one with nothing under
       it, and the menu inherited .sh-menu's three-column icon grid, so
       every label wrapped into a tile (2026-09-13, user: "the right
       click options on a slide look cursed"). */
    menuHead(m,'how it arrives'
      +(motionOK()?'':' — not on this machine'));
    var nowT=(oSl&&typeof oSl.trans==='string')?oSl.trans:null;
    var secM=(oSl&&oSl.sec)?((pres.sections||{})[oSl.sec]||null):null;
    TRANS.forEach(function(t){
      var b=row(t[1],function(){setTrans(i,t[0]);},t[2]);
      /* ticked on the slide's OWN answer. Outside a section there is
         nothing to inherit, so the effective one is its own. */
      var mine=(nowT===null)?(secM?null:transFor(i)):nowT;
      if(mine===t[0]) b.classList.add('on');
    });
    /* THE WAY BACK, which is why Cut had quietly been wired to mean both
       "arrive cut" and "stop overriding": there was no row for the
       second, so the falsy value did double duty and an explicit Cut
       inside a section was unreachable (T57). Offered only inside a
       section, the only place an override has anything to fall back
       to. */
    if(secM){
      var sd=(typeof secM.trans==='string')?secM.trans:'';
      var ub=row('Use the section default ('
        +transLabel(sd).toLowerCase()+')',
        function(){setTrans(i,null);},
        'Stop deciding it on this slide \u2014 \u201c'
        +(secM.name||'this section')+'\u201d decides');
      if(nowT===null) ub.classList.add('on');
    }
    var cuts=cutList();
    if(cuts.length){
      menuHead(m,'in these versions');
      cuts.forEach(function(c){
        var inIt=!!(oSl&&oSl.cuts&&oSl.cuts.indexOf(c.id)>=0);
        var none=!(oSl&&oSl.cuts&&oSl.cuts.length);
        row((inIt||none?'✓ ':'')+c.name,function(){
          toggleSlideCut(i,c.id);},
          none?'In every version, because it names none'
            :(inIt?'Remove it from this version'
              :'Add it to this version'));
      });
    }
    menuHead(m,poster?'this page':'this slide');
    row((oSl&&oSl.opt)?'✓ Optional':'Mark it optional',function(){
      toggleOptional(i);},
      'Running late in present mode skips the optional slides from '
      +'wherever you have got to','flag');
    row('Move it up',function(){moveSlide(i,-1);},null,'prev');
    row('Move it down',function(){moveSlide(i,1);},null,'next');
    if(pageOf().poster) row('Rename this version\u2026',function(){
      var s2=pres.slides[i]; if(!s2) return;
      askText({title:'Name this version',value:s2.label||slideTitle(s2),
        ok:'Rename'},function(v){
      if(v==null) return;
      v=v.trim();
      if(v) s2.label=v; else delete s2.label;
      markDirty();renderFilm();
      });
    },null,'pen');
    row('Duplicate',function(){dupSlide(i);},null,'copy');
    if(ar0&&!isAlt0)
      row('Delete it AND its '+(ar0.n-1)+' version'+(ar0.n===2?'':'s'),
        function(){
          if(confirm('Delete this slide and all '+(ar0.n-1)+' of its versions?')){
            pres.slides.splice(ar0.at,ar0.n);
            if(cur>=pres.slides.length) cur=Math.max(0,pres.slides.length-1);
            activePane=-1;normSections();markDirty();refresh();
          }
        },null,'exit');
    row(ar0&&!isAlt0?'Delete just this one (the next version becomes the main)'
      :'Delete',function(){delSlide(i);},null,'exit');
    floatAt(m,ev);
  }
  /* floatMenu positions against an element's rect; a context menu has
     only a point, so it is handed a zero-size one at the cursor */
  function floatAt(m,ev){
    document.body.appendChild(m);
    floatMenu({getBoundingClientRect:function(){
      return {left:ev.clientX,right:ev.clientX,
        top:ev.clientY,bottom:ev.clientY,width:0,height:0};
    }},m);
    /* outside click OR Escape (T137); both tear down both listeners */
    function off(e){
      if(m.contains(e.target)) return;
      shut();
    }
    function esc(e){
      if(e.key!=='Escape') return;
      e.preventDefault();e.stopPropagation();shut();
    }
    function shut(){
      m.remove();
      document.removeEventListener('click',off);
      document.removeEventListener('keydown',esc,true);
    }
    /* T482: IN CAPTURE, like the overlay owner's. In the bubble phase
       the editor's own ladder ran first on the same key -- Escape on a
       right-click menu dropped the selection, or left the editor, and
       only then closed the menu (2026-09-15 review). */
    setTimeout(function(){
      document.addEventListener('click',off);
      document.addEventListener('keydown',esc,true);
    },0);
  }
  function presNbs(p){
    var set={},order=[];
    (p&&p.slides||[]).forEach(function(s){
      (s.annots||[]).forEach(function(a){
        if(a.k==='cell'&&a.ref){
          var stem=splitRef(a.ref)[0];
          if(stem&&!set[stem]){set[stem]=1;order.push(stem);}
        }
      });
    });
    return order;
  }
  /* T381: NO NOTEBOOK BLOCK ABOVE THE THUMBNAILS. The column used to
     open with a "back to notebooks" header, one row per notebook, Refresh
     all and a More menu (2026-09-12, user: "the back to notebooks button
     shouldn't be there, this is now separate from notebooks; the notebook
     is still listed there; refresh all should be removed, now handled by
     the update button"). Refreshing is Home > Update; the three lock verbs
     live in that same menu; the notebooks rail is the way to a notebook.
     The column is the thumbnails and nothing else. */
  /* stem -> path resolves from an open shell, else a recent path with the
     same filename (paths only exist in the app + web builds); lockAllFrames
     needs it to ask git about a notebook */
  function pathStem(p){
    var s=String(p||''),parts=s.split(/[\/\\]/),nm=parts[parts.length-1]||s;
    nm=nm.split('?')[0].split('#')[0];
    try{nm=decodeURIComponent(nm);}catch(e){}
    return nm.replace(/\.ipynb$/i,'');
  }
  function nbPathFor(stem){
    var sh=APP.shells&&APP.shells[stem];
    if(sh&&sh.path) return sh.path;
    var rec=(APP.project&&APP.project.recent)||[];
    for(var i=0;i<rec.length;i++)
      if(pathStem(rec[i])===stem) return rec[i];
    return null;
  }
  /* ---- Lock all / Unlock all / prefetch locked versions ---- */
  function allCellAnnots(){
    var out=[];
    (pres.slides||[]).forEach(function(s){
      (s.annots||[]).forEach(function(a){
        if(a.k==='cell'&&a.ref) out.push(a);});});
    return out;
  }
  function lockAllFrames(){
    if(APP.mode!=='app'){toast('Locking needs the Junoview app');return;}
    var ann=allCellAnnots().filter(function(a){return !a.lockver;});
    if(!ann.length){toast('Every figure is already locked');return;}
    var byStem={};
    ann.forEach(function(a){
      var pr=splitRef(normRef(a.ref)||String(a.ref||''));
      if(pr[0]) (byStem[pr[0]]=byStem[pr[0]]||[]).push(a);
    });
    var stems=Object.keys(byStem),done=0,locked=0,norepo=0;
    if(!stems.length){toast('Nothing to lock');return;}
    stems.forEach(function(st){
      var path=nbPathFor(st);
      function fin(){
        if(++done!==stems.length) return;
        markDirty();refresh();
        toast(locked
          ?('Locked '+locked+' figure'+(locked===1?'':'s')
            +(norepo?' — '+norepo+' not in git':''))
          :'Nothing lockable — are the notebooks committed to git?');
      }
      if(!path||/^https?:/i.test(path)){
        norepo+=byStem[st].length;fin();return;}
      APP.api('/api/gitstate',{path:path}).then(function(g){
        if(g&&g.repo&&g.commit){
          byStem[st].forEach(function(a){
            a.lockver={commit:g.commit.id,msg:g.commit.msg||'',
              date:g.commit.date||''};
            locked++;
          });
        } else norepo+=byStem[st].length;
        fin();
      }).catch(fin);
    });
  }
  function unlockAllFrames(){
    var ann=allCellAnnots().filter(function(a){return a.lockver;});
    if(!ann.length){toast('No locked figures');return;}
    if(!window.confirm('Unlock all '+ann.length+' figure'
      +(ann.length===1?'':'s')+'? They will follow notebook refreshes '
      +'again — locked versions stop showing.')) return;
    ann.forEach(function(a){delete a.lockver;});
    markDirty();refresh();
    toast('Unlocked '+ann.length+' figure'+(ann.length===1?'':'s'));
  }
  function loadLockedVersions(){
    var groups={};
    allCellAnnots().forEach(function(a){
      if(!(a.lockver&&a.lockver.commit)) return;
      var lp=lockParts(a); if(!lp) return;
      (groups[lp.pkey]=groups[lp.pkey]||{path:lp.path,
        commit:a.lockver.commit,anchors:[]});
      if(groups[lp.pkey].anchors.indexOf(lp.anchor)<0)
        groups[lp.pkey].anchors.push(lp.anchor);
    });
    var keys=Object.keys(groups);
    if(!keys.length){toast('No locked figures to load');return;}
    var total=0;
    keys.forEach(function(k){total+=groups[k].anchors.length;});
    toast('Loading '+total+' locked figure'+(total===1?'':'s')
      +' from '+keys.length+' version'+(keys.length===1?'':'s')+'…');
    keys.forEach(function(k){
      fetchVerCards(groups[k].path,groups[k].commit,
        groups[k].anchors);});
  }
  /* ---- the Home tab's Slides group -----------------------------------
     The same four actions the thumbnail strip offers on hover, in the
     place you look for them when the strip is scrolled away from the
     current slide. They call the strip's own implementations, so there is
     one of each. */
  (function(){
    var b;
    b=$('#hm-newslide');
    if(b) b.addEventListener('click',function(){
      var add=$('#film-add'); if(add) add.click();});
    b=$('#hm-dupslide');
    if(b) b.addEventListener('click',function(){dupSlide(cur);});
    /* T318 */
    b=$('#hm-version');
    if(b) b.addEventListener('click',function(){addVersion(cur);});
    b=$('#hm-main');
    if(b) b.addEventListener('click',function(){starVersion(cur);});
    b=$('#hm-delslide');
    if(b) b.addEventListener('click',function(){delSlide(cur);});
    b=$('#hm-match');
    if(b) b.addEventListener('click',function(e){
      e.stopPropagation();openMatchMenu(this);});
  })();
  function renderCreate(){
    renderPresRow();renderControls();renderFilm();
    syncFurnBtns();   /* the furniture toggles show their own state */
  }
  function moveSlide(i,d){
    var j=i+d; if(j<0||j>=pres.slides.length) return;
    var t=pres.slides[i];pres.slides[i]=pres.slides[j];pres.slides[j]=t;
    if(cur===i)cur=j; else if(cur===j)cur=i;
    /* BOTH swapped slides take their section from the neighbour on their
       far side — the one OUTSIDE the pair. Without this, stepping a slide
       across a divider left its old tag behind, normSections dragged it
       back on the next pass, and the arrow button looked like it had done
       nothing at all (2026-08-22). */
    var far=function(at,dir){
      var nb=pres.slides[at+dir];
      return nb?((nb.sec)||''):null;
    };
    var sj=far(j,d),si=far(i,-d);
    if(sj!==null){if(sj) pres.slides[j].sec=sj; else delete pres.slides[j].sec;}
    if(si!==null){if(si) pres.slides[i].sec=si; else delete pres.slides[i].sec;}
    normSections();markDirty();refresh();
  }
  function delSlide(i){
    /* T318: deleting a main promotes the next version; a group left
       with one member dissolves in normAlts. Say so. */
    var ar=altRun(i);
    if(ar&&i===ar.at&&ar.n>1){
      var nx=pres.slides[i+1];
      toast('\u201c'+(nx.label||'Version 2')+'\u201d is the main version now');
    }
    pres.slides.splice(i,1);
    if(cur>=pres.slides.length) cur=Math.max(0,pres.slides.length-1);
    activePane=-1;
    normSections();markDirty();refresh();
  }
  /* duplicate in place — decks never had this at all (2026-08-19, user:
     "still no duplicate slide"); a poster's copy becomes a named version
     like "+ Create new version" makes */
  function dupSlide(i){
    var s=pres.slides[i]; if(!s) return;
    var cp=deep(s);
    if(pageOf().poster) cp.label=nextVersionName();
    else delete cp.label;
    /* T318: Duplicate never grows a group -- New version is the verb
       that does. The copy is an ordinary slide placed after the whole
       group, or it would land inside the run and become a version. */
    delete cp.alt;delete cp.sid;
    var ar=altRun(i);
    var at=ar?(ar.at+ar.n):(i+1);
    pres.slides.splice(at,0,cp);
    cur=at;activePane=-1;selAnnot=null;selSet=[];
    normSections();markDirty();refresh();
  }

  /* ---------- mode switching ---------- */
  /* ---- edit mode borrows the FILE controls into the ribbon
     (2026-08-05, user: the docked column "basically just feels like
     having the File button open all the time"). The real nodes MOVE —
     every existing handler and menu keeps working — and move back when
     create mode needs the panel again. With its head gone the panel is
     just the slide strip, and posters (one page, no slides) drop the
     panel entirely. ---- */
  /* fileToRibbon / fileToPanel are GONE (2026-08-19): the document
     actions used to be borrowed into the ribbon's File group while
     editing and restored on leaving. They live permanently in the left
     column now — Notebooks, then File/Save/undo/redo and the save
     readout, then the thumbnails — so there is nothing to borrow and
     nothing to restore, and the whole class of "moved node lost its
     styling/anchor" bugs goes with the machinery. */
  function syncTopBar(){
    var dt=$('.deck-top',deckEl);
    /* Row 1 of the deck holds exactly one bar. Presenting gets .deck-top,
       which is only a way out; editing and building get .deck-qat, which
       is the document's own controls — File, Save, undo/redo, the name,
       Find, zoom, Present (2026-08-20). Never both. */
    var qat=$('#deck-qat',deckEl);
    var editing=(mode==='edit'||mode==='create');
    if(dt) dt.hidden=editing;
    if(qat) qat.hidden=!editing;
    /* the first moment the bar has a real width to be judged against */
    if(editing) requestAnimationFrame(fitQat);
    var tabs=$('#rbn-tabs',deckEl);
    if(tabs) tabs.hidden=(mode!=='edit');
    var xb=$('#deck-exit');
    if(xb){
      /* This bar is shown only while presenting. Keeping its wording fixed
         means it cannot briefly describe a different, destructive-sounding
         action while the editor changes mode. */
      xb.innerHTML=bic('return')+' Stop presenting';
      xb.title='Stop presenting and go back to the builder (Esc). Nothing '
        +'is closed or lost.';
    }
    syncLateButton();
    if(typeof renderDeckPresentationDrawer==='function')
      renderDeckPresentationDrawer();
  }
  function setUIMode(m){
    var startingTalk=(m==='view'&&mode!=='view');
    var endingTalk=(m!=='view'&&mode==='view');
    /* Running late belongs to ONE run. A named version survives the run,
       but its first audience slide must actually belong to it (T50). */
    if(startingTalk){
      lateFrom=-1;
      if(slideSkipped(cur)){
        var to=nextShown(cur,1);
        if(to<0) to=nextShown(cur,-1);
        if(to>=0) cur=to;
        else {
          var emptyName=(cutMap()[activeCut()]||{}).name||'version';
          showCut='';
          toast('“'+emptyName+'” has no slides — showing every slide');
        }
      }
    }
    /* entering Present must not leave a fresher deck in memory than in
       the draft — the debounced write lands before the talk starts */
    if(m==='view') flushDraftWrite();
    /* a rehearsal is exactly "present mode, from when it starts to when
       it ends" -- so it begins and ends where the mode does (T29) */
    if(startingTalk){
      rehStart();
      /* T285: and the presenter's own clock, which is a different
         number from the rehearsal's and was starting too early */
      if(typeof presTimerStart==='function') presTimerStart();
    }
    else if(endingTalk){
      rehStop();lateFrom=-1;
      /* the panel belongs to the run; the SETTINGS survive it, because a
         projector does not change between runs (T88) */
      var tp=$('#talkpane');
      if(tp) tp.hidden=true;
      var tbn=$('#talkbtn');
      if(tbn) tbn.setAttribute('aria-expanded','false');
    }
    mode=m;
    /* T471: Quick animate is an editor mode; leaving the editor ends it */
    if(m!=='edit'&&typeof seqOn==='function'&&seqOn()) seqEnd(true);
    /* T491: the Story strip is the editor's; the show's stage is not
       its to watch (it re-rendered the strip on every click of the
       show, and its zoom leaked into the show -- third review pass) */
    if(m!=='edit'&&typeof storyOpen==='function'&&storyOpen()
       &&typeof storyShow==='function') storyShow(false);
    if(m!=='view'&&typeof closeDeckPresentationDrawer==='function')
      closeDeckPresentationDrawer();
    if(m!=='view'&&typeof talkToolsReset==='function') talkToolsReset();
    var creating=(m==='create'), editing=(m==='edit');
    deckEl.classList.toggle('creating',creating);
    deckEl.classList.toggle('editing',editing);
    /* nothing moves any more: the document actions LIVE in the left
       column in every mode (2026-08-19) */
    /* the builder panel stays visible while editing a slide */
    $('#deck-create').hidden=!(creating||editing);
    var et=$('#edit-tools'); if(et) et.hidden=!editing;
    if(editing){
      applyTab();
      /* the folded state is remembered per project, like the tab */
      if(!deckEl._foldInit){
        deckEl._foldInit=1;
        setRibbonFold(lsGet(FOLDKEY2+SCOPE)==='1');
        /* the two auto-hides are remembered the same way and come back in
           the same place, so there is ONE moment where the editor's
           remembered chrome state is restored -- and it is the first
           moment the ribbon and the column have real geometry to be
           measured against. Order matters: the ribbon first, because
           setFilmAuto ends by re-fitting it. */
        setRibbonAuto(lsGet(RBNAUTOKEY+SCOPE)==='1');
        setFilmAuto(lsGet(FILMAUTOKEY+SCOPE)==='1');
      }
    }
    /* The top bar earns its row or it does not appear. While editing it
       is only needed by a POSTER, which has no panel and therefore keeps
       File and Save up here; a presentation keeps them in the panel head,
       leaving the bar with nothing but a redundant button and a whole row
       of wasted height (2026-08-07). fileToRibbon has already run, so the
       slot's contents are the honest test. */
    syncTopBar();
    document.body.classList.toggle('creating-docs',
      (creating||editing)&&!deckEl.hidden);
    document.body.classList.toggle('slide-editing',
      editing&&!deckEl.hidden);
    var full=!creating&&!deckEl.hidden;
    document.body.classList.toggle('deck-open',full);
    /* the same condition as the class, so the two can never disagree
       about whether this is a full-screen surface (T104) */
    deckIsolate(full);
    if(full) deckTakeFocus();
    selAnnot=null;selSet=[];
    if(m==='view') revealCount=0;   /* start the build sequence fresh */
    if(!editing){                   /* Objects pane is an editing tool */
      var sp=$('#selpane'); if(sp) sp.hidden=true;
      var ob=$('#objects-btn');
      if(ob) ob.setAttribute('aria-pressed','false');
      /* Notes are an editing pane too. Leaving it open put the pane over
         the audience's slide after the ribbon disappeared (T48). */
      var np=$('#notespane'); if(np) np.hidden=true;
      var nb=$('#notes-btn');
      if(nb) nb.setAttribute('aria-pressed','false');
      /* ...and so is the Versions pane. Put the strip back where the
         builder expects to find it before the builder renders. */
      showVerpane(false);
      animPaneClose();
      filmToPanel();
      rbnGalleryClose();
      /* MutationObserver catches every ordinary pane toggle, but it is
         asynchronous; presenting must fit the page before this turn's
         render/fullscreen work starts. */
      syncPaneDock();
    }
    /* A custom layout may have moved contextual controls out of #et-fmt,
       so hiding that one holder cannot reset the ribbon. showFmt owns the
       complete list and now sees the cleared selection above. */
    showFmt();
    if(editing) setTool('select');
    /* real full screen while presenting (browser chrome gone) */
    try{
      if(m==='view'&&!deckEl.hidden&&fullTarget().requestFullscreen
         &&!document.fullscreenElement)
        fullTarget().requestFullscreen().catch(function(){});
      /* ...but full-screen EDITING is deliberate, not a leftover from
         presenting: leaving it alone here is what lets a poster be edited
         full screen at all (every mode re-apply would otherwise drop it) */
      else if(m!=='view'&&document.fullscreenElement&&!editFull)
        document.exitFullscreen().catch(function(){});
    }catch(err){}
    if(m!=='edit'&&editFull){
      editFull=false;deckEl.classList.remove('editfull');
      try{if(document.fullscreenElement)
        document.exitFullscreen().catch(function(){});}catch(err2){}
    }
    applySideRibbon();
    syncViewBtns();
    /* entering edit mode is the first moment the ribbon has a real width
       -- and therefore the first moment the strip's ceiling can be
       measured. A width restored from localStorage is clamped by
       --film-max here rather than eating the row on open (T80) */
    if(m==='edit') requestAnimationFrame(function(){
      fitFilmMax();fitEditRibbon();});
    if(creating||editing){
      activePane=-1;
      renderCreate();
    }
    if(!creating) renderSlide();
    /* the bar's title depends on the mode, and openDeck calls status()
       BEFORE the mode is set — so it is refreshed once more here */
    status();
    if(startingTalk||endingTalk) presenterSync();
  }
  function refresh(){
    if(mode==='create'){renderCreate();}
    else if(mode==='edit'){renderCreate();renderSlide();}
    else renderSlide();
  }
  function routeSync(){
    if(window.SemApp&&window.SemApp.updateHash) window.SemApp.updateHash();
  }
  /* ---- BACKGROUND ISOLATION -------------------------------------
     The deck is `position:fixed` over the whole window, and CSS had
     already isolated the three channels CSS can: the background does
     not scroll (`body.deck-open{overflow:hidden}`), it cannot be
     clicked through (an opaque z-index:100 surface) and the app's top
     bar leaves the tab order while editing. What CSS cannot do is the
     fourth channel, and `inert` is not a CSS property: the notebook
     underneath stayed in the accessibility tree and in the TAB ORDER.
     So Tab walked off the editor into a document nobody could see --
     around 12,670px of it -- and a screen reader met two applications
     at once, one of them invisible (2026-08-30 review).

     Named surfaces rather than "every child of body except the deck".
     The deck reaches OUT to page-level overlays -- Help, the open
     dialog, the figure lightbox, its own floating menus -- and a sweep
     would take those with it and break them. These eight are the
     document application behind the deck and nothing else.

     MODE-AWARE. `creating` is a side panel, not a full-screen surface:
     the notebook beside it is a live drag source, by design, and
     isolating it would break a shipped gesture. So this follows
     `deck-open`, which is already exactly "not creating". */
  var DECK_BEHIND = ['#apptop', '#presrail', '#presrail-show', '#docs',
    '#welcome', '#present-bar', '#present-bar-show', '#stylepanel'];
  var deckInerted = [];
  var deckFocusReturn = null;

  function deckIsolate(on){
    if(on){
      if(deckInerted.length) return;          /* already isolated */
      DECK_BEHIND.forEach(function(sel){
        var el=$(sel);
        /* something already inert is inert for its own reason, and
           un-inerting it on close would be this feature breaking
           another one */
        if(!el||el.hasAttribute('inert')) return;
        el.setAttribute('inert','');
        el.setAttribute('aria-hidden','true');
        deckInerted.push(el);
      });
      return;
    }
    deckInerted.forEach(function(el){
      el.removeAttribute('inert');
      el.removeAttribute('aria-hidden');
    });
    deckInerted=[];
  }

  /* Focus has to GO somewhere when the background stops accepting it,
     or it stays on a control that is now inert and the next Tab starts
     from the top of the document. And it has to come back, or closing
     the editor leaves the page focused on nothing. */
  function deckTakeFocus(){
    var live=document.activeElement;
    if(live&&live!==document.body&&!deckEl.contains(live))
      deckFocusReturn=live;
    if(deckEl.contains(document.activeElement)) return;
    /* the first VISIBLE control, not the first in the markup. The deck
       carries a dozen panels that are hidden most of the time, and
       focusing something inside a display:none subtree silently does
       nothing -- which looks exactly like this function not running. */
    var cand=deckEl.querySelectorAll(
      'button:not([disabled]),[href],input:not([disabled]),'
      +'select:not([disabled]),textarea:not([disabled]),[tabindex]');
    for(var i=0;i<cand.length;i++){
      var el=cand[i];
      if(el.hidden||el.offsetParent===null) continue;
      try{el.focus();}catch(err){continue;}
      if(document.activeElement===el) return;
    }
    /* nothing focusable yet (the ribbon builds on first render), so the
       surface itself takes it -- which is what keeps Tab inside */
    if(!deckEl.hasAttribute('tabindex')) deckEl.setAttribute('tabindex','-1');
    try{deckEl.focus();}catch(err){}
  }
  function deckReturnFocus(){
    var back=deckFocusReturn;
    deckFocusReturn=null;
    if(!back||!back.isConnected||back.hasAttribute('inert')) return;
    try{back.focus();}catch(err){}
  }
  /* T465: openDeck(m, resume) -- `resume` is the notebook picker's way
     back: the deck was hidden for a trip to the notebook, not closed,
     so it is the SAME editing session and the undo stack survives.
     Every trip through the picker (including Escape and Cancel) used
     to wipe it -- draw a frame, pick a figure, and Ctrl+Z did nothing
     (2026-09-15 review, driven). */
  function openDeck(m,resume){
    deckEl.hidden=false;
    if(pres&&typeof notePresentationOpen==='function')
      notePresentationOpen(pres.name);
    if(!resume){
      histReset();   /* undo history starts fresh per editing session */
      /* ONE ON ARRIVAL, so "how it was when I sat down" is always
         reachable -- the same rule the notebook's own snapshots follow,
         and deduped, so opening and closing without touching anything
         costs nothing (T32) */
      /* the opening snapshot waits for the stored head pointer, so a
         reload's first entry descends from where you actually were
         rather than founding a new root (T127) */
      snapTake('opened',undefined,histSeed());
    }
    status();
    setUIMode(m||'view');
    routeSync();
    /* the welcome screen can now be showing WITH the deck opening over
       it (its presentations column, or Home with nothing else open), so
       the chrome has to be told a deck exists (2026-08-21) */
    if(APP.refreshChrome) APP.refreshChrome();
  }
  /* WHAT GOES OUT. A poster is one page: its other pages are drafts and
     variants, and you send one to the print shop, not the pile. Since
     "+ Create new version" makes those easy to accumulate, exporting all
     of them would quietly turn one A0 into three (2026-08-10). A deck's
     slides ARE the deck, so they all go. */
  function outputSlides(){
    var all=[];
    (pres.slides||[]).forEach(function(s,i){
      /* T318: exports show the main version only. This list never
         consulted slideSkipped -- deliberately, so a rehearsal cut does
         not silently trim a PDF -- so the deck-state half of the test
         is asked here directly. */
      if(slideIsAlt(i)) return;
      /* A FLIP BOOK EXPLODES ON THE WAY OUT. This is the whole payoff:
         the complaint was "heaps of new slides each with a new figure",
         so the editor keeps ONE slide with the figures stacked inside it
         and the exporter builds the pile — six frames become six real
         PowerPoint slides, each with the items tied to that frame and
         nothing else (2026-08-22).
         The FIRST flip book on the slide is the one that explodes it.
         Two of them multiplying into a grid of pages is nobody's
         intention, and the second simply rests on its own frame. */
      /* THE SLIDE'S BOOK, not merely its first flip book (T165): a
         slide whose only book is made of words explodes too, or four
         fifths of its text would leave the building silently. And a
         flip book with words walking beside it explodes over its WALK,
         so figure 2's three paragraphs are three output pages rather
         than one page showing the last of them. */
      var walk=bookWalk(s);
      if(walk.length>1){
        for(var f=0;f<walk.length;f++) all.push({s:s,i:i,f:f});
        return;
      }
      all.push({s:s,i:i,f:null});
    });
    if(!pageOf().poster||all.length<2) return all;
    var k=0;
    all.forEach(function(e,j){if(e.i===cur&&!k) k=j;});
    return all[k]?[all[k]]:all;
  }
  /* named for the toast, so it is never a silent choice */
  function outputNote(){
    var all=(pres.slides||[]).length;
    if(!pageOf().poster||all<2) return '';
    var s=pres.slides[Math.min(Math.max(cur,0),all-1)];
    return ' Sent "'+((s&&s.label)||slideTitle(s||{}))+'" only — a poster '
      +'goes out one version at a time; open Versions to switch.';
  }
  function closeDeck(){
    /* SPA navigation does not fire pagehide. Home/hash routing can close
       this surface directly, so it is just as real an end to a rehearsal
       as the visible Stop presenting button (T48). */
    if(mode==='view') rehStop();
    try{
      if(document.fullscreenElement)
        document.exitFullscreen().catch(function(){});
    }catch(err){}
    closeVFull();
    if(typeof closeDeckPresentationDrawer==='function')
      closeDeckPresentationDrawer();
    rbnGalleryClose();
    showVerpane(false);filmToPanel();   /* the strip goes home */
    deckEl.hidden=true;
    document.body.classList.remove('deck-open');
    deckIsolate(false);
    deckReturnFocus();
    document.body.classList.remove('creating-docs');
    document.body.classList.remove('slide-editing');
    deckEl.classList.remove('creating');
    deckEl.classList.remove('editing');
    renderPresTabs();
    routeSync();
    /* ...and told when it stops existing: closing the last deck with no
       notebook open has to land back on the welcome, not a blank page */
    if(APP.refreshChrome) APP.refreshChrome();
  }
  /* ---- URL routing hooks used by the SemApp router (docs side) ---- */
  /* T482: the app bar's Theme menu opens over the deck's own menus and
     must close them first (app.js) */
  window.SemApp.deckOverlayCloseAll=function(){
    if(typeof overlayCloseAll==='function') overlayCloseAll();};
  window.SemApp.deckState=function(){
    return deckEl.hidden?null:{name:pres.name,slide:cur};
  };
  window.SemApp.deckClose=function(){closeDeck();};
  /* ---- what the welcome screen lists ---------------------------------
     The presentations rail is not the only door any more: it collapses,
     and once it was away the front door had no route to a deck at all
     (2026-08-21, user: "you can't get to the presentations from here
     either"). Same source of truth as the rail's own rows. */
  window.SemApp.deckNames=function(){
    var out=[],seen={},saved=allSaved(),savedNames={};
    saved.forEach(function(p){savedNames[p.name]=1;});
    function push(nm,p,draft){
      if(!nm||seen[nm]) return;
      seen[nm]=1;
      out.push({name:nm,
        slides:(((p||{}).slides)||[]).length,
        poster:/^a\d/.test(String((p||{}).page||'')),
        view:isViewPres(p||{}),
        folder:(p||{}).folder||'',
        draft:!!draft});
    }
    saved.forEach(function(p){push(p.name,p,false);});
    draftNames().forEach(function(nm){
      push(nm,loadDraft(nm)||{},!savedNames[nm]);});
    return out;
  };
  /* opening one is the rail's own action, so a deck, a poster and a
     custom view each land where they belong */
  window.SemApp.deckChoose=function(nm){choosePresentation(nm);};
  /* a presentation needs no notebook: every tool except the cell frame
     works on an empty deck, so the front door can offer this as a way
     IN rather than as something you reach after opening a notebook
     (2026-08-22, user: "you can really only create a presentation once
     you have a notebook open"). */
  window.SemApp.deckNew=function(){newPresentation();};
  /* T282: the front door's Posters section needs the same door the rail
     has, and the rail collapses. Same shape as deckNew. */
  window.SemApp.deckNewPoster=function(){newPoster();};
  /* (the chrome redraw for these hooks runs from THE BOOT SEQUENCE) */
  window.SemApp.deckGo=function(slide){   /* move slide, keep the current mode */
    if(deckEl.hidden) return;
    go(Math.max(0,Math.min(((pres.slides||[]).length||1)-1,slide||0)));
  };
  window.SemApp.deckOpen=function(name,slide){
    if(!name) return false;
    if(pres.name!==name){
      if(!(savedByName(name)||loadDraft(name))) return false;
      lsSet(PFX+'last',name);
      loadPresentation(name);
      activePane=-1;
    }
    cur=0;
    if(typeof slide==='number'&&slide>0)
      cur=Math.max(0,Math.min(((pres.slides||[]).length||1)-1,slide));
    openDeck('edit');
    return true;
  };
  /* wrap so the click Event isn't forwarded (closeDeck takes no args) */
  var prDocs=document.getElementById('pr-docs');
  if(prDocs) prDocs.addEventListener('click',function(){closeDeck();});
  var prNew=document.getElementById('pr-new');
  if(prNew) prNew.addEventListener('click',newPresentation);
  var prNewPost=document.getElementById('pr-newpost');
  if(prNewPost) prNewPost.addEventListener('click',newPoster);
  var prNewView=document.getElementById('pr-newview');
  if(prNewView) prNewView.addEventListener('click',newCustomView);
  var sbDone=document.getElementById('sb-done');
  if(sbDone) sbDone.addEventListener('click',closeCustomView);
  $('#pres-current').addEventListener('click',function(){
    var inp=$('#pres-name');
    this.hidden=true;
    inp.hidden=false;inp.value=pres.name;
    inp.focus();inp.select();
  });
  var presentFrom='create';
  /* T477: one sync for the Play menu's version rows and the Present
     tab's strip; published because renameCut in another part and
     renderFilm need it. Declared BEFORE the menu's sub-IIFE below,
     which assigns it at script evaluation -- a `var` stub after it
     would overwrite the assignment (driven: the strip never followed). */
  var cutsSync=function(){};
  /* ---- the Present menu ------------------------------------------------
     Play from here, play from the start, or open the presenter view first
     and then play. Presenter view deliberately does NOT start playback:
     you want to drag the window to the other screen before anything goes
     full screen (2026-08-20). */
  (function(){
    var wrap=$('#dc-playmore'),menu=$('#play-menu');
    if(!wrap||!menu) return;
    wrap.addEventListener('click',function(e){
      e.stopPropagation();
      /* the one owner (T135): the outside click that used to live here
         forgot aria-expanded, which is the stale state JVUX-02 caught */
      if(menu.hidden){overlayShow(wrap,menu);floatMenu(wrap,menu);}
      else overlayHide(menu);
    });
    function mi(id,fn){
      var b=$(id);
      if(b) b.addEventListener('click',function(e){
        e.stopPropagation();overlayHide(menu);fn();});
    }
    /* WHICH VERSION (T24). Built rather than written into the markup
       because the list is the deck's, and a deck with no cuts must show
       nothing at all here. Running late is in the presenter bar: an
       edit-only menu was the one place it could not work mid-talk. */
    function syncCuts(){
      $$('.pl-cut',menu).forEach(function(n){n.remove();});
      var list=cutList();
      var selected=activeCut();
      var anchor=$('#pl-here');
      if(!anchor||!anchor.parentNode) return;
      function add(el){
        el.classList.add('pl-cut');
        menu.insertBefore(el,anchor);
      }
      var hd=document.createElement('div');
      hd.className='hd-lab';hd.textContent='which version';
      add(hd);
      function opt(id,label,why){
        var b=document.createElement('button');
        b.className='dbtn dc-mi';
        b.textContent=label;
        if(why) b.title=why;
        b.setAttribute('aria-pressed',(selected===id).toString());
        b.addEventListener('click',function(e){
          e.stopPropagation();overlayHide(menu);setCut(id);syncCuts();});
        add(b);
      }
      opt('','Every slide','The whole deck, which is what a deck with '
        +'no cuts always shows');
      list.forEach(function(c){
        var box=document.createElement('div');
        box.className='pl-cutrow';box.dataset.cut=c.id;
        var choose=document.createElement('button');
        choose.className='dbtn dc-mi pl-cutpick';
        choose.textContent=c.name;
        choose.title='Only the slides that name this version';
        choose.setAttribute('aria-pressed',(selected===c.id).toString());
        choose.addEventListener('click',function(e){
          e.stopPropagation();overlayHide(menu);setCut(c.id);syncCuts();});
        box.appendChild(choose);
        [[bic('pen'),'Rename',function(){return renameCut(c.id);}],
         [bic('exit'),'Delete',function(){return delCut(c.id);}]]
          .forEach(function(p){
            var b=document.createElement('button');
            b.className='dbtn pl-cutact';
            b.innerHTML=p[0]+' ';
            b.appendChild(document.createTextNode(p[1]));
            b.title=p[1]+' the “'+c.name+'” version';
            b.addEventListener('click',function(e){
              e.stopPropagation();if(p[2]()) syncCuts();});
            box.appendChild(b);
          });
        add(box);
      });
      var nb=document.createElement('button');
      nb.className='dbtn dc-mi';
      nb.textContent='New version…';
      nb.title='Name a shorter cut of this same deck — no second '
        +'file, no diverging copies';
      nb.addEventListener('click',function(e){
        e.stopPropagation();overlayHide(menu);
        askText({title:'A new version of this deck',label:'Call it',
          value:'20-min',ok:'Make it',note:'Then right-click a slide to '
            +'put it in'},function(nm){
        if(nm==null) return;
        nm=nm.trim();if(!nm) return;
        var id=newCut(nm);if(!id) return;
        toast('“'+nm+'” created — right-click a '
          +'slide to put it in');
        setCut(id);syncCuts();
        });
      });
      add(nb);
      var sep=document.createElement('div');
      sep.className='hd-lab';sep.textContent='play';
      add(sep);
    }
    wrap.addEventListener('click',syncCuts);
    /* T477: THE STRIP ON THE PRESENT TAB, from the same list. One
       published sync redraws both, so a rename from the menu, a New
       version… from the tab, or a cut chosen anywhere lands on both. */
    function versionStripSync(){
      var strip=$('#pr-version-strip'); if(!strip) return;
      var list=cutList(),selected=activeCut();
      /* rebuilt only when the answer changed: renderFilm calls this on
         every slide change and the tiles are a chooser's, not a film's */
      var sig=JSON.stringify(list)+'|'+selected;
      if(strip.getAttribute('data-sig')===sig) return;
      strip.setAttribute('data-sig',sig);
      strip.innerHTML='';
      function tile(id,label,tip){
        var b=document.createElement('button');
        b.type='button';b.className='fx-tile';
        b.innerHTML=bic(id?'versions':'present')+'<span>'+esc(label)+'</span>';
        b.title=tip;
        b.setAttribute('aria-pressed',(selected===id).toString());
        b.addEventListener('click',function(e){
          e.stopPropagation();setCut(id);cutsSync();});
        strip.appendChild(b);
      }
      tile('','Every slide','The whole deck, which is what a deck with '
        +'no versions always shows');
      list.forEach(function(c){
        tile(c.id,c.name,'Only the slides that name this version. '
          +'Rename or delete it from the Present menu');
      });
    }
    cutsSync=function(){syncCuts();versionStripSync();};
    var nvb=$('#pr-newversion');
    if(nvb) nvb.addEventListener('click',function(e){
      e.stopPropagation();
      askText({title:'A new version of this deck',label:'Call it',
        value:'20-min',ok:'Make it',note:'Then right-click a slide to '
          +'put it in'},function(nm){
        if(nm==null) return;
        nm=nm.trim();if(!nm) return;
        var id=newCut(nm);if(!id) return;
        toast('\u201c'+nm+'\u201d created \u2014 right-click a slide to put it in');
        setCut(id);cutsSync();
      });
    });
    versionStripSync();
    mi('#pl-here',function(){$('#dc-play').click();});
    mi('#pl-start',function(){cur=0;refresh();$('#dc-play').click();});
    mi('#pl-presenter',openPresenter);
    mi('#pl-notes',function(){
      if(window.SemDeckNotes) window.SemDeckNotes();});
    /* present from here WITH the panel open: the panel's corner button
       only exists once you are already presenting, so the menu is where
       the decision actually gets made (T126) */
    mi('#pl-talk',function(){
      $('#dc-play').click();
      setTimeout(function(){
        if(window.SemDeckTalk) window.SemDeckTalk.open(true);},200);});
    function syncTap(){
      var b=$('#pl-tap'); if(!b) return;
      b.textContent='Click a figure to enlarge it: '
        +(pres&&pres.tapzoom?'on':'off');
      b.title=pres&&pres.tapzoom
        ?'Clicking an item during the talk blows it up. Clicking anywhere '
          +'else still moves you on.'
        :'Off: a click anywhere moves the talk on, and Alt+click (or Z) '
          +'blows up whatever is under the pointer.';
    }
    mi('#pl-tap',function(){
      if(pres.tapzoom) delete pres.tapzoom; else pres.tapzoom=1;
      markDirty();syncTap();
      toast(pres.tapzoom
        ?'Clicking a figure or a text box now enlarges it while presenting'
        :'Back to a plain click moving the talk on');
    });
    /* THE CODE TRAIL DOOR (T69). ONE flag suppresses the trail, the
       "Show code" pill, the up/down arrows and the scroll region
       together, because updateVNav shows the pill purely from whether a
       .vtrace node exists and renderSlide is the only thing that ever
       builds one -- so the gate goes there and nothing else has to know.
       Stored as hideTrace (SUPPRESSION) rather than showTrace, so every
       deck already saved keeps the trail it has with no migration. */
    function syncTrace(){
      var b=$('#pl-trace'); if(!b) return;
      b.textContent='Show the code trail under the slide: '
        +(pres&&pres.hideTrace?'off':'on');
      b.title=pres&&pres.hideTrace
        ?'Off: the slide is the whole screen and nothing scrolls under '
          +'it. The lineage is still there in the notebook.'
        :'On: the cells that made each figure sit under the slide -- '
          +'scroll, or press the Show code pill, to reach them.';
    }
    mi('#pl-trace',function(){
      if(pres.hideTrace) delete pres.hideTrace; else pres.hideTrace=1;
      markDirty();syncTrace();
      /* the menu lives in the builder chrome, so this is normally set
         between talks -- but re-render if it somehow fires mid-talk */
      if(mode==='view') renderSlide();
      toast(pres.hideTrace
        ?'The code trail is hidden while presenting'
        :'The code trail is back under every slide');
    });
    var plBtn=$('#dc-playmore');
    if(plBtn) plBtn.addEventListener('click',function(){
      syncTap();syncTrace();});
    syncTap();syncTrace();
  })();
  $('#dc-play').addEventListener('click',function(){
    presentFrom=mode;setUIMode('view');});
  var undoBtn=$('#dc-undo');
  if(undoBtn) undoBtn.addEventListener('click',undo);
  var redoBtn=$('#dc-redo');
  if(redoBtn) redoBtn.addEventListener('click',redo);
  $('#deck-exit').addEventListener('click',function(){
    setUIMode(presentFrom==='edit'?'edit':'create');});
  $('#deck-prev').addEventListener('click',function(){backStep();});
  $('#deck-next').addEventListener('click',function(){advance();});
  /* click the letterbox AROUND the slide to clear the selection (clicks on
     the canvas itself are already handled by the annot-layer). Scoped to the
     stage element only, so it never fights a fresh text/arrow placement. */
  if(stage) stage.addEventListener('mousedown',function(ev){
    if(mode!=='edit'||tool!=='select'||ev.target!==stage) return;
    var l=stage.querySelector('.annot-layer');
    if(l) selectAnnot(l,null);
  });
  /* ONE mode toggle: swaps between the slide editor and the notebook view */
  var editBtn=$('#dc-edit');
  if(editBtn) editBtn.addEventListener('click',function(){
    /* "Swap to notebooks" now actually goes to the notebooks. It used to
       run setUIMode('create'), landing you in the presentation BUILDER —
       slide layouts, slide strip, the lot — which is not where the label
       said you were going and is meaningless for a poster (2026-08-07,
       user: "it takes you to the view for presentations"). */
    if(mode==='edit') closeDeck();
    else if(pres.slides[cur]) setUIMode('edit');
  });
  var cxBtn=$('#et-cancel');
  if(cxBtn) cxBtn.addEventListener('click',function(){setTool('select');});
  $$('#edit-tools .et').forEach(function(b){
    /* pressing an armed tool again is the second way out, and the one
       people try first */
    b.addEventListener('click',function(){
      setTool(tool===b.dataset.tool?'select':b.dataset.tool);});
  });
  /* ---- "+ Shapes" dropdown: choose a shape, then draw it ---- */
  function shapeIcon(shp){
    var svg=document.createElementNS(SVGNS,'svg');
    svg.setAttribute('class','sh-ico');svg.setAttribute('viewBox','0 0 100 100');
    if(shp==='rect'){
      var rc=document.createElementNS(SVGNS,'rect');
      rc.setAttribute('x','12');rc.setAttribute('y','22');
      rc.setAttribute('width','76');rc.setAttribute('height','56');
      rc.setAttribute('rx','7');rc.setAttribute('fill','#c9d6e2');
      svg.appendChild(rc);
    } else if(shp==='ellipse'){
      var el=document.createElementNS(SVGNS,'ellipse');
      el.setAttribute('cx','50');el.setAttribute('cy','50');
      el.setAttribute('rx','42');el.setAttribute('ry','33');
      el.setAttribute('fill','#c9d6e2');svg.appendChild(el);
    } else if(SHAPE_GLYPH[shp]){
      var tx=document.createElementNS(SVGNS,'text');
      tx.setAttribute('x','50');tx.setAttribute('y','56');
      tx.setAttribute('text-anchor','middle');
      tx.setAttribute('dominant-baseline','central');
      tx.setAttribute('font-size','98');tx.setAttribute('font-weight','800');
      tx.setAttribute('fill','#c9d6e2');tx.textContent=SHAPE_GLYPH[shp];
      svg.appendChild(tx);
    } else {
      var p=document.createElementNS(SVGNS,'path');
      p.setAttribute('d',SHAPE_PATHS[shp]||'');
      if(SHAPE_OPEN[shp]){
        /* T419: drawn as the stroke it is */
        p.setAttribute('fill','none');p.setAttribute('stroke','#c9d6e2');
        p.setAttribute('stroke-width','9');
        p.setAttribute('stroke-linecap','round');
        p.setAttribute('stroke-linejoin','round');
      } else p.setAttribute('fill','#c9d6e2');
      svg.appendChild(p);
    }
    return svg;
  }
  /* ---- THE SHAPE STRIP (T197) ------------------------------------------
     Fifteen shapes as tiles in the row, each drawn by the same shapeIcon
     the Object tab's Shape menu uses, so the two cannot look like
     different features. Click one and the shape tool arms for it; the
     tile stays lit while it is armed; click it again to put the tool
     down. It replaces the Shape door ("the shapes should be on their
     own", 2026-09-02). */
  var shapeStripSync=function(){};
  /* ---- THE STRIP FRAME'S DOOR (T203) ----------------------------------
     Every tile strip sits in a frame with a chevron at its end. The
     chevron opens a window under the strip holding EVERY tile at
     once, wrapped: the strip element itself is moved into the window,
     so each tile keeps the wiring its builder gave it, and moved back
     into the frame when the window closes (the overlay owner hides
     it; an attribute observer sees that and puts the strip home).
     Picking a tile closes the window, the way a gallery does. */
  /* THE PRESENT TAB (T216): every button presses the Present menu's row
     of the same name, and the two toggles read their state off the
     row's words, so nothing is decided twice. LAYERS ON HOME: a tile
     that presses View's Layers button and mirrors its pressed state. */
  /* T228: the two doors the ribbon was missing. Notes was reachable
     only from the Present tab, which is the wrong tab for something
     you write while building (2026-09-03, user: "put the notes with
     the home next to layers. I like the notes"); and a slide could
     only be made optional from a right-click menu on the strip
     ("how are slides made optional?"). */
  function homeDoorsBoot(){
    /* T467: the same shape as Layers beside it -- press View's own
       Notes toggle and mirror its state, so the tile lights while the
       pane is open and a second press closes it (it pressed the
       Present menu's row, which only ever opened) */
    var n=$('#hm-notes'),nb=$('#notes-btn');
    if(n&&nb){
      n.addEventListener('click',function(e){
        e.stopPropagation();nb.click();});
      var mirrorN=function(){
        n.setAttribute('aria-pressed',nb.getAttribute('aria-pressed')||'false');};
      new MutationObserver(mirrorN)
        .observe(nb,{attributes:true,attributeFilter:['aria-pressed']});
      mirrorN();
    } else if(n) n.addEventListener('click',function(e){
      e.stopPropagation();
      var row=$('#pl-notes'); if(row) row.click();
    });
    var o=$('#hm-optional');
    if(o) o.addEventListener('click',function(e){
      e.stopPropagation();toggleOptional(cur);syncHomeDoors();
    });
    syncHomeDoors();
  }
  function syncHomeDoors(){
    /* T318: the star shows only when the current slide is grouped, so
       a versionless deck's ribbon is unchanged; pressed and inert on
       the main, live on an alternative */
    var st=$('#hm-main');
    if(st){
      var r=altRun(cur),isA=!!(r&&cur>r.at);
      st.hidden=!r;
      st.disabled=!!(r&&!isA);
      st.setAttribute('aria-pressed',(r&&!isA)?'true':'false');
      st.title=!r?'':(isA
        ?'Make this the main version \u2014 the talk, the arrows and every '
          +'export show it instead'
        :'This is the main version: it is what the talk shows');
      /* T365: showing Main takes "This slide" from four cells to five,
         which is an odd count -- a hole, and a whole extra column the
         width ladder has not judged. Re-fit rather than let either go
         stale (this is the same self-healing rule the comment above
         sizeRibbonGroups states, applied at the path that broke it). */
      if(typeof fitEditRibbon==='function') fitEditRibbon();
    }
    var o=$('#hm-optional'); if(!o) return;
    var s=(pres&&pres.slides)?pres.slides[cur]:null;
    var on=!!(s&&s.opt);
    o.setAttribute('aria-pressed',on?'true':'false');
    o.title=on
      ?'This slide is optional: Running late will skip it. Click to '
        +'make it required again'
      :'Mark this slide optional, so Running late can skip it when '
        +'the talk overruns';
  }
  function presentTabBoot(){
    [['pr-here','pl-here'],['pr-start','pl-start'],
     ['pr-presenter','pl-presenter'],['pr-scroll','pl-scroll'],
     ['pr-talk','pl-talk'],
     ['pr-notes','pl-notes'],['pr-timing','pl-notes'],
     ['pr-tap','pl-tap'],['pr-trace','pl-trace']]
      .forEach(function(p){
        var b=$('#'+p[0]),row=$('#'+p[1]);
        if(!b||!row) return;
        b.addEventListener('click',function(e){
          e.stopPropagation();
          var pm=$('#play-menu'); if(pm&&!pm.hidden) overlayHide(pm);
          row.click();
          /* T222: Notes and Timing share the pane and differ by the
             tab they land on -- the pane has had those tabs since
             T29 and nothing pointed at them */
          if(p[0]==='pr-notes'||p[0]==='pr-timing'){
            var want=(p[0]==='pr-timing')?'time':'slide';   /* T465 */
            setTimeout(function(){
              var t=$('.np-tab[data-np="'+want+'"]');
              if(t) t.click();
            },0);
          }
          setTimeout(presentTabSync,0);
        });
      });
    var tap=$('#pl-tap'),tr=$('#pl-trace');
    [tap,tr].forEach(function(row){
      if(row) new MutationObserver(presentTabSync)
        .observe(row,{childList:true,characterData:true,subtree:true});
    });
    presentTabSync();
    var hl=$('#hm-layers'),ob=$('#objects-btn');
    if(hl&&ob){
      hl.addEventListener('click',function(e){
        e.stopPropagation();ob.click();});
      var mirror=function(){
        hl.setAttribute('aria-pressed',ob.getAttribute('aria-pressed')||'false');};
      new MutationObserver(mirror)
        .observe(ob,{attributes:true,attributeFilter:['aria-pressed']});
      mirror();
    }
    /* T469: Build order's Layers door is the same door, and mirrors the
       same state (it showed no pressed state while the pane was open) */
    var al=$('#anim-layers');
    if(al&&ob){
      var mirrorA=function(){
        al.setAttribute('aria-pressed',ob.getAttribute('aria-pressed')||'false');};
      new MutationObserver(mirrorA)
        .observe(ob,{attributes:true,attributeFilter:['aria-pressed']});
      mirrorA();
    }
  }
  function presentTabSync(){
    [['pr-tap','pl-tap'],['pr-trace','pl-trace']].forEach(function(p){
      var b=$('#'+p[0]),row=$('#'+p[1]);
      if(!b||!row) return;
      var on=/:\s*on\s*$/.test(row.textContent||'');
      b.setAttribute('aria-pressed',on?'true':'false');
    });
  }
  function stripMoreBoot(){
    $$('.strip-frame').forEach(function(frame){
      var strip=frame.querySelector('.fx-strip'),
          more=frame.querySelector('.strip-more'),
          nav=frame.querySelector('.strip-nav'),
          prev=frame.querySelector('.strip-prev'),
          next=frame.querySelector('.strip-next');
      if(!strip||!more) return;
      /* THE GALLERY THE POWERPOINT WAY (T207): no scrollbar, only a
         compact back/next/more column. Most galleries wrap below the first
         row; text types now use the same horizontal full-height tiles as
         Animation, so their arrows step a tile sideways instead. */
      var ROW=60;
      var horizontal=strip.classList.contains('tx-strip');
      function tiles(){return $$('.fx-tile,.dbtn.lay',strip);}
      /* T463: the text tiles are each as wide as their name, so a
         sideways step is "to the next tile that is cut", not one fixed
         width: next scrolls the first tile past the right edge to the
         left edge; back scrolls the last tile past the left edge to the
         right edge. Nothing lands half-shown by the arrows' own doing. */
      function stepNext(){
        var sr=strip.getBoundingClientRect(),right=sr.right-4;
        var ts=tiles();
        for(var i=0;i<ts.length;i++){
          var r=ts[i].getBoundingClientRect();
          if(r.right>right+1){
            strip.scrollLeft+=Math.round(r.left-sr.left-4);return;}
        }
      }
      function stepPrev(){
        var sr=strip.getBoundingClientRect(),left=sr.left+4;
        var ts=tiles();
        for(var i=ts.length-1;i>=0;i--){
          var r=ts[i].getBoundingClientRect();
          if(r.left<left-1){
            strip.scrollLeft-=Math.round(sr.right-4-r.right);return;}
        }
      }
      /* T463: THE LIT TILE IS IN VIEW. A gallery that scrolls (the
         layouts, four rows deep; the effects) lit the chosen tile
         wherever it was, and the row that was showing was whichever
         you had left it on -- so the choice was a highlight nobody
         could see (2026-09-15, user: "you cannot really tell which one
         you selected"). Whenever a tile becomes pressed, and whenever
         the strip is first shown, its row is scrolled to it -- the
         way PowerPoint's galleries open on the selected item. */
      function reveal(){
        if(!strip.clientHeight) return;
        var on=strip.querySelector('[aria-pressed="true"]');
        if(!on||strip.parentNode!==frame) return;
        var sr=strip.getBoundingClientRect(),r=on.getBoundingClientRect();
        if(horizontal){
          if(r.left<sr.left+4) strip.scrollLeft-=Math.round(sr.left+4-r.left);
          else if(r.right>sr.right-4)
            strip.scrollLeft+=Math.round(r.right-(sr.right-4));
        } else {
          var top=r.top-sr.top+strip.scrollTop-2;
          strip.scrollTop=Math.round(top/ROW)*ROW;
        }
        setTimeout(ends,0);
      }
      function ends(){
        if(!prev||!next) return;
        var top=horizontal?strip.scrollLeft:strip.scrollTop;
        var max=horizontal
          ?strip.scrollWidth-strip.clientWidth
          :strip.scrollHeight-strip.clientHeight;
        /* dimmed, never disabled: a strip measured while its tab was
           hidden reads zero, and a disabled arrow would swallow the very
           click that would have measured it again */
        prev.setAttribute('aria-disabled',top<=1?'true':'false');
        next.setAttribute('aria-disabled',top>=max-1?'true':'false');
      }
      if(prev) prev.addEventListener('click',function(e){
        e.stopPropagation();
        if(horizontal) stepPrev();
        else strip.scrollTop=Math.max(0,Math.round(strip.scrollTop/ROW)*ROW-ROW);
        setTimeout(ends,0);});
      if(next) next.addEventListener('click',function(e){
        e.stopPropagation();
        if(horizontal) stepNext();
        else strip.scrollTop=Math.round(strip.scrollTop/ROW)*ROW+ROW;
        setTimeout(ends,0);});
      strip.addEventListener('scroll',ends);
      new MutationObserver(function(){setTimeout(ends,0);})
        .observe(strip,{childList:true});
      /* a tile NEWLY lit from anywhere -- a pick, a selection change,
         a reload -- brings its row into view. Newly: the marks are
         re-set on every refresh, and re-setting the same tile must not
         drag a strip you have scrolled elsewhere back to it. */
      var lastOn=null;
      new MutationObserver(function(ms){
        for(var i=0;i<ms.length;i++){
          var t=ms[i].target;
          if(t.getAttribute&&t.getAttribute('aria-pressed')==='true'){
            if(t!==lastOn){lastOn=t;setTimeout(reveal,0);}
            return;}
        }
      }).observe(strip,{subtree:true,attributes:true,
        attributeFilter:['aria-pressed']});
      /* the strip is measured when its tab shows, not at boot when the
         ribbon is hidden and every height reads zero -- and the first
         time it has a height is when the lit tile can be revealed */
      var shownH=0;
      if(typeof ResizeObserver==='function')
        new ResizeObserver(function(){
          if(!shownH&&strip.clientHeight) reveal();
          shownH=strip.clientHeight;
          ends();
        }).observe(strip);
      setTimeout(ends,0);
      var panel=null;
      function home(){
        if(strip.parentNode===frame) return;
        frame.insertBefore(strip,nav||more);
        frame.style.width='';
        more.setAttribute('aria-expanded','false');
        /* T465: the ladder was re-judged while the strip was away and
           every rung came off; with the strip back the row overflowed
           the window by 220px until something resized it (2026-09-15
           review). Fit again, now. */
        if(typeof fitEditRibbon==='function') fitEditRibbon();
        setTimeout(ends,0);
      }
      function build(){
        panel=document.createElement('div');
        panel.className='sh-menu strip-all';
        panel.id=strip.id+'-all';
        panel.hidden=true;
        var h=document.createElement('div');
        h.className='strip-all-h';
        h.textContent=strip.getAttribute('aria-label')||'All';
        panel.appendChild(h);
        /* inside the editor's own layer: the editor sits above the
           page, so a window appended to body opens underneath it */
        ((typeof deckEl!=='undefined'&&deckEl)||document.body)
          .appendChild(panel);
        /* a tile picked in the window closes it, after its own
           handler has run */
        /* CAPTURE (T465): a text tile's own handler stops propagation,
           so a bubbling listener never heard the pick and the window
           stayed open over the armed tool */
        panel.addEventListener('click',function(e){
          var t=e.target&&e.target.closest?
            e.target.closest('.fx-tile,.dbtn.lay'):null;
          if(t&&panel.contains(t))
            setTimeout(function(){overlayHide(panel);},0);
        },true);
        new MutationObserver(function(){
          if(panel.hidden) home();
        }).observe(panel,{attributes:true,attributeFilter:['hidden']});
      }
      more.addEventListener('click',function(e){
        e.stopPropagation();
        if(!panel) build();
        if(!panel.hidden){overlayHide(panel);return;}
        /* T465: the frame keeps the strip's width while the strip is in
           the window, so the bar does not reflow under the pop-up */
        var fw=frame.getBoundingClientRect().width;
        if(fw) frame.style.width=Math.round(fw)+'px';
        panel.appendChild(strip);
        overlayShow(more,panel);
        var fr=frame.getBoundingClientRect(),
            pw=panel.offsetWidth,vw=window.innerWidth;
        panel.style.left=Math.max(8,Math.min(fr.left,vw-pw-8))+'px';
        panel.style.top=(fr.bottom+4)+'px';
      });
    });
  }
  function shapeStripBoot(){
    var strip=$('#shape-strip'); if(!strip) return;
    SHAPE_LIST.forEach(function(pair){
      var b=document.createElement('button');
      b.type='button';b.className='fx-tile shape-tile';
      b.dataset.shape=pair[0];
      b.appendChild(shapeIcon(pair[0]));
      var t=document.createElement('span');t.textContent=pair[1];
      b.appendChild(t);
      b.title='Draw a '+pair[1].toLowerCase()+' — drag on the slide';
      b.addEventListener('click',function(e){
        e.stopPropagation();
        if(tool==='rect'&&pendingShape===pair[0]){setTool('select');return;}
        pendingShape=pair[0];
        setTool('rect');
      });
      strip.appendChild(b);
    });
    shapeStripSync=function(){
      $$('.shape-tile',strip).forEach(function(b){
        var on=(tool==='rect'&&pendingShape===b.dataset.shape);
        b.classList.toggle('on',on);
        b.setAttribute('aria-pressed',on.toString());
      });
    };
  }
  /* ---- WHAT KIND OF TEXT BOX: THE TEXT STRIP (T188) --------------------
     One tile per kind of box -- plain, then every named type in the
     deck, each drawn as a specimen of itself -- in the row of the Insert
     tab, the way the effects are. Click one and the text tool arms for
     that kind; the tile stays lit while it is armed; click it again to
     put the tool down. It replaces the caret menu beside Text, which was
     the one control on Insert that hid its options (2026-09-02, user:
     "the insert options like text should be like 'Effect'").
     The armed kind is NOT written into any button's label (the fit
     ladder has no rung for a label that follows the selection); it is
     the lit tile, and the Drawing group's status line. Rebuilt whenever
     the type registry changes, so a type of your own gets a tile. */
  var txStripSync=function(){};
  function txStripBoot(){
    var strip=$('#tx-strip'); if(!strip) return;
    function build(){
      strip.innerHTML='';
      /* ONE TILE PER KIND (T188, back in T220): plain, then every
         named type in the deck, each drawn as a specimen of itself.
         T207 had collapsed these to one tile for width; Text is its
         own tab now and the width is there. */
      var rows=[['','Text box',null]];
      styleOrder().forEach(function(id){
        rows.push([id,styleDef(id).label,styleDef(id)]);});
      rows.forEach(function(r){
        var b=document.createElement('button');
        b.type='button';b.className='fx-tile tx-tile';
        b.dataset.style=r[0];
        /* the plain tile keeps the door older code and tests know */
        if(!r[0]) b.setAttribute('data-tool','text');
        /* THE NAME IS THE SPECIMEN (2026-09-07, user: "You don't
           need the Aa I reckon, just the Title, Heading 1 in the text
           style"). An "Aa" beside the word said the same thing twice
           and cost the height that made these tiles two lines tall --
           and a heading is the thing people reach for most. So the
           WORD wears the type, the tile is one line, and the strip
           wraps into two short rows instead of one tall one. */
        var t=document.createElement('span');
        t.className='tx-tile-n';t.textContent=r[1];
        if(r[2]){
          t.style.fontWeight=r[2].b?'700':'400';
          if(r[2].i) t.style.fontStyle='italic';
          if(r[2].color) t.style.color=tokVal(r[2].color);
          if(r[2].font) t.style.fontFamily=fontCss(r[2].font);
          /* the ladder, compressed: a title still reads bigger than a
             heading, without a 40px tile */
          t.style.fontSize=Math.max(11,Math.min(17,
            10.5+(r[2].size||2.6)*0.85))+'px';
        }
        b.appendChild(t);
        b.title=r[0]
          ?('Draw a '+r[1]+' box'
            +(r[2]?(' \u2014 '+Math.round(r[2].size*5.4)+' pt'):''))
          :'Draw a plain text box \u2014 drag on the slide, or click for '
           +'one that sizes itself';
        b.addEventListener('click',function(e){
          e.stopPropagation();
          if(tool==='text'&&pendingStyle===r[0]){setTool('select');return;}
          pendingStyle=r[0];
          setTool('text');
        });
        strip.appendChild(b);
      });
      mark();
    }
    function mark(){
      $$('.tx-tile',strip).forEach(function(b){
        var on=(tool==='text'&&pendingStyle===(b.dataset.style||''));
        b.classList.toggle('on',on);
        b.setAttribute('aria-pressed',on.toString());
      });
    }
    /* setTool calls this on every arm and disarm; the registry calls it
       when a type is added or removed, and then the strip is rebuilt */
    txStripSync=function(rebuild){
      if(rebuild) build(); else mark();
    };
    build();
  }
  var downBtn=$('#deck-down');
  if(downBtn) downBtn.addEventListener('click',scrollToTrace);
  var upBtn=$('#deck-up');
  if(upBtn) upBtn.addEventListener('click',scrollToSlide);
  var vfClose=$('#vfull-close');
  if(vfClose) vfClose.addEventListener('click',closeVFull);
  /* ---- "Plot trace" opens a new DOCS tab, subset to the cells that build
     this plot. The deck (which owns the lineage) hands the cell ids + a
     dependency graph to the docs side, which clones those cards into a tab —
     every document filter and button keeps working because the tab IS made
     of real document cards. ---- */
  window.SemTrace={
    open:function(stem,anchor){
      var it=traceItemFor(stem,anchor); if(!it) return;
      if(!(window.SemApp&&window.SemApp.openTraceTab)) return;
      var group=lineageForItem(it.ns);
      var ids={},list=[];
      if(group) group.steps.forEach(function(s){
        if(s.card&&!ids[s.card]){ids[s.card]=1;list.push(s.card);}});
      if(it.card&&!ids[it.card]) list.push(it.card);   /* the plot itself */
      var graph=group?plotGraph(group,function(step){
        if(window.SemApp.traceGoto) window.SemApp.traceGoto(step.card);
      }):null;
      window.SemApp.openTraceTab(
        it.nb,list,it.title||'Plot trace',graph,anchor);
    }
  };
  /* close any open code-trail filter menu on an outside click */
  document.addEventListener('click',function(e){
    $$('.vo-fmenu').forEach(function(m){
      if(!m.hidden&&m.parentNode&&!m.parentNode.contains(e.target))
        m.hidden=true;});
  });
  /* ---- "Notebooks" popover in the deck header ---- */
  document.addEventListener('fullscreenchange',function(){
    /* Esc always exits browser fullscreen (the page cannot prevent
       it), so Esc while presenting leaves the presentation entirely —
       never a windowed half-presentation state. Inner layers (the code
       overlay, the trace) close via their own ✕ / scroll instead. */
    if(document.fullscreenElement) return;
    if(mode!=='view'||deckEl.hidden) return;
    closeVFull();
    /* BACK WHERE YOU WERE: presenting from the editor returned to the
       builder, a view you then had to climb out of via "Open the editor"
       (2026-08-19, user: "takes you to some cursed view") */
    setUIMode(presentFrom==='edit'?'edit':'create');
  });
  document.addEventListener('keydown',function(e){
    if(picking>=0){
      if(e.key==='Escape'){e.preventDefault();endPick();}
      return;
    }
    if(deckEl.hidden) return;
    /* while the document is being presented full screen over an open
       builder, its own Esc / Ctrl+Z own the keyboard — don't let the deck
       also close or undo underneath it */
    if(document.body.classList.contains('doc-presenting')) return;
    var tag=(e.target.tagName||'').toLowerCase();
    if(tag==='input'||tag==='select'||tag==='textarea') return;
    /* BEFORE the early return: Ctrl+S while a caret is in a text box was
       not handled here at all, so it was not preventDefault'ed either and
       the browser's own "Save page as..." dialog opened over the editor,
       saving nothing. Flush first, then let the save branch below run. */
    if(e.target.isContentEditable){
      if((e.ctrlKey||e.metaKey)&&(e.key==='s'||e.key==='S')) flushTextEdits();
      else return;
    }
    if(e.key==='Escape'){
      var vf=$('#vfull');
      /* an armed match is the OUTERMOST mode you can be standing in — you
         cannot be trimming or inside a group while the canvas is a
         picker — so it goes first and swallows the key */
      if(slideArm){e.preventDefault();cancelSlideMatch();return;}
      if(matchArm){e.preventDefault();cancelMatch();return;}
      /* T482: A DIALOG IS THE INNERMOST THING OF ALL. Style sets, Apply
         look, Arrange, Copy layout to slides and the transition's
         give-to are modal boxes whose own Escape listeners sit on the
         box -- and focus was still on the button that opened them, so
         the key came here instead and stepped the ladder: the first
         dropped the selection, the second left the editor with the
         dialog still up over the notebook (2026-09-15 review). */
      var dlgUp=$('.aa-dlg:not([hidden]),.eq-dlg:not([hidden]),'
        +'.ts-dlg:not([hidden])');
      if(dlgUp){
        e.preventDefault();
        var x=dlgUp.querySelector('.aa-head .dc-icon,.eq-head .dc-icon,'
          +'[id$="-close"],[id$="-cancel"]');
        if(x) x.click(); else dlgUp.hidden=true;
        return;
      }
      /* a transient menu or window is INNER to everything below: its
         own owner closes it (overlayBoot, in capture) and this ladder
         must not also step -- belt and braces, in case the two
         listeners ever run the other way round (T177) */
      if(typeof overlayNow!=='undefined'&&overlayNow) return;
      /* a lasso owns the pointer while it is being drawn, so nothing
         else can be happening underneath it (T64) */
      if(freeArm){e.preventDefault();endFreeCrop(false);return;}
      if(vf&&!vf.hidden) closeVFull();
      /* trim mode is the innermost state: the first Esc leaves IT,
         keeping the selection, before any tool/selection drops */
      else if(mode==='edit'&&cropMode){setCropMode(false);}
      /* then the group you have stepped into — also inner, and also worth
         keeping the selection through (2026-08-20) */
      else if(mode==='edit'&&inGroup!=null){
        leaveGroup(stage.querySelector('.annot-layer'));
        var lg=stage.querySelector('.annot-layer');
        if(lg&&typeof selAnnot==='number') selectAnnot(lg,selAnnot);
      }
      else if(spotEl){closeSpot();}
      else if(mode==='view'&&(stage.scrollTop||0)>50) scrollToSlide();
      else if(mode==='edit'
              &&(tool!=='select'||selAnnot!==null||selSet.length)){
        /* first Esc drops the tool / selection; the next one leaves the
           editor (there are no Select/Delete buttons — Esc and Del do it) */
        setTool('select');
        var l=stage.querySelector('.annot-layer');
        if(l) selectAnnot(l,null);
        else {selAnnot=null;selSet=[];showFmt();}
      }
      /* leaving a presentation goes back to WHERE IT STARTED — Esc is the
         third exit route (exit button and fullscreen-change had this, the
         Esc branch still dumped an edit-mode presenter into the builder:
         the "cursed view", 2026-08-20 re-verify) */
      else if(mode==='view')
        setUIMode(presentFrom==='edit'?'edit':'create');
      else if(mode==='edit'){setUIMode('create');}
      else closeDeck();
    }
    else if((e.ctrlKey||e.metaKey)&&(e.key==='z'||e.key==='Z')
            &&mode!=='view'){
      e.preventDefault();
      if(e.shiftKey) redo(); else undo();
    }
    else if((e.ctrlKey||e.metaKey)&&(e.key==='y'||e.key==='Y')
            &&mode!=='view'){
      e.preventDefault();redo();
    }
    else if((e.ctrlKey||e.metaKey)&&(e.key==='s'||e.key==='S')){
      /* saves to wherever "Saved to" points, exactly like the Save button
         (2026-08-19, user: "more shortcuts — ctrl+s"). Present mode still
         swallows it so the browser's save dialog never covers a talk. */
      e.preventDefault();
      if(mode!=='view'){var sb2=$('#dc-save');if(sb2) sb2.click();}
    }
    else if((e.ctrlKey||e.metaKey)&&(e.key==='p'||e.key==='P')
            &&!deckEl.hidden){
      /* T285: PDF is this product's most-used way out, and Ctrl+P went
         to the browser -- which prints the EDITOR: the ribbon, the
         strip, the panes, and the one slide that happened to be on the
         stage. printDeck builds the real print root (every slide at the
         page's true size, crop marks, the background forced through
         print-color-adjust) and File > Print already calls it.
         Guarded on the deck being open, so Ctrl+P over the notebook
         still prints the notebook. */
      e.preventDefault();
      if(typeof printDeck==='function') printDeck();
    }
    else if((e.ctrlKey||e.metaKey)&&e.key==='F1'&&mode==='edit'){
      /* PowerPoint's own shortcut for the same thing (2026-08-20) */
      e.preventDefault();setRibbonFold(!ribbonFolded());
    }
    else if((e.ctrlKey||e.metaKey)&&(e.key==='f'||e.key==='F')
            &&mode!=='view'){
      /* the browser's own find can only see the ONE slide that is
         rendered, which for a deck is almost always the wrong answer —
         so Ctrl+F opens the deck's find instead (2026-08-20) */
      e.preventDefault();
      if(window.SemDeckFind) window.SemDeckFind();
    }
    else if(mode==='edit'){
      if(e.key==='Delete'||e.key==='Backspace'){
        e.preventDefault();deleteSel();
      }
      /* SELECT EVERYTHING ON THIS SLIDE. There was no Ctrl+A at all, so
         the one shortcut every person reaches for when "selecting
         multiple objects" fell straight through to the BROWSER's
         Select All: the entire document highlighted and not one object
         selected -- "it just results in everything being selected"
         (T63). Hidden and fully locked items stay out, the same rule
         the marquee follows; hold Alt as well to sweep the locked ones
         in, exactly as an Alt-marquee does. A caret in a text box never
         reaches here (the isContentEditable early return above), so
         Ctrl+A still means "select these words" while typing. */
      else if((e.ctrlKey||e.metaKey)&&(e.key==='a'||e.key==='A')){
        e.preventDefault();
        var sA=pres.slides[cur],lA=stage.querySelector('.annot-layer');
        var allA=[];
        ((sA&&sA.annots)||[]).forEach(function(a,i){
          if(!a||a.hide) return;
          if(lockedAll(a)&&!e.altKey) return;
          allA.push(i);
        });
        leaveGroup(lA);
        selectMany(lA,allA);
        toast(allA.length
          ?(allA.length+' item'+(allA.length===1?'':'s')+' selected')
          :'Nothing on this slide to select');
      }
      /* T93, AND IT MUST COME FIRST. The plain branch below matches 'D'
         as well as 'd', and e.key is 'D' whenever Shift is down -- so
         Ctrl+Shift+D already fired today as a silent alias for plain
         Duplicate. Putting the variant above it spends no new key and
         retires the alias. Exactly the ordering the two placed pastes
         further down are written around. */
      else if((e.ctrlKey||e.metaKey)&&e.shiftKey
              &&(e.key==='d'||e.key==='D')){
        e.preventDefault();duplicateSel(1);
      }
      else if((e.ctrlKey||e.metaKey)&&(e.key==='d'||e.key==='D')){
        e.preventDefault();duplicateSel();
      }
      /* copy and cut; PASTE rides the real paste event instead, so a
         system-clipboard image can come in too */
      else if((e.ctrlKey||e.metaKey)&&(e.key==='c'||e.key==='C')){
        var nc=copySel();
        if(nc){e.preventDefault();
          toast(nc+' item'+(nc===1?'':'s')+' copied');}
      }
      else if((e.ctrlKey||e.metaKey)&&(e.key==='x'||e.key==='X')){
        var nx=cutSel();
        if(nx){e.preventDefault();
          toast(nx+' item'+(nx===1?'':'s')+' cut');}
      }
      /* the two PLACED pastes. They come first because the plain-paste
         branch below matches 'v' and 'V' alike and would swallow them,
         and they preventDefault because there is nothing the native
         paste event could add: the buffer is ours. */
      else if((e.ctrlKey||e.metaKey)&&e.shiftKey
              &&(e.key==='v'||e.key==='V')){
        if(!clipBuf.length){
          /* nothing of ours to place: the same keys become "paste the
             clipboard as PLAIN text" (T128) -- the canvas's escape from
             a wrong code detection. No preventDefault: the native paste
             event is exactly what has to fire. */
          armPlainPaste();
          return;
        }
        e.preventDefault();tookPaste();
        pasteBuf('place');
        toast('Pasted in place — the coordinates it was copied '
          +'from');
      }
      else if((e.ctrlKey||e.metaKey)&&e.altKey
              &&(e.key==='v'||e.key==='V')){
        e.preventDefault();tookPaste();
        if(!clipBuf.length) toast('Nothing copied yet');
        else {pasteBuf('here');
          toast(pointerPct()?'Pasted at the pointer'
            :'Pasted in the middle — the pointer was off the page');}
      }
      /* NOT preventDefaulted: the native paste event stays the primary
         path (it can carry a system-clipboard image). This one-shot timer
         only fires where that event never arrives, so an internal copy
         still pastes there (2026-08-20) */
      else if((e.ctrlKey||e.metaKey)&&(e.key==='v'||e.key==='V')){
        if(pendingPaste) clearTimeout(pendingPaste);
        pendingPaste=setTimeout(function(){
          pendingPaste=null;
          if(clipBuf.length) pasteBuf();
        },150);
      }
      else if((e.ctrlKey||e.metaKey)&&(e.key==='g'||e.key==='G')){
        e.preventDefault();
        if(e.shiftKey) ungroupSel(); else groupSel();
      }
      else if(e.key.indexOf('Arrow')===0
              &&(selSet.length||selAnnot!==null)){
        e.preventDefault();
        var st=e.shiftKey?2:0.4;
        nudgeSel(e.key==='ArrowLeft'?-st:e.key==='ArrowRight'?st:0,
                 e.key==='ArrowUp'?-st:e.key==='ArrowDown'?st:0);
      }
      /* with NOTHING selected, up/down walk the deck like the thumbnail
         strip (2026-08-19, user: "pressing the down key on the slide
         thumbnails should move you through the slides") */
      else if(!e.ctrlKey&&!e.metaKey
              &&(e.key==='ArrowDown'||e.key==='ArrowUp'
                 ||e.key==='PageDown'||e.key==='PageUp')){
        var dd=(e.key==='ArrowDown'||e.key==='PageDown')?1:-1;
        var nn=cur+dd;
        if(nn>=0&&nn<pres.slides.length){
          e.preventDefault();
          cur=nn;activePane=-1;selAnnot=null;selSet=[];refresh();
        }
      }
      /* Z spotlights whatever the pointer is over. Alt+click does the
         same with the mouse alone; this is the version you can use from a
         lectern with a clicker in one hand (2026-08-20). */
      /* R rulers, G grid — plain keys, so Ctrl+G still groups. H and B
         join them for the guides you drew yourself: H shows or hides
         them (Photoshop's Ctrl+H, without the Ctrl this row does not
         use), B arms the Box. Each DRIVES THE REAL BUTTON rather than
         calling the handler, so the key and the ribbon can never come to
         disagree about what the toggle now says. */
      else if(!e.ctrlKey&&!e.metaKey&&(e.key==='r'||e.key==='R')){
        e.preventDefault();
        var rb=$('#vw-rulers'); if(rb) rb.click();
      }
      else if(!e.ctrlKey&&!e.metaKey&&(e.key==='g'||e.key==='G')){
        e.preventDefault();
        var gb=$('#vw-grid'); if(gb) gb.click();
      }
      else if(!e.ctrlKey&&!e.metaKey&&(e.key==='h'||e.key==='H')){
        e.preventDefault();
        var hb=$('#vw-guides'); if(hb) hb.click();
      }
      else if(!e.ctrlKey&&!e.metaKey&&(e.key==='b'||e.key==='B')){
        e.preventDefault();
        var bb=$('#vw-guidebox');
        /* the button is the door, but it can be hidden by the fit ladder
           or by T11's customiser, and a shortcut must not go with it */
        if(bb&&!bb.hidden) bb.click();
        else setTool(tool==='guide'?'select':'guide');
      }
      /* page zoom from the keyboard, mirroring the -/Fit/+ buttons */
      else if(!e.ctrlKey&&!e.metaKey
              &&(e.key==='+'||e.key==='='||e.key==='-'||e.key==='0')){
        var zb=$(e.key==='-'?'#zoom-out'
          :e.key==='0'?'#zoom-val':'#zoom-in');
        if(zb){e.preventDefault();zb.click();}
      }
    }
    else if(mode==='view'){
      /* T386: the laser, the magnifier and the black screen (P, M, B),
         and Escape puts them down before it does anything else */
      if(typeof talkToolKey==='function'&&talkToolKey(e)){
        e.preventDefault();return;}
      /* Z spotlights whatever the pointer is over. Alt+click does the
         same with the mouse alone; this is the version you can use from
         a lectern with a clicker in one hand (2026-08-20). T465: it sat
         inside the EDIT-mode block guarded by mode==='view', so it could
         never fire -- the tooltip advertised a dead key. */
      if(!e.ctrlKey&&!e.metaKey&&!e.altKey&&(e.key==='z'||e.key==='Z')){
        e.preventDefault();
        if(spotEl) closeSpot(); else if(spotHover) spotlight(spotHover);
        return;
      }
      /* FIND A SLIDE, MID-TALK. "/" is the type-to-search key everywhere
         else on a keyboard, and the map it opens is the one T26 already
         built -- so this is a door, not a second piece of navigation
         (T30). */
      if(!e.ctrlKey&&!e.metaKey&&!e.altKey
         &&(e.key==='l'||e.key==='L')){
        var late=$('#deck-late');
        if(late){e.preventDefault();late.click();}
        return;
      }
      if(e.key==='/'||((e.ctrlKey||e.metaKey)&&(e.key==='f'||e.key==='F'))){
        e.preventDefault();
        openOverview();
        var fi=$('#ovw-find'); if(fi) fi.focus();
        return;
      }
      /* THE TALK'S OWN KEYS (T88). In front of a room the panel is the
         slow way to reach either of these, so both are one key -- and
         they are only bound in view mode, where nothing else claims
         them. */
      if(!e.ctrlKey&&!e.metaKey&&!e.altKey
         &&(e.key==='a'||e.key==='A')){
        e.preventDefault();
        if(window.SemDeckTalk) window.SemDeckTalk.builds(!talkNoBuilds);
        return;
      }
      if(!e.ctrlKey&&!e.metaKey&&!e.altKey
         &&(e.key==='t'||e.key==='T')){
        var tb=$('#talkbtn');
        if(tb){e.preventDefault();tb.click();}
        return;
      }
      if(!e.ctrlKey&&!e.metaKey&&!e.altKey
         &&(e.key==='+'||e.key==='='||e.key==='-'||e.key==='0')){
        e.preventDefault();
        if(window.SemDeckTalk)
          window.SemDeckTalk.zoom(e.key==='-'?1/1.12:e.key==='0'?0:1.12);
        return;
      }
      /* T321: the space bar on a focused clip is play/pause, not next */
      if(tag==='video'||tag==='audio') return;
      if(e.key==='ArrowRight'||e.key==='PageDown'
         ||(e.key===' '&&tag!=='button')){e.preventDefault();advance();}
      else if(e.key==='ArrowLeft'||e.key==='PageUp'){
        e.preventDefault();backStep();}
      else if(e.key==='ArrowDown'){
        e.preventDefault();
        if((stage.scrollTop||0)<60) scrollToTrace();
        else stage.scrollBy({top:stage.clientHeight*0.7,
          behavior:'smooth'});
      }
      else if(e.key==='ArrowUp'){
        e.preventDefault();
        if((stage.scrollTop||0)<=stage.clientHeight*0.8) scrollToSlide();
        else stage.scrollBy({top:-stage.clientHeight*0.7,
          behavior:'smooth'});
      }
    }
    /* F5 — the PowerPoint convention — presents from the current slide
       in either editing view (it shadows the browser's refresh only
       while the editor is open, a deliberate trade) */
    if(e.key==='F5'&&(mode==='edit'||mode==='create')){
      var pl=$('#dc-play');
      if(pl){e.preventDefault();pl.click();}
    }
  });
  /* every deck shortcut is advertised in its button's tooltip, exactly
     like the document ribbon's (the data-kbd chip in app.js) */
  [['#dc-play','F5'],['#dc-undo','Ctrl+Z'],['#dc-redo','Ctrl+Y'],
   ['#dc-save','Ctrl+S'],['#fmt-dup','Ctrl+D'],
   ['#zoom-in','+'],['#zoom-out','-'],['#zoom-val','0'],
   ['#deck-late','L']]
    .forEach(function(p){
      var el=$(p[0]); if(el) el.dataset.kbd=p[1];});

  /* ---------- create mode: click a card in ANY open tab to place it */
  document.addEventListener('click',function(e){
    if(deckEl.hidden||mode!=='create') return;
    var t=e.target;
    if(!t||!t.closest) return;
    if(deckEl.contains(t)) return;
    if(t.closest('.apptop,.opendlg,.welcome')) return;
    var shellEl=t.closest('.nbshell');
    if(!shellEl) return;
    var card=t.closest('.card');
    if(!card) return;
    if(t.closest('.codetoggle,.depchip,a')) return;
    var s=pres.slides[cur];
    if(!s){pres.slides.push(emptySlide());cur=pres.slides.length-1;
      s=pres.slides[cur];}
    if(s.layout==='title'){
      e.preventDefault();e.stopPropagation();
      toast('This is a title slide — pick a layout to add card frames');
      return;
    }
    /* a Plot-trace tab's cards are clones — resolve to the real notebook */
    var ref=nsKey(shellEl.dataset.src||shellEl.dataset.nb,
      card.dataset.anchor);
    if(slideCells(s).some(function(c){return c.a.ref===ref;})){
      e.preventDefault();e.stopPropagation();
      toast('That card is already on this slide');
      card.classList.add('target-flash');
      setTimeout(function(){card.classList.remove('target-flash');},700);
      return;
    }
    /* placement: an ARMED frame wins; with none armed the card takes the
       first EMPTY frame in reading order. Poster templates ship full of
       placeholder frames, and demanding a selection before every single
       click made "Swap to notebooks" feel broken (2026-08-04) — in
       create mode clicking a card IS the intent to place it, so
       successive clicks fill successive slots. A slide with no frames
       at all still creates one. */
    var target=annotByIdx(s,activePane);
    if(!target||target.k!=='cell'||target.ref){
      if(slideCells(s).length===0){
        s.annots=s.annots||[];
        /* the SAME rect a blank slide used to be born with, so
           clicking a card onto an empty slide lands exactly where it
           always did now that emptySlide leaves the page bare (T61) */
        s.annots.push(fullFrame(null));
        target=annotByIdx(s,s.annots.length-1);
      } else {
        var best=null;
        (s.annots||[]).forEach(function(a){
          if(a.k!=='cell'||a.ref) return;
          if(!best||a.y<best.y-0.5
             ||(Math.abs(a.y-best.y)<=0.5&&a.x<best.x)) best=a;
        });
        if(best) target=best;
        else {
          toast('Every frame is full — select a frame on the page '
            +'to replace');
          return;
        }
      }
    }
    e.preventDefault();e.stopPropagation();
    target.ref=ref;
    /* T297: keep the pixels NOW, while the notebook is definitely open
       -- this click is the only moment we can be sure of that */
    if(typeof embedIfAbsent==='function') embedIfAbsent(target);
    activePane=-1;   /* disarm: adding again needs a fresh frame selection */
    markDirty();refresh();
    card.classList.add('target-flash');
    setTimeout(function(){card.classList.remove('target-flash');},700);
  },true);

  /* ---------- create mode: slide + presentation operations ---------- */
  $('#film-add').addEventListener('click',newVersion);
  /* ---- the slide column's own three controls ---------------------------
     Section, the display-mode chooser and the drag handle. All three are
     about the STRIP, so all three live on it rather than in a ribbon that
     has no room and cannot see what it is acting on (2026-08-22). */
  (function(){
    var sec=$('#film-sec');
    if(sec) sec.addEventListener('click',function(){
      newSection(cur,'New section');
      /* the name is the point of a section, so ask for it straight away
         rather than leaving "New section" sitting there */
      var runs=sectionRuns(),i;
      for(i=0;i<runs.length;i++)
        if(runs[i].at<=cur&&cur<runs[i].at+runs[i].n&&runs[i].id)
          {renameSection(runs[i].id);break;}
    });
    var btn=$('#film-view-btn'),menu=$('#film-view-menu');
    function label(){
      var pg=pageOf().poster?2:1,m=filmMode(),i;
      for(i=0;i<FILM_VIEWS.length;i++)
        if(FILM_VIEWS[i][0]===m) return FILM_VIEWS[i][pg];
      return FILM_VIEWS[0][pg];
    }
    function syncFilmBtn(){
      if(btn) btn.innerHTML=bic('layouts')+' '+label()+' &#9662;';
    }
    function setFilmMode(m){
      /* the overview is a VIEW of the deck, not a mode of the strip: it
         opens and the strip keeps whatever it was showing */
      if(m==='overview'){openOverview();return;}
      filmView=m;
      lsSet(FILMKEY+SCOPE,m);
      syncFilmBtn();renderFilm();
    }
    if(btn&&menu){
      btn.addEventListener('click',function(e){
        e.stopPropagation();
        var open=menu.hidden;
        if(open){
          menu.innerHTML='';
          var pg=pageOf().poster?2:1;
          FILM_VIEWS.forEach(function(v){
            var b=document.createElement('button');
            b.className='dc-mi';
            b.textContent=v[pg];
            b.setAttribute('aria-pressed',(filmMode()===v[0]).toString());
            b.addEventListener('click',function(ev){
              ev.stopPropagation();overlayHide(menu);setFilmMode(v[0]);});
            menu.appendChild(b);
          });
          /* ...and the column's own auto-hide, the way the document
             view's presentations panel has one (#pr-auto). Not a listing
             mode, so it goes UNDER them as a separate item rather than
             into FILM_VIEWS -- label() names the button from that list,
             and "Auto-hide" must never become the button's own label.
             The Overview entry already set the shape: this menu is "how
             do I want to look at this deck", and putting the column away
             is that question. A poster has no column strip to hide. */
          if(!pageOf().poster){
            var ab=document.createElement('button');
            ab.className='dc-mi';
            ab.textContent='Auto-hide this column';
            ab.title='The column slides out of the way and comes back when '
              +'you move the pointer to the left edge. Off by default.';
            ab.setAttribute('aria-pressed',filmAutoOn().toString());
            ab.addEventListener('click',function(ev){
              ev.stopPropagation();overlayHide(menu);
              setFilmAuto(!filmAutoOn());});
            menu.appendChild(ab);
          }
        }
        if(open) overlayShow(btn,menu);
        else overlayHide(menu);
      });
      syncFilmBtn();
      window.SemDeckFilmBtn=syncFilmBtn;
    }
    /* the drag. --film-w is set on the DECK and never on --dc-w, which
       the document view's own margin also reads — overloading that one
       makes dragging the slide column shove the notebook sideways. */
    var h=$('#film-resize');
    var wPref=parseInt(lsGet(FILMWKEY+SCOPE),10);
    if(wPref>=150&&wPref<=900)
      deckEl.style.setProperty('--film-w',wPref+'px');
    if(h) h.addEventListener('pointerdown',function(e){
      e.preventDefault();
      h.classList.add('on');
      try{h.setPointerCapture(e.pointerId);}catch(err){}
      /* the ceiling is measured ONCE, here: the ribbon cannot change what
         it holds while you are holding the handle, and re-measuring would
         stamp the whole density ladder on and off sixty times a second */
      var hi=fitFilmMax();
      var w=0;
      function mv(ev){
        w=Math.max(150,Math.min(hi,ev.clientX));
        deckEl.style.setProperty('--film-w',w+'px');
        /* the stage just lost or gained that width, so the page has to
           re-fit as you drag or the slide sits wrong until you let go */
        applyZoom();
      }
      function up(){
        h.classList.remove('on');
        document.removeEventListener('pointermove',mv);
        document.removeEventListener('pointerup',up);
        /* ONE re-render at the end: the thumbnails re-measure their type
           off the new width, and doing that on every pointermove would
           rebuild sixty <svg>s a second */
        if(w){lsSet(FILMWKEY+SCOPE,String(w));renderFilm();}
        /* ...and ONE run of the fit ladder, so the row settles on the rung
           its new width earns. #edit-tools' ResizeObserver re-fits it live
           as the column moves; this is what guarantees the final state,
           and re-publishes --film-max for the next drag (T80) */
        fitFilmMax();fitEditRibbon();
      }
      document.addEventListener('pointermove',mv);
      document.addEventListener('pointerup',up);
    });
    /* THE SAME DRAG, FROM THE KEYBOARD (T155). A splitter with no role,
       no tab stop and no keys is a pointer-only control, and this one
       owns a width the whole editor is laid out around. The arrows are
       also the deck's own slide navigation, so the event stops here
       rather than walking up to the document listener that would change
       slide under you. */
    if(h) h.addEventListener('keydown',function(e){
      var step=0;
      if(e.key==='ArrowLeft') step=-24;
      else if(e.key==='ArrowRight') step=24;
      else return;
      e.preventDefault();e.stopPropagation();
      var hi=fitFilmMax();
      var el=$('#deck-create'); if(!el) return;
      var now=Math.round(el.getBoundingClientRect().width);
      var w=Math.max(150,Math.min(hi,now+step));
      deckEl.style.setProperty('--film-w',w+'px');
      lsSet(FILMWKEY+SCOPE,String(w));
      applyZoom();renderFilm();fitFilmMax();fitEditRibbon();
    });
  })();
  /* (the picker's first render runs from THE BOOT SEQUENCE) */
  /* title-slide text fields (panel); the slide canvas mirrors them */
  [['#ts-title','title'],['#ts-sub','sub']].forEach(function(p){
    var inp=$(p[0]); if(!inp) return;
    inp.addEventListener('input',function(){
      var s=pres.slides[cur];
      if(!s||s.layout!=='title') return;
      s[p[1]]=this.value;
      markDirty();renderFilm();
      if(mode==='edit') renderSlide();
    });
  });
  /* ---- File menu ---- */
  var fileBtn=$('#dc-file'), fileMenu=$('#dc-menu');
  function closeMenu(){overlayHide(fileMenu);}
  if(fileBtn){
    fileBtn.addEventListener('click',function(e){
      e.stopPropagation();
      if(fileMenu.hidden){
        /* floated (position:fixed) so fitQat's scroll floor can never
           cut the menu off at the bar's edge */
        overlayShow(fileBtn,fileMenu);floatMenu(fileBtn,fileMenu);
      } else overlayHide(fileMenu);
    });
  }
  function menuAction(id,fn){
    var b=$(id);
    if(b) b.addEventListener('click',function(){closeMenu();fn();});
  }
  /* ---- Help menu (T397): How to use, and Support. app.js owns what
     How to use does; this only opens and closes the menu. ---- */
  (function(){
    var h=wireMenuToggle('deck-helpwrap','deck-help','deck-help-menu');
    if(!h) return;
    $$('.dc-mi',h.menu).forEach(function(b){
      b.addEventListener('click',function(){overlayHide(h.menu);});
    });
  })();
  menuAction('#mi-new',newPresentation);
  /* ONE rename, reached from the File menu and from the name in the top
     bar. It used to un-hide #pres-name, which lives in .dc-controls — a
     block that is display:none the whole time you are editing, so the
     input was 0x0 and unfocusable and File ▸ Rename… appeared to do
     nothing at all in the primary flow (2026-08-20 diagnosis). */
  menuAction('#mi-rename',startQatRename);
  var qatName=$('#qat-name');
  if(qatName) qatName.addEventListener('click',startQatRename);
  /* T236: no Auto-build rows. They replaced pres.slides wholesale --
     the deck you had made, gone, to lay the notebook out again --
     which is exactly what File > New presentation does from a clean
     start (autoSlides is still what defaultPres is built from). */
  /* T236: the numbers toggle is a FUNCTION now, called by the one
     button that remains -- Design > Page furniture > Numbers. The
     File row was a second door that button forwarded to. */
  function toggleSlideNums(){
    if(pres.showNums){delete pres.showNums;} else {pres.showNums=1;}
    markDirty();refresh();
    toast('Page numbers '+(pres.showNums?'on':'off'));
  }
  function updateCropLabel(){
    var b=$('#mi-crop');
    if(b) b.textContent='Crop marks: '+(pres.cropMarks?'on':'off');
  }
  menuAction('#mi-crop',function(){
    if(pres.cropMarks){delete pres.cropMarks;} else {pres.cropMarks=1;}
    updateCropLabel();markDirty();
    toast(pres.cropMarks
      ?'Crop marks on — the exported sheet grows '+BLEED_MM
        +'mm on each side; the page keeps its exact size'
      :'Crop marks off');
  });
  $('#pres-name').addEventListener('input',function(){
    /* NOTHING happens per keystroke any more. This used to set pres.name
       and lsDel the old draft on every letter typed, so renaming "talk"
       to "talk2" walked through "tal", "ta", "t" — deleting the draft
       under each prefix on the way and leaving four half-named ghosts in
       the rail (2026-08-20 diagnosis). Renaming is a single committed
       action; see renamePresentation. */
  });
  $('#pres-name').addEventListener('keydown',function(e){
    if(e.key==='Enter'||e.key==='Escape') this.blur();
    e.stopPropagation();
  });
  $('#pres-name').addEventListener('blur',function(){
    this.hidden=true;
    var lbl=$('#pres-current');
    if(lbl) lbl.hidden=false;
    if(this.value.trim()) renamePresentation(this.value.trim());
    renderPresRow();
  });

  /* ---- watermark / header / footer, edited in one small form each ---
     T488: the model has carried size, colour, alignment, "not on the
     first slide", the watermark's opacity and angle since T115, read by
     paintFurniture and written nowhere -- the prompt took the words
     alone, and the ribbon button read as a toggle that could not be
     toggled (2026-09-15 review). The form is askText's `rows`; the
     ribbon button stays the on/off readout, and "Turn it off" is the
     form's third button (an empty text turns it off too). Sizes are
     asked in points, the editor's currency everywhere else, and stored
     as the percent of page height the painter reads. */
  var FURN_PT=5.4;   /* pt per percent of page height, as the tooltips */
  function furnEdit(key,label,hint,dflt){
    var cur_=pres[key]||{};
    var lines=String(hint).split('\n');
    var isW=(key==='wmark');
    var on=!!String(cur_.text||'').trim();
    var curCol=cur_.color?tokVal(cur_.color):'';
    var rows=[
      {k:'text',label:'Words',value:cur_.text||dflt||'',placeholder:dflt||'',
       note:lines.slice(1).join(' ')},
      {k:'pt',label:'Size',type:'number',
       value:Math.round((cur_.size==null?(isW?12:2):cur_.size)*FURN_PT),
       min:4,max:isW?400:60,step:1,unit:'pt'}];
    if(isW){
      rows.push({k:'op',label:'Opacity',type:'range',
        value:cur_.op==null?0.12:cur_.op,min:0.03,max:0.6,step:0.01,pct:true});
      rows.push({k:'rot',label:'Angle',type:'number',
        value:cur_.rot==null?-28:cur_.rot,min:-90,max:90,step:1,
        unit:'\u00b0'});
    } else {
      rows.push({k:'align',label:'Aligned',type:'select',
        value:cur_.align||'left',
        options:[['left','Left'],['center','Centre'],['right','Right']]});
    }
    rows.push({k:'color',label:'Colour',type:'color',value:curCol,clear:true});
    if(!isW) rows.push({k:'skipFirst',label:'Not on the first slide',
      type:'check',value:!!cur_.skipFirst});
    askText({title:label,what:lines[0],rows:rows,
      ok:on?'Change it':'Add it',alt:on?'Turn it off':''},
    function(v,why){
      if(why==='alt'||(v&&!String(v.text||'').trim())){
        delete pres[key];
        markDirty();refresh();syncFurnBtns();
        toast(label+' removed');
        return;
      }
      if(v===null) return;
      var o2=pres[key]=pres[key]||{};
      o2.text=String(v.text).trim();
      if(v.pt!=null&&v.pt>0) o2.size=Math.round(v.pt/FURN_PT*100)/100;
      else if(o2.size==null) o2.size=isW?12:2;
      if(isW){
        if(v.op!=null) o2.op=v.op; else if(o2.op==null) o2.op=0.12;
        if(v.rot!=null) o2.rot=v.rot;
      } else {
        if(v.align&&v.align!=='left') o2.align=v.align; else delete o2.align;
        if(v.skipFirst) o2.skipFirst=1; else delete o2.skipFirst;
      }
      /* a token colour (@ink) is kept when the swatch was left alone */
      if(!v.color) delete o2.color;
      else if(v.color.toLowerCase()!==String(curCol).toLowerCase())
        o2.color=v.color;
      markDirty();refresh();syncFurnBtns();
      toast(label+' set');
    });
  }
  function syncFurnBtns(){
    [['#dc-wmark','wmark'],['#dc-head','head'],['#dc-foot','foot']]
      .forEach(function(p2){
        var b=$(p2[0]); if(!b) return;
        var on=!!(pres[p2[1]]&&String(pres[p2[1]].text||'').trim());
        b.setAttribute('aria-pressed',on?'true':'false');
      });
    var nb=$('#dc-nums');
    if(nb) nb.setAttribute('aria-pressed',pres.showNums?'true':'false');
  }
  var wmB=$('#dc-wmark');
  if(wmB) wmB.addEventListener('click',function(){
    furnEdit('wmark','Watermark',
      'One word or phrase, printed faintly across every page and always '
      +'BEHIND your content.\nLeave it empty to remove it.','DRAFT');
  });
  var hdB=$('#dc-head');
  if(hdB) hdB.addEventListener('click',function(){
    furnEdit('head','Header',
      'A line along the top of every page.\n'
      +'{name} the presentation, {date} today, {n} this page, {N} the '
      +'total, {sn}/{sN} the number and count within the section, '
      +'{sec} its name.\nLeave it empty to remove it.','{name}');
  });
  var ftB=$('#dc-foot');
  if(ftB) ftB.addEventListener('click',function(){
    furnEdit('foot','Footer',
      'A line along the bottom of every page.\n'
      +'{name} the presentation, {date} today, {n} this page, {N} the '
      +'total, {sn}/{sN} the number and count within the section, '
      +'{sec} its name.\nLeave it empty to remove it.','{n} / {N}');
  });
  var numB=$('#dc-nums');
  if(numB) numB.addEventListener('click',function(){
    toggleSlideNums();
    syncFurnBtns();
  });
