"""The client-side build: the same tool as a static site, no server.

Python runs in the visitor's browser through Pyodide, so notebooks never leave
their machine and the result is safe to host anywhere. :func:`build_web` writes
a directory that can be committed straight to GitHub Pages.

How the package reaches the browser
-----------------------------------
Junoview used to be one module, and the loader simply fetched
``semantic_render.py`` and imported it. A package cannot ship that way, so
:func:`build_web` writes the application HTML ahead of time and a parsing
worker hands ``junoview.zip`` to Pyodide's ``unpackArchive``. Both ``import``
and :mod:`importlib.resources` work from a
zip, so the CSS/JS/HTML assets load exactly as they do on disk -- and it stays
one HTTP request, as the single file was.
"""

from __future__ import annotations

import base64
import hashlib
import html
import json
import re
import zipfile
from importlib.metadata import PackageNotFoundError, files
from pathlib import Path

from . import assets
from ._write import write_text
from .branding import LOGO_SVG
from .notebook.loader import stem_for
from .notebook.parser import parse_notebook
from .notebook.pptx_read import read_pptx_b64
from .notebook.sources import doc_from_bytes, doc_from_text
from .render.page import has_marked_math, render_page, render_shell
from .render.static import static_files

# A fixed timestamp for every zip member. Without it the archive's bytes change
# on every build, and the committed docs/ Pages build would show a diff each
# time whether or not anything in it actually changed.
_ZIP_EPOCH = (1980, 1, 1, 0, 0, 0)
_LEGAL_FILES = ("LICENSE", "NOTICE")


def web_parse(name: str, text: str, taken_json: str = "[]") -> str:
    """Bridge for the Pyodide build: one dropped file's text -> shell HTML.

    Dispatches through the same producer table the CLI uses, so a
    ``.tex``, a ``.md`` or a ``.csv`` dropped on the web build opens the
    way it does locally -- with no JavaScript parser to keep in step
    (T91).
    """
    doc = doc_from_text(name, text)
    return _web_finish(doc, name, taken_json)


def web_parse_b64(name: str, b64: str, taken_json: str = "[]") -> str:
    """The binary half of the bridge (T113): a dropped .xlsx arrives as
    base64 because a workbook has no text to hand over."""
    doc = doc_from_bytes(name, base64.b64decode(b64))
    return _web_finish(doc, name, taken_json)


def web_import_pptx_b64(name: str, b64: str) -> str:
    """A PowerPoint deck dropped on the web build (T320): the reader's
    answer -- the editor's own item spec plus what was lost -- as JSON,
    for the deck's specToPres. The same function the app's
    ``/api/importpptx`` calls, so the two doors cannot drift."""
    return json.dumps(read_pptx_b64(name, b64), ensure_ascii=False)


def _web_finish(doc, name: str, taken_json: str) -> str:
    base = re.sub(r"\.[A-Za-z0-9]+$", "", str(name)) or "notebook"
    doc.source_name = stem_for(Path(base + ".ipynb"),
                                set(json.loads(taken_json)))
    return render_shell(doc)


def _is_shipped(path: Path) -> bool:
    """Ship source and assets; skip build leftovers."""
    return (path.is_file()
            and "__pycache__" not in path.parts
            and path.suffix not in (".pyc", ".pyo"))


def _legal_text(name: str) -> str:
    """Read a legal file from a checkout or an installed distribution."""
    root = Path(__file__).resolve().parent
    candidate = root.parents[1] / name
    if candidate.is_file():
        return candidate.read_text(encoding="utf-8")
    try:
        dist_files = files("junoview") or ()
    except PackageNotFoundError:
        dist_files = ()
    for item in dist_files:
        if item.name == name:
            candidate = Path(item.locate())
            if candidate.is_file():
                return candidate.read_text(encoding="utf-8")
    raise FileNotFoundError(f"Junoview distribution has no {name}")


def bundle_package(dest: Path) -> Path:
    """Zip this package so Pyodide can unpack and import it whole.

    Written deterministically -- members sorted, timestamps fixed -- so an
    unchanged package always produces byte-identical output.
    """
    root = Path(__file__).resolve().parent
    dest.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as archive:
        for path in sorted(p for p in root.rglob("*") if _is_shipped(p)):
            arcname = Path("junoview") / path.relative_to(root)
            info = zipfile.ZipInfo(arcname.as_posix(), date_time=_ZIP_EPOCH)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
        for name in _LEGAL_FILES:
            info = zipfile.ZipInfo(name, date_time=_ZIP_EPOCH)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, _legal_text(name).encode("utf-8"))
    return dest


def find_example() -> Path | None:
    """Locate the bundled example notebook, if this is a source checkout.

    Installed from a wheel there is nothing to find and the web build simply
    ships without a demo -- which is what it did before this was a package too.
    """
    name = "example_climate_analysis.ipynb"
    here = Path(__file__).resolve().parent
    bases = [*here.parents[1:3], Path.cwd()]
    for base in bases:
        for candidate in (base / "examples" / name, base / name):
            if candidate.exists():
                return candidate
    return None


def find_gifs() -> Path | None:
    """Locate the demo GIFs the help overlay and welcome tour link to.

    They are ~23 MB, so they are not package data -- too big to put in a wheel
    for a feature that degrades cleanly without them. The page probes for one
    and hides the whole demo section if it 404s, so an install with no GIFs
    shows no broken frames; it just doesn't offer the reel.
    """
    here = Path(__file__).resolve().parent
    for base in [*here.parents[1:3], Path.cwd()]:
        for candidate in (base / "docs" / "gifs", base / "gifs"):
            if candidate.is_dir() and any(candidate.glob("*.gif")):
                return candidate
    return None


#: A file _write_static_files wrote: <stem>.<16 hex>.<css|js>. Only names
#: of exactly this shape are ever removed from a build directory.
_HASHED_ASSET = re.compile(
    r"^(core|app|deck|icons|pptx)\.[0-9a-f]{16}\.(css|js)$")

#: The example notebook as build_web renders it: the one URL the page
#: opens it by, and the file the rendering is written to (with the hash
#: of its content, like the assets -- see :func:`_write_example_shell`).
EXAMPLE_URL = "example_climate_analysis.ipynb"
_EXAMPLE_SHELL = re.compile(
    r"^example_climate_analysis\.shell\.[0-9a-f]{16}\.html$")

#: A name earlier builds wrote and this one no longer does: the page
#: carries its runtime inline now. Removed like a stale hashed asset, so
#: a rebuilt docs/ does not keep a file nothing loads.
_RETIRED = ("web-runtime.js",)


def _write_static_files(outdir: Path) -> list[str]:
    """Write the page's content-hashed CSS/JS beside it; return the names.

    A rebuild with changed assets writes new names, so the previous
    build's files are removed here -- otherwise a committed docs/ would
    collect every version ever deployed.
    """
    files = static_files()
    keep = {f.name for f in files}
    for old in outdir.iterdir():
        if _HASHED_ASSET.match(old.name) and old.name not in keep:
            old.unlink()
    for f in files:
        target = outdir / f.name
        if not target.exists() or target.read_bytes() != f.data:
            target.write_bytes(f.data)
    return [f.name for f in files]


def _copy_gifs(outdir: Path) -> bool:
    """Put the demo GIFs beside the page; say whether there are any.

    The help overlay and welcome tour link to gifs/ relative to the page,
    so a build into a fresh directory needs them copied across; without
    this the demo reel silently never appears anywhere but the repo's own
    docs/. The answer is stamped into the page (``web.demos``), which is
    how it knows to offer the reel: it used to find out by downloading a
    317 KB clip at startup (2026-10-09 speed pass, load-static #10).
    """
    gifs = find_gifs()
    dest = outdir / "gifs"
    if gifs and gifs.resolve() != dest.resolve():
        dest.mkdir(exist_ok=True)
        for gif in sorted(gifs.glob("*.gif")):
            target = dest / gif.name
            if not target.exists() or target.stat().st_size != gif.stat().st_size:
                target.write_bytes(gif.read_bytes())
    return dest.is_dir() and any(dest.glob("*.gif"))


def _write_example_shell(outdir: Path, text: str) -> dict[str, object] | None:
    """The example notebook, rendered now: what "Try the example" mounts.

    It used to fetch the notebook and wait for Python -- downloaded and
    started in the visitor's browser just for this -- to parse it: 4.1 s
    from the click to the first card at 4x CPU on localhost, 13.8 s from
    arriving on a 9 Mbps link (2026-10-09 speed pass, load-static #2).
    Rendered here instead, by the very function the browser's worker
    calls (``web_parse``, nothing else taken), it is the same markup
    byte for byte, and the page mounts it with no Python at all.

    The file is named for its content, like the page's other files: a
    copy cached anywhere is final, and a new rendering is a new name. The
    previous build's copy is removed. Returns what the page is told (the
    file, the tab name it makes, whether it holds maths), or None if it
    cannot be rendered -- the page then opens the example through Python,
    as it always did.
    """
    try:
        shell = web_parse(EXAMPLE_URL, text, "[]")
    except Exception:
        shell = ""
    stem = re.search(r'data-nb="([^"]+)"', shell)
    data = shell.encode("utf-8")
    name = ("example_climate_analysis.shell."
            f"{hashlib.sha256(data).hexdigest()[:16]}.html")
    for old in outdir.iterdir():
        if _EXAMPLE_SHELL.match(old.name) and (old.name != name or not stem):
            old.unlink()
    if not stem:
        return None
    target = outdir / name
    if not target.exists() or target.read_bytes() != data:
        target.write_bytes(data)
    info: dict[str, object] = {"shell": name,
                               "stem": html.unescape(stem.group(1))}
    if has_marked_math(shell):
        info["math"] = 1
    return info


def service_worker(version: str, core: list[str], warm: list[str]) -> str:
    """sw.js for this build: its version, and the names of the files it
    wrote that the worker keeps -- ``core`` at install (the page's own
    files), ``warm`` with the runtime once Python is up (the example:
    its rendering, and the notebook for when Python has to open it).

    Version-stamped with the package hash (token replace, NOT str.format
    -- the JS is full of braces) so a new build retires the old cache
    while an unchanged package produces byte-identical output, same as
    the zip itself. The names are ones this build wrote (letters, digits,
    dots), so they need no escaping inside the quotes.
    """
    return assets.sw_js().replace("__JV_VERSION__", version).replace(
        "/*__JV_ASSETS__*/", "".join(f", '{name}'" for name in core)).replace(
        "/*__JV_WARM__*/", "".join(f", '{name}'" for name in warm))


def build_web(outdir: Path, example: Path | None = None) -> None:
    """Write a deployable static web app (index.html + the packaged renderer)."""
    outdir.mkdir(parents=True, exist_ok=True)
    zip_path = bundle_package(outdir / "junoview.zip")
    # the package hash is the build's name: the worker's cache key, and
    # the stamp the loader shows so a screenshot can say which build it
    # is (T206 -- three stale-build screenshots in one day)
    version = hashlib.md5(zip_path.read_bytes()).hexdigest()[:12]

    # What the page is told about this build: whether the demo reel's
    # clips are here, and which notebooks it can open already rendered.
    web: dict[str, object] = {"demos": 1 if _copy_gifs(outdir) else 0}
    pre: dict[str, dict[str, object]] = {}
    # what the service worker keeps with the runtime once Python is up
    warm: list[str] = []
    # bundle the example so "Try the example notebook" works same-origin
    example = example or find_example()
    if example and example.exists():
        (outdir / EXAMPLE_URL).write_bytes(example.read_bytes())
        shell = _write_example_shell(
            outdir, example.read_text(encoding="utf-8"))
        if shell:
            pre[EXAMPLE_URL] = shell
            warm.append(str(shell["shell"]))
        # ...and the notebook itself: with another document open under
        # its name, "Try the example" goes through Python (webOpenUrl),
        # which fetches this -- offline, the worker's copy is the only one
        warm.append(EXAMPLE_URL)
        # also render an INSTANT static demo (no Pyodide load, no install) —
        # a hosted, clickable "live demo above the fold"
        try:
            doc = parse_notebook(json.loads(
                example.read_text(encoding="utf-8")))
            doc.source_name = "example_climate_analysis"
            write_text(outdir / "example_climate_analysis.html",
                       render_page([doc], mode="static"))
        except Exception:
            pass
    web["pre"] = pre

    # Build the empty app here, where Python is already running. The
    # browser can show it immediately while its worker loads the parser.
    # Its stylesheets and scripts are files beside it, named for their
    # content (render/static.py): inline, they were 4.2 MB of index.html
    # that every visit re-tokenised and recompiled on the main thread,
    # because an inline script gets no code cache -- so a repeat visit
    # was barely faster than the first (2026-10-08 speed investigation).
    page = render_page([], mode="web", app_cfg={"web": web}, asset_base="")
    assets_out = _write_static_files(outdir)
    head = assets.web_loader().split("<head>", 1)[1].split("</head>", 1)[0]
    page = re.sub(r"<title>.*?</title>", "", page, count=1, flags=re.S)
    page = page.replace("<head>", "<head>\n" + head, 1)
    # The bridge to the parsing worker goes IN the page: as a file of its
    # own it was a parser-blocking request in <head>, a round trip before
    # the body could even start (load-static #11). It holds no "</".
    runtime = assets.load("js/web-runtime.js").replace(
        "__JV_VERSION__", version)
    if "</" in runtime:
        raise ValueError("web-runtime.js cannot be inlined: it holds '</'")
    page = page.replace("</head>",
                        f'<meta name="junoview-build" content="{version}">\n'
                        f"<script>{runtime}</script>\n</head>", 1)
    write_text(outdir / "index.html", page)
    write_text(outdir / "web-worker.js", assets.load(
        "js/web-worker.js").replace("__JV_VERSION__", version))
    for name in _RETIRED:
        stale = outdir / name
        if stale.is_file():
            stale.unlink()
    write_text(outdir / ".nojekyll", "")
    for name in _LEGAL_FILES:
        write_text(outdir / name, _legal_text(name))
    write_text(outdir / "THIRD_PARTY_NOTICES.html",
               assets.third_party_notices())

    # The offline, installable app: a service worker plus a manifest turn
    # the page into a PWA -- one visit caches the app, the Pyodide runtime
    # and MathJax, after which it loads with no internet and the browser
    # offers "Install app".
    write_text(outdir / "sw.js", service_worker(version, assets_out, warm))
    manifest = {
        "name": "Junoview",
        "short_name": "Junoview",
        "description": "Figure-first Jupyter notebook viewer and "
                       "presentation builder — runs entirely in your "
                       "browser, notebooks never leave your machine.",
        "start_url": "./",
        "scope": "./",
        "display": "standalone",
        "background_color": "#0a141d",
        "theme_color": "#0a141d",
        "icons": [{"src": "icon.svg", "sizes": "any",
                   "type": "image/svg+xml", "purpose": "any"}],
    }
    write_text(outdir / "manifest.webmanifest",
               json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    write_text(outdir / "icon.svg", LOGO_SVG + "\n")
